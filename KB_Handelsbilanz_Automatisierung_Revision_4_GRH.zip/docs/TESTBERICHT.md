# Testbericht – Revision 4

Stand: 17.07.2026

## Ergebnis

- 16 von 16 automatisierten Tests erfolgreich.
- GRH umfasst 22 Regeln; das Gesamtprojekt umfasst 183 Regeln.
- GRH J33 wird separat berechnet und ausgegeben.
- Normale GRH-Kennzahlen schließen `SubsidiaryCode = 401` aus.
- GRH-Geschäftsführer J45/J46 werden über `SubsidiaryCode = 401` erkannt.
- MRP-ClientEEIDs werden weiterhin aus J15/J16 ausgeschlossen und in J56 eingeschlossen; bei J21/J22 erfolgt kein MRP-Ausschluss mehr.
- End-to-End-Erstellung der Excel-Ausgabe erfolgreich.
- Alle referenzierten Regelsets vorhanden.
- Zielzeilen je Gesellschaft eindeutig.
- Windows-BAT-Dateien weiterhin geprüft:
  - ausschließlich CRLF-Zeilenumbrüche,
  - kein UTF-8-BOM,
  - ASCII-kompatible Befehle und Meldungen,
  - vollständige `echo`- und Python-Startbefehle.
- ZIP-Integritätsprüfung erfolgreich.

## Windows-Startfix

Der in Revision 3 behobene Startfehler bleibt korrigiert. Alle BAT-Dateien werden weiterhin im echten Windows-CRLF-Format ausgeliefert.
