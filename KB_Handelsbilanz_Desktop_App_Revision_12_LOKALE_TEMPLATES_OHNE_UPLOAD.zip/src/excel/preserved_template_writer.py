from __future__ import annotations

"""Template-preserving Excel output.

Revision 12 deliberately treats the customer's local workbooks as the source of
truth for layout.  The template is copied first and only report text, dates and
result values are changed.  Column widths, row heights, merges, logos, page
breaks, print areas and all other workbook formatting remain in the template.
"""

from collections import OrderedDict
from copy import copy
from datetime import datetime
import logging
from pathlib import Path
import re
import shutil
import sys
from typing import Any, Iterable

from openpyxl import load_workbook
from openpyxl.styles import Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from core.config_loader import RuleConfig
from core.models import CompanyResult, MetricResult, SourceDataset
from excel.template_writer import (
    BASE_SHEETS,
    COMPANY_HEADER_CODES,
    COMPANY_NAMES,
    COUNT_FORMAT,
    MONEY_FORMAT,
    NEGATIVE_FILL,
    NEGATIVE_FONT,
    OUTPUT_LABELS,
    POSITIVE_FILL,
    POSITIVE_FONT,
    SECTION_CAPTIONS,
    SECTION_CODE_FALLBACKS,
    SHEET_ALIASES,
    _date_from_path,
    _normalise_text,
)

LOGGER = logging.getLogger("kb.template.preserve")
THIN = Side(style="thin", color="000000")
MEDIUM = Side(style="medium", color="000000")


def _metric_map(metrics: Iterable[MetricResult] | None) -> dict[int, MetricResult]:
    return {metric.target_row: metric for metric in metrics or []}


def _group_metrics(metrics: list[MetricResult]) -> OrderedDict[str, list[MetricResult]]:
    groups: OrderedDict[str, list[MetricResult]] = OrderedDict()
    for metric in metrics:
        groups.setdefault(metric.section, []).append(metric)
    return groups


def _section_caption(company: str, section: str) -> str:
    if company == "AG" and section == "EZ – Geschäftsführer":
        return "Einzelzusagen Vorstand"
    return SECTION_CAPTIONS.get(section, section)


def _capture_template_section_codes_openpyxl(ws) -> dict[str, str]:
    result: dict[str, str] = {}
    for row in range(8, ws.max_row + 1):
        code = ws.cell(row, 2).value
        caption = ws.cell(row, 3).value
        if code not in (None, "") and caption not in (None, ""):
            result[_normalise_text(caption)] = str(code)
    return result


def _find_captured_code(captured: dict[str, str], caption: str) -> str | None:
    wanted = _normalise_text(caption)
    if wanted in captured:
        return captured[wanted]
    for key, code in captured.items():
        if len(wanted) >= 8 and len(key) >= 8 and (wanted in key or key in wanted):
            return code
    return None


def _section_code(company: str, section: str, caption: str, captured: dict[str, str]) -> str:
    captured_code = _find_captured_code(captured, caption)
    if captured_code is not None and company != "GRH":
        return captured_code
    return SECTION_CODE_FALLBACKS.get(company, {}).get(section, captured_code or "")


def _report_rows(result: CompanyResult) -> tuple[OrderedDict[str, list[MetricResult]], dict[str, int], dict[str, int | None], int]:
    groups = _group_metrics(result.current)
    section_rows: dict[str, int] = {}
    total_rows: dict[str, int | None] = {}
    max_metric = 8
    for section, metrics in groups.items():
        rows = sorted(metric.target_row for metric in metrics)
        section_rows[section] = max(8, rows[0] - 2)
        total_rows[section] = rows[-1] + 1 if len(rows) > 1 else None
        max_metric = max(max_metric, rows[-1])
    # Prefer the conventional two-row gap after the final metric/total.  If the
    # actual template already has a Gesamtsumme row, it is retained later.
    grand_total = max_metric + 3
    return groups, section_rows, total_rows, grand_total


def _find_grand_total_row_openpyxl(ws) -> int | None:
    for row in range(8, ws.max_row + 1):
        for column in (2, 3, 4):
            if "gesamtsumme" in _normalise_text(ws.cell(row, column).value):
                return row
    return None


def _first_style_rows_openpyxl(ws) -> tuple[int, int, int, int]:
    section = 10
    metric = 12
    total = 16
    grand = _find_grand_total_row_openpyxl(ws) or max(1, ws.max_row)
    for row in range(8, ws.max_row + 1):
        if ws.cell(row, 2).value not in (None, "") and ws.cell(row, 3).value not in (None, ""):
            section = row
            break
    for row in range(8, ws.max_row + 1):
        if ws.cell(row, 4).value not in (None, ""):
            metric = row
            break
    for row in range(metric + 1, ws.max_row + 1):
        if any(ws.cell(row, col).border.bottom.style for col in (6, 8, 10, 12, 14)):
            total = row
            break
    return section, metric, total, grand


def _row_has_format_openpyxl(ws, row: int, max_column: int = 14) -> bool:
    return any(ws.cell(row, col).has_style for col in range(1, max_column + 1))


def _copy_row_format_openpyxl(ws, source_row: int, target_row: int, max_column: int = 14) -> None:
    if source_row == target_row:
        return
    for col in range(1, max_column + 1):
        source = ws.cell(source_row, col)
        target = ws.cell(target_row, col)
        if source.has_style:
            target._style = copy(source._style)
        target.number_format = source.number_format
        target.alignment = copy(source.alignment)
        target.protection = copy(source.protection)
    ws.row_dimensions[target_row].height = ws.row_dimensions[source_row].height
    ws.row_dimensions[target_row].hidden = False


def _ensure_row_format_openpyxl(ws, target_row: int, source_row: int) -> None:
    if not _row_has_format_openpyxl(ws, target_row):
        _copy_row_format_openpyxl(ws, source_row, target_row)


def _clear_value_columns_openpyxl(ws, start_row: int, end_row: int) -> None:
    for row in range(start_row, end_row + 1):
        for column in (6, 8, 10, 12, 14):
            ws.cell(row, column).value = None


def _set_total_cell_openpyxl(cell, value: float | int, is_count: bool) -> None:
    cell.value = value
    font = copy(cell.font)
    cell.font = Font(
        name=font.name or "Arial",
        size=font.sz or 10,
        bold=True,
        italic=font.italic,
        color=font.color,
    )
    cell.number_format = COUNT_FORMAT if is_count else MONEY_FORMAT
    cell.border = Border(
        left=copy(cell.border.left),
        right=copy(cell.border.right),
        top=THIN,
        bottom=MEDIUM,
    )


def _write_metric_openpyxl(ws, metric: MetricResult, previous: MetricResult | None, with_previous: bool) -> None:
    row = metric.target_row
    ws.cell(row, 4).value = metric.label
    if with_previous:
        previous_value = previous.value if previous else 0
        previous_count = previous.employee_count if previous else 0
        difference = metric.value - previous_value
        values = {6: previous_value, 8: previous_count, 10: metric.value, 12: difference, 14: metric.employee_count}
        for col, value in values.items():
            ws.cell(row, col).value = value
            ws.cell(row, col).number_format = COUNT_FORMAT if col in {8, 14} else MONEY_FORMAT
        fill = POSITIVE_FILL if difference >= 0 else NEGATIVE_FILL
        font = POSITIVE_FONT if difference >= 0 else NEGATIVE_FONT
        for col in (10, 12, 14):
            ws.cell(row, col).fill = copy(fill)
            ws.cell(row, col).font = copy(font)
    else:
        ws.cell(row, 6).value = metric.value
        ws.cell(row, 8).value = metric.employee_count
        ws.cell(row, 6).number_format = MONEY_FORMAT
        ws.cell(row, 8).number_format = COUNT_FORMAT


def _write_section_total_openpyxl(
    ws,
    total_row: int,
    metrics: list[MetricResult],
    previous_map: dict[int, MetricResult],
    with_previous: bool,
) -> None:
    current_value = sum(item.value for item in metrics)
    current_count = sum(item.employee_count for item in metrics)
    if with_previous:
        previous_items = [previous_map.get(item.target_row) for item in metrics]
        previous_value = sum(item.value for item in previous_items if item)
        previous_count = sum(item.employee_count for item in previous_items if item)
        values = {6: previous_value, 8: previous_count, 10: current_value, 12: current_value - previous_value, 14: current_count}
    else:
        values = {6: current_value, 8: current_count}
    for col, value in values.items():
        _set_total_cell_openpyxl(ws.cell(total_row, col), value, col in {8, 14})


def _set_header_openpyxl(ws, output_type: str, current_date: str, previous_date: str | None) -> None:
    title = f"Entwicklung der Pensionsrückstellungen {current_date} - {OUTPUT_LABELS[output_type]}"
    ws["C2"] = title
    if previous_date:
        ws["F4"] = "Rückstellung per"
        ws["F5"] = previous_date
        ws["F6"] = "€"
        ws["H4"] = "Anzahl"
        ws["H5"] = "Berechtigte"
        ws["J4"] = "Rückstellung per"
        ws["J5"] = current_date
        ws["J6"] = "€"
        ws["L4"] = "Zuführung"
        ws["L6"] = "€"
        ws["N4"] = "Anzahl"
        ws["N5"] = "Berechtigte"
        for col in range(6, 15):
            ws.column_dimensions[get_column_letter(col)].hidden = False
    else:
        ws["F4"] = "Rückstellung per"
        ws["F5"] = current_date
        ws["F6"] = "€"
        ws["H4"] = "Anzahl"
        ws["H5"] = "Berechtigte"
        for col in range(9, 15):
            ws.column_dimensions[get_column_letter(col)].hidden = True


def _remove_external_links_openpyxl(workbook) -> None:
    try:
        workbook._external_links = []
    except Exception:
        pass
    try:
        for key in list(workbook.defined_names):
            formula = str(workbook.defined_names[key].attr_text or "")
            if "[" in formula or "Rechenlauf" in formula:
                del workbook.defined_names[key]
    except Exception:
        pass


def _prepare_sheet_openpyxl(
    ws,
    result: CompanyResult,
    company_config: dict[str, Any],
    output_type: str,
    current_date: str,
    previous_date: str | None,
    generic_clone: bool,
) -> None:
    groups, section_rows, total_rows, calculated_grand = _report_rows(result)
    existing_grand = _find_grand_total_row_openpyxl(ws)
    grand_row = max(calculated_grand, existing_grand or 0)
    max_needed = max(ws.max_row, grand_row + 1, max((m.target_row for m in result.current), default=8) + 2)
    captured = _capture_template_section_codes_openpyxl(ws)
    style_section, style_metric, style_total, style_grand = _first_style_rows_openpyxl(ws)

    _set_header_openpyxl(ws, output_type, current_date, previous_date)
    _clear_value_columns_openpyxl(ws, 8, max_needed)
    if generic_clone:
        for row in range(8, max_needed + 1):
            for col in (2, 3, 4):
                ws.cell(row, col).value = None

    company = result.company
    ws["B8"] = COMPANY_HEADER_CODES.get(company, str(company_config.get("code", "")))
    ws["C8"] = COMPANY_NAMES.get(company, company)

    previous_map = _metric_map(result.previous)
    for section, metrics in groups.items():
        section_row = section_rows[section]
        _ensure_row_format_openpyxl(ws, section_row, style_section)
        caption = _section_caption(company, section)
        ws.cell(section_row, 2).value = _section_code(company, section, caption, captured)
        ws.cell(section_row, 3).value = caption
        for metric in metrics:
            _ensure_row_format_openpyxl(ws, metric.target_row, style_metric)
            _write_metric_openpyxl(ws, metric, previous_map.get(metric.target_row), previous_date is not None)
        total_row = total_rows[section]
        if total_row:
            _ensure_row_format_openpyxl(ws, total_row, style_total)
            _write_section_total_openpyxl(ws, total_row, metrics, previous_map, previous_date is not None)

    _ensure_row_format_openpyxl(ws, grand_row, style_grand)
    ws.cell(grand_row, 3).value = "Gesamtsumme:"
    _write_section_total_openpyxl(ws, grand_row, result.current, previous_map, previous_date is not None)

    print_end = "N" if previous_date else "H"
    ws.print_area = f"B1:{print_end}{grand_row}"
    ws.sheet_view.showGridLines = False
    ws.sheet_properties.tabColor = "70AD47"
    for col in (15, 16, 17):
        ws.column_dimensions[get_column_letter(col)].hidden = True


def _clone_sheet_openpyxl(workbook, source_name: str, target_name: str):
    source = workbook[source_name]
    clone = workbook.copy_worksheet(source)
    # openpyxl does not clone images when copying a sheet.
    for image in getattr(source, "_images", []):
        try:
            image_copy = copy(image)
            image_copy.anchor = copy(image.anchor)
            clone.add_image(image_copy)
        except Exception:
            continue
    clone.title = target_name
    return clone


def _write_openpyxl(
    destination: Path,
    template_path: Path,
    output_type: str,
    current_dataset: SourceDataset,
    previous_dataset: SourceDataset | None,
    company_results: list[CompanyResult],
    config: RuleConfig,
    generated_at: datetime,
) -> None:
    keep_vba = template_path.suffix.casefold() == ".xlsm"
    workbook = load_workbook(template_path, keep_vba=keep_vba, keep_links=False, data_only=False)
    try:
        selected = [result.company for result in company_results]
        generic_created: set[str] = set()
        for company in selected:
            if company in workbook.sheetnames:
                continue
            alias = SHEET_ALIASES.get(company)
            if alias and alias in workbook.sheetnames:
                workbook[alias].title = company
                continue
            if "Gesellschaft" in workbook.sheetnames:
                _clone_sheet_openpyxl(workbook, "Gesellschaft", company)
                generic_created.add(company)
                continue
            base = BASE_SHEETS.get(company, company)
            if base not in workbook.sheetnames:
                raise ValueError(
                    f"Das lokale Template enthält weder das Blatt {company!r}, "
                    f"noch 'Gesellschaft' oder die Basis {base!r}."
                )
            _clone_sheet_openpyxl(workbook, base, company)

        for ws in list(workbook.worksheets):
            if ws.title not in selected:
                workbook.remove(ws)

        current_date = _date_from_path(current_dataset.path, generated_at)
        previous_date = _date_from_path(previous_dataset.path, generated_at) if previous_dataset else None
        result_map = {result.company: result for result in company_results}
        for company in selected:
            _prepare_sheet_openpyxl(
                workbook[company],
                result_map[company],
                config.companies[company],
                output_type,
                current_date,
                previous_date,
                company in generic_created,
            )

        _remove_external_links_openpyxl(workbook)
        workbook._sheets = [workbook[name] for name in selected]
        workbook.active = 0
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_name(destination.stem + ".tmp" + destination.suffix)
        workbook.save(temporary)
        temporary.replace(destination)
    finally:
        workbook.close()


def _excel_color(hex_value: str) -> int:
    value = hex_value.lstrip("#")
    red = int(value[0:2], 16)
    green = int(value[2:4], 16)
    blue = int(value[4:6], 16)
    return red + green * 256 + blue * 65536


def _com_sheet(workbook, name: str):
    try:
        return workbook.Worksheets(name)
    except Exception:
        return None


def _com_normal_value(ws, row: int, col: int) -> str:
    try:
        return _normalise_text(ws.Cells(row, col).Value)
    except Exception:
        return ""


def _find_grand_total_row_com(ws, max_row: int) -> int | None:
    for row in range(8, max_row + 1):
        if any("gesamtsumme" in _com_normal_value(ws, row, col) for col in (2, 3, 4)):
            return row
    return None


def _capture_codes_com(ws, max_row: int) -> dict[str, str]:
    result: dict[str, str] = {}
    for row in range(8, max_row + 1):
        code = ws.Cells(row, 2).Value
        caption = ws.Cells(row, 3).Value
        if code not in (None, "") and caption not in (None, ""):
            result[_normalise_text(caption)] = str(code)
    return result


def _style_rows_com(ws, max_row: int) -> tuple[int, int, int, int]:
    section, metric, total = 10, 12, 16
    grand = _find_grand_total_row_com(ws, max_row) or max_row
    for row in range(8, max_row + 1):
        if ws.Cells(row, 2).Value not in (None, "") and ws.Cells(row, 3).Value not in (None, ""):
            section = row
            break
    for row in range(8, max_row + 1):
        if ws.Cells(row, 4).Value not in (None, ""):
            metric = row
            break
    # A conventional total row is usually directly after the first metric block.
    for row in range(metric + 1, max_row + 1):
        try:
            if ws.Cells(row, 6).Borders(9).LineStyle not in (0, None):
                total = row
                break
        except Exception:
            continue
    return section, metric, total, grand


def _row_is_unformatted_com(ws, row: int) -> bool:
    try:
        return all(ws.Cells(row, col).Style == "Normal" for col in range(2, 15))
    except Exception:
        return False


def _copy_format_com(excel, ws, source_row: int, target_row: int) -> None:
    if source_row == target_row:
        return
    ws.Rows(source_row).Copy()
    ws.Rows(target_row).PasteSpecial(Paste=-4122)  # xlPasteFormats
    ws.Rows(target_row).RowHeight = ws.Rows(source_row).RowHeight
    excel.CutCopyMode = False


def _ensure_format_com(excel, ws, row: int, source_row: int) -> None:
    if _row_is_unformatted_com(ws, row):
        _copy_format_com(excel, ws, source_row, row)


def _set_total_border_com(cell) -> None:
    try:
        cell.Borders(8).LineStyle = 1
        cell.Borders(8).Weight = 2
        cell.Borders(9).LineStyle = 1
        cell.Borders(9).Weight = -4138
    except Exception:
        pass


def _break_external_links_com(workbook) -> None:
    try:
        sources = workbook.LinkSources(1)  # xlLinkTypeExcelLinks
    except Exception:
        sources = None
    if not sources:
        return
    try:
        for source in list(sources):
            workbook.BreakLink(Name=source, Type=1)
    except Exception:
        pass


def _set_header_com(ws, output_type: str, current_date: str, previous_date: str | None) -> None:
    ws.Range("C2").Value = f"Entwicklung der Pensionsrückstellungen {current_date} - {OUTPUT_LABELS[output_type]}"
    if previous_date:
        values = {
            "F4": "Rückstellung per", "F5": previous_date, "F6": "€",
            "H4": "Anzahl", "H5": "Berechtigte",
            "J4": "Rückstellung per", "J5": current_date, "J6": "€",
            "L4": "Zuführung", "L6": "€",
            "N4": "Anzahl", "N5": "Berechtigte",
        }
        for address, value in values.items():
            ws.Range(address).Value = value
        ws.Range("F:N").EntireColumn.Hidden = False
    else:
        values = {
            "F4": "Rückstellung per", "F5": current_date, "F6": "€",
            "H4": "Anzahl", "H5": "Berechtigte",
        }
        for address, value in values.items():
            ws.Range(address).Value = value
        ws.Range("I:N").EntireColumn.Hidden = True


def _write_metric_com(ws, metric: MetricResult, previous: MetricResult | None, with_previous: bool) -> None:
    row = metric.target_row
    ws.Cells(row, 4).Value = metric.label
    if with_previous:
        previous_value = previous.value if previous else 0
        previous_count = previous.employee_count if previous else 0
        difference = metric.value - previous_value
        values = {6: previous_value, 8: previous_count, 10: metric.value, 12: difference, 14: metric.employee_count}
        for col, value in values.items():
            ws.Cells(row, col).Value = value
            ws.Cells(row, col).NumberFormat = "0" if col in {8, 14} else "#,##0;[Red]-#,##0"
        color = _excel_color("92D050" if difference >= 0 else "C00000")
        font_color = _excel_color("000000" if difference >= 0 else "FFFFFF")
        ws.Range(ws.Cells(row, 10), ws.Cells(row, 14)).Interior.Color = color
        ws.Range(ws.Cells(row, 10), ws.Cells(row, 14)).Font.Color = font_color
    else:
        ws.Cells(row, 6).Value = metric.value
        ws.Cells(row, 8).Value = metric.employee_count
        ws.Cells(row, 6).NumberFormat = "#,##0;[Red]-#,##0"
        ws.Cells(row, 8).NumberFormat = "0"


def _write_total_com(ws, row: int, metrics: list[MetricResult], previous_map: dict[int, MetricResult], with_previous: bool) -> None:
    current_value = sum(item.value for item in metrics)
    current_count = sum(item.employee_count for item in metrics)
    if with_previous:
        previous_items = [previous_map.get(item.target_row) for item in metrics]
        previous_value = sum(item.value for item in previous_items if item)
        previous_count = sum(item.employee_count for item in previous_items if item)
        values = {6: previous_value, 8: previous_count, 10: current_value, 12: current_value - previous_value, 14: current_count}
    else:
        values = {6: current_value, 8: current_count}
    for col, value in values.items():
        cell = ws.Cells(row, col)
        cell.Value = value
        cell.Font.Bold = True
        cell.NumberFormat = "0" if col in {8, 14} else "#,##0;[Red]-#,##0"
        _set_total_border_com(cell)


def _write_com(
    destination: Path,
    template_path: Path,
    output_type: str,
    current_dataset: SourceDataset,
    previous_dataset: SourceDataset | None,
    company_results: list[CompanyResult],
    config: RuleConfig,
    generated_at: datetime,
) -> None:
    import pythoncom  # type: ignore[import-not-found]
    import win32com.client  # type: ignore[import-not-found]

    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(template_path, destination)
    pythoncom.CoInitialize()
    excel = None
    workbook = None
    try:
        excel = win32com.client.DispatchEx("Excel.Application")
        excel.Visible = False
        excel.DisplayAlerts = False
        excel.ScreenUpdating = False
        workbook = excel.Workbooks.Open(
            str(destination.resolve()),
            UpdateLinks=0,
            ReadOnly=False,
            IgnoreReadOnlyRecommended=True,
        )
        _break_external_links_com(workbook)
        selected = [result.company for result in company_results]
        generic_created: set[str] = set()
        for company in selected:
            if _com_sheet(workbook, company) is not None:
                continue
            alias = SHEET_ALIASES.get(company)
            if alias and _com_sheet(workbook, alias) is not None:
                workbook.Worksheets(alias).Name = company
                continue
            generic = _com_sheet(workbook, "Gesellschaft")
            if generic is not None:
                generic.Copy(After=workbook.Worksheets(workbook.Worksheets.Count))
                workbook.Worksheets(workbook.Worksheets.Count).Name = company
                generic_created.add(company)
                continue
            base = BASE_SHEETS.get(company, company)
            source = _com_sheet(workbook, base)
            if source is None:
                raise ValueError(
                    f"Das lokale Template enthält weder das Blatt {company!r}, "
                    f"noch 'Gesellschaft' oder die Basis {base!r}."
                )
            source.Copy(After=workbook.Worksheets(workbook.Worksheets.Count))
            workbook.Worksheets(workbook.Worksheets.Count).Name = company

        for index in range(workbook.Worksheets.Count, 0, -1):
            if workbook.Worksheets(index).Name not in selected:
                workbook.Worksheets(index).Delete()

        current_date = _date_from_path(current_dataset.path, generated_at)
        previous_date = _date_from_path(previous_dataset.path, generated_at) if previous_dataset else None
        result_map = {result.company: result for result in company_results}

        for company in selected:
            ws = workbook.Worksheets(company)
            result = result_map[company]
            groups, section_rows, total_rows, calculated_grand = _report_rows(result)
            max_metric = max((item.target_row for item in result.current), default=8)
            used_max = max(int(ws.UsedRange.Rows.Count), calculated_grand + 1, max_metric + 2)
            existing_grand = _find_grand_total_row_com(ws, used_max)
            grand_row = max(calculated_grand, existing_grand or 0)
            captured = _capture_codes_com(ws, used_max)
            style_section, style_metric, style_total, style_grand = _style_rows_com(ws, used_max)

            _set_header_com(ws, output_type, current_date, previous_date)
            for col in (6, 8, 10, 12, 14):
                ws.Range(ws.Cells(8, col), ws.Cells(used_max, col)).ClearContents()
            if company in generic_created:
                ws.Range(ws.Cells(8, 2), ws.Cells(used_max, 4)).ClearContents()

            ws.Range("B8").Value = COMPANY_HEADER_CODES.get(company, str(config.companies[company].get("code", "")))
            ws.Range("C8").Value = COMPANY_NAMES.get(company, company)

            previous_map = _metric_map(result.previous)
            for section, metrics in groups.items():
                section_row = section_rows[section]
                _ensure_format_com(excel, ws, section_row, style_section)
                caption = _section_caption(company, section)
                ws.Cells(section_row, 2).Value = _section_code(company, section, caption, captured)
                ws.Cells(section_row, 3).Value = caption
                for metric in metrics:
                    _ensure_format_com(excel, ws, metric.target_row, style_metric)
                    _write_metric_com(ws, metric, previous_map.get(metric.target_row), previous_date is not None)
                total_row = total_rows[section]
                if total_row:
                    _ensure_format_com(excel, ws, total_row, style_total)
                    _write_total_com(ws, total_row, metrics, previous_map, previous_date is not None)

            _ensure_format_com(excel, ws, grand_row, style_grand)
            ws.Cells(grand_row, 3).Value = "Gesamtsumme:"
            _write_total_com(ws, grand_row, result.current, previous_map, previous_date is not None)

            print_end = "N" if previous_date else "H"
            try:
                ws.PageSetup.PrintArea = f"$B$1:${print_end}${grand_row}"
                ws.PageSetup.Zoom = False
                ws.PageSetup.FitToPagesWide = 1
                ws.PageSetup.FitToPagesTall = False
            except Exception:
                pass
            try:
                ws.Range("O:Q").EntireColumn.Hidden = True
                ws.Activate()
                excel.ActiveWindow.DisplayGridlines = False
            except Exception:
                pass

        workbook.Worksheets(selected[0]).Activate()
        workbook.Save()
    finally:
        if workbook is not None:
            try:
                workbook.Close(SaveChanges=True)
            except Exception:
                pass
        if excel is not None:
            try:
                excel.Quit()
            except Exception:
                pass
        pythoncom.CoUninitialize()


def write_template_workbook_preserving_layout(
    destination: Path,
    template_path: Path,
    output_type: str,
    current_dataset: SourceDataset,
    previous_dataset: SourceDataset | None,
    company_results: list[CompanyResult],
    config: RuleConfig,
    generated_at: datetime,
) -> None:
    """Copy the selected local template and fill it without rebuilding layout."""
    if sys.platform == "win32":
        try:
            _write_com(
                destination,
                template_path,
                output_type,
                current_dataset,
                previous_dataset,
                company_results,
                config,
                generated_at,
            )
            return
        except Exception as exc:
            LOGGER.warning("Excel-COM-Ausgabe fehlgeschlagen; verwende layouttreuen OpenPyXL-Modus: %s", exc)
            if destination.exists():
                try:
                    destination.unlink()
                except OSError:
                    pass

    _write_openpyxl(
        destination,
        template_path,
        output_type,
        current_dataset,
        previous_dataset,
        company_results,
        config,
        generated_at,
    )
