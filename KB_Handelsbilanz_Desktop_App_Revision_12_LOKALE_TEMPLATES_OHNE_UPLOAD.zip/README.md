# KB Handelsbilanz Desktop App – Revision 12

Revision 12 verwendet die beiden lokalen Excel-Templates direkt als unveränderte Layoutbasis. Ein Upload der Templates ist nicht erforderlich.

## Automatische Template-Auswahl

Ohne ausgewählte Vorjahresdatei:

```text
data\samples\Knorr_Bremse_ICT_template_ohne_VJ.xlsx
```

Mit ausgewählter Vorjahresdatei:

```text
data\samples\Knorr_Bremse_ICT_template_mit_VJ.xlsx
```

Auch `.xlsm` wird unterstützt. Die Dateiendung muss in `config/template_settings.json` nicht eingetragen werden.

Das Template **ohne Vorjahr** darf ein einziges generisches Blatt namens `Gesellschaft` enthalten. Dieses Blatt wird für jede ausgewählte Gesellschaft kopiert und ausschließlich an den festen Zielzeilen der Regeln befüllt. Das Layout wird nicht mehr neu aufgebaut.

Das Template **mit Vorjahr** kann bereits eigene Gesellschaftsblätter wie `SFN`, `SFS`, `AG`, `KBM`, `HW`, `IT` und `Steering` enthalten. Vorhandene Gesellschaftsblätter werden bevorzugt. Für `GRH` wird weiterhin das SFS-Blatt als Layoutbasis verwendet, sofern kein eigenes GRH-Blatt vorhanden ist.

## Start

Erster Start:

```text
INSTALLIEREN_UND_STARTEN.bat
```

Danach:

```text
STARTEN.bat
```

Der normale Start verwendet `pythonw.exe`; hinter der App bleibt kein Terminalfenster geöffnet. Für Diagnosen steht `STARTEN_MIT_TERMINAL.bat` zur Verfügung.

## Output

Der erzeugte Bericht enthält derzeit ausschließlich die ausgewählten Gesellschaftsblätter. `Gesellschaft`, `Rechenlauf`, `Summe`, `BilMoG` und nicht ausgewählte Blätter werden aus der Ergebnisdatei entfernt.

Weitere Details: `docs/TEMPLATE_LOKAL_OHNE_UPLOAD_REVISION_12.md`


## Template-Diagnose ohne Upload

Mit `TEMPLATES_PRUEFEN.bat` wird lokal `logs\template_diagnose.json` erzeugt. Damit lässt sich die erkannte Blatt- und Zeilenstruktur prüfen, ohne die Excel-Dateien hochzuladen.
