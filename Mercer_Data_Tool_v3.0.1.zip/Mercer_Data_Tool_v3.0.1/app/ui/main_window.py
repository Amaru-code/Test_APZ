from __future__ import annotations

import threading
import time
import traceback
from pathlib import Path

from PySide6.QtCore import QThread, Qt, QTimer, Signal
from PySide6.QtGui import QCloseEvent
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QComboBox,
    QDialog,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QProgressBar,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from app.core.conversion_service import ConversionCancelled, ConversionService, OperationResult
from app.core.file_utils import human_file_size, open_folder
from app.core.settings import SETTINGS

from .styles import APP_STYLESHEET
from .widgets import DropTableWidget, SpinnerWidget, svg_icon


class OperationWorker(QThread):
    progress = Signal(int, int, str, str, int)
    completed = Signal(object)
    failed = Signal(str, str)
    cancelled = Signal(str)

    def __init__(
        self,
        *,
        mode: str,
        source_files: list[Path],
        output_dir: Path,
        target_format: str,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.mode = mode
        self.source_files = source_files
        self.output_dir = output_dir
        self.target_format = target_format
        self._cancel_event = threading.Event()

    def request_cancel(self) -> None:
        self._cancel_event.set()

    def _is_cancelled(self) -> bool:
        return self._cancel_event.is_set()

    def _on_progress(self, current: int, total: int, file_name: str, status: str, rows: int) -> None:
        self.progress.emit(current, total, file_name, status, rows)

    def run(self) -> None:
        service = ConversionService()
        try:
            if self.mode == "merge":
                result = service.merge_only(
                    self.source_files,
                    self.output_dir,
                    progress=self._on_progress,
                    is_cancelled=self._is_cancelled,
                )
            else:
                result = service.convert_files(
                    self.source_files,
                    self.output_dir,
                    self.target_format,
                    create_master=self.mode == "convert_master",
                    progress=self._on_progress,
                    is_cancelled=self._is_cancelled,
                )
            self.completed.emit(result)
        except ConversionCancelled as exc:
            self.cancelled.emit(str(exc))
        except Exception as exc:
            self.failed.emit(str(exc), traceback.format_exc())


class ResultDialog(QDialog):
    def __init__(self, result: OperationResult, output_dir: Path, parent=None) -> None:
        super().__init__(parent)
        self.output_dir = output_dir
        self.setWindowTitle("Vorgang abgeschlossen")
        self.setModal(True)
        self.setMinimumWidth(560)
        self.setStyleSheet(APP_STYLESHEET)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(26, 24, 26, 22)
        layout.setSpacing(14)

        header = QHBoxLayout()
        icon_label = QLabel()
        icon_label.setPixmap(svg_icon("circle-check", "#00A878", 34).pixmap(34, 34))
        header.addWidget(icon_label, 0, Qt.AlignmentFlag.AlignTop)

        title_box = QVBoxLayout()
        title = QLabel("Vorgang abgeschlossen")
        title.setObjectName("SectionTitle")
        subtitle = QLabel(self._summary_text(result))
        subtitle.setObjectName("SectionHint")
        subtitle.setWordWrap(True)
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        header.addLayout(title_box, 1)
        layout.addLayout(header)

        if result.master_file:
            master_card = QFrame()
            master_card.setObjectName("Card")
            master_layout = QVBoxLayout(master_card)
            master_layout.setContentsMargins(16, 12, 16, 12)
            master_title = QLabel("Masterdatei")
            master_title.setObjectName("SectionTitle")
            master_path = QLabel(str(result.master_file))
            master_path.setObjectName("SectionHint")
            master_path.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            master_path.setWordWrap(True)
            master_layout.addWidget(master_title)
            master_layout.addWidget(master_path)
            layout.addWidget(master_card)

        if result.errors:
            error_label = QLabel(f"{len(result.errors)} Datei(en) konnten nicht vollständig verarbeitet werden.")
            error_label.setStyleSheet("color:#B42318; font-weight:600;")
            layout.addWidget(error_label)
            details = QTextEdit()
            details.setReadOnly(True)
            details.setPlainText("\n".join(result.errors))
            details.setMaximumHeight(150)
            layout.addWidget(details)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        open_button = QPushButton("Ordner öffnen")
        open_button.setObjectName("AccentButton")
        open_button.setIcon(svg_icon("folder-open", "#FFFFFF", 17))
        open_button.clicked.connect(self._open_output_folder)
        close_button = QPushButton("Schließen")
        close_button.setObjectName("PrimaryButton")
        close_button.clicked.connect(self.accept)
        buttons.addWidget(open_button)
        buttons.addWidget(close_button)
        layout.addLayout(buttons)

    @staticmethod
    def _summary_text(result: OperationResult) -> str:
        parts: list[str] = []
        if result.successful_files:
            parts.append(f"{len(result.successful_files)} Datei(en) erfolgreich konvertiert")
        if result.skipped_files:
            parts.append(f"{len(result.skipped_files)} übersprungen")
        if result.master_file:
            parts.append(f"Masterdatei mit {result.master_rows:,} Datenzeilen erstellt".replace(",", "."))
        if not parts:
            parts.append("Keine Ausgabedatei wurde erstellt")
        return " · ".join(parts)

    def _open_output_folder(self) -> None:
        try:
            open_folder(self.output_dir)
        except Exception as exc:
            QMessageBox.warning(self, "Ordner konnte nicht geöffnet werden", str(exc))


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.source_files: list[Path] = []
        self.output_dir: Path | None = None
        self.worker: OperationWorker | None = None
        self.started_at = 0.0

        self.setWindowTitle(SETTINGS.application_name)
        self.resize(980, 800)
        self.setMinimumSize(830, 700)
        self.setStyleSheet(APP_STYLESHEET)
        self.setWindowIcon(svg_icon("wand-magic-sparkles", "#002C77", 32))

        self._elapsed_timer = QTimer(self)
        self._elapsed_timer.timeout.connect(self._update_elapsed)

        self._build_ui()
        self._update_action_state()

    def _build_ui(self) -> None:
        central = QWidget()
        root_layout = QVBoxLayout(central)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)
        self.setCentralWidget(central)

        top_bar = QFrame()
        top_bar.setObjectName("TopBar")
        top_layout = QHBoxLayout(top_bar)
        top_layout.setContentsMargins(30, 20, 30, 20)

        title_box = QVBoxLayout()
        title = QLabel("Data Converter & Merger")
        title.setObjectName("AppTitle")
        subtitle = QLabel("DU/DP-Dateien konvertieren, bereinigen und optional zusammenfassen")
        subtitle.setObjectName("AppSubtitle")
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        top_layout.addLayout(title_box, 1)

        version = QLabel(f"Version {SETTINGS.version}")
        version.setObjectName("VersionBadge")
        top_layout.addWidget(version, 0, Qt.AlignmentFlag.AlignTop)
        root_layout.addWidget(top_bar)

        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(28, 22, 28, 24)
        content_layout.setSpacing(16)
        root_layout.addWidget(content, 1)

        content_layout.addWidget(self._build_files_card(), 1)
        content_layout.addWidget(self._build_options_card())
        content_layout.addLayout(self._build_action_row())
        content_layout.addWidget(self._build_progress_card())

    def _section_header(self, number: str, title: str, hint: str) -> QHBoxLayout:
        layout = QHBoxLayout()
        badge = QLabel(number)
        badge.setObjectName("StepBadge")
        layout.addWidget(badge, 0, Qt.AlignmentFlag.AlignTop)

        text_box = QVBoxLayout()
        text_box.setSpacing(2)
        title_label = QLabel(title)
        title_label.setObjectName("SectionTitle")
        hint_label = QLabel(hint)
        hint_label.setObjectName("SectionHint")
        hint_label.setWordWrap(True)
        text_box.addWidget(title_label)
        text_box.addWidget(hint_label)
        layout.addLayout(text_box, 1)
        return layout

    def _build_files_card(self) -> QFrame:
        card = QFrame()
        card.setObjectName("Card")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 18)
        layout.setSpacing(12)
        layout.addLayout(
            self._section_header(
                "1",
                "Quelldateien",
                "Dateien auswählen oder per Drag & Drop in die Liste ziehen.",
            )
        )

        button_row = QHBoxLayout()
        self.select_button = QPushButton("Dateien auswählen")
        self.select_button.setObjectName("PrimaryButton")
        self.select_button.setIcon(svg_icon("folder-open", "#FFFFFF", 17))
        self.select_button.clicked.connect(self.select_files)

        self.add_button = QPushButton("Weitere hinzufügen")
        self.add_button.setObjectName("SecondaryButton")
        self.add_button.setIcon(svg_icon("plus", "#002C77", 15))
        self.add_button.clicked.connect(self.select_files)

        self.remove_button = QPushButton("Auswahl entfernen")
        self.remove_button.setObjectName("SecondaryButton")
        self.remove_button.setIcon(svg_icon("xmark", "#002C77", 15))
        self.remove_button.clicked.connect(self.remove_selected_files)

        self.clear_button = QPushButton("Liste leeren")
        self.clear_button.setObjectName("DangerButton")
        self.clear_button.setIcon(svg_icon("trash", "#B42318", 15))
        self.clear_button.clicked.connect(self.clear_files)

        button_row.addWidget(self.select_button)
        button_row.addWidget(self.add_button)
        button_row.addWidget(self.remove_button)
        button_row.addStretch(1)
        button_row.addWidget(self.clear_button)
        layout.addLayout(button_row)

        self.file_table = DropTableWidget()
        self.file_table.files_dropped_callback = self.add_files
        self.file_table.setColumnCount(3)
        self.file_table.setHorizontalHeaderLabels(["Dateiname", "Typ", "Größe"])
        self.file_table.setAlternatingRowColors(True)
        self.file_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.file_table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.file_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.file_table.verticalHeader().setVisible(False)
        self.file_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.file_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.file_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.file_table.setMinimumHeight(205)
        layout.addWidget(self.file_table, 1)

        footer = QHBoxLayout()
        self.file_count_label = QLabel("Keine Dateien ausgewählt")
        self.file_count_label.setObjectName("SectionHint")
        footer.addWidget(self.file_count_label)
        footer.addStretch(1)
        filter_chip = QLabel("FirmenID-Filter aktiv")
        filter_chip.setObjectName("StatusChip")
        filter_chip.setToolTip("Es werden nur die in app/config/settings.json hinterlegten FirmenIDs übernommen.")
        footer.addWidget(filter_chip)
        layout.addLayout(footer)
        return card

    def _build_options_card(self) -> QFrame:
        card = QFrame()
        card.setObjectName("Card")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 18)
        layout.setSpacing(12)
        layout.addLayout(
            self._section_header(
                "2",
                "Ausgabe festlegen",
                "Zielformat und Speicherort auswählen. Es werden keine zusätzlichen Quelldatei- oder Log-TXT-Dateien erzeugt.",
            )
        )

        fields = QHBoxLayout()
        fields.setSpacing(14)

        format_box = QVBoxLayout()
        format_label = QLabel("Zielformat")
        format_label.setObjectName("SectionHint")
        self.format_combo = QComboBox()
        self.format_combo.addItem("Excel-Arbeitsmappe (.xlsx)", "xlsx")
        self.format_combo.addItem("CSV-Datei (.csv)", "csv")
        self.format_combo.addItem("Textdatei (.txt)", "txt")
        self.format_combo.addItem("PDF-Dokument (.pdf)", "pdf")
        self.format_combo.addItem("Word-Dokument (.docx)", "docx")
        default_index = self.format_combo.findData(SETTINGS.default_target_format)
        self.format_combo.setCurrentIndex(max(0, default_index))
        self.format_combo.currentIndexChanged.connect(self._update_action_state)
        format_box.addWidget(format_label)
        format_box.addWidget(self.format_combo)
        fields.addLayout(format_box, 0)

        output_box = QVBoxLayout()
        output_label = QLabel("Ausgabeordner")
        output_label.setObjectName("SectionHint")
        output_row = QHBoxLayout()
        self.output_edit = QLineEdit()
        self.output_edit.setReadOnly(True)
        self.output_edit.setPlaceholderText("Noch kein Ausgabeordner ausgewählt")
        self.output_button = QPushButton("Ordner wählen")
        self.output_button.setObjectName("SecondaryButton")
        self.output_button.setIcon(svg_icon("folder", "#002C77", 16))
        self.output_button.clicked.connect(self.select_output_dir)
        output_row.addWidget(self.output_edit, 1)
        output_row.addWidget(self.output_button)
        output_box.addWidget(output_label)
        output_box.addLayout(output_row)
        fields.addLayout(output_box, 1)
        layout.addLayout(fields)
        return card

    def _build_action_row(self) -> QHBoxLayout:
        row = QHBoxLayout()
        row.setSpacing(10)

        self.convert_button = QPushButton("Konvertieren")
        self.convert_button.setObjectName("PrimaryButton")
        self.convert_button.setIcon(svg_icon("play", "#FFFFFF", 16))
        self.convert_button.setMinimumHeight(44)
        self.convert_button.clicked.connect(lambda: self.start_operation("convert"))

        self.convert_master_button = QPushButton("Konvertieren + Master")
        self.convert_master_button.setObjectName("AccentButton")
        self.convert_master_button.setIcon(svg_icon("code-merge", "#FFFFFF", 17))
        self.convert_master_button.setMinimumHeight(44)
        self.convert_master_button.setToolTip("Konvertiert alle Dateien nach Excel und fasst die bereinigten Ausgaben zusätzlich zusammen.")
        self.convert_master_button.clicked.connect(lambda: self.start_operation("convert_master"))

        self.merge_button = QPushButton("Nur zusammenführen")
        self.merge_button.setObjectName("SecondaryButton")
        self.merge_button.setIcon(svg_icon("code-merge", "#002C77", 17))
        self.merge_button.setMinimumHeight(44)
        self.merge_button.setToolTip("Fasst die ausgewählten Tabellen zusammen, ohne einzelne Konvertierungsdateien zu erzeugen.")
        self.merge_button.clicked.connect(lambda: self.start_operation("merge"))

        row.addWidget(self.convert_button, 1)
        row.addWidget(self.convert_master_button, 1)
        row.addWidget(self.merge_button, 1)
        return row

    def _build_progress_card(self) -> QFrame:
        card = QFrame()
        card.setObjectName("Card")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 14, 18, 14)
        layout.setSpacing(9)

        top = QHBoxLayout()
        self.spinner = SpinnerWidget()
        top.addWidget(self.spinner)

        status_box = QVBoxLayout()
        status_box.setSpacing(1)
        self.status_title = QLabel("Bereit")
        self.status_title.setObjectName("StatusTitle")
        self.status_detail = QLabel("Dateien und Ausgabeordner auswählen, anschließend Vorgang starten.")
        self.status_detail.setObjectName("StatusDetail")
        self.status_detail.setWordWrap(True)
        status_box.addWidget(self.status_title)
        status_box.addWidget(self.status_detail)
        top.addLayout(status_box, 1)

        info_box = QVBoxLayout()
        info_box.setSpacing(1)
        self.progress_count = QLabel("0 / 0")
        self.progress_count.setAlignment(Qt.AlignmentFlag.AlignRight)
        self.progress_count.setObjectName("StatusTitle")
        self.elapsed_label = QLabel("00:00")
        self.elapsed_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        self.elapsed_label.setObjectName("StatusDetail")
        info_box.addWidget(self.progress_count)
        info_box.addWidget(self.elapsed_label)
        top.addLayout(info_box)

        self.cancel_button = QPushButton("Abbrechen")
        self.cancel_button.setObjectName("DangerButton")
        self.cancel_button.setIcon(svg_icon("ban", "#B42318", 15))
        self.cancel_button.clicked.connect(self.cancel_operation)
        self.cancel_button.hide()
        top.addWidget(self.cancel_button)
        layout.addLayout(top)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(False)
        layout.addWidget(self.progress_bar)
        return card

    def select_files(self) -> None:
        files, _ = QFileDialog.getOpenFileNames(
            self,
            "Quelldateien auswählen",
            "",
            "Alle Dateien (*)",
        )
        if files:
            self.add_files([Path(file) for file in files])

    def add_files(self, files: list[Path]) -> None:
        existing = {str(path.resolve()).lower() for path in self.source_files}
        for path in files:
            try:
                key = str(path.resolve()).lower()
            except OSError:
                key = str(path).lower()
            if path.is_file() and key not in existing:
                self.source_files.append(path)
                existing.add(key)
        self.source_files.sort(key=lambda path: path.name.lower())
        self._refresh_file_table()

    def remove_selected_files(self) -> None:
        selected_rows = sorted({index.row() for index in self.file_table.selectedIndexes()}, reverse=True)
        for row in selected_rows:
            if 0 <= row < len(self.source_files):
                self.source_files.pop(row)
        self._refresh_file_table()

    def clear_files(self) -> None:
        self.source_files.clear()
        self._refresh_file_table()

    def _refresh_file_table(self) -> None:
        self.file_table.setRowCount(len(self.source_files))
        total_size = 0
        for row, path in enumerate(self.source_files):
            try:
                size = path.stat().st_size
            except OSError:
                size = 0
            total_size += size
            file_type = path.suffix.lower().lstrip(".").upper() or "Ohne Endung"
            name_item = QTableWidgetItem(path.name)
            name_item.setToolTip(str(path))
            type_item = QTableWidgetItem(file_type)
            size_item = QTableWidgetItem(human_file_size(size))
            size_item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            self.file_table.setItem(row, 0, name_item)
            self.file_table.setItem(row, 1, type_item)
            self.file_table.setItem(row, 2, size_item)

        if self.source_files:
            self.file_count_label.setText(
                f"{len(self.source_files)} Datei(en) · {human_file_size(total_size)} gesamt"
            )
        else:
            self.file_count_label.setText("Keine Dateien ausgewählt")
        self._update_action_state()

    def select_output_dir(self) -> None:
        directory = QFileDialog.getExistingDirectory(
            self,
            "Ausgabeordner auswählen",
            str(self.output_dir or Path.home()),
        )
        if directory:
            self.output_dir = Path(directory)
            self.output_edit.setText(directory)
            self.output_edit.setToolTip(directory)
            self._update_action_state()

    def _update_action_state(self) -> None:
        busy = self.worker is not None and self.worker.isRunning()
        ready = bool(self.source_files) and self.output_dir is not None and not busy
        target_format = self.format_combo.currentData() if hasattr(self, "format_combo") else "xlsx"

        if hasattr(self, "convert_button"):
            self.convert_button.setEnabled(ready)
            self.convert_master_button.setEnabled(ready and target_format == "xlsx")
            self.merge_button.setEnabled(ready)
            for widget in (
                self.select_button,
                self.add_button,
                self.remove_button,
                self.clear_button,
                self.output_button,
                self.format_combo,
                self.file_table,
            ):
                widget.setEnabled(not busy)

    def start_operation(self, mode: str) -> None:
        if not self.source_files:
            QMessageBox.warning(self, "Keine Dateien", "Bitte zuerst mindestens eine Datei auswählen.")
            return
        if self.output_dir is None:
            QMessageBox.warning(self, "Kein Ausgabeordner", "Bitte einen Ausgabeordner auswählen.")
            return
        if mode == "convert_master" and self.format_combo.currentData() != "xlsx":
            QMessageBox.warning(self, "Excel erforderlich", "Die Masterfunktion ist nur für das Zielformat Excel verfügbar.")
            return

        self.worker = OperationWorker(
            mode=mode,
            source_files=list(self.source_files),
            output_dir=self.output_dir,
            target_format=str(self.format_combo.currentData()),
            parent=self,
        )
        self.worker.progress.connect(self._on_progress)
        self.worker.completed.connect(self._on_completed)
        self.worker.failed.connect(self._on_failed)
        self.worker.cancelled.connect(self._on_cancelled)
        self.worker.finished.connect(self._worker_finished)

        self.started_at = time.monotonic()
        self._elapsed_timer.start(500)
        self.spinner.start()
        self.cancel_button.show()
        self.progress_bar.setRange(0, max(1, len(self.source_files)))
        self.progress_bar.setValue(0)
        self.progress_count.setText(f"0 / {len(self.source_files)}")
        self.status_title.setText("Vorgang läuft")
        self.status_detail.setText("Dateien werden vorbereitet. Das Fenster bleibt bedienbar.")
        self._update_action_state()
        self.worker.start()

    def cancel_operation(self) -> None:
        if self.worker and self.worker.isRunning():
            self.worker.request_cancel()
            self.cancel_button.setEnabled(False)
            self.status_title.setText("Abbruch wird vorbereitet")
            self.status_detail.setText("Die aktuell bearbeitete Datei wird noch sauber beendet.")

    def _on_progress(self, current: int, total: int, file_name: str, status: str, rows: int) -> None:
        self.progress_bar.setRange(0, max(1, total))
        self.progress_bar.setValue(min(current, total))
        self.progress_count.setText(f"{min(current, total)} / {total}")
        self.status_title.setText(status)
        detail = file_name
        if rows:
            detail += f" · {rows:,} Datenzeilen übernommen".replace(",", ".")
        self.status_detail.setText(detail)

    def _on_completed(self, result: OperationResult) -> None:
        self._finish_busy_state()
        if result.errors and not result.successful_files and not result.master_file:
            self.status_title.setText("Keine Datei erstellt")
            self.status_detail.setText("Die Fehlerdetails werden im Ergebnisfenster angezeigt.")
        else:
            self.status_title.setText("Erfolgreich abgeschlossen")
            if result.master_file:
                self.status_detail.setText(f"Masterdatei erstellt: {result.master_file.name}")
            else:
                self.status_detail.setText(f"{len(result.successful_files)} Datei(en) erstellt.")
        ResultDialog(result, self.output_dir or Path.cwd(), self).exec()

    def _on_failed(self, message: str, details: str) -> None:
        self._finish_busy_state()
        self.status_title.setText("Fehler")
        self.status_detail.setText(message)
        dialog = QMessageBox(self)
        dialog.setIcon(QMessageBox.Icon.Critical)
        dialog.setWindowTitle("Vorgang fehlgeschlagen")
        dialog.setText("Der Vorgang konnte nicht abgeschlossen werden.")
        dialog.setInformativeText(message)
        dialog.setDetailedText(details)
        dialog.exec()

    def _on_cancelled(self, message: str) -> None:
        self._finish_busy_state()
        self.status_title.setText("Vorgang abgebrochen")
        self.status_detail.setText(message)

    def _worker_finished(self) -> None:
        self.worker = None
        self._update_action_state()

    def _finish_busy_state(self) -> None:
        self._elapsed_timer.stop()
        self.spinner.stop()
        self.cancel_button.hide()
        self.cancel_button.setEnabled(True)
        self._update_elapsed()

    def _update_elapsed(self) -> None:
        if self.started_at <= 0:
            self.elapsed_label.setText("00:00")
            return
        elapsed = max(0, int(time.monotonic() - self.started_at))
        minutes, seconds = divmod(elapsed, 60)
        self.elapsed_label.setText(f"{minutes:02d}:{seconds:02d}")

    def closeEvent(self, event: QCloseEvent) -> None:  # noqa: N802
        if self.worker and self.worker.isRunning():
            answer = QMessageBox.question(
                self,
                "Vorgang läuft",
                "Der Vorgang läuft noch. Wirklich abbrechen und Anwendung schließen?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if answer != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            self.worker.request_cancel()
            self.worker.wait(3000)
        event.accept()
