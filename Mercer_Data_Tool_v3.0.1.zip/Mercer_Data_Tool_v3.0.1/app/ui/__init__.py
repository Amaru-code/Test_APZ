"""Qt user interface."""
