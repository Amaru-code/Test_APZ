from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable

from app.converters.registry import ConverterRegistry
from app.core.file_utils import unique_output_path
from app.core.merge_service import MergeCancelled, merge_files


ProgressCallback = Callable[[int, int, str, str, int], None]
CancelCallback = Callable[[], bool]


class ConversionCancelled(RuntimeError):
    pass


@dataclass
class OperationResult:
    operation: str
    successful_files: list[Path] = field(default_factory=list)
    skipped_files: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    master_file: Path | None = None
    master_rows: int = 0


class ConversionService:
    def __init__(self) -> None:
        self.registry = ConverterRegistry()

    def convert_files(
        self,
        source_files: Iterable[Path],
        output_dir: Path,
        target_format: str,
        *,
        create_master: bool,
        progress: ProgressCallback | None = None,
        is_cancelled: CancelCallback | None = None,
    ) -> OperationResult:
        files = [Path(path) for path in source_files]
        if not files:
            raise ValueError("Es wurden keine Quelldateien ausgewählt.")
        if create_master and target_format != "xlsx":
            raise ValueError("Eine Masterdatei kann nur aus Excel-Ausgaben erstellt werden.")

        output_dir.mkdir(parents=True, exist_ok=True)
        result = OperationResult(operation="convert_and_merge" if create_master else "convert")
        total = len(files)

        for index, source_path in enumerate(files, start=1):
            if is_cancelled and is_cancelled():
                raise ConversionCancelled("Vorgang wurde abgebrochen.")

            if progress:
                progress(index - 1, total, source_path.name, "Konvertierung wird vorbereitet", 0)

            try:
                # Copying a file to the same format without cleanup is unnecessary.
                # XLSX remains an exception because the Mercer cleanup/filter is applied.
                if source_path.suffix.lower() == f".{target_format}" and target_format != "xlsx":
                    result.skipped_files.append(f"{source_path.name}: Zielformat bereits vorhanden")
                else:
                    output_file = unique_output_path(source_path, output_dir, target_format)
                    converter = self.registry.get(source_path)
                    converter.convert_to(source_path, output_file, target_format)
                    result.successful_files.append(output_file)
            except Exception as exc:
                result.errors.append(f"{source_path.name}: {exc}")

            if progress:
                progress(index, total, source_path.name, "Datei abgeschlossen", 0)

        if create_master and result.successful_files:
            try:
                merge_total_steps = len(result.successful_files) + 1

                def merge_progress(current: int, total_steps: int, file_name: str, status: str, rows: int) -> None:
                    if progress:
                        progress(total + current, total + merge_total_steps, file_name, status, rows)

                master_file, row_count, merge_errors = merge_files(
                    result.successful_files,
                    output_dir,
                    progress=merge_progress,
                    is_cancelled=is_cancelled,
                )
                result.master_file = master_file
                result.master_rows = row_count
                result.errors.extend(merge_errors)
            except MergeCancelled as exc:
                raise ConversionCancelled(str(exc)) from exc

        return result

    def merge_only(
        self,
        source_files: Iterable[Path],
        output_dir: Path,
        *,
        progress: ProgressCallback | None = None,
        is_cancelled: CancelCallback | None = None,
    ) -> OperationResult:
        result = OperationResult(operation="merge")
        try:
            master_file, row_count, errors = merge_files(
                source_files,
                output_dir,
                progress=progress,
                is_cancelled=is_cancelled,
            )
        except MergeCancelled as exc:
            raise ConversionCancelled(str(exc)) from exc

        result.master_file = master_file
        result.master_rows = row_count
        result.errors = errors
        return result
