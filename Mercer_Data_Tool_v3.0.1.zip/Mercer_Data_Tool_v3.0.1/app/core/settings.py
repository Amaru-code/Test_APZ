from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


APP_DIR = Path(__file__).resolve().parents[1]
PROJECT_DIR = APP_DIR.parent
ASSETS_DIR = PROJECT_DIR / "assets"
ICONS_DIR = ASSETS_DIR / "icons"
CONFIG_PATH = APP_DIR / "config" / "settings.json"


@dataclass(frozen=True)
class AppSettings:
    application_name: str
    version: str
    default_target_format: str
    target_sheet_name: str
    master_sheet_name: str
    apply_company_filter: bool
    allowed_company_ids: tuple[str, ...]
    company_id_column_index: int
    target_headers: tuple[str, ...]


def load_settings(path: Path = CONFIG_PATH) -> AppSettings:
    with path.open("r", encoding="utf-8") as handle:
        raw: dict[str, Any] = json.load(handle)

    return AppSettings(
        application_name=str(raw["application_name"]),
        version=str(raw["version"]),
        default_target_format=str(raw["default_target_format"]),
        target_sheet_name=str(raw["target_sheet_name"]),
        master_sheet_name=str(raw["master_sheet_name"]),
        apply_company_filter=bool(raw["apply_company_filter"]),
        allowed_company_ids=tuple(str(value).strip() for value in raw["allowed_company_ids"]),
        company_id_column_index=int(raw["company_id_column_index"]),
        target_headers=tuple(str(value) for value in raw["target_headers"]),
    )


SETTINGS = load_settings()
