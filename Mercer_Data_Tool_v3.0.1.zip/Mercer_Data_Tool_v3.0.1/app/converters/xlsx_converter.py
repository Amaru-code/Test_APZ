from __future__ import annotations

from pathlib import Path

from app.core.settings import SETTINGS
from app.core.spreadsheet_io import (
    read_spreadsheet_table,
    write_csv_table,
    write_txt_table,
    write_xlsx_table,
)

from .base_converter import BaseConverter
from .document_helpers import table_to_pdf, text_to_docx


class XlsxConverter(BaseConverter):
    def convert_to(self, source_file: Path, output_file: Path, target_format: str) -> Path:
        source_path = self.validate_file(source_file)
        table = read_spreadsheet_table(source_path, fixed_target_header=True)

        if target_format == "xlsx":
            return write_xlsx_table(table, output_file, sheet_name=SETTINGS.target_sheet_name)
        if target_format == "csv":
            return write_csv_table(table, output_file)
        if target_format == "txt":
            return write_txt_table(table, output_file)
        if target_format == "pdf":
            return table_to_pdf(table, output_file, title=source_path.name)
        if target_format == "docx":
            text = "\n".join(";".join(row) for row in [table.header] + table.rows)
            return text_to_docx(text, output_file, title=source_path.name)
        raise ValueError(f"Konvertierung von Excel zu {target_format.upper()} wird nicht unterstützt.")
