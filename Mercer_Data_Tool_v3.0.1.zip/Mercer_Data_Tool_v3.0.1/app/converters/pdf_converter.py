from __future__ import annotations

from pathlib import Path

from app.core.data_parser import ParsedTable
from app.core.spreadsheet_io import write_xlsx_table

from .base_converter import BaseConverter
from .document_helpers import text_to_docx


class PdfConverter(BaseConverter):
    def _extract_text(self, source_path: Path) -> str:
        from pypdf import PdfReader

        reader = PdfReader(str(source_path))
        return "\n\n".join((page.extract_text() or "") for page in reader.pages)

    def convert_to(self, source_file: Path, output_file: Path, target_format: str) -> Path:
        source_path = self.validate_file(source_file)
        text = self._extract_text(source_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)

        if target_format == "txt":
            output_file.write_text(text, encoding="utf-8")
            return output_file
        if target_format == "docx":
            return text_to_docx(text, output_file, title=source_path.name)
        if target_format == "xlsx":
            rows = [[line] for line in text.splitlines() if line.strip()]
            return write_xlsx_table(ParsedTable(header=["PDF-Inhalt"], rows=rows), output_file, sheet_name="PDF-Inhalt")
        raise ValueError(f"Konvertierung von PDF zu {target_format.upper()} wird nicht unterstützt.")
