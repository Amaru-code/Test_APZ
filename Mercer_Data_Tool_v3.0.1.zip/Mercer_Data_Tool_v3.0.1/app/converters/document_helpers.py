from __future__ import annotations

from pathlib import Path

from app.core.data_parser import ParsedTable


def table_to_pdf(table: ParsedTable, output_file: Path, title: str = "Konvertierte Daten") -> Path:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A3, landscape
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import LongTable, Paragraph, SimpleDocTemplate, Spacer, TableStyle

    output_file.parent.mkdir(parents=True, exist_ok=True)
    document = SimpleDocTemplate(
        str(output_file),
        pagesize=landscape(A3),
        leftMargin=8 * mm,
        rightMargin=8 * mm,
        topMargin=10 * mm,
        bottomMargin=10 * mm,
    )
    styles = getSampleStyleSheet()
    story = [Paragraph(title, styles["Heading1"]), Spacer(1, 4 * mm)]

    data = [table.header] + table.rows
    if not data:
        data = [["Keine Daten"]]

    pdf_table = LongTable(data, repeatRows=1, hAlign="LEFT")
    pdf_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#002C77")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 5.5),
                ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#D9E2EC")),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F7FAFC")]),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 2),
                ("RIGHTPADDING", (0, 0), (-1, -1), 2),
            ]
        )
    )
    story.append(pdf_table)
    document.build(story)
    return output_file


def text_to_pdf(text: str, output_file: Path, title: str) -> Path:
    from xml.sax.saxutils import escape

    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer

    output_file.parent.mkdir(parents=True, exist_ok=True)
    document = SimpleDocTemplate(
        str(output_file),
        pagesize=A4,
        leftMargin=18 * mm,
        rightMargin=18 * mm,
        topMargin=18 * mm,
        bottomMargin=18 * mm,
    )
    styles = getSampleStyleSheet()
    story = [Paragraph(escape(title), styles["Heading1"]), Spacer(1, 5 * mm)]
    for line in text.splitlines():
        story.append(Paragraph(escape(line) or "&nbsp;", styles["BodyText"]))
    document.build(story)
    return output_file


def text_to_docx(text: str, output_file: Path, title: str | None = None) -> Path:
    from docx import Document

    output_file.parent.mkdir(parents=True, exist_ok=True)
    document = Document()
    if title:
        document.add_heading(title, level=1)
    for line in text.splitlines():
        document.add_paragraph(line)
    document.save(output_file)
    return output_file
