from __future__ import annotations

import os
import sys
import traceback
from pathlib import Path

# Make imports work when main.py is launched directly from START.bat.
APP_DIR = Path(__file__).resolve().parent
PROJECT_DIR = APP_DIR.parent
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

os.environ.setdefault("QT_ENABLE_HIGHDPI_SCALING", "1")
os.environ.setdefault("QT_AUTO_SCREEN_SCALE_FACTOR", "1")

from PySide6.QtCore import Qt  # noqa: E402
from PySide6.QtWidgets import QApplication, QMessageBox  # noqa: E402

from app.core.settings import SETTINGS  # noqa: E402
from app.ui.main_window import MainWindow  # noqa: E402


def main() -> int:
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )
    application = QApplication(sys.argv)
    application.setApplicationName(SETTINGS.application_name)
    application.setOrganizationName("Mercer")

    try:
        window = MainWindow()
        window.show()
        return application.exec()
    except Exception as exc:
        dialog = QMessageBox()
        dialog.setIcon(QMessageBox.Icon.Critical)
        dialog.setWindowTitle("Startfehler")
        dialog.setText("Die Anwendung konnte nicht gestartet werden.")
        dialog.setInformativeText(str(exc))
        dialog.setDetailedText(traceback.format_exc())
        dialog.exec()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
