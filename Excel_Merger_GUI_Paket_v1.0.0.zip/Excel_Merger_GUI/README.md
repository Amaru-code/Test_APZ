# Excel Master Merger GUI

Windows-Paket zum Zusammenführen vieler Excel-, CSV- und TXT-Dateien in eine formatierte `.xlsx`-Masterdatei.

## Schnellstart

1. `START_EXCEL_MERGER.bat` doppelklicken.
2. Beim ersten Start die automatische Installation abschließen.
3. Dateien oder Ordner auswählen.
4. Ausgabedatei festlegen.
5. **MERGE STARTEN** anklicken.

## Funktionen

- Auswahl einzelner Dateien oder kompletter Ordner
- optional rekursive Suche in Unterordnern
- Unterstützung für `.xlsx`, `.xlsm`, `.xls`, `.csv` und `.txt`
- automatische Erkennung semikolongetrennter Datensätze in einzelnen Zellen
- optionales Zusammenführen nach vorhandenen Überschriften
- Einlesen aller Tabellenblätter
- Herkunftsspalten für Datei, Blatt und Ursprungszeile
- Fortschrittsanzeige, Abbrechen-Funktion und Logdateien
- formatierte Excel-Tabelle mit Filtern und fixierter Kopfzeile
- lokale `.venv`, damit andere Python-Projekte unverändert bleiben

Eine ausführliche Beschreibung steht in `ANLEITUNG.txt`.
