@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Excel Master Merger - Debug

if not exist ".venv\Scripts\python.exe" (
    echo Lokale Python-Umgebung fehlt. Starte Installation ...
    call "%~dp0INSTALLIEREN.bat"
    if errorlevel 1 exit /b 1
)

".venv\Scripts\python.exe" "%~dp0Excel_Merger_GUI.py"

echo.
echo Programm wurde beendet.
pause
