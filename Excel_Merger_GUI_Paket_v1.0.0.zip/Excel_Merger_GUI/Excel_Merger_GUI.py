from __future__ import annotations

import csv
import os
import queue
import re
import sys
import threading
import traceback
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Callable, Iterator, Sequence

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
    from openpyxl import Workbook, load_workbook
    from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.worksheet.table import Table, TableStyleInfo
    from openpyxl.utils import get_column_letter
    OPENPYXL_IMPORT_ERROR: ImportError | None = None
except ImportError as exc:
    OPENPYXL_IMPORT_ERROR = exc

try:
    import xlrd
except ImportError:
    xlrd = None  # type: ignore[assignment]


APP_NAME = "Excel Master Merger"
APP_VERSION = "1.0.0"
SUPPORTED_EXTENSIONS = {".xlsx", ".xlsm", ".xls", ".csv", ".txt"}
MAX_EXCEL_DATA_ROWS = 1_048_575  # Kopfzeile belegt eine weitere Zeile
MAX_EXCEL_COLUMNS = 16_384
OUTPUT_SHEET_NAME = "Gesamtdaten"
SOURCE_HEADERS = ["Quelle_Datei", "Quelle_Blatt", "Quelle_Zeile"]


class MergeCancelled(Exception):
    """Wird ausgelöst, wenn der Benutzer den Merge abbricht."""


@dataclass(frozen=True)
class MergeOptions:
    first_row_is_header: bool = False
    read_all_sheets: bool = True
    add_source_columns: bool = True


@dataclass
class ScanResult:
    readable_files: list[Path]
    global_headers: list[str]
    max_fields: int
    data_rows: int
    errors: list[str]


ProgressCallback = Callable[[int, str], None]
LogCallback = Callable[[str], None]


def clean_text(value: object) -> str:
    """Konvertiert einen Wert sicher in bereinigten Text."""
    if value is None:
        return ""

    if isinstance(value, datetime):
        if value.time().hour == 0 and value.time().minute == 0 and value.time().second == 0:
            text = value.strftime("%Y-%m-%d")
        else:
            text = value.strftime("%Y-%m-%d %H:%M:%S")
    elif isinstance(value, date):
        text = value.strftime("%Y-%m-%d")
    elif isinstance(value, bool):
        text = "WAHR" if value else "FALSCH"
    else:
        text = str(value)

    text = ILLEGAL_CHARACTERS_RE.sub("", text)
    return text.strip()


def protect_excel_text(value: str) -> str:
    """Verhindert, dass Text mit '=' von Excel als Formel interpretiert wird."""
    if value.startswith("="):
        return "'" + value
    return value


def trim_trailing_empty(values: list[str]) -> list[str]:
    while values and values[-1] == "":
        values.pop()
    return values


def split_semicolon_record(text: str) -> list[str]:
    parsed = next(
        csv.reader(
            [text],
            delimiter=";",
            quotechar='"',
            skipinitialspace=False,
        )
    )
    return trim_trailing_empty([clean_text(value) for value in parsed])


def normalize_row(raw_values: Sequence[object]) -> list[str]:
    """
    Normalisiert eine Zeile. Liegt ein kompletter Semikolon-Datensatz in nur
    einer Zelle, wird er automatisch in einzelne Felder zerlegt.
    """
    values = [clean_text(value) for value in raw_values]
    non_empty = [value for value in values if value != ""]

    if len(non_empty) == 1 and non_empty[0].count(";") >= 2:
        return split_semicolon_record(non_empty[0])

    return trim_trailing_empty(values)


def make_unique_headers(values: Sequence[str]) -> list[str]:
    used: dict[str, int] = {}
    result: list[str] = []

    for index, raw_name in enumerate(values, start=1):
        base = clean_text(raw_name)
        if not base:
            base = f"Feld_{index:02d}"

        base = re.sub(r"[\r\n\t]+", " ", base).strip()
        count = used.get(base, 0) + 1
        used[base] = count
        result.append(base if count == 1 else f"{base}_{count}")

    return result


def safe_data_headers(headers: Sequence[str], add_source_columns: bool) -> list[str]:
    """Verhindert Namenskollisionen mit den Herkunftsspalten."""
    reserved = set(SOURCE_HEADERS) if add_source_columns else set()
    result: list[str] = []
    used: set[str] = set(reserved)

    for index, header in enumerate(headers, start=1):
        candidate = header or f"Feld_{index:02d}"
        if candidate in reserved:
            candidate = f"Daten_{candidate}"

        base = candidate
        suffix = 2
        while candidate in used:
            candidate = f"{base}_{suffix}"
            suffix += 1

        used.add(candidate)
        result.append(candidate)

    return result


def find_text_encoding(path: Path) -> str:
    for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin1"):
        try:
            with path.open("r", encoding=encoding, newline="") as handle:
                handle.read(65536)
            return encoding
        except UnicodeDecodeError:
            continue
    return "latin1"


def detect_delimiter(sample: str) -> str:
    # Semikolon wird priorisiert, da deutsche Dezimalzahlen Kommata enthalten.
    if ";" in sample:
        return ";"
    if "\t" in sample:
        return "\t"
    if "|" in sample:
        return "|"
    return ","


def iter_text_rows(path: Path) -> Iterator[tuple[str, int, list[str]]]:
    encoding = find_text_encoding(path)
    with path.open("r", encoding=encoding, newline="") as handle:
        sample = handle.read(65536)
        handle.seek(0)
        delimiter = detect_delimiter(sample)
        reader = csv.reader(handle, delimiter=delimiter, quotechar='"')
        for line_number, row in enumerate(reader, start=1):
            normalized = normalize_row(row)
            if normalized:
                yield "Textdatei", line_number, normalized


def iter_xlsx_rows(path: Path, read_all_sheets: bool) -> Iterator[tuple[str, int, list[str]]]:
    workbook = load_workbook(
        filename=path,
        read_only=True,
        data_only=True,
        keep_links=False,
    )
    try:
        worksheets = workbook.worksheets if read_all_sheets else workbook.worksheets[:1]
        for worksheet in worksheets:
            for row_number, row in enumerate(worksheet.iter_rows(values_only=True), start=1):
                normalized = normalize_row(row)
                if normalized:
                    yield worksheet.title, row_number, normalized
    finally:
        workbook.close()


def iter_xls_rows(path: Path, read_all_sheets: bool) -> Iterator[tuple[str, int, list[str]]]:
    if xlrd is None:
        raise RuntimeError(
            "Für alte .xls-Dateien fehlt das Paket xlrd. Bitte INSTALLIEREN.bat erneut ausführen."
        )
    workbook = xlrd.open_workbook(str(path), on_demand=True)
    try:
        sheet_indices = range(workbook.nsheets) if read_all_sheets else range(min(1, workbook.nsheets))
        for sheet_index in sheet_indices:
            worksheet = workbook.sheet_by_index(sheet_index)
            for row_index in range(worksheet.nrows):
                normalized = normalize_row(worksheet.row_values(row_index))
                if normalized:
                    yield worksheet.name, row_index + 1, normalized
    finally:
        workbook.release_resources()


def iter_file_rows(path: Path, read_all_sheets: bool) -> Iterator[tuple[str, int, list[str]]]:
    suffix = path.suffix.lower()
    if suffix in {".csv", ".txt"}:
        yield from iter_text_rows(path)
    elif suffix in {".xlsx", ".xlsm"}:
        yield from iter_xlsx_rows(path, read_all_sheets)
    elif suffix == ".xls":
        yield from iter_xls_rows(path, read_all_sheets)
    else:
        raise ValueError(f"Nicht unterstütztes Dateiformat: {suffix}")


def scan_files(
    files: Sequence[Path],
    options: MergeOptions,
    cancel_event: threading.Event,
    progress: ProgressCallback,
    log: LogCallback,
) -> ScanResult:
    readable_files: list[Path] = []
    global_headers: list[str] = []
    header_set: set[str] = set()
    max_fields = 0
    data_rows = 0
    errors: list[str] = []
    file_count = max(len(files), 1)

    for file_index, path in enumerate(files, start=1):
        if cancel_event.is_set():
            raise MergeCancelled()

        progress_value = int((file_index - 1) / file_count * 42)
        progress(progress_value, f"Analysiere {file_index}/{len(files)}: {path.name}")
        log(f"[ANALYSE] {path}")

        try:
            sheet_headers: dict[str, list[str]] = {}
            rows_in_file = 0

            for sheet_name, _source_row, values in iter_file_rows(path, options.read_all_sheets):
                if cancel_event.is_set():
                    raise MergeCancelled()

                if options.first_row_is_header and sheet_name not in sheet_headers:
                    local_headers = make_unique_headers(values)
                    sheet_headers[sheet_name] = local_headers
                    for header in local_headers:
                        if header not in header_set:
                            header_set.add(header)
                            global_headers.append(header)
                    continue

                if options.first_row_is_header:
                    local_headers = sheet_headers.get(sheet_name, [])
                    if len(values) > len(local_headers):
                        start = len(local_headers) + 1
                        for extra_index in range(start, len(values) + 1):
                            header = f"Extra_{extra_index:02d}"
                            while header in local_headers:
                                header += "_X"
                            local_headers.append(header)
                            if header not in header_set:
                                header_set.add(header)
                                global_headers.append(header)
                else:
                    max_fields = max(max_fields, len(values))

                rows_in_file += 1
                data_rows += 1

                if data_rows > MAX_EXCEL_DATA_ROWS:
                    raise ValueError(
                        "Die Datenmenge überschreitet die maximale Größe eines Excel-Blatts "
                        f"({MAX_EXCEL_DATA_ROWS:,} Datenzeilen)."
                    )

            readable_files.append(path)
            log(f"[OK] {path.name}: {rows_in_file:,} Datenzeilen")

        except MergeCancelled:
            raise
        except Exception as exc:
            error_text = f"{path.name}: {type(exc).__name__}: {exc}"
            errors.append(error_text)
            log(f"[ÜBERSPRUNGEN] {error_text}")

    if options.first_row_is_header:
        global_headers = safe_data_headers(global_headers, options.add_source_columns)
    else:
        global_headers = [f"Feld_{index:02d}" for index in range(1, max_fields + 1)]

    if data_rows == 0:
        raise ValueError("In den ausgewählten Dateien wurden keine Datenzeilen gefunden.")

    output_columns = len(global_headers) + (len(SOURCE_HEADERS) if options.add_source_columns else 0)
    if output_columns > MAX_EXCEL_COLUMNS:
        raise ValueError(
            f"Die zusammengeführte Tabelle hätte {output_columns:,} Spalten. "
            f"Excel unterstützt maximal {MAX_EXCEL_COLUMNS:,} Spalten."
        )

    progress(43, f"Analyse abgeschlossen: {data_rows:,} Datenzeilen")
    return ScanResult(readable_files, global_headers, max_fields, data_rows, errors)


def build_output_row(
    values: Sequence[str],
    local_headers: Sequence[str] | None,
    global_headers: Sequence[str],
    options: MergeOptions,
    path: Path,
    sheet_name: str,
    source_row: int,
) -> list[str]:
    if options.first_row_is_header:
        row_map = {
            header: protect_excel_text(values[index]) if index < len(values) else ""
            for index, header in enumerate(local_headers or [])
        }
        data_values = [row_map.get(header, "") for header in global_headers]
    else:
        data_values = [protect_excel_text(value) for value in values]
        data_values.extend([""] * (len(global_headers) - len(data_values)))

    if options.add_source_columns:
        return [path.name, sheet_name, str(source_row)] + data_values
    return data_values


def create_workbook(
    files: Sequence[Path],
    output_path: Path,
    options: MergeOptions,
    scan: ScanResult,
    cancel_event: threading.Event,
    progress: ProgressCallback,
    log: LogCallback,
) -> tuple[int, list[str]]:
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = OUTPUT_SHEET_NAME
    worksheet.freeze_panes = "A2"
    worksheet.sheet_view.showGridLines = False
    worksheet.sheet_view.zoomScale = 90

    headers = (SOURCE_HEADERS if options.add_source_columns else []) + scan.global_headers
    worksheet.append(headers)

    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(color="FFFFFF", bold=True, size=11)
    header_border = Border(bottom=Side(style="thin", color="B4C6E7"))

    for cell in worksheet[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = header_border
    worksheet.row_dimensions[1].height = 26

    max_lengths = [len(str(header)) for header in headers]
    total_written = 0
    write_errors: list[str] = []
    file_count = max(len(scan.readable_files), 1)

    for file_index, path in enumerate(scan.readable_files, start=1):
        if cancel_event.is_set():
            raise MergeCancelled()

        base_progress = 44 + int((file_index - 1) / file_count * 46)
        progress(base_progress, f"Füge {file_index}/{len(scan.readable_files)} ein: {path.name}")
        log(f"[MERGE] {path}")

        try:
            sheet_headers: dict[str, list[str]] = {}
            rows_from_file = 0

            for sheet_name, source_row, values in iter_file_rows(path, options.read_all_sheets):
                if cancel_event.is_set():
                    raise MergeCancelled()

                if options.first_row_is_header and sheet_name not in sheet_headers:
                    raw_headers = make_unique_headers(values)
                    safe_headers = safe_data_headers(raw_headers, options.add_source_columns)
                    sheet_headers[sheet_name] = safe_headers
                    continue

                local_headers = sheet_headers.get(sheet_name) if options.first_row_is_header else None
                if options.first_row_is_header and local_headers is not None and len(values) > len(local_headers):
                    for extra_index in range(len(local_headers) + 1, len(values) + 1):
                        local_headers.append(f"Extra_{extra_index:02d}")

                output_row = build_output_row(
                    values,
                    local_headers,
                    scan.global_headers,
                    options,
                    path,
                    sheet_name,
                    source_row,
                )
                worksheet.append(output_row)
                total_written += 1
                rows_from_file += 1

                for index, value in enumerate(output_row):
                    if index < len(max_lengths):
                        max_lengths[index] = min(max(max_lengths[index], len(str(value))), 60)

                if total_written % 5000 == 0:
                    within_file = min(4, int(rows_from_file / max(scan.data_rows, 1) * 4))
                    progress(min(base_progress + within_file, 90), f"{total_written:,} Zeilen geschrieben")

            log(f"[OK] {path.name}: {rows_from_file:,} Zeilen eingefügt")

        except MergeCancelled:
            raise
        except Exception as exc:
            error_text = f"{path.name}: {type(exc).__name__}: {exc}"
            write_errors.append(error_text)
            log(f"[SCHREIBFEHLER] {error_text}")

    if total_written == 0:
        raise ValueError("Es konnten keine Daten in die Ausgabedatei geschrieben werden.")

    progress(92, "Formatiere die Master-Tabelle ...")

    last_row = worksheet.max_row
    last_column = worksheet.max_column
    end_column = get_column_letter(last_column)
    table = Table(displayName="MasterTabelle", ref=f"A1:{end_column}{last_row}")
    table.tableStyleInfo = TableStyleInfo(
        name="TableStyleMedium2",
        showFirstColumn=False,
        showLastColumn=False,
        showRowStripes=True,
        showColumnStripes=False,
    )
    worksheet.add_table(table)
    worksheet.auto_filter.ref = f"A1:{end_column}{last_row}"

    for column_index, observed_length in enumerate(max_lengths, start=1):
        width = min(max(observed_length + 2, 10), 42)
        if options.add_source_columns and column_index == 1:
            width = min(max(width, 24), 38)
        elif options.add_source_columns and column_index == 2:
            width = min(max(width, 16), 28)
        worksheet.column_dimensions[get_column_letter(column_index)].width = width

    worksheet.page_setup.orientation = "landscape"
    worksheet.page_setup.fitToWidth = 1
    worksheet.page_setup.fitToHeight = 0
    worksheet.sheet_properties.pageSetUpPr.fitToPage = True
    worksheet.print_title_rows = "1:1"
    worksheet.auto_filter.ref = f"A1:{end_column}{last_row}"

    workbook.properties.title = "Zusammengeführte Excel-Daten"
    workbook.properties.subject = "Erstellt mit Excel Master Merger"
    workbook.properties.creator = APP_NAME
    workbook.properties.description = (
        f"Zusammengeführt aus {len(files)} Quelldateien am "
        f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = output_path.with_name(f".{output_path.stem}_temp_{os.getpid()}.xlsx")

    try:
        progress(96, "Speichere Excel-Datei ...")
        workbook.save(temp_path)
        if output_path.exists():
            output_path.unlink()
        temp_path.replace(output_path)
    finally:
        if temp_path.exists():
            try:
                temp_path.unlink()
            except OSError:
                pass

    progress(100, "Fertig")
    return total_written, write_errors


def merge_files(
    files: Sequence[Path],
    output_path: Path,
    options: MergeOptions,
    cancel_event: threading.Event,
    progress: ProgressCallback,
    log: LogCallback,
) -> dict[str, object]:
    started = datetime.now()
    log(f"{APP_NAME} v{APP_VERSION}")
    log(f"Start: {started.strftime('%Y-%m-%d %H:%M:%S')}")
    log(f"Ausgabe: {output_path}")
    log(f"Quelldateien: {len(files)}")
    log("-" * 70)

    scan = scan_files(files, options, cancel_event, progress, log)
    written_rows, write_errors = create_workbook(
        files, output_path, options, scan, cancel_event, progress, log
    )

    all_errors = scan.errors + write_errors
    finished = datetime.now()
    duration = finished - started
    log("-" * 70)
    log(f"Fertig: {finished.strftime('%Y-%m-%d %H:%M:%S')}")
    log(f"Dauer: {duration}")
    log(f"Geschriebene Datenzeilen: {written_rows:,}")
    log(f"Übersprungene/fehlerhafte Vorgänge: {len(all_errors)}")

    return {
        "written_rows": written_rows,
        "errors": all_errors,
        "duration": duration,
        "output_path": output_path,
    }


class ExcelMergerApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title(f"{APP_NAME} v{APP_VERSION}")
        self.root.geometry("980x720")
        self.root.minsize(860, 620)

        self.base_dir = Path(__file__).resolve().parent
        self.selected_files: list[Path] = []
        self.cancel_event = threading.Event()
        self.events: queue.Queue[tuple[str, object]] = queue.Queue()
        self.worker: threading.Thread | None = None

        self.first_row_header_var = tk.BooleanVar(value=False)
        self.all_sheets_var = tk.BooleanVar(value=True)
        self.source_columns_var = tk.BooleanVar(value=True)
        self.include_subfolders_var = tk.BooleanVar(value=True)
        self.output_var = tk.StringVar(value=str(self.default_output_path()))
        self.status_var = tk.StringVar(value="Bereit – bitte Dateien auswählen.")
        self.progress_var = tk.IntVar(value=0)

        self.configure_style()
        self.build_ui()
        self.root.after(100, self.process_events)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def configure_style(self) -> None:
        style = ttk.Style()
        try:
            style.theme_use("vista")
        except tk.TclError:
            pass
        style.configure("Title.TLabel", font=("Segoe UI", 20, "bold"))
        style.configure("Subtitle.TLabel", font=("Segoe UI", 10))
        style.configure("Section.TLabelframe.Label", font=("Segoe UI", 10, "bold"))
        style.configure("Primary.TButton", font=("Segoe UI", 11, "bold"), padding=(16, 10))
        style.configure("TButton", font=("Segoe UI", 9), padding=(8, 5))
        style.configure("TCheckbutton", font=("Segoe UI", 9))

    def build_ui(self) -> None:
        container = ttk.Frame(self.root, padding=16)
        container.pack(fill="both", expand=True)

        ttk.Label(container, text="Excel Master Merger", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            container,
            text=(
                "Mehrere Excel-/CSV-/TXT-Dateien auswählen und in eine formatierte "
                "Master-Tabelle zusammenführen."
            ),
            style="Subtitle.TLabel",
        ).pack(anchor="w", pady=(0, 12))

        file_frame = ttk.LabelFrame(container, text="1. Quelldateien", style="Section.TLabelframe", padding=10)
        file_frame.pack(fill="both", expand=True)

        button_row = ttk.Frame(file_frame)
        button_row.pack(fill="x", pady=(0, 8))
        ttk.Button(button_row, text="Dateien auswählen", command=self.select_files).pack(side="left", padx=(0, 6))
        ttk.Button(button_row, text="Ordner hinzufügen", command=self.select_folder).pack(side="left", padx=(0, 6))
        ttk.Button(button_row, text="Markierte entfernen", command=self.remove_selected).pack(side="left", padx=(0, 6))
        ttk.Button(button_row, text="Liste leeren", command=self.clear_files).pack(side="left")
        ttk.Checkbutton(
            button_row,
            text="Unterordner einbeziehen",
            variable=self.include_subfolders_var,
        ).pack(side="right")

        list_container = ttk.Frame(file_frame)
        list_container.pack(fill="both", expand=True)
        self.file_listbox = tk.Listbox(
            list_container,
            selectmode=tk.EXTENDED,
            font=("Consolas", 9),
            activestyle="none",
        )
        scrollbar = ttk.Scrollbar(list_container, orient="vertical", command=self.file_listbox.yview)
        self.file_listbox.configure(yscrollcommand=scrollbar.set)
        self.file_listbox.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.file_count_label = ttk.Label(file_frame, text="0 Dateien ausgewählt")
        self.file_count_label.pack(anchor="w", pady=(6, 0))

        settings_frame = ttk.LabelFrame(container, text="2. Einstellungen", style="Section.TLabelframe", padding=10)
        settings_frame.pack(fill="x", pady=(10, 0))
        ttk.Checkbutton(
            settings_frame,
            text="Die erste nicht-leere Zeile jedes Tabellenblatts enthält Überschriften",
            variable=self.first_row_header_var,
        ).grid(row=0, column=0, sticky="w", padx=(0, 20))
        ttk.Checkbutton(
            settings_frame,
            text="Alle Tabellenblätter einlesen",
            variable=self.all_sheets_var,
        ).grid(row=0, column=1, sticky="w")
        ttk.Checkbutton(
            settings_frame,
            text="Herkunftsspalten hinzufügen (Datei, Blatt, Zeile)",
            variable=self.source_columns_var,
        ).grid(row=1, column=0, sticky="w", pady=(6, 0), padx=(0, 20))
        ttk.Label(
            settings_frame,
            text="Hinweis: Bei deinem gezeigten Datenformat bleibt die Überschriften-Option deaktiviert.",
        ).grid(row=1, column=1, sticky="w", pady=(6, 0))

        output_frame = ttk.LabelFrame(container, text="3. Ausgabedatei", style="Section.TLabelframe", padding=10)
        output_frame.pack(fill="x", pady=(10, 0))
        output_frame.columnconfigure(0, weight=1)
        self.output_entry = ttk.Entry(output_frame, textvariable=self.output_var)
        self.output_entry.grid(row=0, column=0, sticky="ew", padx=(0, 8))
        ttk.Button(output_frame, text="Speicherort wählen", command=self.select_output).grid(row=0, column=1)

        action_frame = ttk.Frame(container)
        action_frame.pack(fill="x", pady=(12, 0))
        self.start_button = ttk.Button(
            action_frame,
            text="MERGE STARTEN",
            style="Primary.TButton",
            command=self.start_merge,
        )
        self.start_button.pack(side="left")
        self.cancel_button = ttk.Button(
            action_frame,
            text="Abbrechen",
            command=self.cancel_merge,
            state="disabled",
        )
        self.cancel_button.pack(side="left", padx=(8, 0))
        ttk.Label(action_frame, textvariable=self.status_var).pack(side="right")

        self.progress_bar = ttk.Progressbar(
            container,
            maximum=100,
            variable=self.progress_var,
            mode="determinate",
        )
        self.progress_bar.pack(fill="x", pady=(10, 0))

        log_frame = ttk.LabelFrame(container, text="Protokoll", style="Section.TLabelframe", padding=8)
        log_frame.pack(fill="both", expand=False, pady=(10, 0))
        self.log_text = tk.Text(log_frame, height=8, wrap="word", font=("Consolas", 8), state="disabled")
        log_scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=log_scroll.set)
        self.log_text.pack(side="left", fill="both", expand=True)
        log_scroll.pack(side="right", fill="y")

    def default_output_path(self) -> Path:
        output_dir = self.base_dir / "Ausgabe"
        output_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return output_dir / f"MERGED_MASTER_{stamp}.xlsx"

    def set_busy(self, busy: bool) -> None:
        self.start_button.configure(state="disabled" if busy else "normal")
        self.cancel_button.configure(state="normal" if busy else "disabled")

    def refresh_file_list(self) -> None:
        self.file_listbox.delete(0, tk.END)
        for path in self.selected_files:
            self.file_listbox.insert(tk.END, str(path))
        self.file_count_label.configure(text=f"{len(self.selected_files)} Dateien ausgewählt")

        if self.selected_files:
            first_parent = self.selected_files[0].parent
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            self.output_var.set(str(first_parent / f"MERGED_MASTER_{stamp}.xlsx"))

    def add_paths(self, paths: Sequence[Path]) -> None:
        existing = {path.resolve() for path in self.selected_files}
        for path in paths:
            try:
                resolved = path.resolve()
            except OSError:
                continue
            if (
                path.is_file()
                and path.suffix.lower() in SUPPORTED_EXTENSIONS
                and not path.name.startswith("~$")
                and resolved not in existing
            ):
                self.selected_files.append(path)
                existing.add(resolved)
        self.selected_files.sort(key=lambda item: str(item).lower())
        self.refresh_file_list()

    def select_files(self) -> None:
        paths = filedialog.askopenfilenames(
            title="Quelldateien auswählen",
            filetypes=[
                ("Unterstützte Dateien", "*.xlsx *.xlsm *.xls *.csv *.txt"),
                ("Excel-Dateien", "*.xlsx *.xlsm *.xls"),
                ("Textdateien", "*.csv *.txt"),
                ("Alle Dateien", "*.*"),
            ],
        )
        self.add_paths([Path(path) for path in paths])

    def select_folder(self) -> None:
        folder = filedialog.askdirectory(title="Ordner mit Quelldateien auswählen")
        if not folder:
            return
        base = Path(folder)
        iterator = base.rglob("*") if self.include_subfolders_var.get() else base.glob("*")
        self.add_paths([path for path in iterator if path.is_file()])

    def remove_selected(self) -> None:
        selected_indices = set(self.file_listbox.curselection())
        self.selected_files = [
            path for index, path in enumerate(self.selected_files) if index not in selected_indices
        ]
        self.refresh_file_list()

    def clear_files(self) -> None:
        self.selected_files.clear()
        self.refresh_file_list()

    def select_output(self) -> None:
        current = Path(self.output_var.get()) if self.output_var.get().strip() else self.default_output_path()
        output = filedialog.asksaveasfilename(
            title="Master-Excel speichern",
            initialdir=str(current.parent),
            initialfile=current.name,
            defaultextension=".xlsx",
            filetypes=[("Excel-Arbeitsmappe", "*.xlsx")],
        )
        if output:
            self.output_var.set(output)

    def append_log(self, message: str) -> None:
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.configure(state="normal")
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.log_text.see(tk.END)
        self.log_text.configure(state="disabled")

    def start_merge(self) -> None:
        if not self.selected_files:
            messagebox.showwarning("Keine Dateien", "Bitte zuerst mindestens eine Quelldatei auswählen.")
            return

        output_text = self.output_var.get().strip()
        if not output_text:
            messagebox.showwarning("Kein Speicherort", "Bitte eine Ausgabedatei auswählen.")
            return

        output_path = Path(output_text)
        if output_path.suffix.lower() != ".xlsx":
            output_path = output_path.with_suffix(".xlsx")
            self.output_var.set(str(output_path))

        source_paths = {path.resolve() for path in self.selected_files}
        if output_path.resolve() in source_paths:
            messagebox.showerror("Ungültiger Speicherort", "Die Ausgabedatei darf keine der Quelldateien überschreiben.")
            return

        if output_path.exists() and not messagebox.askyesno(
            "Datei überschreiben",
            f"Die Datei existiert bereits:\n\n{output_path}\n\nSoll sie überschrieben werden?",
        ):
            return

        options = MergeOptions(
            first_row_is_header=self.first_row_header_var.get(),
            read_all_sheets=self.all_sheets_var.get(),
            add_source_columns=self.source_columns_var.get(),
        )

        self.cancel_event.clear()
        self.progress_var.set(0)
        self.status_var.set("Merge wird vorbereitet ...")
        self.set_busy(True)
        self.append_log("Merge gestartet.")

        files = list(self.selected_files)
        self.worker = threading.Thread(
            target=self.merge_worker,
            args=(files, output_path, options),
            daemon=True,
        )
        self.worker.start()

    def merge_worker(self, files: list[Path], output_path: Path, options: MergeOptions) -> None:
        log_dir = self.base_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / f"Excel_Merger_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"

        def emit_progress(value: int, message: str) -> None:
            self.events.put(("progress", (value, message)))

        def emit_log(message: str) -> None:
            self.events.put(("log", message))
            try:
                with log_path.open("a", encoding="utf-8") as handle:
                    handle.write(message + "\n")
            except OSError:
                pass

        try:
            result = merge_files(
                files,
                output_path,
                options,
                self.cancel_event,
                emit_progress,
                emit_log,
            )
            result["log_path"] = log_path
            self.events.put(("done", result))
        except MergeCancelled:
            self.events.put(("cancelled", None))
        except Exception as exc:
            error_details = traceback.format_exc()
            emit_log(error_details)
            self.events.put(("error", (exc, log_path)))

    def process_events(self) -> None:
        try:
            while True:
                event_type, payload = self.events.get_nowait()
                if event_type == "progress":
                    value, message = payload  # type: ignore[misc]
                    self.progress_var.set(int(value))
                    self.status_var.set(str(message))
                elif event_type == "log":
                    self.append_log(str(payload))
                elif event_type == "done":
                    self.handle_done(payload)  # type: ignore[arg-type]
                elif event_type == "cancelled":
                    self.handle_cancelled()
                elif event_type == "error":
                    self.handle_error(payload)  # type: ignore[arg-type]
        except queue.Empty:
            pass
        self.root.after(100, self.process_events)

    def handle_done(self, result: dict[str, object]) -> None:
        self.set_busy(False)
        self.progress_var.set(100)
        written_rows = int(result["written_rows"])
        errors = list(result["errors"])  # type: ignore[arg-type]
        output_path = Path(result["output_path"])  # type: ignore[arg-type]
        log_path = Path(result["log_path"])  # type: ignore[arg-type]
        self.status_var.set(f"Fertig: {written_rows:,} Zeilen zusammengeführt")
        self.append_log(f"Master-Datei erstellt: {output_path}")

        detail = (
            "Der Merge wurde erfolgreich abgeschlossen.\n\n"
            f"Datenzeilen: {written_rows:,}\n"
            f"Fehler/übersprungene Vorgänge: {len(errors)}\n\n"
            f"Ausgabedatei:\n{output_path}\n\n"
            f"Protokoll:\n{log_path}"
        )
        if errors:
            detail += "\n\nDie Details zu übersprungenen Dateien stehen im Protokoll."

        open_folder = messagebox.askyesno(
            "Merge abgeschlossen",
            detail + "\n\nSoll der Ausgabeordner geöffnet werden?",
        )
        if open_folder:
            try:
                os.startfile(str(output_path.parent))  # type: ignore[attr-defined]
            except OSError:
                pass

    def handle_cancelled(self) -> None:
        self.set_busy(False)
        self.progress_var.set(0)
        self.status_var.set("Merge wurde abgebrochen.")
        self.append_log("Merge wurde durch den Benutzer abgebrochen.")
        messagebox.showinfo("Abgebrochen", "Der Merge wurde abgebrochen.")

    def handle_error(self, payload: tuple[Exception, Path]) -> None:
        self.set_busy(False)
        self.status_var.set("Fehler beim Merge")
        exc, log_path = payload
        self.append_log(f"FEHLER: {type(exc).__name__}: {exc}")
        messagebox.showerror(
            "Merge fehlgeschlagen",
            "Der Merge konnte nicht abgeschlossen werden.\n\n"
            f"{type(exc).__name__}: {exc}\n\n"
            f"Weitere Details stehen im Protokoll:\n{log_path}",
        )

    def cancel_merge(self) -> None:
        if self.worker and self.worker.is_alive():
            self.cancel_event.set()
            self.status_var.set("Abbruch wird durchgeführt ...")
            self.cancel_button.configure(state="disabled")

    def on_close(self) -> None:
        if self.worker and self.worker.is_alive():
            if not messagebox.askyesno(
                "Merge läuft",
                "Der Merge läuft noch. Soll er abgebrochen und das Programm geschlossen werden?",
            ):
                return
            self.cancel_event.set()
        self.root.destroy()


def main() -> None:
    if OPENPYXL_IMPORT_ERROR is not None:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(
            "Fehlende Installation",
            "Benötigte Python-Pakete fehlen.\n\n"
            "Bitte zuerst INSTALLIEREN.bat ausführen.\n\n"
            f"Technische Meldung: {OPENPYXL_IMPORT_ERROR}",
        )
        raise SystemExit(1)

    root = tk.Tk()
    ExcelMergerApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
