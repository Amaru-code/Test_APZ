@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Excel Master Merger

if exist ".venv\Scripts\pythonw.exe" goto START_APP

echo ============================================================
echo  Excel Master Merger - Ersteinrichtung erforderlich
echo ============================================================
echo.
echo Die lokale Python-Umgebung wurde noch nicht eingerichtet.
echo Die Installation wird jetzt gestartet.
echo.
call "%~dp0INSTALLIEREN.bat"
if errorlevel 1 (
    echo.
    echo Die Installation war nicht erfolgreich.
    pause
    exit /b 1
)

:START_APP
start "" ".venv\Scripts\pythonw.exe" "%~dp0Excel_Merger_GUI.py"
exit /b 0
