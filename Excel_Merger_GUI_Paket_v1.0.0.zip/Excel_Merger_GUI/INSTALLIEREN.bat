@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title Excel Master Merger - Installation

set "PYTHON_CMD="

for %%V in (3.13 3.12 3.11 3.10) do (
    if not defined PYTHON_CMD (
        py -%%V -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
        if not errorlevel 1 set "PYTHON_CMD=py -%%V"
    )
)

if not defined PYTHON_CMD (
    python -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=python"
)

echo ============================================================
echo  Excel Master Merger - Lokale Installation
echo ============================================================
echo.

if not defined PYTHON_CMD (
    echo FEHLER: Python 3.10 oder neuer wurde nicht gefunden.
    echo.
    echo Bitte Python fuer Windows installieren:
    echo https://www.python.org/downloads/windows/
    echo.
    echo Bei der Installation unbedingt aktivieren:
    echo   [X] Add python.exe to PATH
    echo.
    pause
    exit /b 1
)

echo Verwende: %PYTHON_CMD%
echo.

if not exist ".venv\Scripts\python.exe" (
    echo Erstelle lokale Programmumgebung .venv ...
    %PYTHON_CMD% -m venv ".venv"
    if errorlevel 1 (
        echo FEHLER beim Erstellen der lokalen Umgebung.
        pause
        exit /b 1
    )
)

echo Aktualisiere pip ...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto INSTALL_ERROR

echo Installiere benoetigte Pakete ...
".venv\Scripts\python.exe" -m pip install -r "%~dp0requirements.txt"
if errorlevel 1 goto INSTALL_ERROR

echo.
echo ============================================================
echo  INSTALLATION ERFOLGREICH
ECHO ============================================================
echo.
echo Das Programm kann jetzt mit START_EXCEL_MERGER.bat gestartet werden.
echo.
pause
exit /b 0

:INSTALL_ERROR
echo.
echo FEHLER: Die benoetigten Pakete konnten nicht installiert werden.
echo Bitte Internetverbindung und Unternehmens-Proxy pruefen.
echo.
pause
exit /b 1
