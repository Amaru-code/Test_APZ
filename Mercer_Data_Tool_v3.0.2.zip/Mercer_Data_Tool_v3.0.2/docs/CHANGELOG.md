# Changelog

## 3.0.2

- FirmenID-Filter auf die zehn fachlich freigegebenen Werte korrigiert
- `INTELSK_0003` ergänzt
- nicht mehr gewünschte IDs `MERCER_0004`, `MERCER_0365` und `MERCER_0366` entfernt
- Filter wird bei Einzelkonvertierung, Konvertieren + Master und Nur zusammenführen angewendet
- FirmenID-Vergleich gegen Leerzeichen und Groß-/Kleinschreibung abgesichert

## 3.0.1

- PySide6-Installation gegen Windows-Long-Path-Fehler abgesichert
- virtuelle Umgebung in kurzen Pfad unter `%LOCALAPPDATA%\MercerDataTool\venv` verlegt
- unvollstaendige alte Projekt-Runtime wird bei der Installation entfernt
- pip-Cache fuer die Installation deaktiviert, damit defekte Cache-Eintraege nicht stoeren
- START.bat prueft die Installation und startet bei Bedarf automatisch die Reparatur

## 3.0.0

- bisheriges Converter-Tool und Excel-Merger zu einer Anwendung kombiniert
- professionelle PySide6-Oberfläche mit SVG-Icons
- native skalierbare Darstellung ohne Emoji- oder Custom-Titlebar-Fehler
- drei klare Aktionen: Konvertieren, Konvertieren + Master, Nur zusammenführen
- sichtbare Ladeanimation, Fortschrittsbalken, aktuelle Datei, Zeilenzähler und Laufzeit
- Markerzeilen `>>>> ...` und `<<<<<` vollständig entfernt
- wiederholte Header werden nicht mehr als Daten übernommen
- Metadatenzeilen vor dem Header werden verworfen
- keine automatischen Quelldatei-, Fehler- oder Dateilisten-TXT-Dateien im Ausgabeordner
- saubere Root-Struktur mit ausschließlich BAT-Dateien und Unterordnern
