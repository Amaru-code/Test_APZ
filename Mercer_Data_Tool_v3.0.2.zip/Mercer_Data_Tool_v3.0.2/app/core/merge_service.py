from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Callable, Iterable

from app.core.data_parser import (
    ParsedTable,
    extract_table,
    normalize_header,
    parse_text_rows,
    read_text_with_fallback,
)
from app.core.file_utils import unique_named_path
from app.core.settings import SETTINGS
from app.core.spreadsheet_io import read_spreadsheet_table, write_xlsx_table


ProgressCallback = Callable[[int, int, str, str, int], None]
CancelCallback = Callable[[], bool]


class MergeCancelled(RuntimeError):
    pass


def _read_merge_table(file_path: Path) -> ParsedTable:
    suffix = file_path.suffix.lower()
    if suffix in {".xlsx", ".xlsm", ".xls"}:
        return read_spreadsheet_table(
            file_path,
            fixed_target_header=False,
            apply_company_filter=True,
        )

    content = read_text_with_fallback(file_path)
    rows = parse_text_rows(content)
    return extract_table(rows, fixed_target_header=False, apply_company_filter=True)


def _align_rows(source: ParsedTable, master_header: list[str]) -> list[list[str]]:
    source_norm = [normalize_header(value) for value in source.header]
    master_norm = [normalize_header(value) for value in master_header]

    if source_norm == master_norm:
        return source.rows

    source_index = {name: index for index, name in enumerate(source_norm) if name}
    common = sum(1 for name in master_norm if name in source_index)

    # All files are expected to have the same header. A high-overlap mapping
    # still permits harmless spelling/order differences.
    if common < max(4, int(len(master_norm) * 0.60)):
        raise ValueError("Header weicht zu stark von den übrigen Dateien ab.")

    aligned: list[list[str]] = []
    for row in source.rows:
        aligned.append(
            [row[source_index[name]] if name in source_index and source_index[name] < len(row) else "" for name in master_norm]
        )
    return aligned


def merge_files(
    source_files: Iterable[Path],
    output_dir: Path,
    *,
    progress: ProgressCallback | None = None,
    is_cancelled: CancelCallback | None = None,
) -> tuple[Path, int, list[str]]:
    files = [Path(path) for path in source_files]
    if not files:
        raise ValueError("Es wurden keine Dateien zum Zusammenfassen ausgewählt.")

    master_header: list[str] | None = None
    master_rows: list[list[str]] = []
    errors: list[str] = []
    total_files = len(files)
    total_steps = total_files + 1

    for index, file_path in enumerate(files, start=1):
        if is_cancelled and is_cancelled():
            raise MergeCancelled("Vorgang wurde abgebrochen.")

        if progress:
            progress(index - 1, total_steps, file_path.name, "Datei wird eingelesen", len(master_rows))

        try:
            table = _read_merge_table(file_path)
            if not table.header:
                raise ValueError("Kein Tabellen-Header gefunden.")

            if master_header is None:
                master_header = table.header
                master_rows.extend(table.rows)
            else:
                master_rows.extend(_align_rows(table, master_header))
        except Exception as exc:
            errors.append(f"{file_path.name}: {exc}")

        if progress:
            progress(index, total_steps, file_path.name, "Datei abgeschlossen", len(master_rows))

    if master_header is None:
        raise RuntimeError("Aus den ausgewählten Dateien konnten keine Daten übernommen werden.")

    if is_cancelled and is_cancelled():
        raise MergeCancelled("Vorgang wurde abgebrochen.")

    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = unique_named_path(output_dir, f"MERCER_MASTER_{timestamp}.xlsx")

    if progress:
        progress(total_steps, total_steps, output_file.name, "Masterdatei wird geschrieben", len(master_rows))

    write_xlsx_table(
        ParsedTable(header=master_header, rows=master_rows),
        output_file,
        sheet_name=SETTINGS.master_sheet_name,
        table_name="MercerMasterDaten",
    )

    return output_file, len(master_rows), errors
