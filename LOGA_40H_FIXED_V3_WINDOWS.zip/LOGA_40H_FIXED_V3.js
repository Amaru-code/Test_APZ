// ============================================================================
// LOGA 40H – AUTO-SCROLL + SICHERES ÜBERSPRINGEN – V3
// ============================================================================
//
// ZEITPLAN:
//   Montag bis Freitag: 09:00–12:00 / 13:00–18:00 = 8h netto
//   Gesamt: 40 Stunden netto
//
// FIXES DIESER VERSION:
//   - Ein übersprungener Tag löst keinen unbeabsichtigten Drop mehr aus.
//   - Escape wird VOR dem Mouseup ausgelöst.
//   - Der Drag wird am Smart-Thing statt auf dem Kalendertag beendet.
//   - Versehentlich geöffnete Buchungs-Popups werden automatisch geschlossen.
//   - Es wird nur das echte Zeitbuchungs-Popup erkannt, nicht jedes LOGA-Popup.
//   - Bereits gebuchte Tage werden zusätzlich im geöffneten Popup geprüft.
//   - Nach Speichern und Überspringen wird sauber auf den LOGA-Refresh gewartet.
//   - Einzelne Standardwerte im Popup führen nicht mehr zum Überspringen.
//   - Kein doppelter Click mehr nach erfolgreichem Drag/Drop.
//   - Kalender wird zum Scrollen nicht mehr während eines aktiven Drags verschoben.
//   - Nach jedem Scrollschritt wird der Drag neu gestartet und das Overlay neu aufgebaut.
//   - Ein Scrollbereich gilt nur dann als korrekt, wenn sich die sichtbaren Datumsziele ändern.
//
// START:
//   1. LOGA öffnen und Zeitdaten/Kalender anzeigen.
//   2. F12 > Konsole.
//   3. Gesamtes Skript einfügen und Enter drücken.
// ============================================================================

(async () => {
  "use strict";

  if (window.__LOGA_40H_AUTOFILL_RUNNING__) {
    alert("Das LOGA-Skript läuft bereits.");
    return;
  }
  window.__LOGA_40H_AUTOFILL_RUNNING__ = true;

  // ========================================================================
  // KONFIGURATION
  // ========================================================================

  // 0 = Montag, 1 = Dienstag, 2 = Mittwoch, 3 = Donnerstag, 4 = Freitag
  const START_INDEX = 0;

  const START_TIME = "09:00";
  const PAUSE_START = "12:00";
  const PAUSE_END = "13:00";
  const PLAN_HOURS_GROSS = [9, 9, 9, 9, 9];
  const SKIP_ALREADY_BOOKED_DAYS = true;

  const SMART_THING_KNOWN_UIN = "smartthing-L3SDCjT5ZSA";

  const AUTO_SCROLL_STEP_PX = 180;
  const AUTO_SCROLL_WAIT_MS = 550;
  const AUTO_SCROLL_MAX_STEPS_PER_DIRECTION = 25;
  const AUTO_SCROLL_EDGE_MARGIN = 35;

  // ========================================================================
  // GRUNDFUNKTIONEN
  // ========================================================================

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const Q = (selector, root = document) => root.querySelector(selector);
  const QA = (selector, root = document) => [...root.querySelectorAll(selector)];
  const normalizeText = (value) => String(value || "").replace(/\s+/g, " ").trim();
  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

  const waitFor = async (
    condition,
    timeout = 30000,
    interval = 150,
    description = "Bedingung"
  ) => {
    const startedAt = Date.now();
    let lastError = null;

    while (Date.now() - startedAt < timeout) {
      try {
        const result = condition();
        if (result) return result;
      } catch (error) {
        lastError = error;
      }
      await sleep(interval);
    }

    throw new Error(
      `${description}: Timeout nach ${Math.round(timeout / 1000)} Sekunden.` +
      (lastError ? ` Letzter Fehler: ${lastError.message}` : "")
    );
  };

  const isVisible = (element) => {
    if (!element || !element.isConnected) return false;
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return (
      style.display !== "none" &&
      style.visibility !== "hidden" &&
      Number(style.opacity || 1) !== 0 &&
      rect.width > 0 &&
      rect.height > 0
    );
  };

  const isInViewport = (element) => {
    if (!isVisible(element)) return false;
    const rect = element.getBoundingClientRect();
    return (
      rect.bottom > 0 &&
      rect.right > 0 &&
      rect.top < window.innerHeight &&
      rect.left < window.innerWidth
    );
  };

  const centerOf = (element) => {
    const rect = element.getBoundingClientRect();
    return {
      x: rect.left + rect.width / 2,
      y: rect.top + rect.height / 2
    };
  };

  const fireMouseEvent = (element, type, options = {}) => {
    if (!element) return;
    element.dispatchEvent(
      new MouseEvent(type, {
        bubbles: true,
        cancelable: true,
        view: window,
        ...options
      })
    );
  };

  const fireWheelEvent = (element, deltaY, clientX, clientY) => {
    if (!element) return;
    element.dispatchEvent(
      new WheelEvent("wheel", {
        bubbles: true,
        cancelable: true,
        view: window,
        deltaMode: 0,
        deltaX: 0,
        deltaY,
        clientX,
        clientY
      })
    );
  };

  const fireEscape = (type) => {
    const targets = [document.activeElement, document.body, document].filter(Boolean);

    for (const target of targets) {
      try {
        target.dispatchEvent(
          new KeyboardEvent(type, {
            bubbles: true,
            cancelable: true,
            key: "Escape",
            code: "Escape",
            keyCode: 27,
            which: 27
          })
        );
      } catch (_) {}
    }
  };

  const pressEscape = () => {
    fireEscape("keydown");
    fireEscape("keyup");
  };

  const clickGwt = (element) => {
    if (!element) throw new Error("Klickziel ist nicht vorhanden.");
    const point = centerOf(element);

    fireMouseEvent(element, "mouseover", {
      clientX: point.x,
      clientY: point.y
    });
    fireMouseEvent(element, "mousedown", {
      clientX: point.x,
      clientY: point.y,
      button: 0,
      buttons: 1
    });
    fireMouseEvent(element, "mouseup", {
      clientX: point.x,
      clientY: point.y,
      button: 0,
      buttons: 0
    });
    fireMouseEvent(element, "click", {
      clientX: point.x,
      clientY: point.y,
      button: 0,
      buttons: 0
    });
  };

  const setInputValue = (input, value) => {
    if (!input) throw new Error("Zeit-Eingabefeld ist nicht vorhanden.");

    input.scrollIntoView?.({ block: "center", inline: "center" });
    input.focus();

    const setter = Object.getOwnPropertyDescriptor(
      HTMLInputElement.prototype,
      "value"
    )?.set;

    if (setter) setter.call(input, value);
    else input.value = value;

    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.dispatchEvent(
      new KeyboardEvent("keydown", {
        bubbles: true,
        cancelable: true,
        key: "Enter",
        code: "Enter",
        keyCode: 13,
        which: 13
      })
    );
    input.dispatchEvent(
      new KeyboardEvent("keyup", {
        bubbles: true,
        cancelable: true,
        key: "Enter",
        code: "Enter",
        keyCode: 13,
        which: 13
      })
    );
    input.blur();
  };

  // ========================================================================
  // DATUMSBERECHNUNG – MONTAG BIS FREITAG DER VORWOCHE
  // ========================================================================

  const WEEKDAYS = [
    "Sonntag",
    "Montag",
    "Dienstag",
    "Mittwoch",
    "Donnerstag",
    "Freitag",
    "Samstag"
  ];

  const MONTHS = [
    "Januar",
    "Februar",
    "März",
    "April",
    "Mai",
    "Juni",
    "Juli",
    "August",
    "September",
    "Oktober",
    "November",
    "Dezember"
  ];

  const targetDates = (() => {
    const now = new Date();
    const daysSinceMonday = (now.getDay() + 6) % 7;

    const thisMonday = new Date(now);
    thisMonday.setDate(now.getDate() - daysSinceMonday);
    thisMonday.setHours(12, 0, 0, 0);

    const lastMonday = new Date(thisMonday);
    lastMonday.setDate(thisMonday.getDate() - 7);

    return Array.from({ length: 5 }, (_, offset) => {
      const date = new Date(lastMonday);
      date.setDate(lastMonday.getDate() + offset);
      return date;
    });
  })();

  const createTargetLabel = (date) =>
    `${WEEKDAYS[date.getDay()]} ${date.getDate()} ${MONTHS[date.getMonth()]}`;

  const formatShortDate = (date) =>
    `${WEEKDAYS[date.getDay()]} ${String(date.getDate()).padStart(2, "0")}.` +
    `${String(date.getMonth() + 1).padStart(2, "0")}.${date.getFullYear()}`;

  const calculateEndTime = (startTime, grossHours) => {
    const [hours, minutes] = startTime.split(":").map(Number);
    const totalMinutes = hours * 60 + minutes + Math.round(grossHours * 60);
    return (
      String(Math.floor(totalMinutes / 60) % 24).padStart(2, "0") +
      ":" +
      String(totalMinutes % 60).padStart(2, "0")
    );
  };

  // ========================================================================
  // ZEITBUCHUNGS-POPUP – NUR DAS RELEVANTE POPUP ERKENNEN
  // ========================================================================

  const looksLikeBookingPopup = (popup) => {
    if (!isVisible(popup)) return false;

    if (
      popup.querySelector(
        'input.gwt-TimeBox, [data-uin="btn-saveconfirm"], .Personal-CalendarPopup-GridRow'
      )
    ) {
      return true;
    }

    const text = normalizeText(popup.innerText).toLowerCase();
    return (
      text.includes("bestätigen") &&
      (text.includes("kommen") || text.includes("pause") || text.includes("gehen"))
    );
  };

  const getVisibleBookingPopup = () =>
    QA(".LGMaskPartPopup-Content").find(looksLikeBookingPopup) || null;

  const findPopupCloseButton = (popup) => {
    const selectors = [
      '[data-uin="btn-cancel"]',
      '[data-uin*="cancel"]',
      '[data-uin*="close"]',
      '[aria-label="Schließen"]',
      '[aria-label="Schliessen"]',
      '[aria-label="Abbrechen"]',
      '[title="Schließen"]',
      '[title="Schliessen"]',
      '[title="Abbrechen"]',
      '.ic-close',
      '.ic-navigationclose',
      '.LGMaskPartPopup-CloseButton'
    ];

    for (const selector of selectors) {
      const button = QA(selector, popup).find(isVisible);
      if (button) return button;
    }

    const exactTexts = new Set(["abbrechen", "schließen", "schliessen", "zurück"]);
    return (
      QA('[role="button"], button, span, div', popup)
        .filter(isVisible)
        .find((element) => exactTexts.has(normalizeText(element.textContent).toLowerCase())) ||
      null
    );
  };

  const closeBookingPopupIfPresent = async (reason = "") => {
    for (let attempt = 1; attempt <= 5; attempt++) {
      let popup = getVisibleBookingPopup();
      if (!popup) return true;

      if (attempt === 1) {
        console.warn(
          `[AUTO] Offenes Buchungs-Popup wird geschlossen${reason ? ` (${reason})` : ""}.`
        );
      }

      // Zuerst Escape, weil dies in LOGA meist sauber abbricht.
      pressEscape();
      await sleep(350);

      popup = getVisibleBookingPopup();
      if (!popup) return true;

      const closeButton = findPopupCloseButton(popup);
      if (closeButton) {
        clickGwt(closeButton);
        await sleep(700);
      } else {
        // Noch einmal Escape, falls das Popup erst nach einer DOM-Aktualisierung reagiert.
        pressEscape();
        await sleep(700);
      }
    }

    return !getVisibleBookingPopup();
  };

  const ensureNoBookingPopup = async () => {
    if (!getVisibleBookingPopup()) return;

    const closed = await closeBookingPopupIfPresent("vor dem nächsten Tag");
    if (!closed) {
      throw new Error(
        "Ein vorheriges Zeitbuchungs-Popup konnte nicht geschlossen werden."
      );
    }

    await waitFor(
      () => !getVisibleBookingPopup(),
      15000,
      200,
      "Schließen des vorherigen Zeitbuchungs-Popups"
    );
    await sleep(700);
  };

  // ========================================================================
  // SMART-THING-ERKENNUNG
  // ========================================================================

  const getVisibleSmartThings = () =>
    QA('[data-uin^="smartthing-"]').filter(isVisible);

  let rememberedSmartThing = null;

  const rememberSmartThing = (element) => {
    const all = getVisibleSmartThings();
    const index = all.indexOf(element);

    rememberedSmartThing = {
      text: normalizeText(element.textContent),
      ariaLabel: normalizeText(element.getAttribute("aria-label")),
      title: normalizeText(element.getAttribute("title")),
      index: index >= 0 ? index : 0
    };

    console.log("[AUTO] Smart-Thing-Merkmale gespeichert:", rememberedSmartThing);
  };

  const findSmartThingHandle = () => {
    const exact = Q(`[data-uin="${SMART_THING_KNOWN_UIN}"]`);
    if (isVisible(exact)) {
      if (!rememberedSmartThing) rememberSmartThing(exact);
      return exact;
    }

    const all = getVisibleSmartThings();
    if (!all.length || !rememberedSmartThing) return null;

    const match = all.find((element) => {
      const text = normalizeText(element.textContent);
      const aria = normalizeText(element.getAttribute("aria-label"));
      const title = normalizeText(element.getAttribute("title"));

      return (
        (rememberedSmartThing.ariaLabel && aria === rememberedSmartThing.ariaLabel) ||
        (rememberedSmartThing.title && title === rememberedSmartThing.title) ||
        (rememberedSmartThing.text && text === rememberedSmartThing.text)
      );
    });

    return match || all[rememberedSmartThing.index] || all[0] || null;
  };

  const findPanelOpenButton = () => {
    const selectors = [
      ".LGSmartThingSimpleCollapsedPanel",
      ".LGSTRoundButton.Enter",
      '[aria-label="Smarte Dinge"][role="button"]',
      '[title="Smarte Dinge"][role="button"]'
    ];

    for (const selector of selectors) {
      const element = QA(selector).find(isVisible);
      if (element) return element;
    }
    return null;
  };

  const getSmartThingHandle = async () => {
    let handle = null;

    try {
      handle = await waitFor(
        () => findSmartThingHandle(),
        10000,
        200,
        "Smart-Thing nach Kalender-Refresh"
      );
    } catch (_) {
      handle = null;
    }

    if (handle) return handle;

    const panelButton = findPanelOpenButton();
    if (panelButton) {
      console.log("[AUTO] Kein Smart Thing sichtbar. Öffne das Panel ...");
      clickGwt(panelButton);
      await sleep(1200);
    }

    handle = await waitFor(
      () => findSmartThingHandle(),
      45000,
      200,
      "Smart-Thing-Handle"
    );

    if (!rememberedSmartThing) rememberSmartThing(handle);
    return handle;
  };

  // ========================================================================
  // DROP-ZIELE UND AUTO-SCROLL
  // ========================================================================

  const getAllDropTargets = () =>
    QA(".SmartThingOverlayItem.dragdrop-dropTarget[aria-label]");

  const getDropTarget = (targetLabel) =>
    getAllDropTargets().find(
      (element) =>
        normalizeText(element.getAttribute("aria-label")) === normalizeText(targetLabel) &&
        isVisible(element)
    ) || null;

  const getVisibleTargetLabels = () =>
    getAllDropTargets()
      .filter(isInViewport)
      .map((element) => normalizeText(element.getAttribute("aria-label")))
      .filter(Boolean);

  const isPotentialVerticalScroller = (element) => {
    if (!element) return false;

    const scrollingElement = document.scrollingElement;
    if (
      element === document.documentElement ||
      element === document.body ||
      element === scrollingElement
    ) {
      return Boolean(
        scrollingElement &&
        scrollingElement.scrollHeight > scrollingElement.clientHeight + 20
      );
    }

    if (!element.isConnected) return false;
    const rect = element.getBoundingClientRect();

    return (
      element.scrollHeight > element.clientHeight + 20 &&
      rect.width > window.innerWidth * 0.35 &&
      rect.height > 180
    );
  };

  const getScrollableAncestors = (element) => {
    const results = [];
    let current = element;

    while (current) {
      if (isPotentialVerticalScroller(current)) results.push(current);
      current = current.parentElement;
    }

    return results;
  };

  const addUnique = (array, element) => {
    if (element && !array.includes(element)) array.push(element);
  };

  const getScrollCandidates = () => {
    const candidates = [];
    const probeX = clamp(window.innerWidth * 0.62, 350, window.innerWidth - 120);
    const probeY = clamp(window.innerHeight * 0.62, 180, window.innerHeight - 100);
    const probeElement = document.elementFromPoint(probeX, probeY);

    for (const ancestor of getScrollableAncestors(probeElement)) {
      addUnique(candidates, ancestor);
    }

    for (const target of getAllDropTargets()) {
      for (const ancestor of getScrollableAncestors(target)) {
        addUnique(candidates, ancestor);
      }
    }

    const likelyElements = QA(
      '[class*="Calendar"], [class*="calendar"], [class*="Scroll"], ' +
      '[class*="scroll"], [class*="Zeitdaten"], [class*="zeitdaten"]'
    );

    for (const element of likelyElements) {
      if (isPotentialVerticalScroller(element)) addUnique(candidates, element);
      for (const ancestor of getScrollableAncestors(element)) {
        addUnique(candidates, ancestor);
      }
    }

    for (const element of QA("body *")) {
      if (isPotentialVerticalScroller(element)) addUnique(candidates, element);
    }

    addUnique(candidates, document.scrollingElement);

    return candidates.filter(Boolean).sort((a, b) => {
      const score = (element) => {
        if (element === document.scrollingElement) return 1000;
        const rect = element.getBoundingClientRect();
        return (
          rect.width * rect.height +
          (element.scrollHeight - element.clientHeight) * 200
        );
      };
      return score(b) - score(a);
    });
  };

  const getScrollTop = (element) => {
    if (
      element === document.scrollingElement ||
      element === document.documentElement ||
      element === document.body
    ) {
      return window.scrollY;
    }
    return element.scrollTop;
  };

  const getMaximumScrollTop = (element) => {
    if (
      element === document.scrollingElement ||
      element === document.documentElement ||
      element === document.body
    ) {
      return Math.max(
        0,
        (document.scrollingElement?.scrollHeight || 0) - window.innerHeight
      );
    }
    return Math.max(0, element.scrollHeight - element.clientHeight);
  };

  const setScrollTop = (element, value) => {
    const targetValue = clamp(value, 0, getMaximumScrollTop(element));

    if (
      element === document.scrollingElement ||
      element === document.documentElement ||
      element === document.body
    ) {
      window.scrollTo({ top: targetValue, left: window.scrollX, behavior: "auto" });
    } else {
      element.scrollTop = targetValue;
      element.dispatchEvent(new Event("scroll", { bubbles: true }));
    }
  };

  const describeScrollContainer = (element) => {
    if (element === document.scrollingElement) return "Dokument";
    const id = normalizeText(element.id);
    const className = normalizeText(element.className);
    return (
      element.tagName +
      (id ? `#${id}` : "") +
      (className ? `.${className.split(" ").slice(0, 3).join(".")}` : "")
    );
  };

  const parseOverlayDate = (label, targetDate) => {
    const match = normalizeText(label).match(
      /^(Sonntag|Montag|Dienstag|Mittwoch|Donnerstag|Freitag|Samstag)\s+(\d{1,2})\s+([A-Za-zÄÖÜäöüß]+)$/
    );
    if (!match) return null;

    const day = Number(match[2]);
    const monthIndex = MONTHS.findIndex(
      (month) => month.toLowerCase() === normalizeText(match[3]).toLowerCase()
    );
    if (monthIndex < 0) return null;

    let year = targetDate.getFullYear();
    let parsed = new Date(year, monthIndex, day, 12, 0, 0, 0);
    const difference = parsed.getTime() - targetDate.getTime();
    const halfYear = 183 * 24 * 60 * 60 * 1000;

    if (difference > halfYear) year -= 1;
    else if (difference < -halfYear) year += 1;

    return new Date(year, monthIndex, day, 12, 0, 0, 0);
  };

  const determinePreferredDirection = (targetDate) => {
    const dates = getVisibleTargetLabels()
      .map((label) => parseOverlayDate(label, targetDate))
      .filter(Boolean)
      .sort((a, b) => a.getTime() - b.getTime());

    if (!dates.length) return 1;
    if (targetDate.getTime() > dates[dates.length - 1].getTime()) return 1;
    if (targetDate.getTime() < dates[0].getTime()) return -1;
    return 1;
  };

  const moveDragCursorToEdge = (direction, scrollContainer) => {
    const rect =
      scrollContainer === document.scrollingElement
        ? {
            left: 0,
            top: 0,
            right: window.innerWidth,
            bottom: window.innerHeight,
            width: window.innerWidth,
            height: window.innerHeight
          }
        : scrollContainer.getBoundingClientRect();

    const x = clamp(rect.left + rect.width * 0.65, 350, window.innerWidth - 100);
    const y =
      direction > 0
        ? clamp(rect.bottom - AUTO_SCROLL_EDGE_MARGIN, 100, window.innerHeight - 20)
        : clamp(rect.top + AUTO_SCROLL_EDGE_MARGIN, 20, window.innerHeight - 100);

    fireMouseEvent(document, "mousemove", {
      clientX: x,
      clientY: y,
      button: 0,
      buttons: 1
    });
    fireMouseEvent(scrollContainer, "mousemove", {
      clientX: x,
      clientY: y,
      button: 0,
      buttons: 1
    });

    return { x, y };
  };

  const scrollOneStepWhileDragging = async (scrollContainer, direction) => {
    const before = getScrollTop(scrollContainer);
    const maximum = getMaximumScrollTop(scrollContainer);

    if (direction > 0 && before >= maximum - 2) return false;
    if (direction < 0 && before <= 2) return false;

    const cursor = moveDragCursorToEdge(direction, scrollContainer);
    const delta = direction * AUTO_SCROLL_STEP_PX;

    fireWheelEvent(scrollContainer, delta, cursor.x, cursor.y);
    setScrollTop(scrollContainer, before + delta);
    await sleep(AUTO_SCROLL_WAIT_MS);

    return Math.abs(getScrollTop(scrollContainer) - before) > 1;
  };

  const restoreScrollPositions = async (positions) => {
    for (const [element, position] of positions.entries()) {
      setScrollTop(element, position);
    }
    await sleep(AUTO_SCROLL_WAIT_MS);
  };

  const bringTargetIntoViewport = async (targetLabel) => {
    let target = getDropTarget(targetLabel);
    if (!target) return null;

    if (!isInViewport(target)) {
      target.scrollIntoView?.({
        block: "center",
        inline: "nearest",
        behavior: "auto"
      });
      await sleep(AUTO_SCROLL_WAIT_MS);
      target = getDropTarget(targetLabel);
    }

    return target;
  };

  const getTargetLabelSignature = () =>
    getVisibleTargetLabels().join("|");

  const scrollOneStepWithoutDrag = async (scrollContainer, direction) => {
    const before = getScrollTop(scrollContainer);
    const maximum = getMaximumScrollTop(scrollContainer);

    if (direction > 0 && before >= maximum - 2) return false;
    if (direction < 0 && before <= 2) return false;

    const rect =
      scrollContainer === document.scrollingElement
        ? {
            left: 0,
            top: 0,
            right: window.innerWidth,
            bottom: window.innerHeight,
            width: window.innerWidth,
            height: window.innerHeight
          }
        : scrollContainer.getBoundingClientRect();

    const x = clamp(
      rect.left + rect.width * 0.65,
      350,
      window.innerWidth - 100
    );

    const y = clamp(
      rect.top + rect.height * 0.55,
      80,
      window.innerHeight - 80
    );

    const delta = direction * AUTO_SCROLL_STEP_PX;

    // Das Wheel-Event informiert LOGA/GWT über die beabsichtigte Bewegung.
    fireWheelEvent(scrollContainer, delta, x, y);
    await sleep(60);

    // Synthetische Wheel-Events scrollen Browser nicht immer selbst.
    // Deshalb wird scrollTop als Rückfallebene explizit gesetzt.
    if (Math.abs(getScrollTop(scrollContainer) - before) < 1) {
      setScrollTop(scrollContainer, before + delta);
    }

    await sleep(AUTO_SCROLL_WAIT_MS + 250);

    return Math.abs(getScrollTop(scrollContainer) - before) > 1;
  };

  const startFreshDragState = async () => {
    await ensureNoBookingPopup();

    let handle = await getSmartThingHandle();
    let startPoint = await startDrag(handle);

    // Dem GWT-Overlay Zeit geben, seine Datumsziele neu aufzubauen.
    await sleep(450);

    return { handle, startPoint };
  };

  const findDropTargetWithRestartedScroll = async (
    targetLabel,
    targetDate,
    initialHandle,
    initialStartPoint
  ) => {
    let state = {
      handle: initialHandle,
      startPoint: initialStartPoint
    };

    let target = await bringTargetIntoViewport(targetLabel);

    if (target && isInViewport(target)) {
      console.log("[AUTO] ✓ Drop-Ziel ohne Scrollen gefunden");
      return { ...state, target };
    }

    const candidates = getScrollCandidates();

    if (!candidates.length) {
      await cancelDragSafely(state.handle);
      throw new Error(
        "Es wurde kein vertikal scrollbarer Kalenderbereich gefunden."
      );
    }

    console.log(
      "[AUTO] Drop-Ziel nicht sichtbar. Starte robusten Scroll-Neustart ..."
    );
    console.log(
      "[AUTO] Scroll-Bereiche:",
      candidates.slice(0, 6).map(describeScrollContainer)
    );

    const originalPositions = new Map(
      candidates.map((candidate) => [
        candidate,
        getScrollTop(candidate)
      ])
    );

    const preferredDirection = determinePreferredDirection(targetDate);
    const directions = [preferredDirection, -preferredDirection];

    for (
      let directionIndex = 0;
      directionIndex < directions.length;
      directionIndex++
    ) {
      const direction = directions[directionIndex];

      if (directionIndex > 0) {
        console.log(
          "[AUTO] Kehre für die Gegenrichtung zur Ausgangsposition zurück ..."
        );

        await cancelDragSafely(state.handle);
        await restoreScrollPositions(originalPositions);
        state = await startFreshDragState();
      }

      console.log(
        direction > 0
          ? "[AUTO] Suche nach unten ..."
          : "[AUTO] Suche nach oben ..."
      );

      let activeContainer = null;
      let currentSignature = getTargetLabelSignature();

      for (
        let step = 1;
        step <= AUTO_SCROLL_MAX_STEPS_PER_DIRECTION;
        step++
      ) {
        target = await bringTargetIntoViewport(targetLabel);

        if (target && isInViewport(target)) {
          console.log(`[AUTO] ✓ '${targetLabel}' gefunden`);
          return { ...state, target };
        }

        // ---------------------------------------------------------------
        // Bereits bestätigten Kalender-Scroller einen Schritt bewegen.
        // ---------------------------------------------------------------
        if (activeContainer) {
          const positionBeforeStep = getScrollTop(activeContainer);

          await cancelDragSafely(state.handle);

          const moved = await scrollOneStepWithoutDrag(
            activeContainer,
            direction
          );

          state = await startFreshDragState();

          const newSignature = getTargetLabelSignature();

          target = await bringTargetIntoViewport(targetLabel);

          if (target && isInViewport(target)) {
            console.log(`[AUTO] ✓ '${targetLabel}' gefunden`);
            return { ...state, target };
          }

          if (!moved || newSignature === currentSignature) {
            console.warn(
              "[AUTO] Der bestätigte Scrollbereich verändert die sichtbaren Datumsziele nicht mehr."
            );

            await cancelDragSafely(state.handle);
            setScrollTop(activeContainer, positionBeforeStep);
            await sleep(AUTO_SCROLL_WAIT_MS);
            state = await startFreshDragState();

            activeContainer = null;
            currentSignature = getTargetLabelSignature();
            continue;
          }

          currentSignature = newSignature;

          console.log(
            `[AUTO] Scroll-Suche Schritt ${step}/` +
            `${AUTO_SCROLL_MAX_STEPS_PER_DIRECTION} in ` +
            describeScrollContainer(activeContainer)
          );

          continue;
        }

        // ---------------------------------------------------------------
        // Scrollbereiche testen. Ein Bereich wird nur akzeptiert, wenn
        // nach Scrollen + neuem Drag andere Datumsziele sichtbar sind.
        // ---------------------------------------------------------------
        let matchingContainerFound = false;

        for (const candidate of candidates) {
          const positionBeforeTest = getScrollTop(candidate);
          const signatureBeforeTest = currentSignature;

          await cancelDragSafely(state.handle);

          const moved = await scrollOneStepWithoutDrag(
            candidate,
            direction
          );

          state = await startFreshDragState();

          const signatureAfterTest = getTargetLabelSignature();

          target = await bringTargetIntoViewport(targetLabel);

          if (target && isInViewport(target)) {
            console.log(`[AUTO] ✓ '${targetLabel}' gefunden`);
            return { ...state, target };
          }

          if (
            moved &&
            signatureAfterTest &&
            signatureAfterTest !== signatureBeforeTest
          ) {
            activeContainer = candidate;
            currentSignature = signatureAfterTest;
            matchingContainerFound = true;

            console.log(
              "[AUTO] Richtiger Kalender-Scrollbereich erkannt:",
              describeScrollContainer(candidate)
            );

            break;
          }

          // Falscher Scrollbereich: Position wieder zurücksetzen.
          await cancelDragSafely(state.handle);
          setScrollTop(candidate, positionBeforeTest);
          await sleep(AUTO_SCROLL_WAIT_MS);
          state = await startFreshDragState();
          currentSignature = getTargetLabelSignature();
        }

        if (!matchingContainerFound) {
          console.warn(
            "[AUTO] Kein Scrollbereich hat die sichtbaren Datumsziele verändert."
          );
          break;
        }
      }
    }

    const lastLabels = getVisibleTargetLabels();

    await cancelDragSafely(state.handle);
    await restoreScrollPositions(originalPositions);

    throw new Error(
      `Das Datum '${targetLabel}' wurde auch nach dem robusten ` +
      `Scroll-Neustart nicht gefunden.\n\n` +
      `Zuletzt sichtbare Ziele:\n` +
      `${lastLabels.join("\n") || "Keine"}`
    );
  };

  // ========================================================================
  // BEREITS GESETZTE TAGE ERKENNEN
  // ========================================================================

  const BOOKING_MARKER_REGEX =
    /(?:^|\s)(?:KO|GE)\s*\d{1,2}:\d{2}\b|\bKommen\b|\bGehen\b|Pause\s*(?:Anfang|Ende)|Arbeitszeit\s*[1-9]\d*\s*h/i;

  const getElementEvidenceText = (element) =>
    normalizeText(
      [
        element.textContent,
        element.getAttribute?.("aria-label"),
        element.getAttribute?.("title"),
        element.getAttribute?.("data-original-title"),
        element.getAttribute?.("data-tooltip")
      ]
        .filter(Boolean)
        .join(" ")
    );

  const verticallyOverlaps = (firstRect, secondRect) => {
    const overlap =
      Math.min(firstRect.bottom, secondRect.bottom) -
      Math.max(firstRect.top, secondRect.top);
    return overlap >= Math.min(8, secondRect.height * 0.25);
  };

  const getExistingBookingEvidence = (target) => {
    if (!target || !target.isConnected) return [];

    const targetRect = target.getBoundingClientRect();
    const calendarContentStart =
      targetRect.left + Math.max(110, targetRect.width * 0.08);

    const evidence = [];
    const seen = new Set();

    for (const element of QA('div, span, td, label, [role="button"], [aria-label], [title]')) {
      if (!isVisible(element) || element === target) continue;
      if (target.contains(element) || element.contains(target)) continue;
      if (
        element.closest(
          '.SmartThingOverlayItem, .LGMaskPartPopup-Content, [data-uin^="smartthing-"]'
        )
      ) {
        continue;
      }

      const rect = element.getBoundingClientRect();
      if (!verticallyOverlaps(rect, targetRect)) continue;
      if (rect.height > targetRect.height * 1.9) continue;
      if (rect.width < 20 || rect.height < 8) continue;
      if (rect.right <= calendarContentStart) continue;
      if (rect.left >= targetRect.right + 5 || rect.right <= targetRect.left) continue;

      const text = getElementEvidenceText(element);
      if (!text || !BOOKING_MARKER_REGEX.test(text)) continue;

      const key = `${text}|${Math.round(rect.left)}|${Math.round(rect.top)}|${Math.round(rect.width)}`;
      if (seen.has(key)) continue;
      seen.add(key);

      evidence.push({ text });
      if (evidence.length >= 10) break;
    }

    return evidence;
  };

  const detectExistingBooking = async (target, targetLabel) => {
    await sleep(350);

    for (let attempt = 1; attempt <= 3; attempt++) {
      const currentTarget = getDropTarget(targetLabel) || target;
      const evidence = getExistingBookingEvidence(currentTarget);
      if (evidence.length) return { booked: true, evidence };
      if (attempt < 3) await sleep(250);
    }

    return { booked: false, evidence: [] };
  };

  // ========================================================================
  // DRAG SICHER ABBRECHEN – ESCAPE VOR MOUSEUP, NIE AUF DEM ZIEL LOSLASSEN
  // ========================================================================

  const cancelDragSafely = async (handle) => {
    /*
     * Wichtig:
     * - Zuerst Escape, damit LOGA den Drag intern verwirft.
     * - Danach Mouseup ohne weiteres Ziehen.
     * - Kein Mousemove mit buttons: 1 mehr. Genau dieses Zurückziehen konnte
     *   in LOGA versehentlich ein Popup öffnen und den GWT-"vo"-Fehler auslösen.
     */
    pressEscape();
    await sleep(140);

    const safePoint =
      handle && isVisible(handle)
        ? centerOf(handle)
        : {
            x: Math.max(20, window.innerWidth - 20),
            y: 20
          };

    if (handle) {
      fireMouseEvent(handle, "mouseup", {
        clientX: safePoint.x,
        clientY: safePoint.y,
        button: 0,
        buttons: 0
      });
    }

    fireMouseEvent(document, "mouseup", {
      clientX: safePoint.x,
      clientY: safePoint.y,
      button: 0,
      buttons: 0
    });

    fireMouseEvent(document.body, "mouseup", {
      clientX: safePoint.x,
      clientY: safePoint.y,
      button: 0,
      buttons: 0
    });

    pressEscape();
    await sleep(450);

    const closed = await closeBookingPopupIfPresent(
      "nach sicherem Drag-Abbruch"
    );

    if (!closed) {
      throw new Error(
        "Der Drag wurde abgebrochen, aber ein versehentlich geöffnetes " +
        "Popup konnte nicht geschlossen werden."
      );
    }

    await sleep(400);
  };

  // ========================================================================
  // DRAG STARTEN UND POPUP ÖFFNEN
  // ========================================================================

  const startDrag = async (handle) => {
    handle.scrollIntoView?.({ block: "center", inline: "center" });
    await sleep(250);

    const startPoint = centerOf(handle);

    fireMouseEvent(handle, "mouseover", {
      clientX: startPoint.x,
      clientY: startPoint.y
    });
    await sleep(50);
    fireMouseEvent(handle, "mouseenter", {
      clientX: startPoint.x,
      clientY: startPoint.y
    });
    await sleep(50);
    fireMouseEvent(handle, "mousedown", {
      clientX: startPoint.x,
      clientY: startPoint.y,
      button: 0,
      buttons: 1
    });
    await sleep(180);

    for (const distance of [10, 25, 45, 70, 100, 140, 190]) {
      fireMouseEvent(document, "mousemove", {
        clientX: startPoint.x - distance,
        clientY: startPoint.y - distance,
        button: 0,
        buttons: 1
      });
      await sleep(80);
    }

    await sleep(500);
    return startPoint;
  };

  const waitForBookingPopupQuietly = async (timeout = 2500) => {
    const startedAt = Date.now();

    while (Date.now() - startedAt < timeout) {
      const popup = getVisibleBookingPopup();
      if (popup) return popup;
      await sleep(100);
    }

    return null;
  };

  const dropOnTarget = async (handle, startPoint, targetLabel, target) => {
    target = getDropTarget(targetLabel) || target;
    const targetPoint = centerOf(target);

    for (let step = 1; step <= 12; step++) {
      const progress = step / 12;

      fireMouseEvent(document, "mousemove", {
        clientX: startPoint.x + (targetPoint.x - startPoint.x) * progress,
        clientY: startPoint.y + (targetPoint.y - startPoint.y) * progress,
        button: 0,
        buttons: 1
      });

      await sleep(60);
    }

    target = getDropTarget(targetLabel) || target;
    const finalPoint = centerOf(target);

    for (const type of ["mousemove", "mouseover", "mouseenter"]) {
      fireMouseEvent(target, type, {
        clientX: finalPoint.x,
        clientY: finalPoint.y,
        button: 0,
        buttons: 1
      });
    }

    await sleep(200);

    // Der echte Drop reicht in LOGA normalerweise bereits zum Öffnen des Popups.
    fireMouseEvent(target, "mouseup", {
      clientX: finalPoint.x,
      clientY: finalPoint.y,
      button: 0,
      buttons: 0
    });

    fireMouseEvent(document, "mouseup", {
      clientX: finalPoint.x,
      clientY: finalPoint.y,
      button: 0,
      buttons: 0
    });

    fireMouseEvent(handle, "mouseup", {
      clientX: finalPoint.x,
      clientY: finalPoint.y,
      button: 0,
      buttons: 0
    });

    // Nicht sofort zusätzlich klicken. Der Doppelimpuls hat in LOGA den
    // GWT-Fehler "Cannot read properties of null (reading 'vo')" ausgelöst.
    let popup = await waitForBookingPopupQuietly(3000);

    if (popup) {
      console.log("[AUTO] ✓ Popup wurde direkt durch den Drop geöffnet.");
      return popup;
    }

    // Nur falls der reine Drop kein Popup geöffnet hat, genau einen Click senden.
    console.warn(
      "[AUTO] Popup nach dem Drop noch nicht sichtbar. Sende einmaligen Click-Fallback ..."
    );

    target = getDropTarget(targetLabel) || target;

    if (!target || !target.isConnected) {
      throw new Error(
        `Das Drop-Ziel '${targetLabel}' ist vor dem Click-Fallback verschwunden.`
      );
    }

    const clickPoint = centerOf(target);

    fireMouseEvent(target, "click", {
      clientX: clickPoint.x,
      clientY: clickPoint.y,
      button: 0,
      buttons: 0
    });

    popup = await waitForBookingPopupQuietly(3000);
    return popup;
  };

  const openPopupForDate = async (date) => {
    const targetLabel = createTargetLabel(date);

    console.log("");
    console.log("[AUTO] ═══════════════════════════════════════════════════");
    console.log("[AUTO] Prüfe:", targetLabel);

    // Nicht mehr 45 Sekunden passiv warten: ein altes Popup aktiv schließen.
    await ensureNoBookingPopup();

    console.log("[AUTO] Warte auf das Smart-Thing-Handle ...");
    const handle = await getSmartThingHandle();
    console.log(
      "[AUTO] ✓ Smart-Thing gefunden:",
      handle.getAttribute("data-uin") || "(ohne data-uin)"
    );

    console.log("[AUTO] Aktiviere Drag-and-Drop-Overlay ...");
    const startPoint = await startDrag(handle);

    let target;

    try {
      const searchResult = await findDropTargetWithRestartedScroll(
        targetLabel,
        date,
        handle,
        startPoint
      );

      handle = searchResult.handle;
      startPoint = searchResult.startPoint;
      target = searchResult.target;
    } catch (error) {
      // Die Suchfunktion beendet ihren letzten Drag bereits selbst.
      pressEscape();
      await closeBookingPopupIfPresent(
        "nach fehlgeschlagener Datumssuche"
      );
      throw error;
    }

    if (SKIP_ALREADY_BOOKED_DAYS) {
      const existing = await detectExistingBooking(target, targetLabel);

      if (existing.booked) {
        // Wichtig: NICHT mehr am Kalendertag loslassen.
        await cancelDragSafely(handle);

        console.warn(
          `[AUTO] ↷ ${targetLabel} ist bereits gebucht und wird übersprungen.`
        );
        console.warn(
          "[AUTO] Erkannte Buchung:",
          existing.evidence.map((item) => item.text)
        );

        return {
          label: targetLabel,
          skipped: true,
          evidence: existing.evidence,
          popup: null
        };
      }

      console.log(`[AUTO] ✓ ${targetLabel} ist noch nicht gebucht.`);
    }

    console.log("[AUTO] Führe Drop aus ...");
    const popupFromDrop = await dropOnTarget(
      handle,
      startPoint,
      targetLabel,
      target
    );

    console.log("[AUTO] Warte auf Eingabe-Popup ...");
    const popup =
      popupFromDrop ||
      (await waitFor(
        () => getVisibleBookingPopup(),
        30000,
        200,
        `Zeitbuchungs-Popup für '${targetLabel}'`
      ));

    console.log("[AUTO] ✓ Popup geöffnet:", targetLabel);

    return {
      label: targetLabel,
      skipped: false,
      evidence: [],
      popup
    };
  };

  // ========================================================================
  // ZWEITE SICHERUNG: IM POPUP ERKENNEN, OB SCHON ZEITEN VORHANDEN SIND
  // ========================================================================

  const getVisibleTimeBoxes = (popup) =>
    QA("input.gwt-TimeBox", popup).filter(isVisible);

  const isMeaningfulTimeValue = (value) => {
    const normalized = normalizeText(value);

    // Leere Werte und der von LOGA teilweise als Platzhalter verwendete
    // Wert 00:00 gelten NICHT als Beweis für eine vorhandene Buchung.
    if (!normalized || normalized === "00:00") return false;

    return /^(?:[01]?\d|2[0-3]):[0-5]\d$/.test(normalized);
  };

  const getPopupBookingType = (timeBox) => {
    const row =
      timeBox.closest("tr") ||
      timeBox.closest(".Personal-CalendarPopup-GridRow") ||
      timeBox.parentElement;

    if (!row) return "";

    const evidenceText = normalizeText(
      [
        row.textContent,
        row.getAttribute?.("aria-label"),
        row.getAttribute?.("title"),
        ...QA("[aria-label], [title]", row).flatMap((element) => [
          element.getAttribute("aria-label"),
          element.getAttribute("title")
        ])
      ]
        .filter(Boolean)
        .join(" ")
    );

    const match = evidenceText.match(
      /\b(Kommen|Gehen|Pause\s+Anfang|Pause\s+Ende)\b/i
    );

    return match ? normalizeText(match[1]) : "";
  };

  const inspectPopupForExistingBookings = async (popup) => {
    /*
     * Alte fehlerhafte Regel:
     *   boxes.length > 1 || values.some(Boolean)
     *
     * Dadurch wurde bereits ein einzelner LOGA-Standard-/Platzhalterwert
     * als vorhandene Buchung gewertet. Genau deshalb wurden Mittwoch und
     * Freitag fälschlich übersprungen.
     *
     * Neue Regel:
     *   Nur mindestens ZWEI echte, sinnvolle Uhrzeiten gelten als starke
     *   Popup-Bestätigung einer bereits vorhandenen Buchung.
     */
    await sleep(700);

    let lastSnapshot = null;

    for (let attempt = 1; attempt <= 3; attempt++) {
      const boxes = getVisibleTimeBoxes(popup);

      const entries = boxes.map((box) => {
        const value = normalizeText(box.value);

        return {
          value,
          meaningful: isMeaningfulTimeValue(value),
          type: getPopupBookingType(box)
        };
      });

      const meaningfulEntries = entries.filter((entry) => entry.meaningful);
      const typedMeaningfulEntries = meaningfulEntries.filter(
        (entry) => entry.type
      );

      // Zwei vorhandene, typisierte Uhrzeiten sind eindeutig.
      // Drei echte Uhrzeiten reichen ebenfalls als starke Bestätigung.
      const booked =
        typedMeaningfulEntries.length >= 2 ||
        meaningfulEntries.length >= 3;

      lastSnapshot = {
        booked,
        evidence: meaningfulEntries.map(
          (entry) =>
            entry.type
              ? `${entry.type}: ${entry.value}`
              : `Zeit ${entry.value}`
        ),
        debug: entries
      };

      if (booked) return lastSnapshot;

      if (attempt < 3) await sleep(300);
    }

    console.log(
      "[AUTO] Popup-Prüfung: keine belastbare vorhandene Buchung erkannt.",
      lastSnapshot?.debug || []
    );

    return {
      booked: false,
      evidence: [],
      debug: lastSnapshot?.debug || []
    };
  };

  // ========================================================================
  // POPUP AUSFÜLLEN
  // ========================================================================

  const getRowForTimeBox = (timeBox) =>
    timeBox.closest("tr") ||
    timeBox.closest(".Personal-CalendarPopup-GridRow") ||
    timeBox.parentElement;

  const findArrowInRow = (row, popup) =>
    QA(".combo-box-action-icon.ic-navigationdown", row).find(isVisible) ||
    QA(".combo-box-action-icon.ic-navigationdown", popup).find(isVisible) ||
    null;

  const findPlusInRow = (row, popup) => {
    const selector =
      'span.LG-Icon.ic-add[data-uin="ic-add"], .LG-Icon.ic-add';
    return QA(selector, row).find(isVisible) || QA(selector, popup).find(isVisible) || null;
  };

  const chooseFromDropdown = async (optionText) => {
    const option = await waitFor(
      () =>
        QA(".gwt-combo-box-option-cell")
          .filter(isVisible)
          .find(
            (element) =>
              normalizeText(element.textContent) === normalizeText(optionText)
          ) || null,
      15000,
      150,
      `Dropdown-Option '${optionText}'`
    );

    clickGwt(option);
    await sleep(350);
  };

  const setBookingRow = async (timeBox, popup, bookingType, time) => {
    const row = getRowForTimeBox(timeBox);
    if (!row) throw new Error(`Zeile für '${bookingType}' wurde nicht gefunden.`);

    const arrow = findArrowInRow(row, popup);
    if (!arrow) {
      throw new Error(`Dropdown-Pfeil für '${bookingType}' wurde nicht gefunden.`);
    }

    clickGwt(arrow);
    await chooseFromDropdown(bookingType);
    setInputValue(timeBox, time);
    await sleep(300);

    console.log(`[AUTO]   ${bookingType}: ${time}`);
  };

  const addNewBookingRow = async (timeBox, popup, expectedRowCount) => {
    const row = getRowForTimeBox(timeBox);
    if (!row) throw new Error("Zeile für den Plus-Button wurde nicht gefunden.");

    const plus = findPlusInRow(row, popup);
    if (!plus) {
      throw new Error("Plus-Button zum Hinzufügen einer Buchung wurde nicht gefunden.");
    }

    clickGwt(plus);

    await waitFor(
      () => getVisibleTimeBoxes(popup).length === expectedRowCount,
      15000,
      150,
      `Erstellen von Buchungszeile ${expectedRowCount}`
    );

    await sleep(250);
  };

  // ========================================================================
  // SPEICHERN – ROBUST GEGEN LOGA-REFRESH
  // ========================================================================

  const findConfirmButton = (popup) =>
    QA('[data-uin="btn-saveconfirm"]', popup).find(isVisible) ||
    QA('[data-uin="btn-saveconfirm"]').find(isVisible) ||
    QA('[role="button"], button, div', popup)
      .filter(isVisible)
      .find(
        (element) => normalizeText(element.textContent).toLowerCase() === "bestätigen"
      ) ||
    null;

  const getValidationText = (popup) => {
    if (!popup || !popup.isConnected) return "";
    const panel = popup.querySelector(".ValidationErrorsPanel");
    return panel ? normalizeText(panel.innerText) : "";
  };

  const confirmAndWaitForRefresh = async (popup) => {
    const confirmButton = findConfirmButton(popup);
    if (!confirmButton) throw new Error("Bestätigen-Button wurde nicht gefunden.");

    confirmButton.scrollIntoView?.({ block: "center", inline: "center" });
    console.log("[AUTO] Speichere Buchungen ...");
    clickGwt(confirmButton);

    const startedAt = Date.now();
    const timeout = 60000;
    let lastMessage = "";

    while (Date.now() - startedAt < timeout) {
      // Erfolg: Das konkrete Popup oder jedes Zeitbuchungs-Popup ist verschwunden.
      if (!popup.isConnected || !isVisible(popup) || !getVisibleBookingPopup()) {
        console.log("[AUTO] Popup geschlossen. Warte auf Kalender-Refresh ...");
        await sleep(3000);
        await ensureNoBookingPopup();
        console.log("[AUTO] ✓ Gespeichert und Refresh abgewartet");
        return;
      }

      const validationText = getValidationText(popup);
      if (validationText && validationText !== lastMessage) {
        lastMessage = validationText;

        if (/fehler|nicht möglich|bitte korrigieren|ungültig/i.test(validationText)) {
          throw new Error("LOGA meldet einen Fehler:\n\n" + validationText);
        }

        console.warn("[AUTO] LOGA-Hinweis nach Bestätigen:\n" + validationText);
      }

      await sleep(250);
    }

    throw new Error(
      "Speichern wurde nicht abgeschlossen: Das Zeitbuchungs-Popup ist nach 60 Sekunden noch offen." +
      (lastMessage ? `\n\nLetzte LOGA-Meldung:\n${lastMessage}` : "")
    );
  };

  const fillDayWithPause = async (popup, startTime, pauseStart, pauseEnd, endTime) => {
    await waitFor(
      () => getVisibleTimeBoxes(popup).length === 1,
      15000,
      150,
      "Erste leere Buchungszeile"
    );

    let timeBoxes = getVisibleTimeBoxes(popup);

    await setBookingRow(timeBoxes[0], popup, "Kommen", startTime);
    await addNewBookingRow(timeBoxes[0], popup, 2);

    timeBoxes = getVisibleTimeBoxes(popup);
    await setBookingRow(timeBoxes[1], popup, "Pause Anfang", pauseStart);
    await addNewBookingRow(timeBoxes[1], popup, 3);

    timeBoxes = getVisibleTimeBoxes(popup);
    await setBookingRow(timeBoxes[2], popup, "Pause Ende", pauseEnd);
    await addNewBookingRow(timeBoxes[2], popup, 4);

    timeBoxes = getVisibleTimeBoxes(popup);
    await setBookingRow(timeBoxes[3], popup, "Gehen", endTime);

    await confirmAndWaitForRefresh(popup);
  };

  // ========================================================================
  // HAUPTABLAUF
  // ========================================================================

  const completedDays = [];
  const skippedDays = [];

  try {
    if (!Number.isInteger(START_INDEX) || START_INDEX < 0 || START_INDEX > 4) {
      throw new Error(`Ungültiger START_INDEX: ${START_INDEX}. Erlaubt sind 0 bis 4.`);
    }

    console.log("════════════════════════════════════════════════════════════");
    console.log("  LOGA 40H – AUTO-SCROLL + SICHERES ÜBERSPRINGEN");
    console.log("════════════════════════════════════════════════════════════");
    console.log("Zieldaten:", targetDates.map(formatShortDate).join(", "));
    console.log("Zeitplan: Montag bis Freitag 09:00–12:00 / 13:00–18:00");
    console.log("Gesamt: 40h netto");
    console.log("[AUTO] Bereits gebuchte Tage werden automatisch übersprungen.");

    for (let index = START_INDEX; index < targetDates.length; index++) {
      const date = targetDates[index];
      const endTime = calculateEndTime(START_TIME, PLAN_HOURS_GROSS[index]);
      const result = await openPopupForDate(date);

      if (result.skipped) {
        skippedDays.push(result.label);
        continue;
      }

      // Zusätzliche Prüfung im Popup, falls die Kalender-Erkennung etwas übersehen hat.
      const popupExisting = await inspectPopupForExistingBookings(result.popup);
      if (SKIP_ALREADY_BOOKED_DAYS && popupExisting.booked) {
        console.warn(
          `[AUTO] ↷ ${result.label} enthält bereits Buchungszeiten im Popup und wird übersprungen.`
        );

        const closed = await closeBookingPopupIfPresent("bereits gesetzter Tag");
        if (!closed) {
          throw new Error(
            `Das Popup für '${result.label}' konnte nach der Überspring-Erkennung nicht geschlossen werden.`
          );
        }

        skippedDays.push(result.label);
        await sleep(1000);
        continue;
      }

      console.log(
        `[AUTO] Fülle ${result.label}: ${START_TIME}–${PAUSE_START}, ` +
        `${PAUSE_END}–${endTime}`
      );

      await fillDayWithPause(
        result.popup,
        START_TIME,
        PAUSE_START,
        PAUSE_END,
        endTime
      );

      completedDays.push(result.label);
      console.log(`[AUTO] ✓ ${result.label} vollständig abgeschlossen`);
    }

    console.log("════════════════════════════════════════════════════════════");
    console.log("  ✓✓✓ ABLAUF ABGESCHLOSSEN ✓✓✓");
    console.log("════════════════════════════════════════════════════════════");
    console.log("[AUTO] Neu eingetragen:", completedDays);
    console.log("[AUTO] Übersprungen:", skippedDays);

    alert(
      "✓ Fertig!\n\n" +
      (completedDays.length
        ? "Neu eingetragen:\n" + completedDays.join("\n")
        : "Keine neuen Tage eingetragen.") +
      (skippedDays.length
        ? "\n\nBereits gesetzt und übersprungen:\n" + skippedDays.join("\n")
        : "") +
      "\n\nSollzeit: 09:00–12:00 / 13:00–18:00."
    );
  } catch (error) {
    console.error("════════════════════════════════════════════════════════════");
    console.error("  ✗ FEHLER");
    console.error("════════════════════════════════════════════════════════════");
    console.error(error.message);
    console.error("Stack:", error.stack);

    // Beim Fehler niemals einen Drag oder ein Popup offen lassen.
    pressEscape();
    await closeBookingPopupIfPresent("Fehlerbereinigung");

    alert(
      "✗ FEHLER:\n\n" +
      error.message +
      "\n\nBitte die Konsole für weitere Details prüfen."
    );
  } finally {
    window.__LOGA_40H_AUTOFILL_RUNNING__ = false;
  }
})();
