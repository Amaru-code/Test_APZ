LOGA 40H Fixed V3
==================

LOGA_40H_FIXED_V3.js
  Vollversion Montag bis Freitag. Bereits gesetzte Tage werden übersprungen.

LOGA_40H_FIXED_V3_FRIDAY_ONLY.js
  Soforttest nur für Freitag. START_INDEX ist bereits auf 4 gesetzt.

Wichtigster Fix:
  Der Kalender wird nicht mehr während eines aktiven Drag-Vorgangs gescrollt.
  Der Drag wird abgebrochen, der Kalender normal gescrollt und anschließend
  ein neuer Drag mit frisch aufgebautem Drop-Overlay gestartet.
