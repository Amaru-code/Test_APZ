@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Excel Master Merger

set "PYTHONW=%~dp0runtime\.venv\Scripts\pythonw.exe"

if not exist "%PYTHONW%" (
    echo Die lokale Installation fehlt und wird jetzt eingerichtet.
    echo.
    call "%~dp0INSTALL.bat"
    if errorlevel 1 exit /b 1
)

start "" "%PYTHONW%" "%~dp0app\Excel_Merger_GUI.py"
exit /b 0
