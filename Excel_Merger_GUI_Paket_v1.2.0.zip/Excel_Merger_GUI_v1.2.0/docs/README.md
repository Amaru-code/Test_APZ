# Excel Master Merger v1.2.0

Das Tool führt viele Excel-, CSV- und TXT-Dateien zu einer einzigen formatierten Excel-Tabelle zusammen.

## Neu in v1.2.0

- saubere Hauptstruktur mit nur `INSTALL.bat`, `START.bat` und Unterordnern
- automatische Erkennung des gemeinsamen Headers
- Header wird genau einmal ausgegeben
- Metadatenzeilen vor dem Header werden verworfen
- keine Herkunfts-, Größen-, Typ- oder Datumsinformationen in der Mastertabelle
- sichtbare Ladeanimation, Prozentfortschritt, aktueller Dateiname und Laufzeit
- Fehler einzelner Dateien werden protokolliert, ohne den gesamten Lauf zwingend abzubrechen

Die Bedienung ist in `ANLEITUNG.txt` beschrieben.
