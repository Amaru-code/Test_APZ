from __future__ import annotations

import csv
import math
import os
import queue
import re
import sys
import threading
import time
import traceback
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Callable, Iterator, Sequence

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
    from openpyxl import Workbook, load_workbook
    from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.worksheet.table import Table, TableStyleInfo
    from openpyxl.utils import get_column_letter
    OPENPYXL_IMPORT_ERROR: ImportError | None = None
except ImportError as exc:
    OPENPYXL_IMPORT_ERROR = exc

try:
    import xlrd
except ImportError:
    xlrd = None  # type: ignore[assignment]


APP_NAME = "Excel Master Merger"
APP_VERSION = "1.2.0"
SUPPORTED_EXTENSIONS = {".xlsx", ".xlsm", ".xls", ".csv", ".txt"}
OUTPUT_SHEET_NAME = "Gesamtdaten"
MAX_EXCEL_DATA_ROWS = 1_048_575
MAX_EXCEL_COLUMNS = 16_384
HEADER_SCAN_LIMIT = 150
ROW_STATUS_INTERVAL = 2_000

METADATA_HINTS = {
    "dateiname",
    "file name",
    "filename",
    "info",
    "information",
    "informationen",
    "größe",
    "groesse",
    "size",
    "typ",
    "type",
    "erstellungsdatum",
    "erstellt am",
    "creation date",
    "created",
    "geändert am",
    "geaendert am",
    "modified",
}


class MergeCancelled(Exception):
    """Wird ausgelöst, wenn der Benutzer den Merge abbricht."""


@dataclass
class HeaderCandidate:
    signature: tuple[str, ...]
    display_values: list[str]
    files: set[str] = field(default_factory=set)
    sheets: set[str] = field(default_factory=set)
    occurrences: int = 0
    positions: list[int] = field(default_factory=list)

    @property
    def non_empty_count(self) -> int:
        return sum(1 for value in self.signature if value)

    @property
    def alpha_ratio(self) -> float:
        values = [value for value in self.signature if value]
        if not values:
            return 0.0
        return sum(1 for value in values if any(char.isalpha() for char in value)) / len(values)

    @property
    def average_position(self) -> float:
        return sum(self.positions) / len(self.positions) if self.positions else 9999.0


@dataclass
class ScanResult:
    readable_files: list[Path]
    header_signature: tuple[str, ...]
    headers: list[str]
    data_rows: int
    errors: list[str]
    skipped_sheets: list[str]


ProgressCallback = Callable[[int, str, str], None]
LogCallback = Callable[[str], None]


def clean_text(value: object) -> str:
    if value is None:
        return ""

    if isinstance(value, datetime):
        if value.time().hour == 0 and value.time().minute == 0 and value.time().second == 0:
            text = value.strftime("%Y-%m-%d")
        else:
            text = value.strftime("%Y-%m-%d %H:%M:%S")
    elif isinstance(value, date):
        text = value.strftime("%Y-%m-%d")
    elif isinstance(value, bool):
        text = "WAHR" if value else "FALSCH"
    else:
        text = str(value)

    text = ILLEGAL_CHARACTERS_RE.sub("", text)
    return text.strip()


def protect_excel_text(value: str) -> str:
    if value.startswith("="):
        return "'" + value
    return value


def trim_trailing_empty(values: list[str]) -> list[str]:
    while values and values[-1] == "":
        values.pop()
    return values


def split_semicolon_record(text: str) -> list[str]:
    parsed = next(
        csv.reader(
            [text],
            delimiter=";",
            quotechar='"',
            skipinitialspace=False,
        )
    )
    return trim_trailing_empty([clean_text(value) for value in parsed])


def normalize_row(raw_values: Sequence[object]) -> list[str]:
    values = [clean_text(value) for value in raw_values]
    non_empty = [value for value in values if value != ""]

    # Exporte liegen häufig komplett semikolongetrennt in nur einer Excel-Zelle.
    if len(non_empty) == 1 and non_empty[0].count(";") >= 2:
        return split_semicolon_record(non_empty[0])

    return trim_trailing_empty(values)


def normalize_header_cell(value: str) -> str:
    value = re.sub(r"\s+", " ", clean_text(value)).strip().casefold()
    return value


def row_signature(values: Sequence[str]) -> tuple[str, ...]:
    normalized = [normalize_header_cell(value) for value in values]
    while normalized and normalized[-1] == "":
        normalized.pop()
    return tuple(normalized)


def make_unique_headers(values: Sequence[str]) -> list[str]:
    used: dict[str, int] = {}
    result: list[str] = []

    for index, raw_name in enumerate(values, start=1):
        base = re.sub(r"[\r\n\t]+", " ", clean_text(raw_name)).strip()
        if not base:
            base = f"Feld_{index:02d}"

        count = used.get(base, 0) + 1
        used[base] = count
        result.append(base if count == 1 else f"{base}_{count}")

    return result


def is_metadata_like(values: Sequence[str]) -> bool:
    non_empty = [normalize_header_cell(value) for value in values if clean_text(value)]
    if not non_empty:
        return True

    joined = " | ".join(non_empty)
    contains_hint = any(hint in joined for hint in METADATA_HINTS)

    # Typische Dateiinformationen stehen in schmalen Schlüssel/Wert-Zeilen.
    return contains_hint and len(non_empty) <= 8


def is_header_candidate(values: Sequence[str]) -> bool:
    non_empty = [value for value in values if clean_text(value)]
    if len(non_empty) < 2:
        return False
    if is_metadata_like(values):
        return False

    alpha_cells = sum(1 for value in non_empty if any(char.isalpha() for char in value))
    return alpha_cells >= max(2, math.ceil(len(non_empty) * 0.35))


def find_text_encoding(path: Path) -> str:
    for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin1"):
        try:
            with path.open("r", encoding=encoding, newline="") as handle:
                handle.read(65536)
            return encoding
        except UnicodeDecodeError:
            continue
    return "latin1"


def detect_delimiter(sample: str) -> str:
    if ";" in sample:
        return ";"
    if "\t" in sample:
        return "\t"
    if "|" in sample:
        return "|"
    return ","


def iter_text_rows(path: Path, per_sheet_limit: int | None = None) -> Iterator[tuple[str, int, list[str]]]:
    encoding = find_text_encoding(path)
    yielded = 0
    with path.open("r", encoding=encoding, newline="") as handle:
        sample = handle.read(65536)
        handle.seek(0)
        delimiter = detect_delimiter(sample)
        reader = csv.reader(handle, delimiter=delimiter, quotechar='"')
        for line_number, row in enumerate(reader, start=1):
            normalized = normalize_row(row)
            if not normalized:
                continue
            yield "Textdatei", line_number, normalized
            yielded += 1
            if per_sheet_limit is not None and yielded >= per_sheet_limit:
                break


def iter_xlsx_rows(
    path: Path,
    read_all_sheets: bool = True,
    per_sheet_limit: int | None = None,
) -> Iterator[tuple[str, int, list[str]]]:
    workbook = load_workbook(
        filename=path,
        read_only=True,
        data_only=True,
        keep_links=False,
    )
    try:
        worksheets = workbook.worksheets if read_all_sheets else workbook.worksheets[:1]
        for worksheet in worksheets:
            yielded = 0
            for row_number, row in enumerate(worksheet.iter_rows(values_only=True), start=1):
                normalized = normalize_row(row)
                if not normalized:
                    continue
                yield worksheet.title, row_number, normalized
                yielded += 1
                if per_sheet_limit is not None and yielded >= per_sheet_limit:
                    break
    finally:
        workbook.close()


def iter_xls_rows(
    path: Path,
    read_all_sheets: bool = True,
    per_sheet_limit: int | None = None,
) -> Iterator[tuple[str, int, list[str]]]:
    if xlrd is None:
        raise RuntimeError(
            "Für alte .xls-Dateien fehlt das Paket xlrd. Bitte INSTALL.bat erneut ausführen."
        )

    workbook = xlrd.open_workbook(str(path), on_demand=True)
    try:
        sheet_indices = range(workbook.nsheets) if read_all_sheets else range(min(1, workbook.nsheets))
        for sheet_index in sheet_indices:
            worksheet = workbook.sheet_by_index(sheet_index)
            yielded = 0
            for row_index in range(worksheet.nrows):
                normalized = normalize_row(worksheet.row_values(row_index))
                if not normalized:
                    continue
                yield worksheet.name, row_index + 1, normalized
                yielded += 1
                if per_sheet_limit is not None and yielded >= per_sheet_limit:
                    break
    finally:
        workbook.release_resources()


def iter_file_rows(
    path: Path,
    read_all_sheets: bool = True,
    per_sheet_limit: int | None = None,
) -> Iterator[tuple[str, int, list[str]]]:
    suffix = path.suffix.lower()
    if suffix in {".csv", ".txt"}:
        yield from iter_text_rows(path, per_sheet_limit)
    elif suffix in {".xlsx", ".xlsm"}:
        yield from iter_xlsx_rows(path, read_all_sheets, per_sheet_limit)
    elif suffix == ".xls":
        yield from iter_xls_rows(path, read_all_sheets, per_sheet_limit)
    else:
        raise ValueError(f"Nicht unterstütztes Dateiformat: {suffix}")


def choose_common_header(
    candidates: dict[tuple[str, ...], HeaderCandidate],
    readable_file_count: int,
) -> HeaderCandidate:
    if not candidates:
        raise ValueError(
            "Es konnte keine gemeinsame Kopfzeile erkannt werden. "
            "Bitte prüfen, ob die Dateien tatsächlich dieselbe Tabellenstruktur besitzen."
        )

    pool = [candidate for candidate in candidates.values() if candidate.non_empty_count >= 2]
    pool = [candidate for candidate in pool if not is_metadata_like(candidate.display_values)]
    if not pool:
        raise ValueError("Es wurde nur Datei-Metadaten, aber keine Datentabelle erkannt.")

    # Zuerst auf breite Zeilen eingrenzen. Dadurch gewinnen echte Tabellenköpfe
    # gegen wiederkehrende Zeilen wie 'Dateiname | ...' oder 'Typ | ...'.
    max_width = max(candidate.non_empty_count for candidate in pool)
    wide_threshold = max(3, math.ceil(max_width * 0.60))
    wide_pool = [candidate for candidate in pool if candidate.non_empty_count >= wide_threshold]
    if wide_pool:
        pool = wide_pool

    if readable_file_count >= 2:
        # Bei vielen Dateien ist die Wiederholung über unterschiedliche Dateien
        # das stärkste Kennzeichen einer gemeinsamen Kopfzeile.
        return max(
            pool,
            key=lambda candidate: (
                len(candidate.files),
                candidate.non_empty_count,
                candidate.alpha_ratio,
                -candidate.average_position,
            ),
        )

    # Fallback für eine einzelne Datei.
    return max(
        pool,
        key=lambda candidate: (
            candidate.non_empty_count,
            candidate.alpha_ratio,
            candidate.occurrences,
            -candidate.average_position,
        ),
    )


def detect_header(
    files: Sequence[Path],
    cancel_event: threading.Event,
    progress: ProgressCallback,
    log: LogCallback,
) -> tuple[list[Path], HeaderCandidate, list[str]]:
    candidates: dict[tuple[str, ...], HeaderCandidate] = {}
    readable_files: list[Path] = []
    errors: list[str] = []
    file_count = max(len(files), 1)

    for file_index, path in enumerate(files, start=1):
        if cancel_event.is_set():
            raise MergeCancelled()

        value = int((file_index - 1) / file_count * 32)
        progress(value, "Analysiere gemeinsame Kopfzeile", f"{file_index}/{len(files)} · {path.name}")
        log(f"[HEADER-SCAN] {path}")

        try:
            seen_sheet_positions: dict[str, int] = defaultdict(int)
            file_had_rows = False

            for sheet_name, _source_row, values in iter_file_rows(
                path,
                read_all_sheets=True,
                per_sheet_limit=HEADER_SCAN_LIMIT,
            ):
                if cancel_event.is_set():
                    raise MergeCancelled()

                file_had_rows = True
                seen_sheet_positions[sheet_name] += 1
                if not is_header_candidate(values):
                    continue

                signature = row_signature(values)
                if len(signature) < 2:
                    continue

                candidate = candidates.get(signature)
                if candidate is None:
                    candidate = HeaderCandidate(signature=signature, display_values=list(values))
                    candidates[signature] = candidate

                file_key = str(path.resolve()).casefold()
                sheet_key = f"{file_key}::{sheet_name.casefold()}"
                candidate.files.add(file_key)
                candidate.sheets.add(sheet_key)
                candidate.occurrences += 1
                candidate.positions.append(seen_sheet_positions[sheet_name])

            if file_had_rows:
                readable_files.append(path)
            else:
                errors.append(f"{path.name}: Datei enthält keine lesbaren Zeilen.")

        except MergeCancelled:
            raise
        except Exception as exc:
            error_text = f"{path.name}: {type(exc).__name__}: {exc}"
            errors.append(error_text)
            log(f"[ÜBERSPRUNGEN] {error_text}")

    if not readable_files:
        raise ValueError("Keine der ausgewählten Dateien konnte gelesen werden.")

    chosen = choose_common_header(candidates, len(readable_files))
    progress(
        33,
        "Gemeinsame Kopfzeile erkannt",
        f"{chosen.non_empty_count} Spalten · in {len(chosen.files)}/{len(readable_files)} Dateien gefunden",
    )
    log(
        f"[HEADER] {chosen.non_empty_count} Felder, "
        f"{len(chosen.files)}/{len(readable_files)} Dateien, Position Ø {chosen.average_position:.1f}"
    )
    return readable_files, chosen, errors


def signature_matches(values: Sequence[str], header_signature: tuple[str, ...]) -> bool:
    current = row_signature(values)
    if current == header_signature:
        return True

    # Kleine Unterschiede durch leere Zellen am Ende oder vereinzelte Leerzeichen
    # werden tolerant behandelt. Die Positionen der benannten Felder müssen passen.
    max_len = max(len(current), len(header_signature))
    if max_len == 0:
        return False
    padded_current = current + ("",) * (max_len - len(current))
    padded_header = header_signature + ("",) * (max_len - len(header_signature))
    comparable = [(a, b) for a, b in zip(padded_current, padded_header) if a or b]
    if not comparable:
        return False
    matches = sum(1 for a, b in comparable if a == b)
    return matches / len(comparable) >= 0.92


def scan_data_rows(
    files: Sequence[Path],
    header: HeaderCandidate,
    cancel_event: threading.Event,
    progress: ProgressCallback,
    log: LogCallback,
    initial_errors: list[str],
) -> ScanResult:
    data_rows = 0
    max_data_fields = len(header.signature)
    skipped_sheets: list[str] = []
    errors = list(initial_errors)
    usable_files: list[Path] = []
    file_count = max(len(files), 1)

    for file_index, path in enumerate(files, start=1):
        if cancel_event.is_set():
            raise MergeCancelled()

        value = 34 + int((file_index - 1) / file_count * 21)
        progress(value, "Zähle Datenzeilen", f"{file_index}/{len(files)} · {path.name}")
        log(f"[DATEN-SCAN] {path}")

        try:
            header_found_by_sheet: dict[str, bool] = defaultdict(bool)
            rows_in_file = 0
            processed_rows = 0

            for sheet_name, _source_row, values in iter_file_rows(path, read_all_sheets=True):
                if cancel_event.is_set():
                    raise MergeCancelled()

                processed_rows += 1
                if not header_found_by_sheet[sheet_name]:
                    if signature_matches(values, header.signature):
                        header_found_by_sheet[sheet_name] = True
                    continue

                # Wiederholte Header innerhalb der Daten werden nicht übernommen.
                if signature_matches(values, header.signature):
                    continue

                data_rows += 1
                rows_in_file += 1
                max_data_fields = max(max_data_fields, len(values))

                if data_rows > MAX_EXCEL_DATA_ROWS:
                    raise ValueError(
                        "Die Datenmenge überschreitet die maximale Größe eines Excel-Blatts "
                        f"({MAX_EXCEL_DATA_ROWS:,} Datenzeilen)."
                    )

                if processed_rows % ROW_STATUS_INTERVAL == 0:
                    progress(
                        value,
                        "Zähle Datenzeilen",
                        f"{file_index}/{len(files)} · {path.name} · bisher {data_rows:,} Zeilen",
                    )

            missing = [sheet for sheet, found in header_found_by_sheet.items() if not found]
            for sheet_name in missing:
                skipped_sheets.append(f"{path.name} · {sheet_name}")
                log(f"[BLATT ÜBERSPRUNGEN] Kein gemeinsamer Header: {path.name} · {sheet_name}")

            if rows_in_file > 0:
                usable_files.append(path)
                log(f"[OK] {path.name}: {rows_in_file:,} Datenzeilen")
            else:
                log(f"[OHNE DATEN] {path.name}")

        except MergeCancelled:
            raise
        except Exception as exc:
            error_text = f"{path.name}: {type(exc).__name__}: {exc}"
            errors.append(error_text)
            log(f"[ÜBERSPRUNGEN] {error_text}")

    if data_rows == 0:
        raise ValueError(
            "Unterhalb der gemeinsamen Kopfzeile wurden keine Datenzeilen gefunden."
        )

    raw_headers = list(header.display_values)
    while len(raw_headers) < max_data_fields:
        raw_headers.append(f"Extra_{len(raw_headers) + 1:02d}")
    headers = make_unique_headers(raw_headers)

    if len(headers) > MAX_EXCEL_COLUMNS:
        raise ValueError(
            f"Die Ausgabedatei hätte {len(headers):,} Spalten. "
            f"Excel unterstützt maximal {MAX_EXCEL_COLUMNS:,} Spalten."
        )

    progress(56, "Analyse abgeschlossen", f"{data_rows:,} Datenzeilen werden zusammengeführt")
    return ScanResult(
        readable_files=usable_files,
        header_signature=header.signature,
        headers=headers,
        data_rows=data_rows,
        errors=errors,
        skipped_sheets=skipped_sheets,
    )


def create_workbook(
    output_path: Path,
    scan: ScanResult,
    cancel_event: threading.Event,
    progress: ProgressCallback,
    log: LogCallback,
) -> tuple[int, list[str]]:
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = OUTPUT_SHEET_NAME
    worksheet.freeze_panes = "A2"
    worksheet.sheet_view.showGridLines = False
    worksheet.sheet_view.zoomScale = 90
    worksheet.append(scan.headers)

    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(color="FFFFFF", bold=True, size=11)
    header_border = Border(bottom=Side(style="thin", color="B4C6E7"))
    for cell in worksheet[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = header_border
    worksheet.row_dimensions[1].height = 26

    max_lengths = [len(str(header)) for header in scan.headers]
    written_rows = 0
    errors: list[str] = []

    for file_index, path in enumerate(scan.readable_files, start=1):
        if cancel_event.is_set():
            raise MergeCancelled()

        progress_value = 57 + int(written_rows / max(scan.data_rows, 1) * 35)
        progress(
            min(progress_value, 92),
            "Führe Dateien zusammen",
            f"{file_index}/{len(scan.readable_files)} · {path.name} · {written_rows:,}/{scan.data_rows:,} Zeilen",
        )
        log(f"[MERGE] {path}")

        try:
            header_found_by_sheet: dict[str, bool] = defaultdict(bool)
            rows_in_file = 0

            for sheet_name, _source_row, values in iter_file_rows(path, read_all_sheets=True):
                if cancel_event.is_set():
                    raise MergeCancelled()

                if not header_found_by_sheet[sheet_name]:
                    if signature_matches(values, scan.header_signature):
                        header_found_by_sheet[sheet_name] = True
                    continue

                if signature_matches(values, scan.header_signature):
                    continue

                output_values = [protect_excel_text(clean_text(value)) for value in values]
                output_values.extend([""] * (len(scan.headers) - len(output_values)))
                if len(output_values) > len(scan.headers):
                    output_values = output_values[: len(scan.headers)]

                worksheet.append(output_values)
                written_rows += 1
                rows_in_file += 1

                for index, value in enumerate(output_values):
                    max_lengths[index] = min(max(max_lengths[index], len(str(value))), 60)

                if written_rows % ROW_STATUS_INTERVAL == 0:
                    progress_value = 57 + int(written_rows / max(scan.data_rows, 1) * 35)
                    progress(
                        min(progress_value, 92),
                        "Führe Dateien zusammen",
                        f"{file_index}/{len(scan.readable_files)} · {path.name} · {written_rows:,}/{scan.data_rows:,} Zeilen",
                    )

            log(f"[OK] {path.name}: {rows_in_file:,} Zeilen eingefügt")

        except MergeCancelled:
            raise
        except Exception as exc:
            error_text = f"{path.name}: {type(exc).__name__}: {exc}"
            errors.append(error_text)
            log(f"[SCHREIBFEHLER] {error_text}")

    if written_rows == 0:
        raise ValueError("Es konnten keine Daten in die Ausgabedatei geschrieben werden.")

    progress(93, "Formatiere Master-Tabelle", "Filter, Spaltenbreiten und Tabellenformat werden gesetzt")

    last_row = worksheet.max_row
    last_column = worksheet.max_column
    end_column = get_column_letter(last_column)

    table = Table(displayName="MasterTabelle", ref=f"A1:{end_column}{last_row}")
    table.tableStyleInfo = TableStyleInfo(
        name="TableStyleMedium2",
        showFirstColumn=False,
        showLastColumn=False,
        showRowStripes=True,
        showColumnStripes=False,
    )
    worksheet.add_table(table)

    for column_index, observed_length in enumerate(max_lengths, start=1):
        worksheet.column_dimensions[get_column_letter(column_index)].width = min(
            max(observed_length + 2, 10), 42
        )

    worksheet.page_setup.orientation = "landscape"
    worksheet.page_setup.fitToWidth = 1
    worksheet.page_setup.fitToHeight = 0
    worksheet.sheet_properties.pageSetUpPr.fitToPage = True
    worksheet.print_title_rows = "1:1"

    workbook.properties.title = "Zusammengeführte Excel-Daten"
    workbook.properties.subject = "Gemeinsame Kopfzeile mit Daten aus mehreren Dateien"
    workbook.properties.creator = APP_NAME
    workbook.properties.description = (
        f"Zusammengeführt aus {len(scan.readable_files)} Quelldateien am "
        f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = output_path.with_name(f".{output_path.stem}_temp_{os.getpid()}.xlsx")

    try:
        progress(97, "Speichere Excel-Datei", output_path.name)
        workbook.save(temp_path)
        if output_path.exists():
            output_path.unlink()
        temp_path.replace(output_path)
    finally:
        if temp_path.exists():
            try:
                temp_path.unlink()
            except OSError:
                pass

    progress(100, "Merge abgeschlossen", f"{written_rows:,} Datenzeilen gespeichert")
    return written_rows, errors


def merge_files(
    files: Sequence[Path],
    output_path: Path,
    cancel_event: threading.Event,
    progress: ProgressCallback,
    log: LogCallback,
) -> dict[str, object]:
    started = datetime.now()
    log(f"{APP_NAME} v{APP_VERSION}")
    log(f"Start: {started.strftime('%Y-%m-%d %H:%M:%S')}")
    log(f"Quelldateien: {len(files)}")
    log(f"Ausgabe: {output_path}")
    log("-" * 72)

    readable_files, header, first_errors = detect_header(
        files, cancel_event, progress, log
    )
    scan = scan_data_rows(
        readable_files,
        header,
        cancel_event,
        progress,
        log,
        first_errors,
    )
    written_rows, write_errors = create_workbook(
        output_path,
        scan,
        cancel_event,
        progress,
        log,
    )

    finished = datetime.now()
    all_errors = scan.errors + write_errors
    log("-" * 72)
    log(f"Fertig: {finished.strftime('%Y-%m-%d %H:%M:%S')}")
    log(f"Dauer: {finished - started}")
    log(f"Datenzeilen: {written_rows:,}")
    log(f"Übersprungene Blätter: {len(scan.skipped_sheets)}")
    log(f"Fehler: {len(all_errors)}")

    return {
        "written_rows": written_rows,
        "errors": all_errors,
        "skipped_sheets": scan.skipped_sheets,
        "duration": finished - started,
        "output_path": output_path,
        "header_count": len(scan.headers),
    }


class ExcelMergerApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title(f"{APP_NAME} v{APP_VERSION}")
        self.root.geometry("840x650")
        self.root.minsize(760, 590)

        self.selected_files: list[Path] = []
        self.cancel_event = threading.Event()
        self.events: queue.Queue[tuple[str, object]] = queue.Queue()
        self.worker: threading.Thread | None = None
        self.log_messages: list[str] = []
        self.busy = False
        self.animation_index = 0
        self.started_monotonic = 0.0

        self.output_folder_var = tk.StringVar(value="")
        self.status_var = tk.StringVar(value="Bereit")
        self.detail_var = tk.StringVar(value="Bitte Quelldateien und einen Zielordner auswählen.")
        self.file_count_var = tk.StringVar(value="Keine Dateien ausgewählt")
        self.progress_var = tk.IntVar(value=0)
        self.animation_var = tk.StringVar(value="○ ○ ○")
        self.elapsed_var = tk.StringVar(value="")

        self.configure_style()
        self.build_ui()
        self.root.after(80, self.process_events)
        self.root.after(200, self.animate_status)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def configure_style(self) -> None:
        style = ttk.Style()
        try:
            style.theme_use("vista")
        except tk.TclError:
            pass

        style.configure("Title.TLabel", font=("Segoe UI", 21, "bold"))
        style.configure("Subtitle.TLabel", font=("Segoe UI", 10))
        style.configure("Section.TLabelframe.Label", font=("Segoe UI", 10, "bold"))
        style.configure("Primary.TButton", font=("Segoe UI", 11, "bold"), padding=(18, 11))
        style.configure("TButton", font=("Segoe UI", 9), padding=(9, 6))
        style.configure("StatusTitle.TLabel", font=("Segoe UI", 11, "bold"))
        style.configure("Animation.TLabel", font=("Segoe UI", 16, "bold"))
        style.configure("Hint.TLabel", font=("Segoe UI", 9), foreground="#555555")
        style.configure("Horizontal.TProgressbar", thickness=16)

    def build_ui(self) -> None:
        container = ttk.Frame(self.root, padding=18)
        container.pack(fill="both", expand=True)

        ttk.Label(container, text="Excel Master Merger", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            container,
            text="Gemeinsame Kopfzeile automatisch erkennen und nur die darunterliegenden Daten zusammenführen.",
            style="Subtitle.TLabel",
        ).pack(anchor="w", pady=(1, 14))

        source_frame = ttk.LabelFrame(
            container,
            text="1. Quelldateien",
            style="Section.TLabelframe",
            padding=11,
        )
        source_frame.pack(fill="both", expand=True)

        button_row = ttk.Frame(source_frame)
        button_row.pack(fill="x", pady=(0, 8))
        self.files_button = ttk.Button(
            button_row,
            text="Dateien auswählen",
            command=self.select_files,
        )
        self.files_button.pack(side="left", padx=(0, 7))
        self.folder_button = ttk.Button(
            button_row,
            text="Ordner auswählen",
            command=self.select_source_folder,
        )
        self.folder_button.pack(side="left", padx=(0, 7))
        self.clear_button = ttk.Button(
            button_row,
            text="Auswahl leeren",
            command=self.clear_files,
        )
        self.clear_button.pack(side="left")
        ttk.Label(button_row, textvariable=self.file_count_var).pack(side="right")

        list_frame = ttk.Frame(source_frame)
        list_frame.pack(fill="both", expand=True)
        self.file_listbox = tk.Listbox(
            list_frame,
            selectmode=tk.EXTENDED,
            height=9,
            font=("Segoe UI", 9),
            activestyle="none",
        )
        list_scroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.file_listbox.yview)
        self.file_listbox.configure(yscrollcommand=list_scroll.set)
        self.file_listbox.pack(side="left", fill="both", expand=True)
        list_scroll.pack(side="right", fill="y")

        output_frame = ttk.LabelFrame(
            container,
            text="2. Zielordner",
            style="Section.TLabelframe",
            padding=11,
        )
        output_frame.pack(fill="x", pady=(11, 0))
        output_frame.columnconfigure(0, weight=1)
        self.output_entry = ttk.Entry(output_frame, textvariable=self.output_folder_var, state="readonly")
        self.output_entry.grid(row=0, column=0, sticky="ew", padx=(0, 8))
        self.output_button = ttk.Button(
            output_frame,
            text="Zielordner wählen",
            command=self.select_output_folder,
        )
        self.output_button.grid(row=0, column=1)
        ttk.Label(
            output_frame,
            text="Die Datei wird automatisch als MERGED_MASTER_Datum_Uhrzeit.xlsx gespeichert.",
            style="Hint.TLabel",
        ).grid(row=1, column=0, columnspan=2, sticky="w", pady=(6, 0))

        info_frame = ttk.Frame(container)
        info_frame.pack(fill="x", pady=(11, 0))
        ttk.Label(
            info_frame,
            text=(
                "Dateiinformationen vor der Tabelle sowie wiederholte Header werden automatisch übersprungen. "
                "Die gemeinsame Kopfzeile erscheint genau einmal."
            ),
            style="Hint.TLabel",
            wraplength=790,
        ).pack(anchor="w")

        action_row = ttk.Frame(container)
        action_row.pack(fill="x", pady=(13, 0))
        self.start_button = ttk.Button(
            action_row,
            text="MERGE STARTEN",
            style="Primary.TButton",
            command=self.start_merge,
        )
        self.start_button.pack(side="left")
        self.cancel_button = ttk.Button(
            action_row,
            text="Abbrechen",
            command=self.cancel_merge,
            state="disabled",
        )
        self.cancel_button.pack(side="left", padx=(8, 0))

        status_frame = ttk.LabelFrame(
            container,
            text="Status",
            style="Section.TLabelframe",
            padding=11,
        )
        status_frame.pack(fill="x", pady=(11, 0))
        status_frame.columnconfigure(1, weight=1)

        self.animation_label = ttk.Label(status_frame, textvariable=self.animation_var, style="Animation.TLabel")
        self.animation_label.grid(row=0, column=0, rowspan=2, sticky="w", padx=(0, 12))
        ttk.Label(status_frame, textvariable=self.status_var, style="StatusTitle.TLabel").grid(
            row=0, column=1, sticky="w"
        )
        ttk.Label(status_frame, textvariable=self.elapsed_var).grid(row=0, column=2, sticky="e")
        ttk.Label(status_frame, textvariable=self.detail_var, style="Hint.TLabel").grid(
            row=1, column=1, columnspan=2, sticky="w", pady=(2, 0)
        )
        self.progress_bar = ttk.Progressbar(
            status_frame,
            maximum=100,
            variable=self.progress_var,
            mode="determinate",
        )
        self.progress_bar.grid(row=2, column=0, columnspan=3, sticky="ew", pady=(10, 0))

    def add_paths(self, paths: Sequence[Path]) -> None:
        existing = {path.resolve() for path in self.selected_files}
        for path in paths:
            try:
                resolved = path.resolve()
            except OSError:
                continue

            if (
                path.is_file()
                and path.suffix.lower() in SUPPORTED_EXTENSIONS
                and not path.name.startswith("~$")
                and not path.name.upper().startswith((
                    "MERGED_MASTER_",
                    "MERGE_HINWEISE_",
                    "MERGE_FEHLER_",
                ))
                and resolved not in existing
            ):
                self.selected_files.append(path)
                existing.add(resolved)

        self.selected_files.sort(key=lambda item: str(item).casefold())
        self.refresh_file_list()

    def refresh_file_list(self) -> None:
        self.file_listbox.delete(0, tk.END)
        for path in self.selected_files:
            self.file_listbox.insert(tk.END, str(path))

        count = len(self.selected_files)
        self.file_count_var.set(f"{count} Datei" if count == 1 else f"{count} Dateien")

        if self.selected_files and not self.output_folder_var.get():
            self.output_folder_var.set(str(self.selected_files[0].parent))

    def select_files(self) -> None:
        paths = filedialog.askopenfilenames(
            title="Quelldateien auswählen",
            filetypes=[
                ("Unterstützte Dateien", "*.xlsx *.xlsm *.xls *.csv *.txt"),
                ("Excel-Dateien", "*.xlsx *.xlsm *.xls"),
                ("Textdateien", "*.csv *.txt"),
                ("Alle Dateien", "*.*"),
            ],
        )
        self.add_paths([Path(path) for path in paths])

    def select_source_folder(self) -> None:
        folder = filedialog.askdirectory(title="Ordner mit Quelldateien auswählen")
        if not folder:
            return
        base = Path(folder)
        self.add_paths([path for path in base.rglob("*") if path.is_file()])

    def clear_files(self) -> None:
        self.selected_files.clear()
        self.refresh_file_list()

    def select_output_folder(self) -> None:
        folder = filedialog.askdirectory(
            title="Zielordner für die Masterdatei auswählen",
            initialdir=self.output_folder_var.get() or None,
        )
        if folder:
            self.output_folder_var.set(folder)

    def set_busy(self, busy: bool) -> None:
        self.busy = busy
        normal_state = "disabled" if busy else "normal"
        self.files_button.configure(state=normal_state)
        self.folder_button.configure(state=normal_state)
        self.clear_button.configure(state=normal_state)
        self.output_button.configure(state=normal_state)
        self.start_button.configure(state=normal_state)
        self.cancel_button.configure(state="normal" if busy else "disabled")

    def append_log(self, message: str) -> None:
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_messages.append(f"[{timestamp}] {message}")

    def make_output_path(self) -> Path:
        output_folder = Path(self.output_folder_var.get().strip())
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return output_folder / f"MERGED_MASTER_{stamp}.xlsx"

    def start_merge(self) -> None:
        if not self.selected_files:
            messagebox.showwarning("Keine Dateien", "Bitte zuerst mindestens eine Quelldatei auswählen.")
            return

        output_folder_text = self.output_folder_var.get().strip()
        if not output_folder_text:
            messagebox.showwarning("Kein Zielordner", "Bitte einen Zielordner auswählen.")
            return

        output_folder = Path(output_folder_text)
        if not output_folder.exists() or not output_folder.is_dir():
            messagebox.showerror("Ungültiger Zielordner", "Der ausgewählte Zielordner existiert nicht.")
            return

        output_path = self.make_output_path()
        self.cancel_event.clear()
        self.log_messages.clear()
        self.progress_var.set(0)
        self.status_var.set("Merge wird gestartet")
        self.detail_var.set("Die Dateien werden vorbereitet …")
        self.animation_var.set("● ○ ○")
        self.elapsed_var.set("00:00")
        self.started_monotonic = time.monotonic()
        self.set_busy(True)

        files = list(self.selected_files)
        self.worker = threading.Thread(
            target=self.merge_worker,
            args=(files, output_path),
            daemon=True,
        )
        self.worker.start()

    def merge_worker(self, files: list[Path], output_path: Path) -> None:
        def emit_progress(value: int, status: str, detail: str) -> None:
            self.events.put(("progress", (value, status, detail)))

        def emit_log(message: str) -> None:
            self.events.put(("log", message))

        try:
            result = merge_files(
                files,
                output_path,
                self.cancel_event,
                emit_progress,
                emit_log,
            )
            self.events.put(("done", result))
        except MergeCancelled:
            self.events.put(("cancelled", None))
        except Exception as exc:
            emit_log(traceback.format_exc())
            self.events.put(("error", exc))

    def process_events(self) -> None:
        try:
            while True:
                event_type, payload = self.events.get_nowait()
                if event_type == "progress":
                    value, status, detail = payload  # type: ignore[misc]
                    self.progress_var.set(int(value))
                    self.status_var.set(str(status))
                    self.detail_var.set(str(detail))
                elif event_type == "log":
                    self.append_log(str(payload))
                elif event_type == "done":
                    self.handle_done(payload)  # type: ignore[arg-type]
                elif event_type == "cancelled":
                    self.handle_cancelled()
                elif event_type == "error":
                    self.handle_error(payload)  # type: ignore[arg-type]
        except queue.Empty:
            pass
        self.root.after(80, self.process_events)

    def animate_status(self) -> None:
        if self.busy:
            frames = ("● ○ ○", "○ ● ○", "○ ○ ●", "○ ● ○")
            self.animation_var.set(frames[self.animation_index % len(frames)])
            self.animation_index += 1

            elapsed = max(0, int(time.monotonic() - self.started_monotonic))
            minutes, seconds = divmod(elapsed, 60)
            hours, minutes = divmod(minutes, 60)
            if hours:
                self.elapsed_var.set(f"{hours:02d}:{minutes:02d}:{seconds:02d}")
            else:
                self.elapsed_var.set(f"{minutes:02d}:{seconds:02d}")

        self.root.after(220, self.animate_status)

    def write_error_log(self, result: dict[str, object]) -> Path | None:
        errors = list(result.get("errors", []))  # type: ignore[arg-type]
        skipped = list(result.get("skipped_sheets", []))  # type: ignore[arg-type]
        if not errors and not skipped:
            return None

        output_path = Path(result["output_path"])  # type: ignore[arg-type]
        log_path = output_path.with_name(f"MERGE_HINWEISE_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt")
        lines = [
            f"{APP_NAME} v{APP_VERSION}",
            f"Erstellt: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "",
        ]
        if skipped:
            lines.append("TABELLENBLÄTTER OHNE GEMEINSAMEN HEADER:")
            lines.extend(f"- {item}" for item in skipped)
            lines.append("")
        if errors:
            lines.append("FEHLER / ÜBERSPRUNGENE DATEIEN:")
            lines.extend(f"- {item}" for item in errors)
            lines.append("")
        lines.append("TECHNISCHES PROTOKOLL:")
        lines.extend(self.log_messages)

        try:
            log_path.write_text("\n".join(lines), encoding="utf-8")
            return log_path
        except OSError:
            return None

    def handle_done(self, result: dict[str, object]) -> None:
        self.set_busy(False)
        self.progress_var.set(100)
        self.animation_var.set("✓")
        written_rows = int(result["written_rows"])
        header_count = int(result["header_count"])
        output_path = Path(result["output_path"])  # type: ignore[arg-type]
        errors = list(result["errors"])  # type: ignore[arg-type]
        skipped = list(result["skipped_sheets"])  # type: ignore[arg-type]
        log_path = self.write_error_log(result)

        self.status_var.set("Merge erfolgreich abgeschlossen")
        self.detail_var.set(f"{written_rows:,} Datenzeilen · {header_count} Spalten · {output_path.name}")

        detail = (
            "Die Masterdatei wurde erfolgreich erstellt.\n\n"
            f"Datenzeilen: {written_rows:,}\n"
            f"Spalten: {header_count}\n"
            f"Hinweise/Fehler: {len(errors) + len(skipped)}\n\n"
            f"Ausgabedatei:\n{output_path}"
        )
        if log_path:
            detail += f"\n\nHinweisprotokoll:\n{log_path}"

        if messagebox.askyesno("Merge abgeschlossen", detail + "\n\nSoll der Zielordner geöffnet werden?"):
            try:
                os.startfile(str(output_path.parent))  # type: ignore[attr-defined]
            except OSError:
                pass

    def handle_cancelled(self) -> None:
        self.set_busy(False)
        self.progress_var.set(0)
        self.animation_var.set("○ ○ ○")
        self.status_var.set("Merge abgebrochen")
        self.detail_var.set("Es wurde keine fertige Masterdatei erstellt.")
        self.elapsed_var.set("")
        messagebox.showinfo("Abgebrochen", "Der Merge wurde abgebrochen.")

    def handle_error(self, exc: Exception) -> None:
        self.set_busy(False)
        self.animation_var.set("✕")
        self.status_var.set("Merge fehlgeschlagen")
        self.detail_var.set(f"{type(exc).__name__}: {exc}")

        output_folder_text = self.output_folder_var.get().strip()
        log_path: Path | None = None
        if output_folder_text:
            try:
                log_path = Path(output_folder_text) / f"MERGE_FEHLER_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
                log_path.write_text("\n".join(self.log_messages), encoding="utf-8")
            except OSError:
                log_path = None

        text = f"Der Merge konnte nicht abgeschlossen werden.\n\n{type(exc).__name__}: {exc}"
        if log_path:
            text += f"\n\nFehlerprotokoll:\n{log_path}"
        messagebox.showerror("Merge fehlgeschlagen", text)

    def cancel_merge(self) -> None:
        if self.worker and self.worker.is_alive():
            self.cancel_event.set()
            self.status_var.set("Merge wird abgebrochen")
            self.detail_var.set("Der aktuelle Dateivorgang wird sauber beendet …")
            self.cancel_button.configure(state="disabled")

    def on_close(self) -> None:
        if self.worker and self.worker.is_alive():
            if not messagebox.askyesno(
                "Merge läuft",
                "Der Merge läuft noch. Soll er abgebrochen und das Programm geschlossen werden?",
            ):
                return
            self.cancel_event.set()
        self.root.destroy()


def main() -> None:
    if OPENPYXL_IMPORT_ERROR is not None:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(
            "Fehlende Installation",
            "Benötigte Python-Pakete fehlen.\n\n"
            "Bitte zuerst INSTALL.bat ausführen.\n\n"
            f"Technische Meldung: {OPENPYXL_IMPORT_ERROR}",
        )
        raise SystemExit(1)

    root = tk.Tk()
    ExcelMergerApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
