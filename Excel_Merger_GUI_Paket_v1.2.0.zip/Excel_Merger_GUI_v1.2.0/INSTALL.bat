@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title Excel Master Merger - Installation

set "PYTHON_CMD="
set "VENV_DIR=%~dp0runtime\.venv"

for %%V in (3.13 3.12 3.11 3.10) do (
    if not defined PYTHON_CMD (
        py -%%V -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
        if not errorlevel 1 set "PYTHON_CMD=py -%%V"
    )
)

if not defined PYTHON_CMD (
    python -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=python"
)

echo ============================================================
echo  Excel Master Merger - Installation
echo ============================================================
echo.

if not defined PYTHON_CMD (
    echo FEHLER: Python 3.10 oder neuer wurde nicht gefunden.
    echo.
    echo Bitte Python fuer Windows installieren:
    echo https://www.python.org/downloads/windows/
    echo.
    echo Bei der Installation aktivieren:
    echo   Add python.exe to PATH
    echo.
    pause
    exit /b 1
)

if not exist "%~dp0runtime" mkdir "%~dp0runtime"

if not exist "%VENV_DIR%\Scripts\python.exe" (
    echo Erstelle lokale Programmumgebung ...
    %PYTHON_CMD% -m venv "%VENV_DIR%"
    if errorlevel 1 goto INSTALL_ERROR
)

echo Aktualisiere pip ...
"%VENV_DIR%\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto INSTALL_ERROR

echo Installiere benoetigte Pakete ...
"%VENV_DIR%\Scripts\python.exe" -m pip install -r "%~dp0app\requirements.txt"
if errorlevel 1 goto INSTALL_ERROR

echo.
echo ============================================================
echo  INSTALLATION ERFOLGREICH
echo ============================================================
echo.
echo Das Tool kann jetzt mit START.bat gestartet werden.
echo.
pause
exit /b 0

:INSTALL_ERROR
echo.
echo FEHLER: Die Installation konnte nicht abgeschlossen werden.
echo Bitte Internetverbindung und Unternehmens-Proxy pruefen.
echo.
pause
exit /b 1
