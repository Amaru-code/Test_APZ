from __future__ import annotations

import json
import os
import shutil
import tempfile
from datetime import datetime
import unittest
from pathlib import Path

from openpyxl import load_workbook

from app.service import run_calculation
from core.models import AppOptions
from excel.template_writer import resolve_template_path
from excel.preserved_template_writer import _rewrite_summary_formula


ROOT = Path(__file__).resolve().parents[1]
SAMPLE = ROOT / "data" / "samples" / "sample_AllOnetabOrFile.xlsx"


def _print_area_coordinates(value: object) -> str:
    text = str(value or "")
    return text.split("!", 1)[-1]


def _set_source_date(path: Path, value: datetime | str) -> None:
    workbook = load_workbook(path)
    workbook["AllOnetabOrFile"]["B5"] = value
    workbook.save(path)
    workbook.close()


class PrintReportTests(unittest.TestCase):
    def test_template_is_resolved_from_samples_folder(self) -> None:
        template_without = resolve_template_path(ROOT, with_previous_year=False)
        template_with = resolve_template_path(ROOT, with_previous_year=True)
        self.assertTrue(template_without.is_file())
        self.assertTrue(template_with.is_file())

    def test_separate_template_names_are_selected_by_previous_year_mode(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "config").mkdir()
            samples = root / "data" / "samples"
            samples.mkdir(parents=True)
            (root / "config" / "template_settings.json").write_text(
                json.dumps(
                    {
                        "template_without_previous": "data/samples/Knorr_Bremse_ICT_template_ohne_VJ",
                        "template_with_previous": "data/samples/Knorr_Bremse_ICT_template_mit_VJ",
                    }
                ),
                encoding="utf-8",
            )
            without = samples / "Knorr_Bremse_ICT_template_ohne_VJ.xlsx"
            with_previous = samples / "Knorr_Bremse_ICT_template_mit_VJ.xlsm"
            without.touch()
            with_previous.touch()

            self.assertEqual(
                resolve_template_path(root, with_previous_year=False),
                without.resolve(),
            )
            self.assertEqual(
                resolve_template_path(root, with_previous_year=True),
                with_previous.resolve(),
            )

    def test_generic_gesellschaft_sheet_is_cloned_for_selected_companies(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            generic_template = temp_path / "Knorr_Bremse_ICT_template_ohne_VJ.xlsx"
            source_template = resolve_template_path(ROOT, with_previous_year=False)
            workbook = load_workbook(source_template)
            source_sheet = workbook["SFS"]
            source_sheet.title = "Gesellschaft"
            for worksheet in list(workbook.worksheets):
                if worksheet.title != "Gesellschaft":
                    workbook.remove(worksheet)
            workbook.save(generic_template)
            workbook.close()

            current = temp_path / "Sommerbewertung_30.06.2026.xlsx"
            shutil.copy2(SAMPLE, current)
            old_value = os.environ.get("KB_REPORT_TEMPLATE_WITHOUT_PREVIOUS")
            os.environ["KB_REPORT_TEMPLATE_WITHOUT_PREVIOUS"] = str(generic_template)
            try:
                result = run_calculation(
                    ROOT,
                    AppOptions(
                        current_file=current,
                        previous_file=None,
                        output_type="HGB",
                        companies=["GRH", "SFS", "Steering"],
                        output_dir=temp_path / "out",
                    ),
                )
            finally:
                if old_value is None:
                    os.environ.pop("KB_REPORT_TEMPLATE_WITHOUT_PREVIOUS", None)
                else:
                    os.environ["KB_REPORT_TEMPLATE_WITHOUT_PREVIOUS"] = old_value

            output = load_workbook(result.output_workbook)
            self.assertEqual(output.sheetnames, ["GRH", "SFS", "Steering"])
            self.assertNotIn("Gesellschaft", output.sheetnames)
            output.close()

    def test_company_only_template_report_without_previous_year(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            current = temp_path / "Sommerbewertung_30.06.2026.xlsx"
            shutil.copy2(SAMPLE, current)
            _set_source_date(current, datetime(2026, 7, 17))
            result = run_calculation(
                ROOT,
                AppOptions(
                    current_file=current,
                    previous_file=None,
                    output_type="HGB",
                    companies=["GRH", "SFS", "Steering"],
                    output_dir=temp_path / "out",
                ),
            )
            workbook = load_workbook(result.output_workbook, data_only=False)
            self.assertEqual(workbook.sheetnames, ["GRH", "SFS", "Steering", "Summe"])
            self.assertNotIn("Rechenlauf", workbook.sheetnames)
            self.assertIn("Summe", workbook.sheetnames)
            self.assertNotIn("BilMoG", workbook.sheetnames)

            grh = workbook["GRH"]
            template_workbook = load_workbook(resolve_template_path(ROOT, with_previous_year=False))
            template_sheet = template_workbook["SFS"]
            template_print_area = _print_area_coordinates(template_sheet.print_area)
            template_a_hidden = bool(template_sheet.column_dimensions["A"].hidden)
            template_i_hidden = bool(template_sheet.column_dimensions["I"].hidden)
            template_j_hidden = bool(template_sheet.column_dimensions["J"].hidden)
            template_workbook.close()

            self.assertEqual(
                grh["C2"].value,
                "Entwicklung der Pensionsrückstellungen 17.07.2026 - Handelsbilanz",
            )
            self.assertEqual(grh["F5"].value, "17.07.2026")
            self.assertEqual(grh["C8"].value, "GRH")
            self.assertEqual(grh["C10"].value, "Versorgungswerk Anwärter")
            self.assertEqual(grh["D12"].value, "Anwärter Männer")
            self.assertEqual(grh["D59"].value, "unverfallb. Ausgesch.")
            self.assertIsInstance(grh["F12"].value, (int, float))
            self.assertIsInstance(grh["F59"].value, (int, float))
            self.assertIsInstance(grh["H12"].value, int)

            # The lower GRH block is placed according to the ICT template.
            self.assertEqual(grh["C43"].value, "Einzelzusagen Geschäftsführer")
            self.assertEqual(grh["F17"].value, "=SUM(F12:F16)")
            self.assertEqual(grh["H17"].value, "=SUM(H12:H16)")
            self.assertEqual(grh["F47"].value, "=SUM(F45:F46)")
            self.assertEqual(grh["H47"].value, "=SUM(H45:H46)")
            self.assertIsNone(grh["B48"].value)
            self.assertIsNone(grh["C48"].value)
            self.assertIsNone(grh["D48"].value)
            self.assertEqual(grh["C49"].value, "Einzelzusagen Anwärter")
            self.assertEqual(grh["D51"].value, "Mitarbeiter Auslandsges.")
            self.assertEqual(grh["C53"].value, "Barlohnumwandlung")
            self.assertEqual(grh["D55"].value, "Einbehalte von Mitarbeitern")
            self.assertIsNone(grh["B56"].value)
            self.assertIsNone(grh["C56"].value)
            self.assertIsNone(grh["D56"].value)
            self.assertEqual(grh["C57"].value, "MRP")
            self.assertEqual(grh["D59"].value, "unverfallb. Ausgesch.")
            grand_rows = [
                row for row in range(60, grh.max_row + 1)
                if grh.cell(row, 3).value == "Gesamtsumme:"
            ]
            self.assertEqual(len(grand_rows), 1)
            self.assertGreater(grand_rows[0], 59)
            self.assertEqual(bool(grh.column_dimensions["A"].hidden), template_a_hidden)
            self.assertEqual(bool(grh.column_dimensions["I"].hidden), template_i_hidden)
            self.assertEqual(bool(grh.column_dimensions["J"].hidden), template_j_hidden)
            self.assertNotEqual(_print_area_coordinates(grh.print_area), template_print_area)
            self.assertTrue(_print_area_coordinates(grh.print_area).endswith(f"$N${grand_rows[0]}"))
            self.assertEqual(grh.page_setup.fitToWidth, 1)
            grand_row = grand_rows[0]
            self.assertEqual(
                grh.cell(grand_row, 6).value,
                "=F17+F25+F34+F41+F47+F51+F55+F59",
            )
            self.assertEqual(
                grh.cell(grand_row, 8).value,
                "=H17+H25+H34+H41+H47+H51+H55+H59",
            )
            bold_total_rows = [17, 25, 34, 41, 47, grand_row]
            for row in bold_total_rows:
                self.assertTrue(str(grh.cell(row, 6).value).startswith("="))
                self.assertTrue(str(grh.cell(row, 8).value).startswith("="))
                self.assertTrue(grh.cell(row, 6).font.bold)
                self.assertTrue(grh.cell(row, 8).font.bold)
                self.assertIsNotNone(grh.cell(row, 6).border.bottom.style)
                self.assertIsNotNone(grh.cell(row, 8).border.bottom.style)

            self.assertFalse(grh["C49"].font.bold)
            self.assertFalse(grh["C53"].font.bold)
            self.assertFalse(grh["F45"].font.bold)
            self.assertFalse(grh["H45"].font.bold)
            self.assertTrue(grh["F47"].font.bold)
            self.assertTrue(grh["H47"].font.bold)
            self.assertTrue(grh["F51"].font.bold)
            self.assertTrue(grh["H51"].font.bold)
            self.assertFalse(grh["F55"].font.bold)
            self.assertFalse(grh["H55"].font.bold)
            self.assertTrue(grh["F59"].font.bold)
            self.assertTrue(grh["H59"].font.bold)

            steering = workbook["Steering"]
            self.assertEqual(steering["C15"].value, "Gesamtsumme:")
            self.assertIsNone(steering["D15"].value)
            self.assertEqual(steering["F15"].value, "=SUM(F12:F14)")
            self.assertEqual(steering["H15"].value, "=SUM(H12:H14)")
            self.assertEqual(steering["C17"].value, "Gesamtsumme:")
            self.assertEqual(steering["F17"].value, "=F15")
            self.assertEqual(steering["H17"].value, "=H15")
            self.assertTrue(_print_area_coordinates(steering.print_area).endswith("$N$17"))
            self.assertFalse(any(
                steering.cell(row, 3).value == "Gesamtsumme:"
                for row in range(18, steering.max_row + 1)
            ))
            workbook.close()

    def test_grh_lower_block_uses_output_row_overrides_without_changing_rules(self) -> None:
        rules = json.loads((ROOT / "config" / "rules.json").read_text(encoding="utf-8"))
        by_label = {rule["label"]: rule["target_row"] for rule in rules["companies"]["GRH"]["rules"]}
        self.assertEqual(by_label["Mitarbeiter Auslandsges."], 49)
        self.assertEqual(by_label["Einbehalte von Mitarbeitern"], 51)
        self.assertEqual(by_label["unverfallb. Ausgesch."], 56)

        source = (ROOT / "src" / "excel" / "preserved_template_writer.py").read_text(encoding="utf-8")
        self.assertIn('49: 51', source)
        self.assertIn('51: 55', source)
        self.assertIn('56: 59', source)

    def test_preserved_writer_does_not_reformat_or_rebuild_page_layout(self) -> None:
        source = (ROOT / "src" / "excel" / "preserved_template_writer.py").read_text(
            encoding="utf-8"
        )
        self.assertNotIn(".NumberFormat =", source)
        self.assertIn("PageSetup.PrintArea =", source)
        self.assertNotIn("EntireColumn.Hidden =", source)
        self.assertIn("Excel-COM-Ausgabe erfolgreich", source)
        self.assertIn("OpenPyXL-Fallback erzeugt", source)

    def test_summe_template_formulas_are_rewritten_to_local_company_sheets(self) -> None:
        formula = (
            "='K:\\Reports\\[AG.xlsx]Handelsbilanz'!$F$12"
            "+'K:\\Reports\\[GRH.xlsx]Handelsbilanz'!$F$56"
            "+'K:\\Reports\\[Kiepe.xlsx]Handelsbilanz'!$F$12"
            "+'K:\\Reports\\[HW.xlsx]Handelsbilanz'!$F$12"
        )
        rewritten = _rewrite_summary_formula(formula, ["AG", "GRH", "Steering"])
        self.assertEqual(
            rewritten,
            "='AG'!$F$12+'GRH'!$F$59+'Steering'!$F$12+0",
        )
        self.assertNotIn("[", rewritten)
        self.assertNotIn("K:", rewritten)
        self.assertEqual(
            _rewrite_summary_formula("=SUM(F12:F14)", ["AG"]),
            "=SUM(F12:F14)",
        )
        self.assertEqual(
            _rewrite_summary_formula(
                "='Kiepe'!$F$44+'GRH'!$F$44",
                ["GRH", "Steering"],
                {"Steering": {44: 17}, "GRH": {44: 61}},
            ),
            "='Steering'!$F$17+'GRH'!$F$61",
        )

    def test_template_report_with_previous_year(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            current = temp_path / "Bewertung_20.07.2099.xlsx"
            previous = temp_path / "Bewertung_19.07.2098.xlsx"
            shutil.copy2(SAMPLE, current)
            shutil.copy2(SAMPLE, previous)
            _set_source_date(current, "30.06.2026")
            _set_source_date(previous, datetime(2025, 12, 31))
            result = run_calculation(
                ROOT,
                AppOptions(
                    current_file=current,
                    previous_file=previous,
                    output_type="HGB",
                    companies=["SFS"],
                    output_dir=temp_path / "out",
                ),
            )
            workbook = load_workbook(result.output_workbook, data_only=False)
            self.assertEqual(workbook.sheetnames, ["SFS", "Summe"])
            sfs = workbook["SFS"]
            self.assertEqual(sfs["F5"].value, "31.12.2025")
            self.assertEqual(sfs["J5"].value, "30.06.2026")
            self.assertEqual(sfs["L12"].value, 0)
            self.assertEqual(sfs["F17"].value, "=SUM(F12:F16)")
            self.assertEqual(sfs["H17"].value, "=SUM(H12:H16)")
            self.assertEqual(sfs["J17"].value, "=SUM(J12:J16)")
            self.assertEqual(sfs["L17"].value, "=J17-F17")
            self.assertEqual(sfs["N17"].value, "=SUM(N12:N16)")
            self.assertFalse(sfs.column_dimensions["J"].hidden)
            self.assertIn("$N$", str(sfs.print_area))
            self.assertIsNone(result.output_pdf)  # Linux-Testumgebung ohne Excel-COM
            workbook.close()


if __name__ == "__main__":
    unittest.main()
