from __future__ import annotations

import json
from pathlib import Path
from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parents[1]
SAMPLES = ROOT / "data" / "samples"
OUT = ROOT / "logs" / "template_diagnose.json"


def find(stem: str) -> Path | None:
    for suffix in (".xlsx", ".xlsm"):
        exact = SAMPLES / f"{stem}{suffix}"
        if exact.is_file():
            return exact
    matches = sorted(SAMPLES.glob(f"{stem}*.xls*"))
    return matches[0] if matches else None


def inspect(path: Path) -> dict:
    wb = load_workbook(path, read_only=False, data_only=False, keep_vba=path.suffix.lower() == ".xlsm")
    try:
        sheets = []
        for ws in wb.worksheets:
            key_rows = []
            for row in range(1, min(ws.max_row, 140) + 1):
                values = {col: ws[f"{col}{row}"].value for col in ("B", "C", "D", "F", "H", "J", "L", "N")}
                if any(value not in (None, "") for value in values.values()):
                    key_rows.append({"row": row, **values})
            sheets.append({
                "name": ws.title,
                "max_row": ws.max_row,
                "max_column": ws.max_column,
                "print_area": str(ws.print_area or ""),
                "merged_ranges": [str(item) for item in ws.merged_cells.ranges],
                "key_rows": key_rows,
            })
        return {"path": str(path), "sheets": sheets}
    finally:
        wb.close()


def main() -> int:
    result = {}
    for key, stem in {
        "without_previous": "Knorr_Bremse_ICT_template_ohne_VJ",
        "with_previous": "Knorr_Bremse_ICT_template_mit_VJ",
    }.items():
        path = find(stem)
        result[key] = inspect(path) if path else {"error": f"{stem}.xlsx/.xlsm nicht gefunden"}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(f"Diagnose erstellt: {OUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
