@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" "scripts\template_diagnose.py"
) else (
  py -3 "scripts\template_diagnose.py"
)
echo.
echo Die Datei logs\template_diagnose.json wurde erstellt.
pause
