# KB Handelsbilanz Desktop App – Revision 13

Revision 13 verwendet die beiden lokalen Excel-Templates direkt als Layoutbasis und ergänzt die korrigierte GRH-/Steering-Darstellung sowie das Formelblatt `Summe`.

## Automatische Template-Auswahl

Ohne ausgewählte Vorjahresdatei:

```text
data\samples\Knorr_Bremse_ICT_template_ohne_VJ.xlsx
```

Mit ausgewählter Vorjahresdatei:

```text
data\samples\Knorr_Bremse_ICT_template_mit_VJ.xlsx
```

Auch `.xlsm` wird unterstützt. Die Dateiendung muss in `config/template_settings.json` nicht eingetragen werden.

Das Template **ohne Vorjahr** darf ein generisches Blatt namens `Gesellschaft` enthalten. Dieses Blatt wird für jede ausgewählte Gesellschaft kopiert und an den festen fachlichen Zielzeilen befüllt.

Das Template **mit Vorjahr** kann bereits eigene Gesellschaftsblätter wie `SFN`, `SFS`, `AG`, `KBM`, `HW`, `IT` und `Steering` enthalten. Vorhandene Gesellschaftsblätter werden bevorzugt. Für `GRH` wird das SFS-Blatt als Layoutbasis verwendet, sofern kein eigenes GRH-Blatt vorhanden ist.

Das lokale Template-Blatt **`Summe`** bleibt erhalten. Seine vorhandenen Formeln werden auf die im aktuellen Lauf erzeugten Gesellschaftsblätter umgeschrieben. Dadurch enthält die Summe echte Excel-Formeln statt statischer Python-Werte.

## Änderungen in Revision 13

- GRH: Leerzeile vor MRP, korrigierte Fettschrift und vollständige Summenrahmen.
- Steering/Kiepe: kompakter Bericht ohne langen Leerbereich; Gesamtsumme und Druckbereich enden in Zeile 17.
- Summe: vorhandenes Template-Blatt wird als letztes Blatt übernommen und mit lokalen Formeln belegt.
- Fachliche Regeln in `config/rules.json` bleiben unverändert.

Details: `docs\GRH_STEERING_SUMME_REVISION_13.md`

## Start

Erster Start:

```text
INSTALLIEREN_UND_STARTEN.bat
```

Danach:

```text
STARTEN.bat
```

Der normale Start verwendet `pythonw.exe`; hinter der App bleibt kein Terminalfenster geöffnet. Für Diagnosen steht `STARTEN_MIT_TERMINAL.bat` zur Verfügung.

## Output

Der erzeugte Bericht enthält:

- alle ausgewählten Gesellschaftsblätter,
- das vorhandene Blatt `Summe` als letztes Blatt,
- keine nicht ausgewählten Gesellschafts-, Rechenlauf- oder BilMoG-Blätter.

Die Gesellschaftsblätter enthalten die berechneten Werte und Anzahlen. Das Blatt `Summe` enthält Formeln auf diese Gesellschaftsblätter und wird beim Öffnen in Excel vollständig neu berechnet.

## Template-Diagnose ohne Upload

Mit `TEMPLATES_PRUEFEN.bat` wird lokal `logs\template_diagnose.json` erzeugt. Damit lässt sich die erkannte Blatt- und Zeilenstruktur prüfen, ohne die Excel-Dateien hochzuladen.
