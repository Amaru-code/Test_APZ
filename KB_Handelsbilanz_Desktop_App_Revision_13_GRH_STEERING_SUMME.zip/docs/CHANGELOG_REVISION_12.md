# Changelog – Revision 12

- Keine Template-Datei muss hochgeladen werden.
- Lokale Dateien in `data/samples` werden direkt verwendet.
- Das Template wird zuerst vollständig kopiert.
- Der Bericht wird nicht mehr dynamisch neu angeordnet.
- Kennzahlen werden wieder in die festen Zielzeilen der Feldregeln geschrieben.
- Formatierungen, Logos, Seitenlayout und Druckeinstellungen bleiben erhalten.
- Externe Excel-Verknüpfungen werden soweit möglich entfernt.
- Neuer lokaler Diagnoseweg: `TEMPLATES_PRUEFEN.bat`.
