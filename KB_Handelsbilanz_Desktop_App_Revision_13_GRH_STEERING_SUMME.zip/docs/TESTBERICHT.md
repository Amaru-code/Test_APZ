# Testbericht – Revision 13

## Automatisierte Prüfung

- 40 von 40 Tests erfolgreich.
- Bestehende 183 Feldregeln unverändert gültig.
- Ausgabe ohne und mit Vorjahr geprüft.
- Genau eine Leerzeile vor dem GRH-MRP-Block geprüft.
- GRH-Fettschrift für Abschnittsüberschriften, Detailwerte und Summen geprüft.
- Summenrahmen der GRH-Zwischensummen geprüft.
- Kompaktes Steering-Blatt mit Gesamtsumme und Druckbereich bis Zeile 17 geprüft.
- Blatt `Summe` bleibt in der Ergebnisdatei erhalten.
- Umschreibung externer Summenformeln auf lokale Gesellschaftsblätter geprüft.
- GRH-Zeilenverschiebung und Umbenennung `Kiepe` zu `Steering` in Summenformeln geprüft.
- Nicht ausgewählte Gesellschaften werden in Summenformeln durch `0` ersetzt.
- Windows-BAT-Dateien bleiben ASCII und CRLF-formatiert.

## Windows-Ausgabe

Unter Windows bearbeitet Microsoft Excel die lokale Template-Kopie über Excel COM. Dadurch bleiben Logos, Formen, Druckeinstellungen und XLSM-Inhalte erhalten. Die COM-Implementierung enthält dieselben GRH-, Steering- und Summenblattkorrekturen wie der automatisiert geprüfte OpenPyXL-Testpfad.

Die Windows-Excel-COM-Ausführung kann in der Linux-Testumgebung nicht gestartet werden. Der COM-Code wurde syntaktisch geprüft und die gemeinsame Formel- und Zeilenlogik wird durch die Tests abgedeckt.
