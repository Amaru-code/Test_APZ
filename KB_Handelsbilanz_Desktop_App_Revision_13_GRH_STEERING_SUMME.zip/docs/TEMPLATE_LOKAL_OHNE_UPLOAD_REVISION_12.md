# Revision 12 – Lokale Templates ohne Upload

Die beiden Excel-Templates müssen **nicht** in ChatGPT hochgeladen werden. Die
Anwendung liest sie direkt auf dem Windows-PC aus `data/samples`:

- `Knorr_Bremse_ICT_template_ohne_VJ.xlsx` oder `.xlsm`
- `Knorr_Bremse_ICT_template_mit_VJ.xlsx` oder `.xlsm`

## Neue Ausgabelogik

1. Das ausgewählte lokale Template wird bytegenau in den Ausgabeordner kopiert.
2. Microsoft Excel öffnet die Kopie unsichtbar im Hintergrund.
3. Es werden nur Datum, Gesellschaft, Blattname, Kennzahlen und Anzahlen ersetzt.
4. Zeilenhöhen, Spaltenbreiten, Logos, Seitenumbrüche, Druckeinstellungen,
   Rahmen, Farben und sonstige Formatierungen bleiben aus dem Template erhalten.
5. `Summe`, `BilMoG` und nicht ausgewählte Gesellschaftsblätter werden weiterhin
   entfernt.
6. Externe Excel-Verknüpfungen werden soweit möglich getrennt, damit keine
   Aktualisierungswarnung erscheint.

Die frühere Neuanordnung der Berichtszeilen wurde entfernt. Die Regeln schreiben
wieder in ihre festen Zielzeilen wie `J12`, `J21`, `J45` usw. Dadurch entspricht
der Output dem lokal hinterlegten Template.
