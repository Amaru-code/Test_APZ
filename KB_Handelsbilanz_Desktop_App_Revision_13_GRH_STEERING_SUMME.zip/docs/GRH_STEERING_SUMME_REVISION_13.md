# Revision 13 – GRH, Steering und Summenblatt

## GRH-Layout

- Vor dem MRP-Block bleibt immer genau eine vollständig leere Zeile.
- `Einzelzusagen Anwärter` und `Barlohnumwandlung` werden als normale, nicht fette Abschnittsüberschriften ausgegeben.
- Die Werte der Barlohnumwandlung bleiben normal formatiert.
- Betrag und Anzahl von `Mitarbeiter Auslandsges.` werden fett dargestellt.
- Die Detailwerte der Geschäftsführer bleiben normal; die Abschnittssumme ist fett.
- Die MRP-Werte sind fett.
- Abschnittssummen und Gesamtsumme übernehmen die Summenrahmen aus dem Template.
- Der Druckbereich wird bis zur tatsächlichen Gesamtsumme erweitert.

Die fachlichen Zielzeilen in `config/rules.json` wurden nicht geändert. Die notwendige physische Verschiebung des unteren GRH-Blocks wird ausschließlich beim Schreiben des Reports vorgenommen.

## Kompaktes Steering-Blatt

Das Steering-/Kiepe-Blatt enthält keinen künstlichen Leerbereich mehr. Die drei Detailzeilen stehen in den Zeilen 12 bis 14, die Abschnittssumme in Zeile 15 und die grüne Gesamtsumme in Zeile 17. Der Druckbereich endet ebenfalls in Zeile 17.

## Blatt `Summe`

Das im lokalen Template vorhandene Blatt `Summe` bleibt in der Ergebnisdatei erhalten und wird als letztes Blatt einsortiert.

- Die vorhandene Formatierung des Template-Blatts bleibt erhalten.
- Die vorhandenen Summenformeln werden vor dem Trennen externer Links gesichert.
- Externe Verweise werden durch lokale Formeln auf die tatsächlich erzeugten Gesellschaftsblätter ersetzt.
- Nicht ausgewählte Gesellschaften werden in den Formeln mit `0` berücksichtigt, sodass keine `#BEZUG!`-Fehler entstehen.
- `Kiepe`-Verweise werden auf das erzeugte Blatt `Steering` umgeleitet.
- Die GRH-Zeilenverschiebungen werden auch in den Formeln des Summenblatts berücksichtigt.
- Excel wird zur vollständigen Neuberechnung der Formeln aufgefordert.

Voraussetzung ist, dass das lokale Template das fachlich aufgebaute Blatt `Summe` mit seinen Ausgangsformeln enthält. Die Anwendung erzeugt bewusst kein frei erfundenes Ersatzlayout.
