# Changelog – Revision 13

- Genau eine Leerzeile zwischen Barlohnumwandlung und MRP im GRH-Blatt ergänzt.
- GRH-Fettschrift für Überschriften, Detailwerte, Geschäftsführer-Summe, Auslandsanzahl und MRP korrigiert.
- Fehlende Summenrahmen aus dem Template wieder auf die Zwischensummen übertragen.
- Steering-/Kiepe-Blatt ohne langen Leerbereich kompakt bis Zeile 17 aufgebaut.
- Druckbereiche von GRH und Steering an die tatsächliche Berichtshöhe angepasst.
- Das vorhandene Template-Blatt `Summe` wird nicht mehr entfernt.
- Externe Summenverweise werden in lokale Excel-Formeln auf die erzeugten Gesellschaftsblätter umgeschrieben.
- Nicht ausgewählte Gesellschaften erzeugen keine defekten Links oder Zirkelbezüge.
- Fachliche Regeln in `config/rules.json` unverändert gelassen.
- Automatisierte Tests auf 40 erfolgreiche Prüfungen erweitert.
