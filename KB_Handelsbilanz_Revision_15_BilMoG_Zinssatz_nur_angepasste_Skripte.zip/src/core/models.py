from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable


LogCallback = Callable[[str], None]


@dataclass(slots=True)
class AppOptions:
    current_file: Path
    output_type: str
    companies: list[str]
    output_dir: Path
    previous_file: Path | None = None
    interest_rate: float | None = None


@dataclass(slots=True)
class SourceDataset:
    path: Path
    sheet_name: str
    header_row: int
    headers: dict[str, int]
    records: list[dict[str, Any]]


@dataclass(slots=True)
class MetricResult:
    company: str
    target_row: int
    cell_reference: str
    section: str
    label: str
    value: float
    employee_count: int
    matched_rows: int
    employee_ids: list[str] = field(default_factory=list)
    warning: str | None = None


@dataclass(slots=True)
class CompanyResult:
    company: str
    current: list[MetricResult]
    previous: list[MetricResult] | None = None


@dataclass(slots=True)
class RunResult:
    output_workbook: Path
    output_folder: Path
    markdown_files: list[Path]
    manifest_file: Path
    warnings: list[str]
    output_pdf: Path | None = None
