from __future__ import annotations

from copy import deepcopy
from datetime import date, datetime
import json
import logging
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import uuid
from typing import Any

from app.service import run_calculation
from core.config_loader import load_rule_config
from core.models import AppOptions
from core.normalization import parse_interest_rate_percent
from excel.source_reader import read_source_file


LOGGER = logging.getLogger(__name__)


_ALLOWED_OPERATORS = {"eq", "neq", "in", "not_in", "gt", "gte", "lt", "lte"}


class DesktopBridge:
    """Python bridge used by the local WebView desktop interface."""

    def __init__(self, root_dir: Path) -> None:
        self._root_dir = root_dir.resolve()
        self._jobs: dict[str, dict[str, Any]] = {}
        self._jobs_lock = threading.Lock()
        self._settings_path = self._root_dir / "config" / "app_settings.json"
        self._rules_path = self._root_dir / "config" / "rules.json"
        self._ensure_settings()

    def _default_settings(self) -> dict[str, Any]:
        return {
            "output_dir": str(self._root_dir / "outputs"),
            "auto_open_excel": False,
            "auto_open_folder": False,
            "remember_last_selection": True,
            "theme": "light",
        }

    def _ensure_settings(self) -> None:
        if not self._settings_path.exists():
            self._settings_path.parent.mkdir(parents=True, exist_ok=True)
            self._settings_path.write_text(
                json.dumps(self._default_settings(), ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )

    def get_settings(self) -> dict[str, Any]:
        self._ensure_settings()
        try:
            data = json.loads(self._settings_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            data = self._default_settings()
        defaults = self._default_settings()
        defaults.update({key: value for key, value in data.items() if key in defaults})
        return defaults

    def save_settings(self, settings: dict[str, Any]) -> dict[str, Any]:
        current = self._default_settings()
        current.update({key: value for key, value in settings.items() if key in current})
        output_dir = Path(str(current["output_dir"])).expanduser()
        if not output_dir.is_absolute():
            output_dir = (self._root_dir / output_dir).resolve()
        output_dir.mkdir(parents=True, exist_ok=True)
        current["output_dir"] = str(output_dir)
        self._settings_path.write_text(
            json.dumps(current, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return current

    def get_bootstrap(self) -> dict[str, Any]:
        config = load_rule_config(self._rules_path)
        companies = [
            {
                "name": name,
                "code": data.get("code", ""),
                "rule_count": len(data.get("rules", [])),
            }
            for name, data in config.companies.items()
        ]
        version_path = self._root_dir / "VERSION.txt"
        version = version_path.read_text(encoding="utf-8").strip() if version_path.exists() else "Desktop UI"
        return {
            "version": version,
            "companies": companies,
            "value_columns": config.value_columns,
            "history": self.list_history(),
            "settings": self.get_settings(),
            "rule_count": sum(item["rule_count"] for item in companies),
        }

    def select_excel_file(self) -> str | None:
        """Open a native dialog and return a validated Excel workbook path.

        pywebview validates filter descriptions with a deliberately narrow
        parser. Descriptions may contain letters, numbers and spaces, but no
        hyphens. Some Windows installations can still reject a custom filter;
        in that case the dialog is opened again without a filter and the file
        extension is validated in Python.
        """
        try:
            import webview

            window = webview.active_window()
            if window is None and getattr(webview, "windows", None):
                window = webview.windows[0]
            if window is None:
                raise RuntimeError("Das Desktop-Fenster ist noch nicht bereit.")
            dialog_open = getattr(webview.FileDialog, "OPEN", None) or getattr(
                webview.FileDialog, "LOAD"
            )
            try:
                result = window.create_file_dialog(
                    dialog_open,
                    allow_multiple=False,
                    file_types=("Excel Dateien (*.xlsx;*.xlsm)", "Alle Dateien (*.*)"),
                )
            except Exception as filter_error:
                LOGGER.warning(
                    "Der gefilterte Excel-Dateidialog wurde abgelehnt; "
                    "erneuter Versuch ohne Filter: %s",
                    filter_error,
                )
                result = window.create_file_dialog(
                    dialog_open,
                    allow_multiple=False,
                )
        except Exception as exc:
            LOGGER.exception("Der Excel-Dateidialog konnte nicht geöffnet werden.")
            raise RuntimeError(f"Der Excel-Dateidialog konnte nicht geöffnet werden: {exc}") from exc
        if not result:
            return None
        selected = result[0] if isinstance(result, (list, tuple)) else result
        selected_path = Path(str(selected)).expanduser().resolve()
        if selected_path.suffix.casefold() not in {".xlsx", ".xlsm"}:
            raise RuntimeError(
                "Bitte eine Excel-Datei im Format .xlsx oder .xlsm auswählen."
            )
        if not selected_path.is_file():
            raise FileNotFoundError(f"Die ausgewählte Excel-Datei wurde nicht gefunden: {selected_path}")
        return str(selected_path)

    def select_output_folder(self) -> str | None:
        """Open the native folder dialog supported by pywebview 6."""
        try:
            import webview

            window = webview.active_window()
            if window is None and getattr(webview, "windows", None):
                window = webview.windows[0]
            if window is None:
                raise RuntimeError("Das Desktop-Fenster ist noch nicht bereit.")
            result = window.create_file_dialog(webview.FileDialog.FOLDER)
        except Exception as exc:
            LOGGER.exception("Der Ordnerdialog konnte nicht geöffnet werden.")
            raise RuntimeError(f"Der Ordnerdialog konnte nicht geöffnet werden: {exc}") from exc
        if not result:
            return None
        selected = result[0] if isinstance(result, (list, tuple)) else result
        return str(Path(str(selected)).resolve())

    def inspect_source(self, path: str, output_type: str, companies: list[str]) -> dict[str, Any]:
        config = load_rule_config(self._rules_path)
        selected = companies or config.company_names()
        required_fields = config.required_fields(selected, output_type)
        dataset = read_source_file(Path(path), config, required_fields)
        return {
            "path": str(dataset.path),
            "name": dataset.path.name,
            "sheet_name": dataset.sheet_name,
            "header_row": dataset.header_row,
            "record_count": len(dataset.records),
        }

    def start_calculation(self, payload: dict[str, Any]) -> str:
        job_id = uuid.uuid4().hex
        job = {
            "id": job_id,
            "state": "queued",
            "progress": 1,
            "stage": "Auswertung wird vorbereitet",
            "logs": [],
            "result": None,
            "error": None,
        }
        with self._jobs_lock:
            self._jobs[job_id] = job

        thread = threading.Thread(
            target=self._run_calculation_job,
            args=(job_id, deepcopy(payload)),
            name=f"kb-run-{job_id[:8]}",
            daemon=True,
        )
        thread.start()
        return job_id

    def _patch_job(self, job_id: str, **updates: Any) -> None:
        with self._jobs_lock:
            if job_id in self._jobs:
                self._jobs[job_id].update(updates)

    def _append_job_log(self, job_id: str, message: str) -> None:
        progress = None
        stage = message
        lower = message.casefold()
        if "lese aktuelles jahr" in lower:
            progress = 8
        elif "aktuell: header" in lower:
            progress = 22
        elif "lese vorjahr" in lower:
            progress = 30
        elif "vorjahr: header" in lower:
            progress = 38
        elif "berechne kennzahlen" in lower:
            progress = 52
        elif "erstelle excel" in lower:
            progress = 72
        elif "pdf-ausgabe" in lower:
            progress = 88
        elif "fertig" in lower:
            progress = 96
        with self._jobs_lock:
            job = self._jobs.get(job_id)
            if not job:
                return
            job["logs"] = [*job.get("logs", []), message][-80:]
            job["stage"] = stage
            if progress is not None:
                job["progress"] = max(int(job.get("progress", 0)), progress)

    def _run_calculation_job(self, job_id: str, payload: dict[str, Any]) -> None:
        self._patch_job(job_id, state="running", progress=4, stage="Quelldatei wird vorbereitet")
        try:
            settings = self.get_settings()
            output_dir = Path(str(payload.get("output_dir") or settings["output_dir"]))
            if not output_dir.is_absolute():
                output_dir = (self._root_dir / output_dir).resolve()
            output_dir.mkdir(parents=True, exist_ok=True)
            options = AppOptions(
                current_file=Path(str(payload["current_file"])),
                previous_file=Path(str(payload["previous_file"])) if payload.get("previous_file") else None,
                output_type=str(payload.get("output_type") or "HGB"),
                companies=[str(value) for value in payload.get("companies", [])],
                output_dir=output_dir,
                interest_rate=parse_interest_rate_percent(
                    payload.get("interest_rate_percent")
                ),
            )
            result = run_calculation(
                self._root_dir,
                options,
                lambda message: self._append_job_log(job_id, message),
            )
            history_item = self._history_item_from_manifest(result.manifest_file)
            response = {
                "workbook": str(result.output_workbook),
                "pdf": str(result.output_pdf) if result.output_pdf else None,
                "output_folder": str(result.output_folder),
                "warnings": result.warnings,
                "history_item": history_item,
            }
            self._patch_job(
                job_id,
                state="done",
                progress=100,
                stage=("Excel- und PDF-Ausgabe wurden erfolgreich erstellt" if result.output_pdf else "Excel-Ausgabe wurde erfolgreich erstellt"),
                result=response,
            )
            if settings.get("auto_open_excel"):
                self.open_path(str(result.output_workbook))
            elif settings.get("auto_open_folder"):
                self.open_path(str(result.output_folder))
        except Exception as exc:
            self._patch_job(
                job_id,
                state="error",
                progress=100,
                stage="Auswertung fehlgeschlagen",
                error=str(exc),
            )

    def get_job(self, job_id: str) -> dict[str, Any]:
        with self._jobs_lock:
            job = self._jobs.get(job_id)
            if not job:
                return {
                    "id": job_id,
                    "state": "error",
                    "progress": 100,
                    "stage": "Unbekannter Auftrag",
                    "logs": [],
                    "error": "Der Berechnungsauftrag wurde nicht gefunden.",
                }
            return deepcopy(job)

    def _history_item_from_manifest(self, manifest_path: Path) -> dict[str, Any]:
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
        folder = manifest_path.parent
        workbook_value = str(payload.get("workbook") or "")
        workbook = Path(workbook_value)
        if not workbook.exists():
            candidates = sorted([*folder.glob("*.xlsx"), *folder.glob("*.xlsm")])
            workbook = candidates[0] if candidates else workbook
        return {
            "id": folder.name,
            "generated_at": str(payload.get("generated_at") or ""),
            "output_type": str(payload.get("output_type") or "HGB"),
            "current_file": str(payload.get("current_file") or ""),
            "previous_file": payload.get("previous_file"),
            "current_record_count": int(payload.get("current_record_count") or 0),
            "companies": list(payload.get("companies") or []),
            "workbook": str(workbook),
            "pdf": str(payload.get("pdf") or ""),
            "output_folder": str(folder),
            "warnings": list(payload.get("warnings") or []),
        }

    def list_history(self) -> list[dict[str, Any]]:
        output_dirs = {self._root_dir / "outputs"}
        settings_dir = Path(str(self.get_settings()["output_dir"]))
        if not settings_dir.is_absolute():
            settings_dir = (self._root_dir / settings_dir).resolve()
        output_dirs.add(settings_dir)
        items: list[dict[str, Any]] = []
        seen: set[Path] = set()
        for output_dir in output_dirs:
            if not output_dir.exists():
                continue
            for manifest in output_dir.rglob("run_manifest.json"):
                resolved = manifest.resolve()
                if resolved in seen:
                    continue
                seen.add(resolved)
                try:
                    items.append(self._history_item_from_manifest(manifest))
                except (OSError, json.JSONDecodeError, ValueError, TypeError):
                    continue
        items.sort(key=lambda item: item.get("generated_at", ""), reverse=True)
        return items

    @staticmethod
    def _json_cell_value(value: Any) -> str | int | float | bool | None:
        if value is None or isinstance(value, (str, int, float, bool)):
            return value
        if isinstance(value, (datetime, date)):
            return value.strftime("%d.%m.%Y %H:%M:%S" if isinstance(value, datetime) else "%d.%m.%Y")
        return str(value)

    def get_workbook_preview(self, path: str) -> dict[str, Any]:
        from openpyxl import load_workbook

        workbook_path = Path(path)
        if not workbook_path.exists():
            raise FileNotFoundError(f"Excel-Datei wurde nicht gefunden: {workbook_path}")
        workbook = load_workbook(workbook_path, read_only=False, data_only=False)
        try:
            sheets: list[dict[str, Any]] = []
            for worksheet in workbook.worksheets:
                max_row = min(max(1, worksheet.max_row), 250)
                max_col = min(max(1, worksheet.max_column), 40)
                rows: list[list[Any]] = []
                for row in worksheet.iter_rows(min_row=1, max_row=max_row, min_col=1, max_col=max_col):
                    rows.append([self._json_cell_value(cell.value) for cell in row])
                widths: list[float] = []
                for column_index in range(1, max_col + 1):
                    from openpyxl.utils import get_column_letter

                    widths.append(float(worksheet.column_dimensions[get_column_letter(column_index)].width or 12))
                sheets.append(
                    {
                        "name": worksheet.title,
                        "max_row": max_row,
                        "max_col": max_col,
                        "rows": rows,
                        "merges": [str(value) for value in worksheet.merged_cells.ranges],
                        "widths": widths,
                    }
                )
            return {
                "path": str(workbook_path),
                "file_name": workbook_path.name,
                "active_sheet": workbook.index(workbook.active),
                "sheets": sheets,
            }
        finally:
            workbook.close()

    def get_rules(self) -> dict[str, Any]:
        return json.loads(self._rules_path.read_text(encoding="utf-8"))

    def _validate_rules(self, payload: dict[str, Any]) -> None:
        required_sections = {"value_columns", "header_aliases", "employee_id_priority", "companies"}
        missing = sorted(required_sections - set(payload))
        if missing:
            raise ValueError("Fehlende Hauptbereiche: " + ", ".join(missing))
        sets = payload.get("sets", {})
        fields = set(payload.get("header_aliases", {})) | set(payload.get("value_columns", {}).values())
        for company_name, company in payload.get("companies", {}).items():
            if "code" not in company:
                raise ValueError(f"{company_name}: Gesellschaftscode fehlt.")
            rules = company.get("rules")
            if not isinstance(rules, list):
                raise ValueError(f"{company_name}: rules muss eine Liste sein.")
            rows: list[int] = []
            for rule_index, rule in enumerate(rules, start=1):
                try:
                    target_row = int(rule["target_row"])
                except (KeyError, TypeError, ValueError) as exc:
                    raise ValueError(f"{company_name}, Regel {rule_index}: ungültige Zielzeile.") from exc
                rows.append(target_row)
                if not str(rule.get("section", "")).strip() or not str(rule.get("label", "")).strip():
                    raise ValueError(f"{company_name} J{target_row}: Bereich und Bezeichnung sind erforderlich.")
                for group_name in ("all", "any"):
                    conditions = rule.get(group_name, [])
                    if not isinstance(conditions, list):
                        raise ValueError(f"{company_name} J{target_row}: {group_name} muss eine Liste sein.")
                    for condition in conditions:
                        field = condition.get("field")
                        operator = condition.get("op")
                        if field not in fields:
                            raise ValueError(f"{company_name} J{target_row}: unbekanntes Feld {field!r}.")
                        if operator not in _ALLOWED_OPERATORS:
                            raise ValueError(f"{company_name} J{target_row}: unbekannter Operator {operator!r}.")
                        set_ref = condition.get("set_ref")
                        if set_ref and set_ref not in sets:
                            raise ValueError(f"{company_name} J{target_row}: unbekannte Set-Referenz {set_ref!r}.")
            if len(rows) != len(set(rows)):
                duplicates = sorted({row for row in rows if rows.count(row) > 1})
                raise ValueError(f"{company_name}: Zielzeilen mehrfach vergeben: {duplicates}")

    def save_rules(self, payload: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(payload, dict):
            raise ValueError("Die Regelkonfiguration muss ein JSON-Objekt sein.")
        self._validate_rules(payload)
        archive_dir = self._root_dir / "archive" / "rules"
        archive_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        backup = archive_dir / f"rules_{stamp}.json"
        if self._rules_path.exists():
            shutil.copy2(self._rules_path, backup)
        temporary = self._rules_path.with_suffix(".json.tmp")
        temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        # Load through the production parser before replacing the active file.
        load_rule_config(temporary)
        temporary.replace(self._rules_path)
        return {
            "ok": True,
            "message": "Regeln wurden dauerhaft gespeichert.",
            "backup": str(backup),
        }

    def open_path(self, path: str) -> bool:
        target = Path(path)
        if not target.is_absolute():
            target = (self._root_dir / target).resolve()
        if not target.exists():
            raise FileNotFoundError(f"Pfad wurde nicht gefunden: {target}")
        if sys.platform.startswith("win"):
            os.startfile(str(target))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(target)])
        else:
            subprocess.Popen(["xdg-open", str(target)])
        return True
