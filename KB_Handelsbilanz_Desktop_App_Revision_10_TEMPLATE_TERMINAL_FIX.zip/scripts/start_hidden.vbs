Option Explicit
Dim shell, fso, scriptDir, rootDir, pythonw, appFile, command
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
rootDir = fso.GetParentFolderName(scriptDir)
pythonw = rootDir & "\.venv\Scripts\pythonw.exe"
appFile = rootDir & "\src\desktop_app.py"
If Not fso.FileExists(pythonw) Then
    MsgBox "Die virtuelle Umgebung fehlt. Bitte zuerst INSTALLIEREN_UND_STARTEN.bat ausfuehren.", 16, "KB Handelsbilanz"
    WScript.Quit 2
End If
If Not fso.FileExists(appFile) Then
    MsgBox "Die Desktop-Anwendung wurde nicht gefunden: " & appFile, 16, "KB Handelsbilanz"
    WScript.Quit 3
End If
shell.CurrentDirectory = rootDir
command = Chr(34) & pythonw & Chr(34) & " " & Chr(34) & appFile & Chr(34)
shell.Run command, 0, False
