@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title KB Handelsbilanz Desktop App - Revision 10 Diagnose

set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"

echo ============================================================
echo  KB Handelsbilanz Desktop App - Revision 10 Diagnose
echo ============================================================
echo Projektordner: %CD%
echo.

echo [1] Windows und CMD
ver
echo ComSpec: %ComSpec%
echo.

echo [2] Python Launcher
where py.exe 2>nul
py -3 --version 2>nul
echo.

echo [3] Virtuelle Umgebung und Python-Pakete
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" --version
    ".venv\Scripts\python.exe" -c "import openpyxl, importlib.metadata as md; print('openpyxl:', openpyxl.__version__); print('pywebview:', md.version('pywebview'))"
) else (
    echo NICHT VORHANDEN
)
echo.

echo [4] Excel-Template
if exist ".venv\Scripts\python.exe" (
    set "PYTHONPATH=%CD%\src"
    ".venv\Scripts\python.exe" -c "from pathlib import Path; from excel.template_writer import resolve_template_path; print('Template:', resolve_template_path(Path.cwd()))"
) else (
    dir /b "data\samples\Knorr_Bremse_HGB_2023*.xls*" 2>nul
)
echo.

echo [5] Desktop-Frontend
for %%F in ("frontend\dist\index.html" "frontend\dist\app.css" "frontend\dist\app.js" "frontend\dist\assets\logo.svg") do (
    if exist %%F (echo OK: %%~F) else (echo FEHLT: %%~F)
)
echo.

echo [6] Verdeckter Start
for %%F in ("scripts\start_hidden.vbs" ".venv\Scripts\pythonw.exe") do (
    if exist %%F (echo OK: %%~F) else (echo FEHLT: %%~F)
)
echo.

echo [7] Zentrale Projektdateien
for %%F in ("requirements.txt" "config\rules.json" "config\template_settings.json" "src\desktop_app.py" "src\desktop_bridge.py" "src\excel\template_writer.py") do (
    if exist %%F (echo OK: %%~F) else (echo FEHLT: %%~F)
)
echo.

echo Diagnose abgeschlossen.
pause
