from __future__ import annotations

from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from urllib.request import urlopen
import types

from frontend_server import FrontendServer
import desktop_app


class FrontendServerTests(unittest.TestCase):
    def test_serves_frontend_and_assets_over_loopback_http(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            (root / "index.html").write_text(
                '<!doctype html><link rel="stylesheet" href="./app.css"><h1>KB</h1>',
                encoding="utf-8",
            )
            (root / "app.css").write_text("body{color:#123}", encoding="utf-8")

            server = FrontendServer(root, revision=8)
            try:
                url = server.start()
                self.assertTrue(url.startswith("http://127.0.0.1:"), url)
                self.assertIn("/index.html?desktop=1&revision=8", url)
                with urlopen(url, timeout=3) as response:
                    html = response.read().decode("utf-8")
                    self.assertEqual(response.status, 200)
                    self.assertIn("<h1>KB</h1>", html)
                    self.assertEqual(response.headers.get("Cache-Control"), "no-store, no-cache, must-revalidate, max-age=0")
                css_url = url.split("/index.html", 1)[0] + "/app.css"
                with urlopen(css_url, timeout=3) as response:
                    self.assertEqual(response.read().decode("utf-8"), "body{color:#123}")
            finally:
                server.stop()
            self.assertFalse(server.is_running)

    def test_desktop_app_passes_live_http_url_to_webview(self) -> None:
        captured: dict[str, object] = {}

        def create_window(title: str, **kwargs: object) -> object:
            captured["title"] = title
            captured["url"] = kwargs["url"]
            return object()

        def start(**kwargs: object) -> None:
            url = str(captured["url"])
            self.assertTrue(url.startswith("http://127.0.0.1:"), url)
            self.assertIn("desktop=1&revision=10", url)
            with urlopen(url, timeout=3) as response:
                self.assertEqual(response.status, 200)
                self.assertIn("KB Handelsbilanz", response.read().decode("utf-8"))

        fake_webview = types.SimpleNamespace(create_window=create_window, start=start)
        with patch.dict("sys.modules", {"webview": fake_webview}):
            self.assertEqual(desktop_app.main(), 0)
        self.assertEqual(captured["title"], "KB Handelsbilanz")

    def test_missing_index_is_reported_before_webview_starts(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            server = FrontendServer(Path(temp_dir), revision=8)
            with self.assertRaises(FileNotFoundError):
                server.start()


if __name__ == "__main__":
    unittest.main()
