from __future__ import annotations

import shutil
import tempfile
import unittest
from pathlib import Path

from openpyxl import load_workbook

from app.service import run_calculation
from core.models import AppOptions
from excel.template_writer import resolve_template_path


ROOT = Path(__file__).resolve().parents[1]
SAMPLE = ROOT / "data" / "samples" / "sample_AllOnetabOrFile.xlsx"


class PrintReportTests(unittest.TestCase):
    def test_template_is_resolved_from_samples_folder(self) -> None:
        template = resolve_template_path(ROOT)
        self.assertTrue(template.is_file())
        self.assertTrue(template.name.startswith("Knorr_Bremse_HGB_2023"))

    def test_company_only_template_report_without_previous_year(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            current = temp_path / "Sommerbewertung_30.06.2026.xlsx"
            shutil.copy2(SAMPLE, current)
            result = run_calculation(
                ROOT,
                AppOptions(
                    current_file=current,
                    previous_file=None,
                    output_type="HGB",
                    companies=["GRH", "SFS", "Steering"],
                    output_dir=temp_path / "out",
                ),
            )
            workbook = load_workbook(result.output_workbook, data_only=False)
            self.assertEqual(workbook.sheetnames, ["GRH", "SFS", "Steering"])
            self.assertNotIn("Rechenlauf", workbook.sheetnames)
            self.assertNotIn("Summe", workbook.sheetnames)
            self.assertNotIn("BilMoG", workbook.sheetnames)

            grh = workbook["GRH"]
            self.assertEqual(
                grh["C2"].value,
                "Entwicklung der Pensionsrückstellungen 30.06.2026 - Handelsbilanz",
            )
            self.assertEqual(grh["C8"].value, "GRH")
            self.assertEqual(grh["C10"].value, "Versorgungswerk Anwärter")
            self.assertEqual(grh["D12"].value, "Anwärter Männer")
            self.assertIsInstance(grh["F12"].value, (int, float))
            self.assertIsInstance(grh["H12"].value, int)
            self.assertTrue(grh.column_dimensions["J"].hidden)
            self.assertIn("$H$", str(grh.print_area))
            self.assertEqual(grh.page_setup.fitToWidth, 1)
            formulas = [
                cell.value
                for row in grh.iter_rows()
                for cell in row
                if isinstance(cell.value, str) and cell.value.startswith("=")
            ]
            self.assertEqual(formulas, [])
            workbook.close()

    def test_template_report_with_previous_year(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            current = temp_path / "Bewertung_30.06.2026.xlsx"
            previous = temp_path / "Bewertung_31.12.2025.xlsx"
            shutil.copy2(SAMPLE, current)
            shutil.copy2(SAMPLE, previous)
            result = run_calculation(
                ROOT,
                AppOptions(
                    current_file=current,
                    previous_file=previous,
                    output_type="HGB",
                    companies=["SFS"],
                    output_dir=temp_path / "out",
                ),
            )
            workbook = load_workbook(result.output_workbook, data_only=False)
            self.assertEqual(workbook.sheetnames, ["SFS"])
            sfs = workbook["SFS"]
            self.assertEqual(sfs["F5"].value, "31.12.2025")
            self.assertEqual(sfs["J5"].value, "30.06.2026")
            self.assertEqual(sfs["L12"].value, 0)
            self.assertFalse(sfs.column_dimensions["J"].hidden)
            self.assertIn("$N$", str(sfs.print_area))
            self.assertIsNone(result.output_pdf)  # Linux-Testumgebung ohne Excel-COM
            workbook.close()


if __name__ == "__main__":
    unittest.main()
