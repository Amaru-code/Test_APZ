@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title KB Handelsbilanz - Diagnose-Start
if not exist ".venv\Scripts\python.exe" (
    echo Die virtuelle Umgebung fehlt.
    echo Bitte zuerst INSTALLIEREN_UND_STARTEN.bat ausfuehren.
    pause
    exit /b 2
)
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
"%~dp0.venv\Scripts\python.exe" "%~dp0src\desktop_app.py"
set "EXITCODE=%ERRORLEVEL%"
if not "%EXITCODE%"=="0" pause
exit /b %EXITCODE%
