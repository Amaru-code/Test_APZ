@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
    call "%~dp0INSTALLIEREN_UND_STARTEN.bat"
    exit /b %ERRORLEVEL%
)
start "" /b wscript.exe "%~dp0scripts\start_hidden.vbs"
exit /b 0
