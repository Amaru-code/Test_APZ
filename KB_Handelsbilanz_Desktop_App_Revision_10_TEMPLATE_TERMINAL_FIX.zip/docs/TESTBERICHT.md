# Testbericht – Revision 10

## Automatisierte Prüfung

- 35 von 35 Tests erfolgreich
- bestehende 183 Feldregeln unverändert gültig
- Template-Auflösung aus `data/samples` geprüft
- Output enthält ausschließlich ausgewählte Gesellschaftsblätter
- `Rechenlauf`, `Summe` und `BilMoG` werden entfernt
- Ausgabe ohne Vorjahr geprüft
- Ausgabe mit Vorjahr und Zuführung geprüft
- alte `getwert`-Formeln werden entfernt
- Arbeitsmappen lassen sich mit OpenPyXL erneut vollständig laden
- ZIP/XML-Integrität der Testausgabe geprüft
- versteckter `pythonw.exe`-Start und Windows-CRLF-Dateien geprüft

## Windows-Ausgabe

Unter Windows versucht die Anwendung zuerst, das Originaltemplate direkt über Microsoft Excel COM zu bearbeiten. Dadurch bleiben Bilder, Formen, Druckeinstellungen und XLSM-Inhalte bestmöglich erhalten. Falls Excel COM nicht verfügbar ist, greift automatisch die getestete OpenPyXL-Variante.
