# Revision 9 – Druckfertiger Handelsbilanz-Output

## Ziel

Die fachliche Berechnung bleibt unverändert. Die erzeugte Excel-Datei ist nun kein reines Kontrollblatt mehr, sondern ein druckfertiges Berichtspaket.

## Arbeitsmappe

1. **Rechenlauf**  
   Technische Nachvollziehbarkeit mit Quelldateien, Filtern, Zielzellen und allen berechneten Werten.
2. **Ein Reportblatt je ausgewählter Gesellschaft**  
   Kompakte Darstellung nach Versorgungswerk, Einzelzusagen und weiteren Regelabschnitten.
3. **Summe**  
   Aggregierte Übersicht über alle ausgewählten Gesellschaften.

Beim Öffnen ist automatisch das erste Reportblatt aktiv, nicht der technische Rechenlauf.

## Ohne Vorjahr

- Rückstellung zum aktuellen Stichtag
- Anzahl Berechtigte
- fett hervorgehobene Abschnittssummen
- A4-Hochformat und eine Seite Breite

## Mit Vorjahr

- Rückstellung Vorjahr
- Anzahl Berechtigte Vorjahr
- Rückstellung aktueller Stichtag
- Zuführung als Differenz aktuell minus Vorjahr
- Anzahl Berechtigte aktuell
- grüne bzw. rote Hervorhebung entsprechend dem Vorzeichen der Zuführung

## Stichtag

Der Stichtag wird automatisch aus dem Dateinamen gelesen. Unterstützte Beispiele:

- `Sommerbewertung 30.06.2026.xlsx`
- `Bewertung_30-06-2026.xlsm`
- `Bewertung_2026-06-30.xlsx`

Enthält der Dateiname keinen Stichtag, wird das Änderungsdatum der Datei verwendet.

## PDF

Unter Windows versucht das Tool nach der XLSX-Erstellung automatisch, über Microsoft Excel eine PDF zu erzeugen. In die PDF gelangen die Reportblätter und das Summenblatt; der technische Rechenlauf wird ausgeblendet.

Voraussetzungen:

- Microsoft Excel ist installiert.
- `pywin32` wurde durch `INSTALLIEREN_UND_STARTEN.bat` installiert.

Scheitert der automatische PDF-Export, bleibt die XLSX vollständig druckfertig und die Berechnung wird nicht abgebrochen.

## BilMoG

Ein BilMoG-Blatt wird noch nicht mit Berechnungswerten erzeugt. Dafür sind bisher keine eigenständigen BilMoG-Berechnungsspalten oder Feldregeln hinterlegt. Es werden bewusst keine Werte erfunden oder aus HGB kopiert.
