# Revision 10 – Original-Template und unsichtbarer Start

## Unsichtbarer Desktop-Start

Der normale Start erfolgt über `pythonw.exe` und ein kleines VBScript. Dadurch bleibt während der Nutzung kein Terminalfenster geöffnet. Wird das App-Fenster geschlossen, endet auch der Python-Prozess einschließlich des lokalen UI-Servers.

Für Fehlerdiagnosen bleibt `STARTEN_MIT_TERMINAL.bat` verfügbar.

## Verwendetes Excel-Template

Die Anwendung sucht im Ordner `data/samples` nach einer Datei, deren Name mit `Knorr_Bremse_HGB_2023` beginnt und die auf `.xlsm` oder `.xlsx` endet. Bevorzugt wird die Originaldatei:

```text
Knorr_Bremse_HGB_2023 - Kopie.xlsm
```

Die echte Excel-Datei wird benötigt, weil nur sie unter anderem folgende Informationen enthält:

- Zellformate und Rahmen
- Bilder und Logo
- Spaltenbreiten und Zeilenhöhen
- Druckbereiche und Seiteneinstellungen
- Makrocontainer einer XLSM-Datei

Die JSON-Darstellung enthält diese Layoutinformationen nicht vollständig.

## Output

Der erzeugte Bericht enthält vorerst ausschließlich die ausgewählten Gesellschaftsblätter. Folgende Altblätter werden entfernt:

- `Rechenlauf`
- `Summe`
- `BilMoG`
- nicht ausgewählte Gesellschaften

Die Berechnungswerte werden als feste Werte in das Template geschrieben. Alte `getwert`-Formeln und technische Hilfsspalten werden entfernt. Ohne Vorjahr werden die aktuellen Werte in den Spalten F und H dargestellt. Mit Vorjahr werden F/H für das Vorjahr und J/L/N für aktuelles Jahr, Zuführung und aktuelle Anzahl verwendet.

## Gesellschaftsblätter

Vorhandene Templateblätter werden direkt verwendet. Für die neuen Projektgesellschaften gelten diese Layoutbasen:

- `GRH` wird aus dem SFS-Layout abgeleitet, sofern im Originaltemplate noch kein GRH-Blatt existiert.
- `Steering` verwendet das frühere Blatt `Kiepe`.

Ein eigenes GRH-Blatt im Originaltemplate ist optional. Ist eines vorhanden, wird es automatisch bevorzugt.
