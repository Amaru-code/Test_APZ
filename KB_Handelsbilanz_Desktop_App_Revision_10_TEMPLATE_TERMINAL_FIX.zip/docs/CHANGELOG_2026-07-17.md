# Revision 8 – Dateidialog- und Taskleisten-Fix (19.07.2026)

- Ungültige Filterbeschreibung `Excel-Dateien` durch `Excel Dateien` ersetzt.
- `.xlsx` und `.xlsm` sind im nativen Windows-Dateidialog auswählbar.
- Bei Filterproblemen wird der Dialog automatisch ohne Filter erneut geöffnet.
- Python validiert anschließend Dateiendung und Existenz der ausgewählten Datei.
- App startet maximiert und respektiert den Arbeitsbereich oberhalb der Taskleiste.
- Feste Mindesthöhe des Frontends entfernt.
- Kompaktes Layout für geringe Bildschirmhöhen ergänzt.
- Fachregeln und Berechnungslogik unverändert.

---

# Revision 7 – Startpfad-Fix (19.07.2026)

- `ERR_FILE_NOT_FOUND` beim Start behoben.
- Fragile `file:///`-Adresse durch einen lokalen Loopback-HTTP-Server ersetzt.
- Frontend-Dateien werden unabhängig von Leerzeichen, Umlauten und Projektpfad geladen.
- Kein externer Netzwerkzugriff; Bindung ausschließlich an `127.0.0.1`.
- Dateiauswahl-Fix aus Revision 6 unverändert übernommen.

---

# Revision 6 – Dateiauswahl und Desktop-Bridge repariert

- Native Excel-Dateiauswahl auf die pywebview-6-API `FileDialog.OPEN` mit kompatiblem `LOAD`-Fallback umgestellt.
- Ordnerdialog auf `FileDialog.FOLDER` umgestellt.
- WebView-Fenster nicht mehr als Bestandteil des JavaScript-API-Objekts gespeichert; damit ist die zyklische Serialisierung mit `Auto.Auto...` und `maximum recursion depth exceeded` beseitigt.
- Desktop-Frontend wartet nun auf die jeweils konkret benötigte Python-Methode.
- Initialisierung gegen parallele und zu frühe `get_bootstrap`-Aufrufe abgesichert.
- Browser-Demo-Dateipfade werden in der echten Desktop-App nicht mehr als Quelldateien verwendet.
- Dateidialogfehler werden protokolliert und verständlich in der Oberfläche angezeigt, statt stillschweigend in den Demomodus zu wechseln.
- pywebview auf Version 6.2.1 fixiert.
- Fachliche Regeln und visuelles Design unverändert.

---

# Revision 5 – moderne Desktop-Oberfläche

- Neue grün-weiße App-Oberfläche auf Basis des ersten visuellen Entwurfs.
- Navigation auf Review, Ergebnisse, Regeln, Historie und Einstellungen umgestellt.
- Bestehende Python-Berechnung vollständig über eine Desktop-Bridge angebunden.
- Excel-Ergebnisse können direkt in der App mit Sheet-Reitern betrachtet werden.
- Vollständiger visueller Regeleditor mit dauerhaftem Speichern und automatischer Sicherung ergänzt.
- Historie liest frühere Run-Manifeste und öffnet alte Ergebnisse erneut.
- Einstellungen werden dauerhaft in `config/app_settings.json` gespeichert.
- Lokale SVG-Icons und flüssige UI-Animationen integriert.
- React-/TypeScript-/Tailwind-Quellstand und Tauri-2-Projektstruktur beigelegt.
- Direktstart über Windows WebView2/pywebview, ohne Node.js oder Rust beim Anwender.
- Fachliche Regeln aus Revision 4 unverändert beibehalten.

---

# Revision 4 – GRH-Feldregeln aktualisiert

- GRH umfasst nun 22 Kennzahlenregeln; insgesamt enthält das Projekt 183 Regeln.
- Bei den normalen GRH-VO- und GRH-EZ-Kennzahlen wird `SubsidiaryCode != 401` angewendet.
- GRH J30–J40 verwenden nicht mehr `SubsidiaryCode = 400`, sondern entsprechend der neuen Vorgabe `SubsidiaryCode != 401`.
- GRH J33 „Frauen ausgesch. mit unvA“ wurde ergänzt.
- GRH J45/J46 grenzen Geschäftsführer jetzt über `SubsidiaryCode = 401` statt `DivisionCode = 401` ab.
- Der MRP-ClientEEID-Ausschluss wurde aus GRH J21/J22 entfernt; die MRP-Liste bleibt bei J15/J16 als Ausschluss und bei J56 als Einschluss bestehen.
- Die Auslandslogik `(DivisionCode != 270 ODER ClientEEID nicht in GRH_FOREIGN)` wurde unverändert gemäß Vorgabe beibehalten.
- Der Windows-Startfix aus Revision 3 bleibt vollständig erhalten.

---

# Revision 3 – Windows-Startkorrektur

- Alle BAT-Dateien von Unix-LF auf echtes Windows-CRLF umgestellt.
- BAT-Dateien ohne UTF-8-BOM und ausschließlich mit ASCII-Befehlsausgaben gespeichert.
- Fehler behoben, bei dem Windows CMD den ersten Buchstaben einer Zeile verschluckte (`echo` wurde zu `cho`).
- Python-Suche robuster gestaltet und Mindestversion 3.10 geprüft.
- `STARTEN.bat` startet bei fehlender virtueller Umgebung automatisch die Installation.
- Neue `DIAGNOSE.bat` prüft Python, virtuelle Umgebung, Tkinter, openpyxl und Projektdateien.
- Fachliche Feldregeln aus Revision 2 unverändert beibehalten.

---

# Änderungsstand 17.07.2026 – Feldregeln Revision 2

## Übernommen

- 182 Kennzahlenregeln für acht Gesellschaften.
- AG-Geschäftsführer werden über `SubsidiaryCode = 301` abgegrenzt.
- AG J103/J104 verwenden entsprechend der neuen Vorgabe `USC = 50`.
- GRH enthält neue Auslands- und MRP-ClientEEID-Listen.
- HW, IT und KBM grenzen Geschäftsführer über die jeweiligen SubsidiaryCodes 701, 901 und 601 ab; die bisherigen Auslandszeilen J49 entfallen.
- IT J51 verwendet nur noch `GlobeCode = 900` und `VOShortName = DC`.
- SFN enthält die vollständigen neuen Aldersbach-ID-Listen für Anwärter, Ausgeschiedene, Rentner und Witwen.
- SFS-Geschäftsführer werden über `SubsidiaryCode = 201` abgegrenzt.

## Technisch notwendige Festlegung

Die KBM-Zusammenfassung nennt J32 sowohl für Männer als auch für Frauen. Damit beide Kennzahlen separat ausgegeben werden können, bleibt die Frauenzeile in J33. Alle weiteren fachlich ungewöhnlichen Angaben wurden exakt übernommen und in `REGEL_WARNUNGEN.md` vermerkt.

# Revision 9 – Print-ready Report und PDF

- Technisches Hauptblatt in `Rechenlauf` umgewandelt.
- Druckfertige Gesellschaftsblätter im Stil des bisherigen Handelsbilanzberichts ergänzt.
- Originale Zielzeilen der Feldregeln bleiben als Berichtzeilen erhalten.
- Abschnittsüberschriften, fett formatierte Summenzeilen und Gesellschaftsüberschriften ergänzt.
- Vorjahreslayout mit Vorjahr, aktuellem Jahr, Zuführung und Mitarbeiterzahlen ergänzt.
- Positive/negative Zuführungen werden grün bzw. rot hervorgehoben.
- `Summe`-Blatt über alle ausgewählten Gesellschaften ergänzt.
- Berichtsblätter auf A4-Hochformat, eine Seite Breite und Seitenzahlen vorbereitet.
- Stichtage werden aus den Quelldateinamen erkannt.
- Automatischer PDF-Export über Microsoft Excel/COM ergänzt.
- Ergebnisse-Reiter kann eine erzeugte PDF direkt öffnen.
- BilMoG wird mangels eigenständiger Regeln bewusst noch nicht berechnet.
