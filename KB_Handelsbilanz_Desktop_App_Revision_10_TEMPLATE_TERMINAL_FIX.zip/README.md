# KB Handelsbilanz Desktop App – Revision 10

Revision 10 baut auf der stabilen Oberfläche und Berechnungsengine aus Revision 8/9 auf.

## Neu

- Start ohne dauerhaft sichtbares Terminalfenster
- automatisches Beenden des Python-Prozesses beim Schließen der App
- Excel-Ausgabe auf Basis des originalen Knorr-Bremse-Templates
- ausschließlich ausgewählte Gesellschaftsblätter im Output
- `Rechenlauf`, `Summe` und `BilMoG` vorerst entfernt
- Unterstützung für `.xlsx` und `.xlsm` als fertige Ergebnisdatei

## Erster Start

```text
INSTALLIEREN_UND_STARTEN.bat
```

Nach der Installation:

```text
STARTEN.bat
```

Der normale Start verwendet `pythonw.exe`. Es bleibt daher kein schwarzes Terminalfenster hinter der Anwendung geöffnet.

Für eine Diagnose mit sichtbaren Meldungen steht weiterhin zur Verfügung:

```text
STARTEN_MIT_TERMINAL.bat
```

## Originaltemplate

Für das exakte Originaldesign bitte diese Datei im Ordner `data/samples` belassen oder dorthin kopieren:

```text
Knorr_Bremse_HGB_2023 - Kopie.xlsm
```

Es werden auch andere `.xlsm`- oder `.xlsx`-Dateien akzeptiert, deren Dateiname mit `Knorr_Bremse_HGB_2023` beginnt. Die Originaldatei wird vor der mitgelieferten Fallback-Datei bevorzugt.

Das Template darf weiterhin die Blätter `Rechenlauf`, `Summe` und `BilMoG` enthalten. Die Anwendung entfernt diese automatisch aus dem erzeugten Bericht.

Weitere Details: `docs/TEMPLATE_OUTPUT_REVISION_10.md`
