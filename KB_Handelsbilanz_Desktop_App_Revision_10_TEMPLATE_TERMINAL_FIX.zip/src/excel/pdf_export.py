from __future__ import annotations

import logging
import os
import sys
from pathlib import Path


LOGGER = logging.getLogger("kb.pdf")


def export_workbook_to_pdf(workbook_path: Path, pdf_path: Path) -> bool:
    """Exportiert die sichtbaren Reportblätter über Microsoft Excel nach PDF.

    Der technische Tab ``Rechenlauf`` wird nur für den PDF-Export ausgeblendet.
    Die XLSX-Datei selbst wird dabei nicht verändert. Auf Nicht-Windows-Systemen
    oder ohne installierte Excel-COM-Schnittstelle wird ``False`` geliefert.
    """
    if sys.platform != "win32":
        return False

    try:
        import win32com.client  # type: ignore[import-not-found]
    except Exception as exc:  # pragma: no cover - nur Windows
        LOGGER.warning("PDF-Export nicht verfügbar: pywin32 fehlt (%s)", exc)
        return False

    workbook_path = workbook_path.resolve()
    pdf_path = pdf_path.resolve()
    pdf_path.parent.mkdir(parents=True, exist_ok=True)

    excel = None
    workbook = None
    try:  # pragma: no cover - benötigt Microsoft Excel
        excel = win32com.client.DispatchEx("Excel.Application")
        excel.Visible = False
        excel.DisplayAlerts = False
        workbook = excel.Workbooks.Open(str(workbook_path), ReadOnly=True)

        try:
            calculation_sheet = workbook.Worksheets("Rechenlauf")
            # xlSheetHidden = 0; nur im geöffneten COM-Dokument, kein Speichern.
            calculation_sheet.Visible = 0
        except Exception:
            pass

        # 0 = xlTypePDF
        workbook.ExportAsFixedFormat(
            0,
            str(pdf_path),
            Quality=0,
            IncludeDocProperties=True,
            IgnorePrintAreas=False,
            OpenAfterPublish=False,
        )
        return pdf_path.exists() and pdf_path.stat().st_size > 0
    except Exception as exc:
        LOGGER.warning("PDF-Export über Excel ist fehlgeschlagen: %s", exc)
        try:
            if pdf_path.exists() and pdf_path.stat().st_size == 0:
                pdf_path.unlink()
        except OSError:
            pass
        return False
    finally:  # pragma: no cover - benötigt Microsoft Excel
        if workbook is not None:
            try:
                workbook.Close(SaveChanges=False)
            except Exception:
                pass
        if excel is not None:
            try:
                excel.Quit()
            except Exception:
                pass
