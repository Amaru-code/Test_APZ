import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { bridge } from './lib/bridge'
import type { AppPage } from './components/Sidebar'
import type { BootstrapData, JobResult } from './types'
import { Sidebar } from './components/Sidebar'
import { Toasts, type ToastMessage } from './components/Toast'
import { ReviewPage } from './pages/ReviewPage'
import { ResultsPage } from './pages/ResultsPage'
import { RulesPage } from './pages/RulesPage'
import { HistoryPage } from './pages/HistoryPage'
import { SettingsPage } from './pages/SettingsPage'

export default function App() {
  const [activePage, setActivePage] = useState<AppPage>('review')
  const [bootstrap, setBootstrap] = useState<BootstrapData | null>(null)
  const [workbookPath, setWorkbookPath] = useState<string | null>(null)
  const [pdfPath, setPdfPath] = useState<string | null>(null)
  const [toasts, setToasts] = useState<ToastMessage[]>([])

  useEffect(() => {
    bridge.bootstrap().then(setBootstrap).catch((error) => notify('error', error instanceof Error ? error.message : 'Anwendung konnte nicht initialisiert werden.'))
  }, [])

  function notify(kind: ToastMessage['kind'], text: string) {
    const id = Date.now() + Math.random()
    setToasts((items) => [...items, { id, kind, text }])
    window.setTimeout(() => setToasts((items) => items.filter((item) => item.id !== id)), 4200)
  }

  function completed(result: JobResult) {
    setWorkbookPath(result.workbook)
    setPdfPath(result.pdf || null)
    setActivePage('results')
    setBootstrap((current) => current ? { ...current, history: [result.history_item, ...current.history] } : current)
  }

  function openHistory(path: string, pdf?: string | null) {
    setWorkbookPath(path)
    setPdfPath(pdf || null)
    setActivePage('results')
  }

  if (!bootstrap) {
    return (
      <div className="grid h-screen place-items-center bg-slate-100">
        <div className="text-center">
          <div className="mx-auto grid h-16 w-16 animate-pulse place-items-center rounded-2xl bg-gradient-to-br from-teal-500 to-cyan-700 text-xl font-extrabold text-white shadow-soft">KB</div>
          <div className="mt-4 text-sm font-bold text-slate-500">KB Handelsbilanz wird geladen …</div>
        </div>
      </div>
    )
  }

  return (
    <div className="h-screen min-h-0 overflow-hidden p-2 lg:p-3.5">
      <div className="app-shell flex h-full min-h-0 overflow-hidden rounded-app border border-white/90 bg-white/72 shadow-app backdrop-blur-2xl">
        <Sidebar active={activePage} onChange={setActivePage} />
        <main className="min-w-0 flex-1 overflow-auto bg-[rgba(248,251,254,.76)] px-7 py-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={activePage}
              initial={{ opacity: 0, y: 7 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: .22, ease: 'easeOut' }}
              className="min-h-full"
            >
              {activePage === 'review' && <ReviewPage bootstrap={bootstrap} onCompleted={completed} notify={notify} />}
              {activePage === 'results' && <ResultsPage workbookPath={workbookPath} pdfPath={pdfPath} notify={notify} />}
              {activePage === 'rules' && <RulesPage notify={notify} />}
              {activePage === 'history' && <HistoryPage onOpen={openHistory} notify={notify} />}
              {activePage === 'settings' && <SettingsPage notify={notify} />}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
      <Toasts messages={toasts} />
    </div>
  )
}
