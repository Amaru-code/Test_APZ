import { useEffect, useMemo, useState } from 'react'
import { CalendarDays, ChevronRight, FileSpreadsheet, RefreshCw, Search } from 'lucide-react'
import { bridge } from '../lib/bridge'
import type { HistoryRun } from '../types'

export function HistoryPage({ onOpen, notify }: { onOpen: (path: string, pdf?: string | null) => void; notify: (kind: 'success' | 'error' | 'info', text: string) => void }) {
  const [items, setItems] = useState<HistoryRun[]>([])
  const [query, setQuery] = useState('')

  async function refresh() {
    try {
      setItems(await bridge.listHistory())
    } catch (error) {
      notify('error', error instanceof Error ? error.message : 'Historie konnte nicht geladen werden.')
    }
  }

  useEffect(() => { void refresh() }, [])

  const filtered = useMemo(() => items.filter((item) => `${item.output_type} ${item.companies.join(' ')} ${item.current_file}`.toLowerCase().includes(query.toLowerCase())), [items, query])

  return (
    <div>
      <div className="flex items-center justify-between">
        <div><h1 className="text-[28px] font-extrabold tracking-[-.035em] text-ink">Historie</h1><p className="mt-1 text-sm text-slate-500">Alle früheren Auswertungen und erzeugten Excel-Dateien</p></div>
        <button onClick={refresh} className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm font-bold text-slate-600 shadow-sm hover:bg-slate-50"><RefreshCw className="h-4 w-4" /> Aktualisieren</button>
      </div>
      <div className="mt-5 flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-sm"><Search className="h-4 w-4 text-slate-400" /><input value={query} onChange={(event) => setQuery(event.target.value)} className="w-full bg-transparent text-sm outline-none placeholder:text-slate-400" placeholder="Historie durchsuchen …" /></div>
      <div className="mt-4 overflow-hidden rounded-[20px] border border-slate-200 bg-white shadow-soft">
        {filtered.length ? filtered.map((item) => (
          <button key={item.id} onClick={() => onOpen(item.workbook, item.pdf)} className="flex w-full items-center gap-4 border-b border-slate-100 px-5 py-4 text-left transition hover:bg-cyan-50/40 last:border-b-0">
            <span className="grid h-12 w-12 place-items-center rounded-2xl bg-emerald-50 text-emerald-600"><FileSpreadsheet className="h-5 w-5" /></span>
            <div className="min-w-0 flex-1"><div className="flex items-center gap-2"><strong className="text-sm text-ink">{item.output_type}-Auswertung</strong><span className="rounded-full bg-cyan-50 px-2 py-0.5 text-[11px] font-bold text-teal">{item.companies.length} Gesellschaften</span>{item.warnings.length > 0 && <span className="rounded-full bg-amber-50 px-2 py-0.5 text-[11px] font-bold text-amber-700">{item.warnings.length} Hinweise</span>}</div><div className="mt-1 flex items-center gap-3 truncate text-xs text-slate-400"><span className="flex items-center gap-1"><CalendarDays className="h-3.5 w-3.5" /> {new Date(item.generated_at).toLocaleString('de-DE')}</span><span>{item.current_record_count.toLocaleString('de-DE')} Datensätze</span><span className="truncate">{item.current_file}</span></div></div>
            <ChevronRight className="h-5 w-5 text-slate-300" />
          </button>
        )) : <div className="px-6 py-16 text-center text-sm text-slate-400">Noch keine Auswertungen gefunden.</div>}
      </div>
    </div>
  )
}
