import { useEffect, useState } from 'react'
import { FileSpreadsheet, FileText, FolderOpen, LoaderCircle, RotateCcw } from 'lucide-react'
import clsx from 'clsx'
import { bridge } from '../lib/bridge'
import type { WorkbookPreview } from '../types'
import { SpreadsheetView } from '../components/SpreadsheetView'

interface Props {
  workbookPath: string | null
  pdfPath: string | null
  notify: (kind: 'success' | 'error' | 'info', text: string) => void
}

export function ResultsPage({ workbookPath, pdfPath, notify }: Props) {
  const [preview, setPreview] = useState<WorkbookPreview | null>(null)
  const [activeSheet, setActiveSheet] = useState(0)
  const [loading, setLoading] = useState(false)

  async function load(path: string) {
    setLoading(true)
    try {
      const result = await bridge.getWorkbook(path)
      setPreview(result)
      setActiveSheet(result.active_sheet ?? 0)
    } catch (error) {
      notify('error', error instanceof Error ? error.message : 'Excel-Datei konnte nicht geladen werden.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (workbookPath) void load(workbookPath)
  }, [workbookPath])

  if (!workbookPath) {
    return (
      <div className="grid h-full min-h-[650px] place-items-center">
        <div className="max-w-md text-center">
          <span className="mx-auto grid h-20 w-20 place-items-center rounded-3xl bg-cyan-50 text-teal"><FileSpreadsheet className="h-9 w-9" /></span>
          <h1 className="mt-5 text-2xl font-extrabold tracking-[-.03em] text-ink">Noch kein Ergebnis ausgewählt</h1>
          <p className="mt-2 text-sm leading-6 text-slate-500">Erstelle im Reiter Review eine neue Auswertung oder öffne eine ältere Berechnung aus der Historie.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-full min-h-[720px] flex-col">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h1 className="text-[28px] font-extrabold tracking-[-.035em] text-ink">Ergebnisse</h1>
          <p className="mt-1 text-sm text-slate-500">Excel-Ausgabe direkt in der Anwendung prüfen</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => load(workbookPath)} className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm font-bold text-slate-600 shadow-sm hover:bg-slate-50"><RotateCcw className="h-4 w-4" /> Neu laden</button>
          <button onClick={() => bridge.openPath(workbookPath)} className="flex items-center gap-2 rounded-xl bg-teal px-4 py-2.5 text-sm font-bold text-white shadow-sm hover:bg-teal-700"><FileSpreadsheet className="h-4 w-4" /> In Excel öffnen</button>
          <button onClick={() => bridge.openPath(workbookPath.replace(/[\\/][^\\/]+$/, ''))} className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm font-bold text-slate-600 shadow-sm hover:bg-slate-50"><FolderOpen className="h-4 w-4" /> Ordner</button>
        </div>
      </div>

      <section className="flex min-h-0 flex-1 flex-col overflow-hidden rounded-[20px] border border-slate-200 bg-white shadow-soft">
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50/70 px-4 py-3">
          <div className="flex min-w-0 items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-50 text-emerald-600"><FileSpreadsheet className="h-5 w-5" /></span>
            <div className="min-w-0"><strong className="block truncate text-sm text-ink">{preview?.file_name || workbookPath}</strong><span className="text-xs text-slate-400">Schreibgeschützte Vorschau · Änderungen erfolgen in Excel</span></div>
          </div>
          {loading && <LoaderCircle className="h-5 w-5 animate-spin text-teal" />}
        </div>
        <div className="flex gap-1 overflow-x-auto border-b border-slate-200 bg-white px-3 pt-2">
          {preview?.sheets.map((sheet, index) => (
            <button
              key={sheet.name}
              onClick={() => setActiveSheet(index)}
              className={clsx('relative whitespace-nowrap rounded-t-xl px-4 py-2.5 text-xs font-bold transition-colors', index === activeSheet ? 'bg-cyan-50 text-teal' : 'text-slate-500 hover:bg-slate-50 hover:text-ink')}
            >
              {sheet.name}
              {index === activeSheet && <span className="absolute bottom-0 left-3 right-3 h-0.5 rounded-full bg-teal" />}
            </button>
          ))}
        </div>
        <div className="min-h-0 flex-1">
          {preview?.sheets[activeSheet] ? <SpreadsheetView sheet={preview.sheets[activeSheet]} /> : <div className="grid h-full place-items-center text-sm text-slate-400">Excel-Vorschau wird geladen …</div>}
        </div>
      </section>
    </div>
  )
}
