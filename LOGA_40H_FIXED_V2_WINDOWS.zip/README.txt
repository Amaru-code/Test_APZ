LOGA 40H Fixed V2
=================
Fix fuer faelschlich uebersprungene leere Tage.
START_INDEX bleibt auf 0; bereits gesetzte Tage werden uebersprungen.
Mittwoch und Freitag werden jetzt nur uebersprungen, wenn mindestens
zwei belastbare vorhandene Zeitwerte erkannt werden.
