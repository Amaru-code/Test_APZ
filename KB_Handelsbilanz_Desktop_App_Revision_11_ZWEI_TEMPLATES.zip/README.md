# KB Handelsbilanz Desktop App – Revision 11

Revision 11 verwendet zwei getrennte Excel-Templates und wählt sie automatisch anhand des Vorjahresvergleichs aus.

## Automatische Template-Auswahl

Ohne ausgewählte Vorjahresdatei:

```text
data\samples\Knorr_Bremse_ICT_template_ohne_VJ.xlsx
```

Mit ausgewählter Vorjahresdatei:

```text
data\samples\Knorr_Bremse_ICT_template_mit_VJ.xlsx
```

Auch `.xlsm` wird unterstützt. Die Dateiendung muss in `config/template_settings.json` nicht eingetragen werden.

Das Template **ohne Vorjahr** darf ein einziges generisches Blatt namens `Gesellschaft` enthalten. Dieses Blatt wird für jede ausgewählte Gesellschaft kopiert, umbenannt und mit den berechneten Werten befüllt.

Das Template **mit Vorjahr** kann bereits eigene Gesellschaftsblätter wie `SFN`, `SFS`, `AG`, `KBM`, `HW`, `IT` und `Steering` enthalten. Vorhandene Gesellschaftsblätter werden bevorzugt. Für `GRH` wird weiterhin das SFS-Blatt als Layoutbasis verwendet, sofern kein eigenes GRH-Blatt vorhanden ist.

## Start

Erster Start:

```text
INSTALLIEREN_UND_STARTEN.bat
```

Danach:

```text
STARTEN.bat
```

Der normale Start verwendet `pythonw.exe`; hinter der App bleibt kein Terminalfenster geöffnet. Für Diagnosen steht `STARTEN_MIT_TERMINAL.bat` zur Verfügung.

## Output

Der erzeugte Bericht enthält derzeit ausschließlich die ausgewählten Gesellschaftsblätter. `Gesellschaft`, `Rechenlauf`, `Summe`, `BilMoG` und nicht ausgewählte Blätter werden aus der Ergebnisdatei entfernt.

Weitere Details: `docs/ZWEI_TEMPLATES_REVISION_11.md`
