from __future__ import annotations

from collections import OrderedDict
from copy import copy
from datetime import datetime
import json
import logging
import os
from pathlib import Path
import re
import shutil
import sys
from typing import Any, Iterable

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from core.config_loader import RuleConfig
from core.models import CompanyResult, MetricResult, SourceDataset


OUTPUT_LABELS = {
    "HGB": "Handelsbilanz",
    "STB": "Steuerbilanz",
    "7 Jahre": "7 Jahre",
}

SHEET_ALIASES = {
    "Steering": "Kiepe",
}

BASE_SHEETS = {
    "AG": "AG",
    "GRH": "SFS",
    "HW": "HW",
    "IT": "IT",
    "KBM": "KBM",
    "SFN": "SFN",
    "SFS": "SFS",
    "Steering": "Kiepe",
}

COMPANY_NAMES = {
    "AG": "Knorr-Bremse AG",
    "GRH": "GRH",
    "HW": "Hasse & Wrede GmbH",
    "IT": "Knorr-Bremse Services GmbH",
    "KBM": "KB Media GmbH Marketing und Werbung",
    "SFN": "Knorr-Bremse Systeme für Nutzfahrzeuge GmbH",
    "SFS": "Knorr-Bremse Systeme für Schienenfahrzeuge GmbH",
    "Steering": "Kiepe Electric GmbH",
}

COMPANY_HEADER_CODES = {
    "SFS": "186",
    "SFN": "185",
}

SECTION_CAPTIONS = {
    "VO Anwärter": "Versorgungswerk Anwärter",
    "VO Rentner": "Versorgungswerk Rentner",
    "VO Anwärter – Werk Aldersbach": "Versorgungswerk Werk Aldersbach – Anwärter",
    "VO Rentner – Aldersbach": "Versorgungswerk Werk Aldersbach – Rentner",
    "EZ Anwärter": "Einzelzusagen Anwärter",
    "EZ Rentner": "Einzelzusagen Rentner",
    "EZ – Geschäftsführer": "Einzelzusagen Geschäftsführer",
    "VO Anwärter (Ausland)": "Mitarbeiter Auslandsgesellschaften",
    "Steering alte Leipziger": "Steering alte Leipziger",
    "ehem. Bosch MA in Nürnb./Schwieb.": "ehem. Bosch MA in Nürnb./Schwieb.",
}

SECTION_CODE_FALLBACKS: dict[str, dict[str, str]] = {
    "AG": {
        "VO Anwärter": "330",
        "VO Rentner": "340",
        "EZ Anwärter": "210",
        "EZ Rentner": "220",
        "EZ – Geschäftsführer": "300",
        "VO Anwärter (Ausland)": "400",
        "Versorgungswerk Anwärter (Übernahme Hasse & Wrede)": "830",
        "Versorgungswerk Rentner (Übernahme Hasse & Wrede)": "840",
        "Einzelzusagen Rentner (Übernahme Hasse & Wrede)": "820",
        "Einzelzusagen Rentner (Übernahme von KB-V)": "420",
        "Versorgungsordnung Rentner (Übernahme von KB-V)": "440",
        "Einzelzusagen Anwärter (Übernahme von KB-V)": "410",
        "VO Anwärter (Übernahme von KB-V)": "430",
        "Barlohnumwandlung": "400",
    },
    "GRH": {
        "VO Anwärter": "430",
        "VO Rentner": "440",
        "EZ Anwärter": "410",
        "EZ Rentner": "420",
        "EZ – Geschäftsführer": "401",
        "VO Anwärter (Ausland)": "470",
        "Barlohnumwandlung": "400",
        "MRP": "460",
    },
    "HW": {
        "VO Anwärter": "730",
        "VO Rentner": "740",
        "EZ Anwärter": "710",
        "EZ Rentner": "720",
        "EZ – Geschäftsführer": "701",
        "Barlohnumwandlung": "700",
    },
    "IT": {
        "VO Anwärter": "930",
        "VO Rentner": "940",
        "EZ Anwärter": "910",
        "EZ Rentner": "920",
        "EZ – Geschäftsführer": "901",
        "Barlohnumwandlung": "900",
    },
    "KBM": {
        "VO Anwärter": "630",
        "VO Rentner": "640",
        "EZ Anwärter": "610",
        "EZ Rentner": "620",
        "EZ – Geschäftsführer": "601",
        "Barlohnumwandlung": "600",
    },
    "SFN": {
        "VO Anwärter": "130",
        "VO Rentner": "140",
        "VO Anwärter – Werk Aldersbach": "150",
        "VO Rentner – Aldersbach": "150",
        "EZ Anwärter": "110",
        "EZ Rentner": "120",
        "EZ – Geschäftsführer": "300",
        "VO Anwärter (Ausland)": "400",
        "Barlohnumwandlung": "500",
        "ehem. Bosch MA in Nürnb./Schwieb.": "600",
    },
    "SFS": {
        "VO Anwärter": "230",
        "VO Rentner": "240",
        "EZ Anwärter": "210",
        "EZ Rentner": "220",
        "EZ – Geschäftsführer": "300",
        "VO Anwärter (Ausland)": "400",
        "Barlohnumwandlung": "500",
        "MRP": "260",
    },
}

THIN = Side(style="thin", color="000000")
MEDIUM = Side(style="medium", color="000000")
MONEY_FORMAT = '#,##0;[Red]-#,##0'
COUNT_FORMAT = '0'
POSITIVE_FILL = PatternFill("solid", fgColor="92D050")
NEGATIVE_FILL = PatternFill("solid", fgColor="C00000")
POSITIVE_FONT = Font(color="000000")
NEGATIVE_FONT = Font(color="FFFFFF")
LOGGER = logging.getLogger("kb.template")


class TemplateNotFoundError(FileNotFoundError):
    pass


def _normalise_text(value: Any) -> str:
    text = str(value or "").casefold()
    text = text.replace("&", " und ")
    text = text.replace("–", "-").replace("—", "-")
    text = re.sub(r"[^a-z0-9äöüß]+", " ", text)
    return " ".join(text.split())


def _date_from_path(path: Path, fallback: datetime) -> str:
    name = path.stem
    patterns = (
        r"(?<!\d)(\d{2})[.\-_](\d{2})[.\-_](\d{4})(?!\d)",
        r"(?<!\d)(\d{4})[.\-_](\d{2})[.\-_](\d{2})(?!\d)",
    )
    match = re.search(patterns[0], name)
    if match:
        day, month, year = match.groups()
        return f"{day}.{month}.{year}"
    match = re.search(patterns[1], name)
    if match:
        year, month, day = match.groups()
        return f"{day}.{month}.{year}"
    try:
        return datetime.fromtimestamp(path.stat().st_mtime).strftime("%d.%m.%Y")
    except OSError:
        return fallback.strftime("%d.%m.%Y")


def _template_path_variants(path: Path) -> list[Path]:
    """Return configured path plus supported Excel extension variants."""
    if path.suffix.casefold() in {".xlsx", ".xlsm"}:
        return [path]
    return [path.with_suffix(".xlsm"), path.with_suffix(".xlsx")]


def resolve_template_path(root_dir: Path, with_previous_year: bool = False) -> Path:
    """Resolve the matching Excel template for the selected report mode.

    ``with_previous_year=False`` selects ``Knorr_Bremse_ICT_template_ohne_VJ``.
    ``with_previous_year=True`` selects ``Knorr_Bremse_ICT_template_mit_VJ``.
    Both ``.xlsx`` and ``.xlsm`` are supported. The former single-template
    configuration remains available as a backwards-compatible fallback.
    """
    root_dir = root_dir.resolve()
    candidates: list[Path] = []
    mode_key = "with_previous" if with_previous_year else "without_previous"
    mode_label = "mit Vorjahr" if with_previous_year else "ohne Vorjahr"

    env_name = (
        "KB_REPORT_TEMPLATE_WITH_PREVIOUS"
        if with_previous_year
        else "KB_REPORT_TEMPLATE_WITHOUT_PREVIOUS"
    )
    env_value = os.environ.get(env_name, "").strip()
    if env_value:
        candidates.extend(_template_path_variants(Path(env_value).expanduser()))

    # Legacy override still works for both modes.
    legacy_env = os.environ.get("KB_REPORT_TEMPLATE", "").strip()
    if legacy_env:
        candidates.extend(_template_path_variants(Path(legacy_env).expanduser()))

    fallback_candidates: list[Path] = []
    settings_path = root_dir / "config" / "template_settings.json"
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text(encoding="utf-8"))
            for configured_value in (
                settings.get(f"template_{mode_key}"),
                settings.get("template_file"),
            ):
                configured = str(configured_value or "").strip()
                if not configured:
                    continue
                configured_path = Path(configured).expanduser()
                if not configured_path.is_absolute():
                    configured_path = root_dir / configured_path
                candidates.extend(_template_path_variants(configured_path))

            fallback_value = str(settings.get("fallback_template") or "").strip()
            if fallback_value:
                fallback_path = Path(fallback_value).expanduser()
                if not fallback_path.is_absolute():
                    fallback_path = root_dir / fallback_path
                fallback_candidates.extend(_template_path_variants(fallback_path))
        except (OSError, json.JSONDecodeError, TypeError):
            pass

    samples = root_dir / "data" / "samples"
    if samples.exists():
        stem = (
            "Knorr_Bremse_ICT_template_mit_VJ"
            if with_previous_year
            else "Knorr_Bremse_ICT_template_ohne_VJ"
        )
        candidates.extend(samples / f"{stem}{suffix}" for suffix in (".xlsm", ".xlsx"))
        candidates.extend(sorted(samples.glob(f"{stem}*.xlsm")))
        candidates.extend(sorted(samples.glob(f"{stem}*.xlsx")))

        # Backwards-compatible single-template candidates.
        exact_names = (
            "Knorr_Bremse_HGB_2023 - Kopie.xlsm",
            "Knorr_Bremse_HGB_2023.xlsm",
            "Knorr_Bremse_HGB_2023 - Kopie.xlsx",
            "Knorr_Bremse_HGB_2023.xlsx",
            "Knorr_Bremse_HGB_2023_FALLBACK.xlsx",
        )
        candidates.extend(samples / name for name in exact_names)
        candidates.extend(sorted(samples.glob("Knorr_Bremse_HGB_2023*.xlsm")))
        candidates.extend(sorted(samples.glob("Knorr_Bremse_HGB_2023*.xlsx")))

    # The packaged fallback is deliberately last so that copied customer
    # templates, including files with a suffix such as "- Kopie", win.
    candidates.extend(fallback_candidates)

    seen: set[Path] = set()
    for candidate in candidates:
        candidate = candidate.resolve()
        if candidate in seen:
            continue
        seen.add(candidate)
        if candidate.is_file() and candidate.suffix.casefold() in {".xlsx", ".xlsm"}:
            return candidate

    expected_name = (
        "Knorr_Bremse_ICT_template_mit_VJ.xlsx"
        if with_previous_year
        else "Knorr_Bremse_ICT_template_ohne_VJ.xlsx"
    )
    raise TemplateNotFoundError(
        f"Das Excel-Template {mode_label} wurde nicht gefunden. Bitte die Datei "
        f"'{expected_name}' im Ordner data\\samples ablegen. Zulässig sind .xlsx und .xlsm."
    )


def output_extension_for_template(template_path: Path) -> str:
    return ".xlsm" if template_path.suffix.casefold() == ".xlsm" else ".xlsx"


def _copy_row_style(ws, source_row: int, target_row: int, max_column: int = 17) -> None:
    if source_row == target_row:
        return
    for column in range(1, max_column + 1):
        source = ws.cell(source_row, column)
        target = ws.cell(target_row, column)
        if source.has_style:
            target._style = copy(source._style)
        if source.number_format:
            target.number_format = source.number_format
        target.alignment = copy(source.alignment)
        target.protection = copy(source.protection)
    source_dimension = ws.row_dimensions[source_row]
    target_dimension = ws.row_dimensions[target_row]
    target_dimension.height = source_dimension.height
    target_dimension.hidden = False
    target_dimension.outlineLevel = source_dimension.outlineLevel


def _copy_images(source_ws, target_ws) -> None:
    for image in getattr(source_ws, "_images", []):
        try:
            cloned = copy(image)
            cloned.anchor = copy(image.anchor)
            target_ws.add_image(cloned)
        except Exception:
            continue


def _clone_sheet(workbook, source_name: str, target_name: str):
    source = workbook[source_name]
    clone = workbook.copy_worksheet(source)
    _copy_images(source, clone)
    clone.title = target_name
    return clone


def _metric_map(metrics: Iterable[MetricResult] | None) -> dict[int, MetricResult]:
    return {metric.target_row: metric for metric in metrics or []}


def _group_metrics(metrics: list[MetricResult]) -> OrderedDict[str, list[MetricResult]]:
    groups: OrderedDict[str, list[MetricResult]] = OrderedDict()
    for metric in metrics:
        groups.setdefault(metric.section, []).append(metric)
    return groups


def _build_layout(groups: OrderedDict[str, list[MetricResult]]) -> tuple[list[dict[str, Any]], int]:
    """Build a collision-free report layout using the template rhythm.

    Each section has a heading row, one blank row, its metrics, an optional
    total row, and one blank row before the next section. The rule target rows
    remain part of the calculation identity, but do not force overlapping
    visual positions in the final template.
    """
    cursor = 10
    layout: list[dict[str, Any]] = []
    for section, metrics in groups.items():
        section_row = cursor
        metric_rows = [section_row + 2 + index for index in range(len(metrics))]
        total_row = metric_rows[-1] + 1 if len(metrics) > 1 else None
        last_row = total_row or metric_rows[-1]
        layout.append(
            {
                "section": section,
                "metrics": metrics,
                "section_row": section_row,
                "metric_rows": metric_rows,
                "total_row": total_row,
            }
        )
        cursor = last_row + 2
    grand_total_row = cursor + 1
    return layout, grand_total_row


def _capture_template_section_codes(ws) -> dict[str, str]:
    result: dict[str, str] = {}
    for row in range(8, ws.max_row + 1):
        code = ws.cell(row, 2).value
        caption = ws.cell(row, 3).value
        if code not in (None, "") and caption not in (None, ""):
            result[_normalise_text(caption)] = str(code)
    return result


def _find_style_rows(ws) -> tuple[int, int, int, int]:
    section_row = 10
    metric_row = 12
    total_row = 17
    grand_row = max(1, ws.max_row)
    for row in range(8, ws.max_row + 1):
        b, c, d, f = (ws.cell(row, col).value for col in (2, 3, 4, 6))
        if b not in (None, "") and c not in (None, "") and d in (None, ""):
            section_row = row
            break
    for row in range(8, ws.max_row + 1):
        if ws.cell(row, 4).value not in (None, ""):
            metric_row = row
            break
    for row in range(metric_row + 1, ws.max_row + 1):
        value = ws.cell(row, 6).value
        if isinstance(value, str) and value.startswith("=") and "SUM" in value.upper():
            total_row = row
            break
    for row in range(8, ws.max_row + 1):
        if "gesamtsumme" in _normalise_text(ws.cell(row, 3).value):
            grand_row = row
            break
    return section_row, metric_row, total_row, grand_row


def _clear_body(ws, max_row: int) -> None:
    for row in range(2, max_row + 1):
        for column in range(1, 18):
            ws.cell(row, column).value = None
            ws.cell(row, column).comment = None
            ws.cell(row, column).hyperlink = None
    for column in (15, 16, 17):
        ws.column_dimensions[get_column_letter(column)].hidden = True


def _section_caption(company: str, section: str) -> str:
    if company == "AG" and section == "EZ – Geschäftsführer":
        return "Einzelzusagen Vorstand"
    return SECTION_CAPTIONS.get(section, section)


def _find_captured_code(captured: dict[str, str], caption: str) -> str | None:
    wanted = _normalise_text(caption)
    if wanted in captured:
        return captured[wanted]
    for key, code in captured.items():
        if len(wanted) >= 8 and len(key) >= 8 and (wanted in key or key in wanted):
            return code
    return None


def _section_code(company: str, section: str, caption: str, captured: dict[str, str]) -> str:
    captured_code = _find_captured_code(captured, caption)
    if captured_code is not None and company != "GRH":
        return captured_code
    return SECTION_CODE_FALLBACKS.get(company, {}).get(section, captured_code or "")


def _set_header(
    ws,
    output_type: str,
    current_date: str,
    previous_date: str | None,
) -> None:
    ws["C2"] = f"Entwicklung der Pensionsrückstellungen {current_date} - {OUTPUT_LABELS[output_type]}"
    ws["C2"].font = copy(ws["C2"].font)

    # Remove old formulas and helper headings first.
    for coordinate in ("C4", "F4", "F5", "F6", "H4", "H5", "J4", "J5", "J6", "L4", "L5", "L6", "N4", "N5"):
        ws[coordinate].value = None

    if previous_date:
        ws["F4"] = "Rückstellung per"
        ws["F5"] = previous_date
        ws["F6"] = "€"
        ws["H4"] = "Anzahl"
        ws["H5"] = "Berechtigte"
        ws["J4"] = "Rückstellung per"
        ws["J5"] = current_date
        ws["J6"] = "€"
        ws["L4"] = "Zuführung"
        ws["L6"] = "€"
        ws["N4"] = "Anzahl"
        ws["N5"] = "Berechtigte"
        for column in range(6, 15):
            ws.column_dimensions[get_column_letter(column)].hidden = False
        print_end = "N"
    else:
        ws["F4"] = "Rückstellung per"
        ws["F5"] = current_date
        ws["F6"] = "€"
        ws["H4"] = "Anzahl"
        ws["H5"] = "Berechtigte"
        for column in range(9, 15):
            ws.column_dimensions[get_column_letter(column)].hidden = True
        print_end = "H"

    for coordinate in ("F4", "F5", "F6", "H4", "H5", "J4", "J5", "J6", "L4", "L6", "N4", "N5"):
        ws[coordinate].alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    ws.sheet_view.showGridLines = False
    ws.page_setup.orientation = "portrait"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_options.horizontalCentered = True
    ws.page_margins.left = 0.25
    ws.page_margins.right = 0.25
    ws.page_margins.top = 0.45
    ws.page_margins.bottom = 0.45
    ws.page_margins.header = 0.15
    ws.page_margins.footer = 0.2
    ws.oddFooter.left.text = "Mercer"
    ws.oddFooter.center.text = "Seite &P von &N"
    ws.oddFooter.right.text = "&D"


def _write_metric(
    ws,
    row: int,
    metric: MetricResult,
    previous: MetricResult | None,
    has_previous: bool,
) -> None:
    ws.cell(row, 4, metric.label)
    if has_previous:
        previous_value = previous.value if previous else 0
        previous_count = previous.employee_count if previous else 0
        difference = metric.value - previous_value
        ws.cell(row, 6, previous_value)
        ws.cell(row, 8, previous_count)
        ws.cell(row, 10, metric.value)
        ws.cell(row, 12, difference)
        ws.cell(row, 14, metric.employee_count)
        for column in (6, 10, 12):
            ws.cell(row, column).number_format = MONEY_FORMAT
        for column in (8, 14):
            ws.cell(row, column).number_format = COUNT_FORMAT
        fill = POSITIVE_FILL if difference >= 0 else NEGATIVE_FILL
        font = POSITIVE_FONT if difference >= 0 else NEGATIVE_FONT
        for column in (10, 12, 14):
            ws.cell(row, column).fill = copy(fill)
            ws.cell(row, column).font = copy(font)
    else:
        ws.cell(row, 6, metric.value)
        ws.cell(row, 8, metric.employee_count)
        ws.cell(row, 6).number_format = MONEY_FORMAT
        ws.cell(row, 8).number_format = COUNT_FORMAT


def _write_total(
    ws,
    row: int,
    metrics: list[MetricResult],
    previous_map: dict[int, MetricResult],
    has_previous: bool,
) -> None:
    current_value = sum(metric.value for metric in metrics)
    current_count = sum(metric.employee_count for metric in metrics)
    if has_previous:
        previous_entries = [previous_map.get(metric.target_row) for metric in metrics]
        previous_value = sum(item.value for item in previous_entries if item is not None)
        previous_count = sum(item.employee_count for item in previous_entries if item is not None)
        values = {6: previous_value, 8: previous_count, 10: current_value, 12: current_value - previous_value, 14: current_count}
    else:
        values = {6: current_value, 8: current_count}
    for column, value in values.items():
        cell = ws.cell(row, column, value)
        cell.font = copy(cell.font)
        cell.font = Font(name=cell.font.name or "Arial", size=cell.font.sz or 10, bold=True, color=cell.font.color)
        cell.border = Border(top=THIN, bottom=MEDIUM)
        cell.number_format = COUNT_FORMAT if column in {8, 14} else MONEY_FORMAT


def _remove_formulas_and_values_outside_report(ws, max_row: int) -> None:
    # All formulas inherited from the legacy Rechenlauf model are intentionally
    # removed. The generated workbook is a self-contained final report.
    for row in range(1, max_row + 1):
        for column in range(1, 18):
            cell = ws.cell(row, column)
            if isinstance(cell.value, str) and cell.value.startswith("="):
                cell.value = None


def _prepare_company_sheet(
    ws,
    company_result: CompanyResult,
    company_config: dict[str, Any],
    output_type: str,
    current_date: str,
    previous_date: str | None,
) -> None:
    captured_codes = _capture_template_section_codes(ws)
    section_style_row, metric_style_row, total_style_row, grand_style_row = _find_style_rows(ws)
    groups = _group_metrics(company_result.current)
    layout, grand_total_row = _build_layout(groups)
    max_needed = max(ws.max_row, grand_total_row + 2)

    _clear_body(ws, max_needed)
    _set_header(ws, output_type, current_date, previous_date)

    # Copy the template's row formats into the collision-free dynamic layout.
    for item in layout:
        _copy_row_style(ws, section_style_row, item["section_row"])
        for output_row in item["metric_rows"]:
            _copy_row_style(ws, metric_style_row, output_row)
        if item["total_row"] is not None:
            _copy_row_style(ws, total_style_row, item["total_row"])
    _copy_row_style(ws, grand_style_row, grand_total_row)

    company_code = COMPANY_HEADER_CODES.get(company_result.company, str(company_config.get("code", "")))
    company_name = COMPANY_NAMES.get(company_result.company, company_result.company)
    ws["B8"] = company_code
    ws["C8"] = company_name
    ws["B8"].font = copy(ws["B8"].font)
    ws["C8"].font = Font(name=ws["C8"].font.name or "Arial", size=ws["C8"].font.sz or 11, bold=True, underline="single")

    previous_map = _metric_map(company_result.previous)
    has_previous = previous_date is not None

    for item in layout:
        section = item["section"]
        metrics = item["metrics"]
        section_row = item["section_row"]
        caption = _section_caption(company_result.company, section)
        ws.cell(section_row, 2, _section_code(company_result.company, section, caption, captured_codes))
        ws.cell(section_row, 3, caption)
        ws.cell(section_row, 3).font = Font(
            name=ws.cell(section_row, 3).font.name or "Arial",
            size=ws.cell(section_row, 3).font.sz or 10,
            bold=True,
            underline="single",
        )
        for metric, output_row in zip(metrics, item["metric_rows"]):
            _write_metric(
                ws,
                output_row,
                metric,
                previous_map.get(metric.target_row),
                has_previous,
            )
        if item["total_row"] is not None:
            _write_total(
                ws,
                item["total_row"],
                metrics,
                previous_map,
                has_previous,
            )

    ws.cell(grand_total_row, 3, "Gesamtsumme:")
    ws.cell(grand_total_row, 3).font = Font(
        name=ws.cell(grand_total_row, 3).font.name or "Arial",
        size=ws.cell(grand_total_row, 3).font.sz or 10,
        bold=True,
    )
    _write_total(ws, grand_total_row, company_result.current, previous_map, has_previous)

    # Helper columns from the legacy UDF model are never part of the final report.
    for column in (15, 16, 17):
        ws.column_dimensions[get_column_letter(column)].hidden = True
    print_end = "N" if has_previous else "H"
    ws.print_area = f"B1:{print_end}{grand_total_row}"
    ws.print_title_rows = "1:7"
    ws.sheet_properties.tabColor = "70AD47"
    ws.freeze_panes = None
    _remove_formulas_and_values_outside_report(ws, grand_total_row)


def _strip_defined_names(workbook) -> None:
    # Legacy named ranges point at the removed Rechenlauf sheet and can prompt
    # Excel to repair an otherwise valid file. The final reports contain no UDFs.
    try:
        for key in list(workbook.defined_names):
            del workbook.defined_names[key]
    except Exception:
        pass




def _excel_color(hex_value: str) -> int:
    value = hex_value.lstrip("#")
    red = int(value[0:2], 16)
    green = int(value[2:4], 16)
    blue = int(value[4:6], 16)
    return red + green * 256 + blue * 65536


def _com_sheet(workbook, name: str):
    try:
        return workbook.Worksheets(name)
    except Exception:
        return None


def _com_cell_value(ws, row: int, column: int):
    value = ws.Cells(row, column).Value
    return value


def _com_capture_section_codes(ws, max_row: int) -> dict[str, str]:
    result: dict[str, str] = {}
    for row in range(8, max_row + 1):
        code = _com_cell_value(ws, row, 2)
        caption = _com_cell_value(ws, row, 3)
        if code not in (None, "") and caption not in (None, ""):
            result[_normalise_text(caption)] = str(code)
    return result


def _com_find_style_rows(ws, max_row: int) -> tuple[int, int, int, int]:
    section_row, metric_row, total_row, grand_row = 10, 12, 17, max_row
    for row in range(8, max_row + 1):
        b = _com_cell_value(ws, row, 2)
        c = _com_cell_value(ws, row, 3)
        d = _com_cell_value(ws, row, 4)
        if b not in (None, "") and c not in (None, "") and d in (None, ""):
            section_row = row
            break
    for row in range(8, max_row + 1):
        if _com_cell_value(ws, row, 4) not in (None, ""):
            metric_row = row
            break
    for row in range(metric_row + 1, max_row + 1):
        formula = str(ws.Cells(row, 6).Formula or "")
        if formula.startswith("=") and "SUM" in formula.upper():
            total_row = row
            break
    for row in range(8, max_row + 1):
        if "gesamtsumme" in _normalise_text(_com_cell_value(ws, row, 3)):
            grand_row = row
            break
    return section_row, metric_row, total_row, grand_row


def _com_copy_row_format(excel, ws, source_row: int, target_row: int) -> None:
    if source_row == target_row:
        return
    ws.Rows(source_row).Copy()
    ws.Rows(target_row).PasteSpecial(Paste=-4122)  # xlPasteFormats
    ws.Rows(target_row).RowHeight = ws.Rows(source_row).RowHeight
    excel.CutCopyMode = False


def _com_set_total_border(cell) -> None:
    try:
        cell.Borders(8).LineStyle = 1  # xlEdgeTop / xlContinuous
        cell.Borders(8).Weight = 2     # xlThin
        cell.Borders(9).LineStyle = 1  # xlEdgeBottom
        cell.Borders(9).Weight = -4138 # xlMedium
    except Exception:
        pass


def _write_template_workbook_com(
    destination: Path,
    template_path: Path,
    output_type: str,
    current_dataset: SourceDataset,
    previous_dataset: SourceDataset | None,
    company_results: list[CompanyResult],
    config: RuleConfig,
    generated_at: datetime,
) -> None:
    import pythoncom  # type: ignore[import-not-found]
    import win32com.client  # type: ignore[import-not-found]

    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(template_path, destination)
    pythoncom.CoInitialize()
    excel = None
    workbook = None
    try:
        excel = win32com.client.DispatchEx("Excel.Application")
        excel.Visible = False
        excel.DisplayAlerts = False
        excel.ScreenUpdating = False
        workbook = excel.Workbooks.Open(
            str(destination.resolve()),
            UpdateLinks=0,
            ReadOnly=False,
            IgnoreReadOnlyRecommended=True,
        )
        selected = [result.company for result in company_results]

        for company in selected:
            if _com_sheet(workbook, company) is not None:
                continue
            alias = SHEET_ALIASES.get(company)
            alias_sheet = _com_sheet(workbook, alias) if alias else None
            if alias_sheet is not None:
                alias_sheet.Name = company
                continue
            # The no-previous-year workbook contains one reusable generic
            # company sheet called "Gesellschaft". Clone it for every selected
            # entity. The with-previous-year workbook may already contain
            # company-specific sheets, which are preferred above.
            generic_source = _com_sheet(workbook, "Gesellschaft")
            if generic_source is not None:
                generic_source.Copy(After=workbook.Worksheets(workbook.Worksheets.Count))
                workbook.Worksheets(workbook.Worksheets.Count).Name = company
                continue
            base_name = BASE_SHEETS.get(company, company)
            source = _com_sheet(workbook, base_name)
            if source is None:
                raise ValueError(
                    f"Das Template enthält kein geeignetes Basisblatt für {company}. "
                    f"Erwartet wurde {base_name!r} oder das generische Blatt 'Gesellschaft'."
                )
            source.Copy(After=workbook.Worksheets(workbook.Worksheets.Count))
            workbook.Worksheets(workbook.Worksheets.Count).Name = company

        for index in range(workbook.Worksheets.Count, 0, -1):
            worksheet = workbook.Worksheets(index)
            if worksheet.Name not in selected:
                worksheet.Delete()

        current_date = _date_from_path(current_dataset.path, generated_at)
        previous_date = _date_from_path(previous_dataset.path, generated_at) if previous_dataset else None
        results_by_company = {result.company: result for result in company_results}

        for company in selected:
            ws = workbook.Worksheets(company)
            result = results_by_company[company]
            company_config = config.companies[company]
            groups = _group_metrics(result.current)
            layout, grand_total_row = _build_layout(groups)
            used_max_row = max(int(ws.UsedRange.Rows.Count), grand_total_row + 2)
            captured_codes = _com_capture_section_codes(ws, used_max_row)
            section_style_row, metric_style_row, total_style_row, grand_style_row = _com_find_style_rows(ws, used_max_row)

            ws.Range(f"A2:Q{used_max_row}").ClearContents()
            ws.Range("O:Q").EntireColumn.Hidden = True

            # Header and page layout
            ws.Range("C2").Value = f"Entwicklung der Pensionsrückstellungen {current_date} - {OUTPUT_LABELS[output_type]}"
            for address in ("C4", "F4", "F5", "F6", "H4", "H5", "J4", "J5", "J6", "L4", "L5", "L6", "N4", "N5"):
                ws.Range(address).ClearContents()
            if previous_date:
                ws.Range("F4").Value = "Rückstellung per"
                ws.Range("F5").Value = previous_date
                ws.Range("F6").Value = "€"
                ws.Range("H4").Value = "Anzahl"
                ws.Range("H5").Value = "Berechtigte"
                ws.Range("J4").Value = "Rückstellung per"
                ws.Range("J5").Value = current_date
                ws.Range("J6").Value = "€"
                ws.Range("L4").Value = "Zuführung"
                ws.Range("L6").Value = "€"
                ws.Range("N4").Value = "Anzahl"
                ws.Range("N5").Value = "Berechtigte"
                ws.Range("F:N").EntireColumn.Hidden = False
                print_end = "N"
            else:
                ws.Range("F4").Value = "Rückstellung per"
                ws.Range("F5").Value = current_date
                ws.Range("F6").Value = "€"
                ws.Range("H4").Value = "Anzahl"
                ws.Range("H5").Value = "Berechtigte"
                ws.Range("I:N").EntireColumn.Hidden = True
                print_end = "H"
            ws.Range("F4:N6").HorizontalAlignment = -4108  # xlCenter
            ws.Range("F4:N6").VerticalAlignment = -4108
            ws.Range("F4:N6").WrapText = True

            company_code = COMPANY_HEADER_CODES.get(company, str(company_config.get("code", "")))
            ws.Range("B8").Value = company_code
            ws.Range("C8").Value = COMPANY_NAMES.get(company, company)
            ws.Range("C8").Font.Bold = True
            ws.Range("C8").Font.Underline = 2

            previous_map = _metric_map(result.previous)
            for item in layout:
                section = item["section"]
                metrics = item["metrics"]
                section_row = item["section_row"]
                _com_copy_row_format(excel, ws, section_style_row, section_row)
                caption = _section_caption(company, section)
                ws.Cells(section_row, 2).Value = _section_code(company, section, caption, captured_codes)
                ws.Cells(section_row, 3).Value = caption
                ws.Cells(section_row, 3).Font.Bold = True
                ws.Cells(section_row, 3).Font.Underline = 2

                for metric, row in zip(metrics, item["metric_rows"]):
                    _com_copy_row_format(excel, ws, metric_style_row, row)
                    ws.Cells(row, 4).Value = metric.label
                    if previous_date:
                        previous = previous_map.get(row)
                        previous_value = previous.value if previous else 0
                        previous_count = previous.employee_count if previous else 0
                        difference = metric.value - previous_value
                        ws.Cells(row, 6).Value = previous_value
                        ws.Cells(row, 8).Value = previous_count
                        ws.Cells(row, 10).Value = metric.value
                        ws.Cells(row, 12).Value = difference
                        ws.Cells(row, 14).Value = metric.employee_count
                        color = _excel_color("92D050" if difference >= 0 else "C00000")
                        font_color = _excel_color("000000" if difference >= 0 else "FFFFFF")
                        ws.Range(ws.Cells(row, 10), ws.Cells(row, 14)).Interior.Color = color
                        ws.Range(ws.Cells(row, 10), ws.Cells(row, 14)).Font.Color = font_color
                    else:
                        ws.Cells(row, 6).Value = metric.value
                        ws.Cells(row, 8).Value = metric.employee_count
                    ws.Cells(row, 6).NumberFormat = "#,##0;[Red]-#,##0"
                    ws.Cells(row, 8).NumberFormat = "0"
                    ws.Cells(row, 10).NumberFormat = "#,##0;[Red]-#,##0"
                    ws.Cells(row, 12).NumberFormat = "#,##0;[Red]-#,##0"
                    ws.Cells(row, 14).NumberFormat = "0"

                if item["total_row"] is not None:
                    total_row = item["total_row"]
                    _com_copy_row_format(excel, ws, total_style_row, total_row)
                    current_value = sum(metric.value for metric in metrics)
                    current_count = sum(metric.employee_count for metric in metrics)
                    if previous_date:
                        previous_items = [previous_map.get(metric.target_row) for metric in metrics]
                        previous_value = sum(item.value for item in previous_items if item is not None)
                        previous_count = sum(item.employee_count for item in previous_items if item is not None)
                        values = {6: previous_value, 8: previous_count, 10: current_value, 12: current_value - previous_value, 14: current_count}
                    else:
                        values = {6: current_value, 8: current_count}
                    for column, value in values.items():
                        cell = ws.Cells(total_row, column)
                        cell.Value = value
                        cell.Font.Bold = True
                        cell.NumberFormat = "0" if column in {8, 14} else "#,##0;[Red]-#,##0"
                        _com_set_total_border(cell)

            _com_copy_row_format(excel, ws, grand_style_row, grand_total_row)
            ws.Cells(grand_total_row, 3).Value = "Gesamtsumme:"
            ws.Cells(grand_total_row, 3).Font.Bold = True
            current_total = sum(metric.value for metric in result.current)
            current_count_total = sum(metric.employee_count for metric in result.current)
            if previous_date:
                previous_total = sum(metric.value for metric in result.previous or [])
                previous_count_total = sum(metric.employee_count for metric in result.previous or [])
                values = {6: previous_total, 8: previous_count_total, 10: current_total, 12: current_total - previous_total, 14: current_count_total}
            else:
                values = {6: current_total, 8: current_count_total}
            for column, value in values.items():
                cell = ws.Cells(grand_total_row, column)
                cell.Value = value
                cell.Font.Bold = True
                cell.NumberFormat = "0" if column in {8, 14} else "#,##0;[Red]-#,##0"
                _com_set_total_border(cell)

            page = ws.PageSetup
            page.Orientation = 1  # xlPortrait
            page.PaperSize = 9    # xlPaperA4
            page.Zoom = False
            page.FitToPagesWide = 1
            page.FitToPagesTall = False
            page.PrintArea = f"$B$1:${print_end}${grand_total_row}"
            page.PrintTitleRows = "$1:$7"
            page.LeftFooter = "Mercer"
            page.CenterFooter = "Seite &P von &N"
            page.RightFooter = "&D"
            ws.Activate()
            excel.ActiveWindow.DisplayGridlines = False

        workbook.Worksheets(selected[0]).Activate()
        workbook.Save()
    finally:
        if workbook is not None:
            try:
                workbook.Close(SaveChanges=True)
            except Exception:
                pass
        if excel is not None:
            try:
                excel.Quit()
            except Exception:
                pass
        pythoncom.CoUninitialize()


def write_template_workbook(
    destination: Path,
    template_path: Path,
    output_type: str,
    current_dataset: SourceDataset,
    previous_dataset: SourceDataset | None,
    company_results: list[CompanyResult],
    config: RuleConfig,
    generated_at: datetime,
) -> None:
    if sys.platform == "win32":
        try:
            _write_template_workbook_com(
                destination=destination,
                template_path=template_path,
                output_type=output_type,
                current_dataset=current_dataset,
                previous_dataset=previous_dataset,
                company_results=company_results,
                config=config,
                generated_at=generated_at,
            )
            return
        except Exception as exc:
            LOGGER.warning("Excel-COM-Templateausgabe fehlgeschlagen; nutze OpenPyXL-Fallback: %s", exc)
            # The pure-Python fallback keeps the application usable when Excel
            # COM is unavailable. The exception is re-raised only if fallback
            # writing also fails.
            if destination.exists():
                try:
                    destination.unlink()
                except OSError:
                    pass

    keep_vba = template_path.suffix.casefold() == ".xlsm"
    workbook = load_workbook(
        template_path,
        keep_vba=keep_vba,
        keep_links=False,
        data_only=False,
    )
    try:
        selected = [result.company for result in company_results]

        # Build missing output sheets before removing legacy sheets. GRH uses the
        # SFS layout as a visual base; Steering uses the former Kiepe layout.
        for company in selected:
            target_name = company
            alias = SHEET_ALIASES.get(company)
            if target_name in workbook.sheetnames:
                continue
            if alias and alias in workbook.sheetnames:
                workbook[alias].title = target_name
                continue
            if "Gesellschaft" in workbook.sheetnames:
                _clone_sheet(workbook, "Gesellschaft", target_name)
                continue
            base_name = BASE_SHEETS.get(company, company)
            if base_name not in workbook.sheetnames:
                raise ValueError(
                    f"Das Template enthält kein geeignetes Basisblatt für {company}. "
                    f"Erwartet wurde {base_name!r} oder das generische Blatt 'Gesellschaft'."
                )
            _clone_sheet(workbook, base_name, target_name)

        # Only the selected legal-entity reports remain. Rechenlauf, Summe and
        # BilMoG are deliberately excluded until their later project phase.
        for worksheet in list(workbook.worksheets):
            if worksheet.title not in selected:
                workbook.remove(worksheet)

        current_date = _date_from_path(current_dataset.path, generated_at)
        previous_date = (
            _date_from_path(previous_dataset.path, generated_at)
            if previous_dataset is not None
            else None
        )

        results_by_company = {result.company: result for result in company_results}
        for company in selected:
            _prepare_company_sheet(
                workbook[company],
                results_by_company[company],
                config.companies[company],
                output_type,
                current_date,
                previous_date,
            )

        _strip_defined_names(workbook)
        workbook._sheets = [workbook[company] for company in selected]
        workbook.active = 0
        try:
            workbook.calculation.fullCalcOnLoad = False
            workbook.calculation.forceFullCalc = False
            workbook.calculation.calcMode = "auto"
        except AttributeError:
            pass

        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_name(destination.stem + ".tmp" + destination.suffix)
        workbook.save(temporary)
        temporary.replace(destination)
    finally:
        workbook.close()
