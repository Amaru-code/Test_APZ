# Testbericht – Revision 11

## Automatisierte Prüfung

- 37 von 37 Tests erfolgreich
- bestehende 183 Feldregeln unverändert gültig
- automatische Auswahl des Templates ohne Vorjahr geprüft
- automatische Auswahl des Templates mit Vorjahr geprüft
- `.xlsx` und `.xlsm` werden erkannt
- generisches Blatt `Gesellschaft` wird für mehrere Gesellschaften korrekt geklont
- Output enthält ausschließlich ausgewählte Gesellschaftsblätter
- `Gesellschaft`, `Rechenlauf`, `Summe` und `BilMoG` werden entfernt
- Ausgabe ohne Vorjahr geprüft
- Ausgabe mit Vorjahr und Zuführung geprüft
- alte `getwert`-Formeln werden entfernt
- Arbeitsmappen lassen sich erneut vollständig laden
- versteckter `pythonw.exe`-Start und Windows-CRLF-Dateien geprüft

## Windows-Ausgabe

Unter Windows versucht die Anwendung zuerst, das ausgewählte Template direkt über Microsoft Excel COM zu bearbeiten. Dadurch bleiben Bilder, Formen, Druckeinstellungen und XLSM-Inhalte bestmöglich erhalten. Falls Excel COM nicht verfügbar ist, greift automatisch die getestete OpenPyXL-Variante.
