# Revision 11 – Zwei getrennte Excel-Templates

## Auswahlregel

Die Anwendung entscheidet anhand der tatsächlich ausgewählten Dateien:

- `previous_file is None` → `Knorr_Bremse_ICT_template_ohne_VJ`
- `previous_file` vorhanden → `Knorr_Bremse_ICT_template_mit_VJ`

Die Dateien können `.xlsx` oder `.xlsm` sein. In `config/template_settings.json` werden die Namen ohne Dateiendung geführt:

```json
{
  "template_without_previous": "data/samples/Knorr_Bremse_ICT_template_ohne_VJ",
  "template_with_previous": "data/samples/Knorr_Bremse_ICT_template_mit_VJ",
  "fallback_template": "data/samples/Knorr_Bremse_HGB_2023_FALLBACK.xlsx"
}
```

## Template ohne Vorjahr

Das Blatt `Gesellschaft` ist die allgemeine Formatvorlage. Für jede im Interface ausgewählte Gesellschaft wird dieses Blatt kopiert, passend umbenannt und mit den Regeln der Gesellschaft dynamisch aufgebaut.

Beispiel bei Auswahl von `GRH`, `SFS` und `IT`:

```text
Gesellschaft -> GRH
Gesellschaft -> SFS
Gesellschaft -> IT
```

Das ursprüngliche Blatt `Gesellschaft`, `Summe`, `BilMoG` und alle übrigen Blätter werden anschließend entfernt.

## Template mit Vorjahr

Vorhandene Gesellschaftsblätter werden direkt verwendet. Dadurch bleiben individuelle Zeilenaufteilungen und Layoutbasen erhalten. Fehlt ein Blatt:

- `GRH` nutzt `SFS` als Basis.
- `Steering` kann weiterhin aus dem früheren Blatt `Kiepe` abgeleitet werden.
- Ist zusätzlich ein Blatt `Gesellschaft` vorhanden, dient es als generische Basis.

## Manuelle Pfade

Normalerweise ist keine Codeänderung mehr notwendig. Andere Dateinamen können direkt in `config/template_settings.json` eingetragen werden. Absolute und relative Pfade werden unterstützt.

Für temporäre Starts stehen außerdem diese Umgebungsvariablen zur Verfügung:

```text
KB_REPORT_TEMPLATE_WITHOUT_PREVIOUS
KB_REPORT_TEMPLATE_WITH_PREVIOUS
```
