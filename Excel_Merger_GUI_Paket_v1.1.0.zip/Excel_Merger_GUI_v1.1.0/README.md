# Excel Master Merger GUI

Schlichtes Windows-Programm zum Zusammenführen vieler Excel-, CSV- und TXT-Dateien in eine einzige formatierte Master-Excel.

## Schnellstart

1. `START_EXCEL_MERGER.bat` doppelklicken.
2. Beim ersten Start wird automatisch die lokale Python-Umgebung eingerichtet.
3. Im Fenster **Dateien auswählen** anklicken und alle Quelldateien markieren.
4. **Zielordner wählen** anklicken.
5. **MERGE STARTEN** anklicken.

Die Ergebnisdatei wird automatisch mit einem Zeitstempel gespeichert, zum Beispiel:

`MERGED_MASTER_20260723_093000.xlsx`

## Unterstützte Formate

- `.xlsx`
- `.xlsm`
- `.xls`
- `.csv`
- `.txt`

Das Programm erkennt auch semikolongetrennte Datensätze, die vollständig in einer einzelnen Excel-Zelle stehen.

## Standardverhalten

Das Programm ist auf das gezeigte Datenformat eingestellt:

- keine Überschriften in den Quelldateien
- alle Tabellenblätter werden eingelesen
- Herkunftsspalten `Quelle_Datei`, `Quelle_Blatt` und `Quelle_Zeile` werden ergänzt
- IDs, ISINs und führende Nullen bleiben als Text erhalten

Es gibt keine festen Eingabe- oder Ausgabeordner im Programmpaket. Die Quelldateien und der Zielordner werden bei jedem Start direkt im Fenster ausgewählt.
