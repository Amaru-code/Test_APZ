@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PYTHONW=%~dp0runtime\venv\Scripts\pythonw.exe"
set "PYTHON=%~dp0runtime\venv\Scripts\python.exe"

if not exist "%PYTHONW%" (
    echo Die Anwendung ist noch nicht installiert.
    echo INSTALL.bat wird jetzt gestartet.
    echo.
    call "%~dp0INSTALL.bat"
    if errorlevel 1 exit /b 1
)

start "" "%PYTHONW%" "%~dp0app\main.py"
exit /b 0
