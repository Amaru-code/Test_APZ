# Changelog

## 3.0.0

- bisheriges Converter-Tool und Excel-Merger zu einer Anwendung kombiniert
- professionelle PySide6-Oberfläche mit SVG-Icons
- native skalierbare Darstellung ohne Emoji- oder Custom-Titlebar-Fehler
- drei klare Aktionen: Konvertieren, Konvertieren + Master, Nur zusammenführen
- sichtbare Ladeanimation, Fortschrittsbalken, aktuelle Datei, Zeilenzähler und Laufzeit
- Markerzeilen `>>>> ...` und `<<<<<` vollständig entfernt
- wiederholte Header werden nicht mehr als Daten übernommen
- Metadatenzeilen vor dem Header werden verworfen
- keine automatischen Quelldatei-, Fehler- oder Dateilisten-TXT-Dateien im Ausgabeordner
- saubere Root-Struktur mit ausschließlich BAT-Dateien und Unterordnern
