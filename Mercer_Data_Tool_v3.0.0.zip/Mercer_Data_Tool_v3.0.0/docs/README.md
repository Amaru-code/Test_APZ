# Mercer Data Converter & Merger 3.0.0

Ein kombiniertes Windows-Tool für die vorhandene DU/DP-Konvertierungslogik und das Zusammenführen vieler Tabellen in eine einzige Excel-Masterdatei.

## Hauptfunktionen

- Mehrfachauswahl und Drag & Drop von Quelldateien
- freie Auswahl des Ausgabeordners
- Konvertierung einzelner Dateien
- Konvertierung mit zusätzlicher Masterdatei
- reiner Merge ohne Einzeldateien
- fester Mercer-Zielheader und FirmenID-Filter
- Entfernung von Metadaten-, Marker- und wiederholten Headerzeilen
- sichtbarer Fortschritt in einem nicht blockierenden Hintergrundprozess
- native Windows-Titelleiste und skalierbare SVG-Icons statt Emoji-Symbole

## Wichtige Merge-Korrekturen

Die folgenden Inhalte werden nicht mehr als Daten übernommen:

```text
>>>> DU_MERCER_20250320_20250320
<<<<<
```

Auch automatische Quelldatei-TXT-Listen und zusätzliche Herkunftsspalten werden nicht erzeugt.

## Oberfläche

Die Oberfläche basiert auf PySide6/Qt. Sie nutzt eine klare Drei-Schritte-Struktur:

1. Quelldateien auswählen
2. Zielformat und Ausgabeordner festlegen
3. Konvertieren, Konvertieren + Master oder Nur zusammenführen

## Konfiguration

Die fachlichen Header und zugelassenen FirmenIDs stehen in:

```text
app/config/settings.json
```

## SVG-Icons

Die mitgelieferten SVG-Icons stammen aus Font Awesome Free und liegen einzeln unter `assets/icons/`. Die zugehörige Lizenz befindet sich unter `assets/licenses/FONT_AWESOME_FREE_LICENSE.txt`.

## Ausgabe

Das Tool schreibt nur die fachlich angeforderten Ausgabedateien. Fehlerdetails werden im Fenster angezeigt und nicht als zusätzliche Textdatei im Ausgabeordner abgelegt.
