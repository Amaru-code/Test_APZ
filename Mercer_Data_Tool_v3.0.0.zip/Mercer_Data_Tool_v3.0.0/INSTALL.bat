@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Mercer Data Tool - Installation

set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "PYTHON_CMD="
set "VENV_DIR=%~dp0runtime\venv"

cls
echo ============================================================
echo  Mercer Data Converter ^& Merger - Installation
echo ============================================================
echo.
echo Die Installation wird lokal im Unterordner runtime angelegt.
echo Bestehende Python-Installationen werden nicht veraendert.
echo.

REM PySide6 ist erfahrungsgemaess mit Python 3.10-3.13 stabil.
REM 3.12 wird bevorzugt, da es auf den Zielrechnern vorhanden ist.
for %%V in (3.12 3.11 3.10 3.13) do (
    if not defined PYTHON_CMD (
        py -%%V -c "import sys" >nul 2>&1
        if not errorlevel 1 set "PYTHON_CMD=py -%%V"
    )
)

if not defined PYTHON_CMD (
    where python.exe >nul 2>&1
    if not errorlevel 1 (
        python -c "import sys; raise SystemExit(0 if (3,10) <= sys.version_info[:2] <= (3,13) else 1)" >nul 2>&1
        if not errorlevel 1 set "PYTHON_CMD=python"
    )
)

if not defined PYTHON_CMD (
    echo FEHLER: Keine kompatible Python-Version gefunden.
    echo.
    echo Benoetigt wird Python 3.10, 3.11, 3.12 oder 3.13.
    echo Empfohlen: Python 3.12 mit aktivierter Option "Add Python to PATH".
    echo.
    pause
    exit /b 1
)

echo Verwende: %PYTHON_CMD%
echo.

if not exist "%~dp0runtime" mkdir "%~dp0runtime"

if not exist "%VENV_DIR%\Scripts\python.exe" (
    echo [1/4] Erstelle lokale Python-Umgebung ...
    %PYTHON_CMD% -m venv "%VENV_DIR%"
    if errorlevel 1 goto :install_error
) else (
    echo [1/4] Lokale Python-Umgebung bereits vorhanden.
)

echo [2/4] Aktualisiere Installationswerkzeuge ...
"%VENV_DIR%\Scripts\python.exe" -m pip install --upgrade pip setuptools wheel
if errorlevel 1 goto :install_error

echo [3/4] Installiere benoetigte Pakete ...
"%VENV_DIR%\Scripts\python.exe" -m pip install -r "%~dp0app\requirements.txt"
if errorlevel 1 goto :install_error

echo [4/4] Pruefe Anwendung ...
"%VENV_DIR%\Scripts\python.exe" -c "import PySide6, openpyxl, xlrd, docx, pptx, pypdf, reportlab; print('Pakete erfolgreich geprueft.')"
if errorlevel 1 goto :install_error

> "%~dp0runtime\installed.txt" echo Installation erfolgreich

echo.
echo ============================================================
echo  Installation erfolgreich
echo ============================================================
echo.
echo Die Anwendung kann jetzt mit START.bat geoeffnet werden.
echo.
pause
exit /b 0

:install_error
echo.
echo ============================================================
echo  FEHLER BEI DER INSTALLATION
echo ============================================================
echo.
echo Bitte Internetverbindung pruefen und INSTALL.bat erneut starten.
echo.
pause
exit /b 1
