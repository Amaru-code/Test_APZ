from __future__ import annotations

import json
import os
import shutil
import tempfile
import unittest
from pathlib import Path

from openpyxl import load_workbook

from app.service import run_calculation
from core.models import AppOptions
from excel.template_writer import resolve_template_path


ROOT = Path(__file__).resolve().parents[1]
SAMPLE = ROOT / "data" / "samples" / "sample_AllOnetabOrFile.xlsx"


def _print_area_coordinates(value: object) -> str:
    text = str(value or "")
    return text.split("!", 1)[-1]


class PrintReportTests(unittest.TestCase):
    def test_template_is_resolved_from_samples_folder(self) -> None:
        template_without = resolve_template_path(ROOT, with_previous_year=False)
        template_with = resolve_template_path(ROOT, with_previous_year=True)
        self.assertTrue(template_without.is_file())
        self.assertTrue(template_with.is_file())

    def test_separate_template_names_are_selected_by_previous_year_mode(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "config").mkdir()
            samples = root / "data" / "samples"
            samples.mkdir(parents=True)
            (root / "config" / "template_settings.json").write_text(
                json.dumps(
                    {
                        "template_without_previous": "data/samples/Knorr_Bremse_ICT_template_ohne_VJ",
                        "template_with_previous": "data/samples/Knorr_Bremse_ICT_template_mit_VJ",
                    }
                ),
                encoding="utf-8",
            )
            without = samples / "Knorr_Bremse_ICT_template_ohne_VJ.xlsx"
            with_previous = samples / "Knorr_Bremse_ICT_template_mit_VJ.xlsm"
            without.touch()
            with_previous.touch()

            self.assertEqual(
                resolve_template_path(root, with_previous_year=False),
                without.resolve(),
            )
            self.assertEqual(
                resolve_template_path(root, with_previous_year=True),
                with_previous.resolve(),
            )

    def test_generic_gesellschaft_sheet_is_cloned_for_selected_companies(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            generic_template = temp_path / "Knorr_Bremse_ICT_template_ohne_VJ.xlsx"
            source_template = resolve_template_path(ROOT, with_previous_year=False)
            workbook = load_workbook(source_template)
            source_sheet = workbook["SFS"]
            source_sheet.title = "Gesellschaft"
            for worksheet in list(workbook.worksheets):
                if worksheet.title != "Gesellschaft":
                    workbook.remove(worksheet)
            workbook.save(generic_template)
            workbook.close()

            current = temp_path / "Sommerbewertung_30.06.2026.xlsx"
            shutil.copy2(SAMPLE, current)
            old_value = os.environ.get("KB_REPORT_TEMPLATE_WITHOUT_PREVIOUS")
            os.environ["KB_REPORT_TEMPLATE_WITHOUT_PREVIOUS"] = str(generic_template)
            try:
                result = run_calculation(
                    ROOT,
                    AppOptions(
                        current_file=current,
                        previous_file=None,
                        output_type="HGB",
                        companies=["GRH", "SFS", "Steering"],
                        output_dir=temp_path / "out",
                    ),
                )
            finally:
                if old_value is None:
                    os.environ.pop("KB_REPORT_TEMPLATE_WITHOUT_PREVIOUS", None)
                else:
                    os.environ["KB_REPORT_TEMPLATE_WITHOUT_PREVIOUS"] = old_value

            output = load_workbook(result.output_workbook)
            self.assertEqual(output.sheetnames, ["GRH", "SFS", "Steering"])
            self.assertNotIn("Gesellschaft", output.sheetnames)
            output.close()

    def test_company_only_template_report_without_previous_year(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            current = temp_path / "Sommerbewertung_30.06.2026.xlsx"
            shutil.copy2(SAMPLE, current)
            result = run_calculation(
                ROOT,
                AppOptions(
                    current_file=current,
                    previous_file=None,
                    output_type="HGB",
                    companies=["GRH", "SFS", "Steering"],
                    output_dir=temp_path / "out",
                ),
            )
            workbook = load_workbook(result.output_workbook, data_only=False)
            self.assertEqual(workbook.sheetnames, ["GRH", "SFS", "Steering"])
            self.assertNotIn("Rechenlauf", workbook.sheetnames)
            self.assertNotIn("Summe", workbook.sheetnames)
            self.assertNotIn("BilMoG", workbook.sheetnames)

            grh = workbook["GRH"]
            template_workbook = load_workbook(resolve_template_path(ROOT, with_previous_year=False))
            template_sheet = template_workbook["SFS"]
            template_print_area = _print_area_coordinates(template_sheet.print_area)
            template_a_hidden = bool(template_sheet.column_dimensions["A"].hidden)
            template_i_hidden = bool(template_sheet.column_dimensions["I"].hidden)
            template_j_hidden = bool(template_sheet.column_dimensions["J"].hidden)
            template_workbook.close()

            self.assertEqual(
                grh["C2"].value,
                "Entwicklung der Pensionsrückstellungen 30.06.2026 - Handelsbilanz",
            )
            self.assertEqual(grh["C8"].value, "GRH")
            self.assertEqual(grh["C10"].value, "Versorgungswerk Anwärter")
            self.assertEqual(grh["D12"].value, "Anwärter Männer")
            self.assertEqual(grh["D58"].value, "unverfallb. Ausgesch.")
            self.assertIsInstance(grh["F12"].value, (int, float))
            self.assertIsInstance(grh["F58"].value, (int, float))
            self.assertIsInstance(grh["H12"].value, int)

            # The lower GRH block is placed according to the ICT template.
            self.assertEqual(grh["C43"].value, "Einzelzusagen Geschäftsführer")
            self.assertEqual(grh["F47"].value, (grh["F45"].value or 0) + (grh["F46"].value or 0))
            self.assertEqual(grh["H47"].value, (grh["H45"].value or 0) + (grh["H46"].value or 0))
            self.assertIsNone(grh["B48"].value)
            self.assertIsNone(grh["C48"].value)
            self.assertIsNone(grh["D48"].value)
            self.assertEqual(grh["C49"].value, "Einzelzusagen Anwärter")
            self.assertEqual(grh["D51"].value, "Mitarbeiter Auslandsges.")
            self.assertEqual(grh["C53"].value, "Barlohnumwandlung")
            self.assertEqual(grh["D55"].value, "Einbehalte von Mitarbeitern")
            self.assertEqual(grh["C56"].value, "MRP")
            self.assertEqual(grh["D58"].value, "unverfallb. Ausgesch.")
            grand_rows = [
                row for row in range(59, grh.max_row + 1)
                if grh.cell(row, 3).value == "Gesamtsumme:"
            ]
            self.assertEqual(len(grand_rows), 1)
            self.assertGreater(grand_rows[0], 58)
            self.assertEqual(bool(grh.column_dimensions["A"].hidden), template_a_hidden)
            self.assertEqual(bool(grh.column_dimensions["I"].hidden), template_i_hidden)
            self.assertEqual(bool(grh.column_dimensions["J"].hidden), template_j_hidden)
            self.assertEqual(_print_area_coordinates(grh.print_area), template_print_area)
            self.assertEqual(grh.page_setup.fitToWidth, 1)
            formulas = [
                cell.value
                for row in grh.iter_rows()
                for cell in row
                if isinstance(cell.value, str) and cell.value.startswith("=")
            ]
            self.assertEqual(formulas, [])
            workbook.close()

    def test_grh_lower_block_uses_output_row_overrides_without_changing_rules(self) -> None:
        rules = json.loads((ROOT / "config" / "rules.json").read_text(encoding="utf-8"))
        by_label = {rule["label"]: rule["target_row"] for rule in rules["companies"]["GRH"]["rules"]}
        self.assertEqual(by_label["Mitarbeiter Auslandsges."], 49)
        self.assertEqual(by_label["Einbehalte von Mitarbeitern"], 51)
        self.assertEqual(by_label["unverfallb. Ausgesch."], 56)

        source = (ROOT / "src" / "excel" / "preserved_template_writer.py").read_text(encoding="utf-8")
        self.assertIn('49: 51', source)
        self.assertIn('51: 55', source)
        self.assertIn('56: 58', source)

    def test_preserved_writer_does_not_reformat_or_rebuild_page_layout(self) -> None:
        source = (ROOT / "src" / "excel" / "preserved_template_writer.py").read_text(
            encoding="utf-8"
        )
        self.assertNotIn(".NumberFormat =", source)
        self.assertNotIn("PageSetup.PrintArea =", source)
        self.assertNotIn("EntireColumn.Hidden =", source)
        self.assertIn("Excel-COM-Ausgabe erfolgreich", source)
        self.assertIn("OpenPyXL-Fallback erzeugt", source)

    def test_template_report_with_previous_year(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            current = temp_path / "Bewertung_30.06.2026.xlsx"
            previous = temp_path / "Bewertung_31.12.2025.xlsx"
            shutil.copy2(SAMPLE, current)
            shutil.copy2(SAMPLE, previous)
            result = run_calculation(
                ROOT,
                AppOptions(
                    current_file=current,
                    previous_file=previous,
                    output_type="HGB",
                    companies=["SFS"],
                    output_dir=temp_path / "out",
                ),
            )
            workbook = load_workbook(result.output_workbook, data_only=False)
            self.assertEqual(workbook.sheetnames, ["SFS"])
            sfs = workbook["SFS"]
            self.assertEqual(sfs["F5"].value, "31.12.2025")
            self.assertEqual(sfs["J5"].value, "30.06.2026")
            self.assertEqual(sfs["L12"].value, 0)
            self.assertFalse(sfs.column_dimensions["J"].hidden)
            self.assertIn("$N$", str(sfs.print_area))
            self.assertIsNone(result.output_pdf)  # Linux-Testumgebung ohne Excel-COM
            workbook.close()


if __name__ == "__main__":
    unittest.main()
