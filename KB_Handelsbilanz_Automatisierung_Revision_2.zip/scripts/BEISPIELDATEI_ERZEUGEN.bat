@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0\.."
if not exist ".venv\Scripts\python.exe" (
    echo Die virtuelle Umgebung fehlt. Starte zuerst INSTALLIEREN_UND_STARTEN.bat.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" "scripts\create_sample_input.py"
pause
