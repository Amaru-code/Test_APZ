# KB Handelsbilanz Automatisierung

Zum ersten Start `INSTALLIEREN_UND_STARTEN.bat` ausführen.

Die vollständige Dokumentation steht unter [`docs/README.md`](docs/README.md). Alle fachlichen Regeln befinden sich zentral in [`config/rules.json`](config/rules.json).


Regelstand: Revision 2 vom 17.07.2026. Details: [`docs/CHANGELOG_2026-07-17.md`](docs/CHANGELOG_2026-07-17.md).
