@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Die virtuelle Umgebung fehlt. Starte zuerst INSTALLIEREN_UND_STARTEN.bat.
    pause
    exit /b 1
)
set "PYTHONPATH=%CD%\src"
".venv\Scripts\python.exe" -m unittest discover -s tests -v
pause
