# Testbericht – Regelrevision 2

Testdatum: 17.07.2026

## Automatisierte Tests

- 11 von 11 Tests erfolgreich.
- Zielzeilen je Gesellschaft eindeutig.
- Sämtliche `set_ref`-Verweise sind gültig.
- Regelbestand: 182 Kennzahlen.
- Neue SFN-Aldersbach-Sets geprüft: 326 / 169 / 92 / 6 eindeutige IDs.
- AG-Geschäftsführerfilter über `SubsidiaryCode = 301` geprüft.
- GRH-MRP-Abgrenzung anhand der neuen ClientEEID-Liste geprüft.
- SFS-Geschäftsführerfilter über `SubsidiaryCode = 201` geprüft.
- Vollständiger End-to-End-Lauf mit aktuellem Jahr und Vorjahr erfolgreich.

## Excel-Validierung

Die erzeugte Testarbeitsmappe enthielt die Sheets Start, AG, GRH, HW, IT, KBM, SFN, SFS und Steering. Die Ausgabe wurde auf Formelfehler wie `#REF!`, `#DIV/0!`, `#VALUE!`, `#NAME?` und `#N/A` geprüft; es wurden keine Treffer gefunden.
