@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"

echo ============================================================
echo  KB Handelsbilanz Automatisierung - Installation und Start
echo ============================================================
echo.

where py >nul 2>&1
if %errorlevel%==0 (
    set "PYTHON_CMD=py -3"
) else (
    where python >nul 2>&1
    if errorlevel 1 (
        echo FEHLER: Python 3 wurde nicht gefunden.
        echo Bitte Python 3.11 oder neuer installieren und "Add Python to PATH" aktivieren.
        pause
        exit /b 1
    )
    set "PYTHON_CMD=python"
)

if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Erstelle virtuelle Python-Umgebung .venv ...
    %PYTHON_CMD% -m venv .venv
    if errorlevel 1 goto :error
) else (
    echo [1/3] Virtuelle Umgebung ist bereits vorhanden.
)

echo [2/3] Installiere bzw. aktualisiere Abhängigkeiten ...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :error
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :error

echo [3/3] Starte Anwendung ...
".venv\Scripts\python.exe" "src\main.py"
set "EXITCODE=%errorlevel%"
if not "%EXITCODE%"=="0" (
    echo.
    echo Die Anwendung wurde mit Fehlercode %EXITCODE% beendet.
    pause
)
exit /b %EXITCODE%

:error
echo.
echo FEHLER: Installation oder Start ist fehlgeschlagen.
pause
exit /b 1
