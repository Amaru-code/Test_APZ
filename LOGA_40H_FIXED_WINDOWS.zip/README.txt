LOGA 40H Fixed
================
1. Die Datei LOGA_40H_FIXED.js in einem Texteditor öffnen.
2. Den vollständigen Inhalt kopieren.
3. In der Browser-Konsole von LOGA einfügen.
