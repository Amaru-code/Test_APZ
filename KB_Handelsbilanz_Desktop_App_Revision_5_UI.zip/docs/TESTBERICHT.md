# Testbericht – Revision 5 Desktop UI

Stand: 19.07.2026

## Automatisierte Prüfungen

- bestehende Regel- und Berechnungstests,
- GRH-Regelstand mit insgesamt 183 Kennzahlen,
- dynamische Headererkennung,
- End-to-End-Erstellung einer XLSX-Ausgabe,
- Desktop-Bridge und Hintergrundberechnung,
- Historie und Excel-Vorschau,
- dauerhaftes Speichern der Regeln inklusive Sicherung,
- Windows-BAT-Dateien mit CRLF und ohne BOM,
- vollständige lokale Frontend-Dateien,
- Auflösung aller SVG-Icon-Verweise,
- JavaScript-Syntaxprüfung,
- TypeScript-Prüfung und erfolgreicher Vite-/Tailwind-Produktionsbuild des React-Quellstands,
- ZIP-Integritätsprüfung.

**23 von 23 automatisierten Tests wurden erfolgreich abgeschlossen.**

## Umgebungsgrenze

Eine Windows-Tauri-EXE kann in der verwendeten Linux-Buildumgebung nicht nativ kompiliert werden. Deshalb ist der sofort startbare Produktivweg als Windows-WebView2-App mit derselben HTML/CSS/JavaScript-Oberfläche umgesetzt. Die Tauri-Quellstruktur ist zusätzlich enthalten.
