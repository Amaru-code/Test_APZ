from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
SRC_DIR = Path(__file__).resolve().parent
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from core.logging_setup import configure_logging  # noqa: E402
from desktop_bridge import DesktopBridge  # noqa: E402


def main() -> int:
    configure_logging(ROOT_DIR)
    try:
        import webview
    except ImportError:
        print("pywebview ist nicht installiert. Bitte INSTALLIEREN_UND_STARTEN.bat ausführen.")
        return 2

    frontend = ROOT_DIR / "frontend" / "dist" / "index.html"
    if not frontend.exists():
        print(f"Frontend wurde nicht gefunden: {frontend}")
        return 3

    bridge = DesktopBridge(ROOT_DIR)
    window = webview.create_window(
        "KB Handelsbilanz",
        url=frontend.as_uri(),
        js_api=bridge,
        width=1500,
        height=960,
        min_size=(1120, 720),
        background_color="#eef3f8",
        confirm_close=False,
        text_select=True,
    )
    bridge.set_window(window)
    webview.start(debug=False)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
