import type {
  BootstrapData,
  HistoryRun,
  Inspection,
  JobStatus,
  RulesConfig,
  RunPayload,
  Settings,
  WorkbookPreview,
} from '../types'

declare global {
  interface Window {
    pywebview?: { api: Record<string, (...args: unknown[]) => Promise<unknown>> }
    __TAURI_INTERNALS__?: unknown
  }
}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

async function waitForPyWebView(timeout = 4500): Promise<boolean> {
  if (window.pywebview?.api) return true
  const started = Date.now()
  while (Date.now() - started < timeout) {
    if (window.pywebview?.api) return true
    await sleep(80)
  }
  return false
}

async function invokePython<T>(method: string, ...args: unknown[]): Promise<T> {
  const available = await waitForPyWebView()
  if (!available || !window.pywebview?.api?.[method]) {
    throw new Error('PYWEBVIEW_NOT_AVAILABLE')
  }
  return window.pywebview.api[method](...args) as Promise<T>
}

const mockHistory: HistoryRun[] = [
  {
    id: 'demo-hgb-20260717',
    generated_at: '2026-07-17T14:32:00',
    output_type: 'HGB',
    current_file: 'source_2026.xlsx',
    previous_file: 'source_2025.xlsx',
    current_record_count: 28641,
    companies: ['AG', 'GRH', 'SFS', 'SFN', 'KBM', 'HW', 'IT', 'Steering'],
    workbook: 'outputs/HGB_20260717/KB_Handelsbilanz_HGB.xlsx',
    output_folder: 'outputs/HGB_20260717',
    warnings: [],
  },
]

async function loadMockRules(): Promise<RulesConfig> {
  const stored = localStorage.getItem('kb-demo-rules')
  if (stored) return JSON.parse(stored) as RulesConfig
  const response = await fetch('./mock-rules.json')
  return response.json() as Promise<RulesConfig>
}

function mockWorkbook(path = 'KB_Handelsbilanz_HGB_Demo.xlsx'): WorkbookPreview {
  const rows: WorkbookPreview['sheets'][number]['rows'] = [
    ['Kennzahl', 'Zelle', 'Bezeichnung', 'Vorjahr', 'Anzahl VJ', 'Aktuell', 'Differenz', 'Anzahl aktuell'],
    ['VO Anwärter', 'J12', 'Anwärter Männer', 4250000, 83, 4510000, 260000, 86],
    ['VO Anwärter', 'J14', 'Anwärter Frauen', 3120000, 61, 3080000, -40000, 60],
    ['VO Anwärter', 'J15', 'Männer ausgesch. mit unvA', 820000, 17, 901000, 81000, 19],
    ['VO Anwärter', 'J16', 'Frauen ausgesch. mit unvA', 610000, 14, 625000, 15000, 15],
    ['VO Rentner', 'J21', 'Rentner Männer', 9820000, 124, 10140000, 320000, 127],
    ['VO Rentner', 'J22', 'Rentner Frauen', 6210000, 96, 6450000, 240000, 99],
  ]
  return {
    path,
    file_name: path.split(/[\\/]/).pop() ?? path,
    sheets: [
      { name: 'Start', max_row: 8, max_col: 2, rows: [['KB Handelsbilanz – Demo'], ['Output-Typ', 'HGB'], ['Datensätze', 28641]], merges: [], widths: [28, 40] },
      { name: 'GRH', max_row: rows.length, max_col: 8, rows, merges: [], widths: [20, 10, 34, 18, 14, 18, 18, 16] },
      { name: 'AG', max_row: rows.length, max_col: 8, rows, merges: [], widths: [20, 10, 34, 18, 14, 18, 18, 16] },
    ],
  }
}

export const bridge = {
  async bootstrap(): Promise<BootstrapData> {
    try {
      return await invokePython<BootstrapData>('get_bootstrap')
    } catch {
      const rules = await loadMockRules()
      const companies = Object.entries(rules.companies).map(([name, value]) => ({
        name,
        code: value.code,
        rule_count: value.rules.length,
      }))
      return {
        version: 'UI-Demo',
        companies,
        value_columns: rules.value_columns as BootstrapData['value_columns'],
        history: mockHistory,
        settings: {
          output_dir: 'outputs',
          auto_open_excel: false,
          auto_open_folder: false,
          remember_last_selection: true,
          theme: 'light',
        },
        rule_count: companies.reduce((sum, item) => sum + item.rule_count, 0),
      }
    }
  },

  async selectExcelFile(): Promise<string | null> {
    try {
      return await invokePython<string | null>('select_excel_file')
    } catch {
      return null
    }
  },

  async selectOutputFolder(): Promise<string | null> {
    try {
      return await invokePython<string | null>('select_output_folder')
    } catch {
      return null
    }
  },

  async inspectSource(path: string, outputType: string, companies: string[]): Promise<Inspection> {
    try {
      return await invokePython<Inspection>('inspect_source', path, outputType, companies)
    } catch {
      return {
        path,
        name: path.split(/[\\/]/).pop() ?? 'source_2026.xlsx',
        sheet_name: 'AllOnetabOrFile',
        header_row: 7,
        record_count: 28641,
      }
    }
  },

  async startRun(payload: RunPayload): Promise<string> {
    try {
      return await invokePython<string>('start_calculation', payload)
    } catch {
      const id = `demo-${Date.now()}`
      sessionStorage.setItem(`job:${id}:started`, String(Date.now()))
      sessionStorage.setItem(`job:${id}:payload`, JSON.stringify(payload))
      return id
    }
  },

  async getJob(id: string): Promise<JobStatus> {
    try {
      return await invokePython<JobStatus>('get_job', id)
    } catch {
      const started = Number(sessionStorage.getItem(`job:${id}:started`) || Date.now())
      const elapsed = Date.now() - started
      const progress = Math.min(100, Math.round(elapsed / 38))
      const done = progress >= 100
      const payload = JSON.parse(sessionStorage.getItem(`job:${id}:payload`) || '{}') as RunPayload
      return {
        id,
        state: done ? 'done' : 'running',
        progress,
        stage: done ? 'Excel-Ausgabe wurde erstellt' : progress < 25 ? 'Quelldatei wird geprüft' : progress < 60 ? 'Gesellschaften werden berechnet' : 'Excel-Ausgabe wird geschrieben',
        logs: ['Header in Zeile 7 erkannt', `${payload.companies?.length || 8} Gesellschaften ausgewählt`],
        result: done
          ? {
              workbook: 'KB_Handelsbilanz_HGB_Demo.xlsx',
              output_folder: 'outputs/Demo',
              warnings: [],
              history_item: mockHistory[0],
            }
          : undefined,
      }
    }
  },

  async getWorkbook(path: string): Promise<WorkbookPreview> {
    try {
      return await invokePython<WorkbookPreview>('get_workbook_preview', path)
    } catch {
      return mockWorkbook(path)
    }
  },

  async listHistory(): Promise<HistoryRun[]> {
    try {
      return await invokePython<HistoryRun[]>('list_history')
    } catch {
      return mockHistory
    }
  },

  async getRules(): Promise<RulesConfig> {
    try {
      return await invokePython<RulesConfig>('get_rules')
    } catch {
      return loadMockRules()
    }
  },

  async saveRules(rules: RulesConfig): Promise<{ ok: boolean; backup?: string; message: string }> {
    try {
      return await invokePython('save_rules', rules)
    } catch {
      localStorage.setItem('kb-demo-rules', JSON.stringify(rules))
      return { ok: true, message: 'Regeln wurden im lokalen Demo-Speicher gespeichert.' }
    }
  },

  async getSettings(): Promise<Settings> {
    try {
      return await invokePython<Settings>('get_settings')
    } catch {
      const stored = localStorage.getItem('kb-demo-settings')
      return stored ? JSON.parse(stored) : {
        output_dir: 'outputs', auto_open_excel: false, auto_open_folder: false, remember_last_selection: true, theme: 'light',
      }
    }
  },

  async saveSettings(settings: Settings): Promise<Settings> {
    try {
      return await invokePython<Settings>('save_settings', settings)
    } catch {
      localStorage.setItem('kb-demo-settings', JSON.stringify(settings))
      return settings
    }
  },

  async openPath(path: string): Promise<boolean> {
    try {
      return await invokePython<boolean>('open_path', path)
    } catch {
      console.info('Demo openPath', path)
      return true
    }
  },
}
