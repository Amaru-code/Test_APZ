from __future__ import annotations

import json
from pathlib import Path
import shutil
import tempfile
import time
import unittest

from desktop_bridge import DesktopBridge


ROOT = Path(__file__).resolve().parents[1]


class DesktopBridgeTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        (self.root / "config").mkdir(parents=True)
        (self.root / "data" / "samples").mkdir(parents=True)
        (self.root / "outputs").mkdir(parents=True)
        (self.root / "archive").mkdir(parents=True)
        shutil.copy2(ROOT / "config" / "rules.json", self.root / "config" / "rules.json")
        shutil.copy2(
            ROOT / "data" / "samples" / "sample_AllOnetabOrFile.xlsx",
            self.root / "data" / "samples" / "sample_AllOnetabOrFile.xlsx",
        )
        (self.root / "VERSION.txt").write_text("test\n", encoding="utf-8")
        self.bridge = DesktopBridge(self.root)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def test_bootstrap_and_source_inspection(self) -> None:
        bootstrap = self.bridge.get_bootstrap()
        self.assertEqual(bootstrap["rule_count"], 183)
        self.assertEqual(len(bootstrap["companies"]), 8)
        inspected = self.bridge.inspect_source(
            str(self.root / "data" / "samples" / "sample_AllOnetabOrFile.xlsx"),
            "HGB",
            ["AG"],
        )
        self.assertEqual(inspected["header_row"], 7)
        self.assertEqual(inspected["sheet_name"], "AllOnetabOrFile")
        self.assertGreater(inspected["record_count"], 0)

    def test_rule_save_creates_backup_and_stays_valid(self) -> None:
        rules = self.bridge.get_rules()
        rules["companies"]["AG"]["rules"][0]["label"] = "Testbezeichnung"
        result = self.bridge.save_rules(rules)
        self.assertTrue(result["ok"])
        self.assertTrue(Path(result["backup"]).exists())
        saved = json.loads((self.root / "config" / "rules.json").read_text(encoding="utf-8"))
        self.assertEqual(saved["companies"]["AG"]["rules"][0]["label"], "Testbezeichnung")

    def test_background_calculation_history_and_preview(self) -> None:
        job_id = self.bridge.start_calculation(
            {
                "current_file": str(self.root / "data" / "samples" / "sample_AllOnetabOrFile.xlsx"),
                "previous_file": None,
                "output_type": "HGB",
                "companies": ["AG"],
                "output_dir": str(self.root / "outputs"),
            }
        )
        status = self.bridge.get_job(job_id)
        for _ in range(100):
            if status["state"] in {"done", "error"}:
                break
            time.sleep(0.03)
            status = self.bridge.get_job(job_id)
        self.assertEqual(status["state"], "done", status.get("error"))
        workbook = Path(status["result"]["workbook"])
        self.assertTrue(workbook.exists())
        history = self.bridge.list_history()
        self.assertEqual(len(history), 1)
        preview = self.bridge.get_workbook_preview(str(workbook))
        self.assertIn("Start", [sheet["name"] for sheet in preview["sheets"]])
        self.assertIn("AG", [sheet["name"] for sheet in preview["sheets"]])


if __name__ == "__main__":
    unittest.main()
