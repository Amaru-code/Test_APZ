LOGA Dynamic V4
===============

Eingaben beim Start:
1. Netto-Arbeitsstunden pro Woche
2. Anzahl Arbeitstage von 1 bis 5
3. Gesamte Pausenstunden pro Woche

Standard:
- 40 Netto-Stunden
- 5 Arbeitstage
- 5 Pausenstunden

Verteilung:
- minutengenau
- Arbeitstage ab Montag
- Restminuten gehen an die ersten Tage
- bereits gebuchte Tage werden nicht verändert
- 0 Pausenstunden erzeugt nur Kommen und Gehen

Sicherheit:
- maximal 16 Bruttostunden je Arbeitstag
- bei langen Tagen wird 09:00 automatisch vorverlegt
- unmögliche Pläne werden vor jeder Änderung gestoppt
