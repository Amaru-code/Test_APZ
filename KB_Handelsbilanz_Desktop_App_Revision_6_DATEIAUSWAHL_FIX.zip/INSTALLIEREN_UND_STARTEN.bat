@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title KB Handelsbilanz - Installation und Start

set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "PYTHON_CMD="

for %%V in (3.12 3.11 3.10 3) do (
    if not defined PYTHON_CMD (
        py -%%V -c "import sys" >nul 2>&1
        if not errorlevel 1 set "PYTHON_CMD=py -%%V"
    )
)

if not defined PYTHON_CMD (
    where python.exe >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=python"
)

if not defined PYTHON_CMD (
    echo FEHLER: Python 3.10 oder neuer wurde nicht gefunden.
    echo Bitte Python installieren und "Add python.exe to PATH" aktivieren.
    pause
    exit /b 1
)

echo ============================================================
echo  KB Handelsbilanz Desktop App
echo ============================================================
echo.
echo Python: %PYTHON_CMD%

if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Erstelle virtuelle Python-Umgebung ...
    call %PYTHON_CMD% -m venv ".venv"
    if errorlevel 1 goto :error
) else (
    echo [1/3] Virtuelle Umgebung ist bereits vorhanden.
)

set "VENV_PYTHON=%CD%\.venv\Scripts\python.exe"

echo [2/3] Installiere Abhaengigkeiten ...
"%VENV_PYTHON%" -m pip install --disable-pip-version-check --upgrade pip
if errorlevel 1 goto :error
"%VENV_PYTHON%" -m pip install --disable-pip-version-check -r "%CD%\requirements.txt"
if errorlevel 1 goto :error

echo [3/3] Starte Desktop-App ...
"%VENV_PYTHON%" "%CD%\src\desktop_app.py"
set "EXITCODE=%ERRORLEVEL%"
if not "%EXITCODE%"=="0" (
    echo.
    echo Die Desktop-App wurde mit Fehlercode %EXITCODE% beendet.
    echo Starte bei Problemen DIAGNOSE.bat oder BROWSER_VORSCHAU_STARTEN.bat.
    pause
)
exit /b %EXITCODE%

:error
echo.
echo FEHLER: Installation oder Start ist fehlgeschlagen.
echo Alternativ kann BROWSER_VORSCHAU_STARTEN.bat verwendet werden.
pause
exit /b 1
