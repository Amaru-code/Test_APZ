@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title KB Handelsbilanz Automatisierung - Tests

set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"

if not exist ".venv\Scripts\python.exe" (
    echo Die virtuelle Umgebung fehlt.
    echo Starte zuerst INSTALLIEREN_UND_STARTEN.bat.
    pause
    exit /b 1
)

set "PYTHONPATH=%CD%\src"
"%CD%\.venv\Scripts\python.exe" -m unittest discover -s "%CD%\tests" -v
set "EXITCODE=%ERRORLEVEL%"

echo.
if "%EXITCODE%"=="0" (
    echo Alle Tests wurden erfolgreich abgeschlossen.
) else (
    echo Mindestens ein Test ist fehlgeschlagen.
)
pause
exit /b %EXITCODE%
