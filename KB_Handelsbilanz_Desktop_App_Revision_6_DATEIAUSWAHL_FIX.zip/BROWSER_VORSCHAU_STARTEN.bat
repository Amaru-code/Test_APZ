@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title KB Handelsbilanz Browser-Vorschau

set "PYTHON_CMD="
if exist ".venv\Scripts\python.exe" set "PYTHON_CMD=%CD%\.venv\Scripts\python.exe"
if not defined PYTHON_CMD (
    where py.exe >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=py -3"
)
if not defined PYTHON_CMD set "PYTHON_CMD=python"

%PYTHON_CMD% "%CD%\scripts\browser_preview.py"
if errorlevel 1 pause
