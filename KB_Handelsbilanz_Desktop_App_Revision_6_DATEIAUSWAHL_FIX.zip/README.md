# KB Handelsbilanz Desktop App – Revision 7

Diese Revision kombiniert die bestehende regelbasierte Excel-Berechnung mit der grün-weißen Desktop-Oberfläche und korrigiert zusätzlich den WebView2-Startpfad.

## Direkt starten

Beim ersten Start:

```text
INSTALLIEREN_UND_STARTEN.bat
```

Danach genügt:

```text
STARTEN.bat
```

Die Installation legt eine lokale `.venv` an, installiert `openpyxl` und `pywebview` und öffnet die Anwendung in einem nativen Windows-WebView2-Fenster. Es öffnet sich kein gewöhnlicher Browser und während der Nutzung ist kein Terminal erforderlich.


## Behobener Startfehler in Revision 7

Die Oberfläche wird nicht mehr direkt über eine `file:///`-Adresse geladen. Stattdessen startet die Anwendung automatisch einen kleinen lokalen Server auf `127.0.0.1` und lädt HTML, CSS, JavaScript sowie SVG-Dateien darüber. Damit tritt `ERR_FILE_NOT_FOUND` beim Start nicht mehr auf – unabhängig davon, in welchem Windows-Ordner das Projekt liegt. Der Server ist ausschließlich auf dem eigenen Rechner erreichbar und beendet sich gemeinsam mit der App.

## Behobener Dateiauswahlfehler

Der Dateiauswahl-Fix aus Revision 6 bleibt vollständig enthalten:

- pywebview 6 wird über `FileDialog.OPEN` beziehungsweise den kompatiblen `LOAD`-Fallback angesprochen.
- Das zyklische WebView-Fenster wird nicht mehr im JavaScript-API-Objekt gespeichert. Dadurch tritt die endlose `Auto.Auto...`-Serialisierung mit anschließendem Rekursionsfehler nicht mehr auf.
- Die Desktop-App wartet auf die konkret benötigte API-Methode. Der Browser-Demopfad `demo://...` wird in der echten Desktop-App nicht mehr verwendet.

Das visuelle Design, das Logo und die Fensterhöhe wurden in dieser Revision bewusst nicht verändert.

## Oberflächenbereiche

- **Review:** Quelldatei und optionales Vorjahr auswählen, HGB/STB/7 Jahre festlegen, Gesellschaften wählen und die Berechnung starten.
- **Ergebnisse:** Die erzeugte Excel-Arbeitsmappe mit Sheet-Reitern, Zeilen- und Spaltenköpfen direkt in der Anwendung ansehen; zusätzlich kann die Datei in Excel oder der Ausgabeordner geöffnet werden.
- **Regeln:** Alle Feldregeln je Gesellschaft und Kennzahl durchsuchen, bearbeiten, ergänzen, duplizieren oder löschen. Speichern schreibt dauerhaft nach `config/rules.json` und erzeugt vorher eine Zeitstempel-Sicherung in `archive/rules`.
- **Historie:** Frühere Auswertungsläufe aus `outputs` aufrufen und erneut in der Ergebnisansicht öffnen.
- **Einstellungen:** Ausgabeordner und automatisches Öffnen nach einer Berechnung festlegen.

## Alternative Starts

- `APP_STARTEN.bat` – Kurzverweis auf den normalen Start.
- `BROWSER_VORSCHAU_STARTEN.bat` – reine Oberflächenvorschau im Browser mit Demodaten; die Python-Funktionen sind dort absichtlich nicht aktiv.
- `ALTE_GUI_STARTEN.bat` – startet die frühere Tkinter-Oberfläche.
- `TAURI_ENTWICKLUNG_STARTEN.bat` – startet die mitgelieferte Tauri-Entwicklungsstruktur, sofern Node.js, Rust und die Windows Build Tools installiert sind.
- `DIAGNOSE.bat` – prüft Python, Abhängigkeiten, Frontend und zentrale Projektdateien.

## Technik

Die sofort nutzbare Desktop-App verwendet:

- bestehende Python-Berechnungsengine,
- lokale HTML/CSS/JavaScript-Oberfläche,
- Windows WebView2 über `pywebview`,
- lokale hochauflösende SVG-Icons,
- vollständig offline verfügbare UI-Dateien.

Zusätzlich liegen unter `frontend/react-tailwind-source` ein React-/TypeScript-/Tailwind-Quellstand und unter `frontend/src-tauri` die Tauri-2-Projektstruktur. Der direkt startbare Windows-Weg nutzt bewusst den Python-WebView, damit die vorhandene Berechnungsengine ohne separate Rust-/Node-Installation funktioniert.

Fachliche Dokumentation: [`docs/README.md`](docs/README.md)  
UI-Dokumentation: [`docs/UI_DESKTOP_APP.md`](docs/UI_DESKTOP_APP.md)  
Regelstand: Revision 4 mit 183 Kennzahlenregeln.
