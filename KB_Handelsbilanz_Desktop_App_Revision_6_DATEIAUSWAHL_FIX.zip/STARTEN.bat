@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title KB Handelsbilanz Desktop App
if not exist ".venv\Scripts\python.exe" (
    call "%~dp0INSTALLIEREN_UND_STARTEN.bat"
    exit /b %ERRORLEVEL%
)
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
"%~dp0.venv\Scripts\python.exe" "%~dp0src\desktop_app.py"
set "EXITCODE=%ERRORLEVEL%"
if not "%EXITCODE%"=="0" (
    echo Die App wurde mit Fehlercode %EXITCODE% beendet.
    pause
)
exit /b %EXITCODE%
