# Revision 7 – Startpfad-Fix

## Behobener Fehler

Revision 6 hat den Desktop-Modus über einen Query-String an einer lokalen
`file:///.../index.html`-Adresse aktiviert. Microsoft WebView2 kann einen
solchen Query-String je nach Installation als Bestandteil des Dateinamens
interpretieren. Die Folge war:

```text
Die Datei wurde nicht gefunden.
ERR_FILE_NOT_FOUND
```

## Neue Lösung

Die statischen UI-Dateien werden beim Start über einen kleinen lokalen Server
bereitgestellt:

```text
http://127.0.0.1:<zufälliger Port>/index.html?desktop=1&revision=7
```

Der Server:

- ist nur auf dem eigenen Rechner erreichbar,
- verwendet einen freien zufälligen Port,
- startet automatisch vor dem App-Fenster,
- beendet sich automatisch mit der Anwendung,
- lädt HTML, CSS, JavaScript, JSON und SVG unabhängig vom Projektpfad,
- verhindert alte zwischengespeicherte UI-Dateien.

Die Berechnungslogik, Feldregeln, Dateiauswahl und das Design wurden nicht
verändert.
