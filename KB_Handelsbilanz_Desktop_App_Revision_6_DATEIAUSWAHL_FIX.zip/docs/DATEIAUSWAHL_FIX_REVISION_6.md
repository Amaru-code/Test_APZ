# Dateiauswahl-Fix – Revision 6

## Beobachtete Fehler

- Nach der Dateiauswahl entstand ein Pfad wie `demo:\Dateiname.xlsx`; dieser Pfad existiert auf dem Dateisystem nicht.
- Teilweise meldete die Oberfläche, dass `get_bootstrap` nicht verfügbar sei.
- Im Terminal erschien eine sehr lange `Auto.Auto...`-Ausgabe, gefolgt von `maximum recursion depth exceeded`.

## Technische Ursache

Revision 5 verwendete für den nativen Dialog eine veraltete pywebview-Konstante. Nach dem internen Fehler wechselte das Frontend auf den Browser-Dateidialog, der aus Sicherheitsgründen nur den Dateinamen und keinen verwendbaren absoluten Pfad liefert. Zusätzlich hielt das öffentlich exponierte API-Objekt das vollständige WebView-Fenster. Dieses Objekt besitzt zyklische Referenzen und wurde von pywebview bei der API-Aufbereitung rekursiv verarbeitet.

## Korrektur

- Verwendung der pywebview-6-Dialog-Enums.
- Ermittlung des aktiven Fensters erst beim Öffnen des Dialogs.
- Kein Fensterobjekt und keine anderen komplexen Laufzeitobjekte als öffentliche API-Daten.
- Desktopmodus wird per URL-Kennzeichen festgelegt; dort ist ein Wechsel auf `demo://` ausgeschlossen.
- API-Bereitschaft wird je Methode geprüft und die Initialisierung nur einmal gestartet.
