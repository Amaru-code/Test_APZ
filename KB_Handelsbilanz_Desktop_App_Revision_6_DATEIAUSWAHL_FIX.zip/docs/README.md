# KB Handelsbilanz Automatisierung

## Zweck

Das Tool liest eine Excel-Quelldatei mit dem Sheet `AllOnetabOrFile`, erkennt die Headerzeile automatisch und berechnet regelbasierte Kennzahlen für ausgewählte Gesellschaften.

**Regelstand:** Revision 4 vom 17.07.2026 mit 183 Kennzahlenregeln. Die Änderungen sind in [`CHANGELOG_2026-07-17.md`](CHANGELOG_2026-07-17.md) dokumentiert.

Unterstützte Output-Typen:

| Output-Typ | Summenspalte |
|---|---|
| HGB | `Trade.Trade AL` |
| STB | `Tax.Tax AL` |
| 7 Jahre | `TradeAltInt.Trade AL` |

## Schnellstart

1. Den Paketinhalt nach
   `C:\Users\Amaru-Zegarra\projects\Aktive_Projekte\KB_Handlesbilanz_Automatisierung`
   kopieren.
2. `INSTALLIEREN_UND_STARTEN.bat` doppelklicken.
3. In der Oberfläche die Datei des aktuellen Jahres auswählen.
4. Optional „Vorjahr einbeziehen“ aktivieren und eine zweite Datei auswählen.
5. Output-Typ und Gesellschaften auswählen.
6. „Berechnung starten“ klicken.

Nach der ersten Installation genügt `STARTEN.bat`.

## Ausgabe

Jeder Lauf erzeugt unter `outputs` einen eigenen Zeitstempelordner, zum Beispiel:

```text
outputs/
└── HGB_20260717_113000/
    ├── KB_Handelsbilanz_HGB_20260717_113000.xlsx
    ├── Regeln_AG.md
    ├── Regeln_GRH.md
    └── run_manifest.json
```

Die Excel-Datei enthält:

- ein Start-/Protokollsheet,
- je ausgewählter Gesellschaft ein eigenes Sheet,
- Werte des Vorjahres in Spalte F,
- Mitarbeiteranzahl des Vorjahres in Spalte H,
- Werte des aktuellen Jahres in Spalte J,
- Differenz `J - F` in Spalte L,
- Mitarbeiteranzahl des aktuellen Jahres in Spalte N.

Ohne Vorjahr werden nur J und N befüllt.

## Headererkennung

Die Anwendung durchsucht die ersten 100 Zeilen und bewertet jede Zeile anhand der benötigten Spalten. Zeile 7 wird dadurch gefunden, ist aber nicht fest einprogrammiert.

Bekannte alternative Header werden über `config/rules.json` zugeordnet, beispielsweise:

- `GlobeCode` oder `GlobalCode`
- `SubsidiaryCode` oder `SubsidaryCode`
- `DivisionCode` oder `Division Code`
- `Gender` oder `Geschlecht`

Fehlt eine für die ausgewählten Regeln benötigte Spalte, bricht die Anwendung mit einer verständlichen Fehlermeldung ab.

## Mitarbeiteranzahl

Die Anzahl wird nicht einfach als Zahl passender Datenzeilen berechnet. Stattdessen werden eindeutige Mitarbeiter-IDs gezählt, und zwar in dieser Reihenfolge:

1. `ClientEEID`
2. `EmployeeIDNumber`
3. `AdditionalID`
4. Excel-Zeilennummer als letzter Fallback

Dadurch werden doppelte Datenzeilen desselben Mitarbeiters nicht automatisch doppelt gezählt.

## Regeln ändern

Alle Regeln stehen in:

```text
config/rules.json
```

Eine Kennzahl enthält insbesondere:

```json
{
  "target_row": 12,
  "label": "Anwärter Männer",
  "section": "VO Anwärter",
  "all": [
    {"field": "VOShortName", "op": "eq", "value": "VO"},
    {"field": "USC", "op": "eq", "value": 10},
    {"field": "Gender", "op": "eq", "value": "M"}
  ]
}
```

Unterstützte Operatoren:

- `eq`, `neq`
- `in`, `not_in`
- `gt`, `gte`, `lt`, `lte`

Bedingungen unter `all` werden mit UND verknüpft. Bedingungen unter `any` werden geklammert mit ODER verknüpft. Insgesamt gilt:

```text
alle all-Bedingungen UND mindestens eine any-Bedingung
```

Große ID-Listen stehen im Bereich `sets` und werden über `set_ref` wiederverwendet.

## Gesellschaftsfilter

Standardmäßig wird jede Regel automatisch auf den GlobeCode der Gesellschaft eingeschränkt. Das verhindert, dass beispielsweise eine allgemein formulierte `VOShortName = VO`-Regel Daten anderer Gesellschaften mitnimmt.

Einzelne ausdrücklich gesellschaftsübergreifende Regeln verwenden:

```json
"disable_company_scope": true
```

## Kommandozeilenmodus

Neben der GUI kann die Anwendung automatisiert ausgeführt werden:

```powershell
.\.venv\Scripts\python.exe .\src\main.py `
  --no-gui `
  --current "C:\Pfad\aktuell.xlsx" `
  --previous "C:\Pfad\vorjahr.xlsx" `
  --type "HGB" `
  --companies "AG,GRH,SFS" `
  --output-dir ".\outputs"
```

## Tests

`TESTS_AUSFUEHREN.bat` startet die automatisierten Tests.

Eine kleine Beispieldatei kann mit `scripts\BEISPIELDATEI_ERZEUGEN.bat` erzeugt werden.

## PDF-Ausgabe

Die erzeugte XLSX ist bewusst der erste stabile Zwischenschritt. Die Sheets enthalten bereits Druckbereich, Querformat, Wiederholungszeilen und „auf eine Seite Breite“-Einstellungen. Die spätere PDF-Stufe kann darauf aufbauen, beispielsweise über lokal installiertes Microsoft Excel.
