# Revision 8 – Dateidialog- und Taskleisten-Fix

## Dateidialog

pywebview 6.2.1 akzeptiert für Filterbeschreibungen nur Buchstaben, Zahlen und Leerzeichen. Der bisherige Text `Excel-Dateien` enthielt einen Bindestrich und wurde bereits vor dem Öffnen des Windows-Dialogs als ungültig abgelehnt.

Die neue Implementierung verwendet:

```text
Excel Dateien (*.xlsx;*.xlsm)
```

Falls ein Windows-Backend den benutzerdefinierten Filter trotzdem ablehnt, wird der Dialog automatisch ohne Filter erneut geöffnet. Danach validiert Python die gewählte Dateiendung.

## Taskleiste und kleine Displays

Das Desktopfenster startet maximiert. Ein maximiertes Windows-Fenster nutzt den Arbeitsbereich oberhalb der Taskleiste. Zusätzlich wurde die feste HTML-Mindesthöhe entfernt und für Displays mit geringer nutzbarer Höhe ein kompakteres Layout ergänzt. Der Hauptbereich bleibt scrollbar.
