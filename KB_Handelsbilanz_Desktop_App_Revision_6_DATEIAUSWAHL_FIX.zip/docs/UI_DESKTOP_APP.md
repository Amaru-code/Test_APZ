# Desktop-Oberfläche – Revision 5

## Zielbild

Die Oberfläche orientiert sich am ersten grün-weißen Entwurf: helle Glasflächen, Petrol-/Türkis-Akzente, weiche Schatten, abgerundete Karten, lokale SVG-Icons und flüssige Seiten- und Statusanimationen.

## Review

Der Reiter **Review** bündelt den vollständigen Berechnungsablauf:

1. XLSX-Datei des aktuellen Jahres auswählen.
2. Optional den Vorjahresvergleich aktivieren und eine zweite XLSX-Datei wählen.
3. HGB, STB oder 7 Jahre auswählen.
4. Gesellschaften auswählen.
5. Quelldatei automatisch prüfen lassen.
6. Berechnung in einem Hintergrundprozess starten.

Die Oberfläche zeigt Headerzeile, Datensatzanzahl, ausgewählte Gesellschaften, Regelanzahl und die verwendete Berechnungsspalte.

## Ergebnisse

Nach einem Lauf wird die erzeugte Arbeitsmappe direkt geladen. Die Ansicht bietet:

- Sheet-Reiter wie in Excel,
- Spaltenbuchstaben und Zeilennummern,
- horizontales und vertikales Scrollen,
- Formelerkennung,
- Öffnen der Originaldatei in Excel,
- Öffnen des Ausgabeordners.

Aus Performancegründen lädt die integrierte Vorschau je Sheet maximal 250 Zeilen und 40 Spalten. Die gespeicherte XLSX selbst bleibt vollständig.

## Regeln

Der Regeleditor arbeitet direkt mit `config/rules.json`.

Funktionen:

- Gesellschaft auswählen,
- Kennzahlen suchen,
- Zielzeile, Abschnitt und Bezeichnung ändern,
- UND- und ODER-Bedingungen bearbeiten,
- Operatoren und Werte ändern,
- große ID-Sets über `set_ref` auswählen,
- Regeln hinzufügen, duplizieren oder löschen,
- vollständige Konfiguration im JSON-Modus bearbeiten,
- Änderungen validieren und dauerhaft speichern.

Vor jedem Speichern wird automatisch eine Sicherung unter `archive/rules/rules_YYYYMMDD_HHMMSS.json` angelegt. Fehlerhafte Operatoren, unbekannte Felder, doppelte Zielzeilen oder fehlende Sets werden abgelehnt.

## Historie

Die Historie liest vorhandene `run_manifest.json`-Dateien aus den Ausgabeordnern. Ein älterer Lauf kann unmittelbar in der Ergebnisansicht geöffnet werden.

## Einstellungen

Aktuell vorhanden:

- Standard-Ausgabeordner,
- Excel nach Abschluss automatisch öffnen,
- Ausgabeordner nach Abschluss automatisch öffnen,
- letzte Auswahl merken.

Die Werte werden in `config/app_settings.json` gespeichert.

## Tauri und direkter Start

Die Tauri-2-Struktur befindet sich unter `frontend/src-tauri`. Da eine Windows-Tauri-EXE nicht in einer Linux-Buildumgebung erzeugt werden kann, ist der mitgelieferte Sofortstart als Windows-WebView2-App umgesetzt. Das Erscheinungsbild und das Frontend sind identisch; der Python-WebView verbindet die UI direkt mit der vorhandenen Berechnungsengine.
