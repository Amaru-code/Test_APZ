# Testbericht – Revision 6 Dateiauswahl-Fix

Stand: 19.07.2026

## Automatisierte Prüfungen

- 26 von 26 Python- und Projektstrukturtests erfolgreich.
- Vollständige bestehende Regel- und Berechnungsprüfung mit 183 Kennzahlen.
- End-to-End-Erstellung einer XLSX-Ausgabe erfolgreich.
- Native Dateidialog-API mit einer simulierten pywebview-6-Umgebung geprüft.
- Sicherstellung, dass das JavaScript-API-Objekt keine öffentlichen komplexen Laufzeitattribute besitzt.
- Desktopmodus wartet auf die konkrete API-Methode.
- Browser-Demopfad ist in der echten Desktop-App deaktiviert.
- JavaScript-Syntax der produktiv verwendeten `frontend/dist/app.js` erfolgreich geprüft.
- Windows-BAT-Dateien werden abschließend auf ASCII und CRLF geprüft.
- ZIP-Integritätsprüfung erfolgreich abgeschlossen.

## Nicht verändert

Das grün-weiße Interface, das aktuelle Logo, die Fensterabmessungen und sämtliche fachlichen Feldregeln wurden in Revision 6 bewusst unverändert gelassen.
