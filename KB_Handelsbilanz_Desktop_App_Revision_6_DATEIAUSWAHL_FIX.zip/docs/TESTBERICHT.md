# Testbericht – Revision 7 Startpfad-Fix

Stand: 19.07.2026

## Automatisierte Prüfungen

- 29 von 29 Python- und Projektstrukturtests erfolgreich.
- Vollständige bestehende Regel- und Berechnungsprüfung mit 183 Kennzahlen.
- End-to-End-Erstellung einer XLSX-Ausgabe erfolgreich.
- Native Dateidialog-API mit einer simulierten pywebview-6-Umgebung geprüft.
- Lokaler Frontend-Server auf `127.0.0.1` gestartet und per HTTP abgerufen.
- `index.html` und ein abhängiges CSS-Asset erfolgreich über denselben Server geladen.
- Prüfung, dass der Start nicht mehr über `frontend.as_uri()` beziehungsweise `file:///` erfolgt.
- Browser-Demopfad ist in der echten Desktop-App deaktiviert.
- Alle lokalen SVG-Verweise vorhanden.
- Windows-BAT-Dateien auf ASCII und CRLF geprüft.

## Behobener Fehler

Der Query-String für den Desktop-Modus wurde in Revision 6 direkt an eine lokale `file:///.../index.html`-Adresse angehängt. WebView2 konnte dies als Bestandteil des Dateinamens behandeln und zeigte `ERR_FILE_NOT_FOUND`. Revision 7 verwendet stattdessen einen lokalen Loopback-HTTP-Server.

## Nicht verändert

Das grün-weiße Interface, das aktuelle Logo, die Fensterabmessungen, die Dateiauswahlkorrekturen aus Revision 6 und sämtliche fachlichen Feldregeln wurden unverändert beibehalten.
