# Testbericht – Revision 8

Stand: 19.07.2026

## Ergebnis

- 31 von 31 automatisierten Tests erfolgreich.
- Regelbestand unverändert: 183 Kennzahlen.
- Excel-End-to-End-Berechnung erfolgreich.
- `.xlsx`-Dateidialog mit gültigem pywebview-Filter simuliert.
- `.xlsm` ist im selben Filter ausdrücklich enthalten.
- Automatischer ungefilterter Fallback getestet.
- Nicht unterstützte Dateiendungen werden nach der Auswahl abgewiesen.
- Maximierter Windows-Start im Desktop-Startcode geprüft.
- Starre Frontend-Mindesthöhe entfernt.
- Kompaktes Layout für Bildschirmhöhen bis 760 Pixel geprüft.
- Lokaler UI-Server und Frontend-Ressourcen erfolgreich geladen.
- Windows-BAT-Dateien verwenden weiterhin CRLF und enthalten kein BOM.

## Behobene Fehler

### Ungültiger Dateifilter

Die pywebview-Filterprüfung erlaubt in der Beschreibung keine Bindestriche. `Excel-Dateien (*.xlsx;*.xlsm)` wurde deshalb abgewiesen, bevor der Windows-Dateidialog geöffnet wurde. Revision 8 verwendet `Excel Dateien (*.xlsx;*.xlsm)`.

### Unterer Bereich hinter der Taskleiste

Das Fenster wurde mit einer festen Höhe von 960 Pixeln geöffnet und das Weblayout erzwang zusätzlich mindestens 720 Pixel Höhe. Revision 8 startet maximiert, reduziert die Mindestgröße und lässt den Hauptbereich auf kleinen Displays scrollen.
