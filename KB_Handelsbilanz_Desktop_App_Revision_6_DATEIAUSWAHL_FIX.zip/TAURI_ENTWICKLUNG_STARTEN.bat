@echo off
setlocal EnableExtensions
cd /d "%~dp0\frontend"
title KB Handelsbilanz - Tauri Entwicklung
where node.exe >nul 2>&1 || goto :missing_node
where npm.cmd >nul 2>&1 || goto :missing_node
where cargo.exe >nul 2>&1 || goto :missing_rust
where rustc.exe >nul 2>&1 || goto :missing_rust
if not exist "node_modules" npm install
if errorlevel 1 goto :error
npm run tauri dev
if errorlevel 1 goto :error
exit /b 0
:missing_node
echo Node.js wurde nicht gefunden. Bitte Node.js LTS installieren.
pause
exit /b 1
:missing_rust
echo Rust/Cargo wurde nicht gefunden. Bitte Rust und die Microsoft C++ Build Tools installieren.
pause
exit /b 1
:error
echo Tauri konnte nicht gestartet werden.
pause
exit /b 1
