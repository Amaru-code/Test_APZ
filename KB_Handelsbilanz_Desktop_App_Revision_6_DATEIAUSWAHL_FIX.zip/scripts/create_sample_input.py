from __future__ import annotations

from pathlib import Path
from openpyxl import Workbook

ROOT = Path(__file__).resolve().parents[1]
DESTINATION = ROOT / "data" / "samples" / "sample_AllOnetabOrFile.xlsx"

headers = [
    "GlobeCode", "VOShortName", "USC", "Gender", "SubsidiaryCode",
    "DivisionCode", "ClientEEID", "EmployeeIDNumber", "AdditionalID",
    "UnitCode", "Trade.Trade AL", "TradeAltInt.Trade AL", "Tax.Tax AL",
]
rows = [
    [300, "VO", 10, "M", 300, 300, 10001, 50001, 0, 300, 1000, 900, 800],
    [300, "VO", 10, "F", 300, 300, 10002, 50002, 0, 300, 2000, 1800, 1600],
    [300, "EZ", 50, "M", 300, 300, 10003, 50003, 0, 300, 3000, 2700, 2400],
    [400, "VO", 50, "M", 400, 230, 10004, 50004, 1, 400, 4000, 3600, 3200],
    [700, "DC", 10, "M", 700, 700, 10005, 50005, 0, 700, 5000, 4500, 4000],
    [1000, "Steering", 55, "M", 1000, 1000, 10006, 50006, 0, 1000, 6000, 5400, 4800],
]

wb = Workbook()
ws = wb.active
ws.title = "AllOnetabOrFile"
for row in range(1, 7):
    ws.cell(row, 1, f"Vorlaufzeile {row}")
for col, header in enumerate(headers, start=1):
    ws.cell(7, col, header)
for row_idx, values in enumerate(rows, start=8):
    for col_idx, value in enumerate(values, start=1):
        ws.cell(row_idx, col_idx, value)
DESTINATION.parent.mkdir(parents=True, exist_ok=True)
wb.save(DESTINATION)
print(DESTINATION)
