@echo off
setlocal EnableExtensions
cd /d "%~dp0\.."
title KB Handelsbilanz Automatisierung - Beispieldatei

set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"

if not exist ".venv\Scripts\python.exe" (
    echo Die virtuelle Umgebung fehlt.
    echo Starte zuerst INSTALLIEREN_UND_STARTEN.bat.
    pause
    exit /b 1
)

"%CD%\.venv\Scripts\python.exe" "%CD%\scripts\create_sample_input.py"
set "EXITCODE=%ERRORLEVEL%"
pause
exit /b %EXITCODE%
