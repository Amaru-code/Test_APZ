from __future__ import annotations

from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import threading
import webbrowser


ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT / "frontend" / "dist"
HOST = "127.0.0.1"
PORT = 8765


def main() -> None:
    if not (FRONTEND / "index.html").exists():
        raise SystemExit(f"Frontend wurde nicht gefunden: {FRONTEND}")
    handler = partial(SimpleHTTPRequestHandler, directory=str(FRONTEND))
    server = ThreadingHTTPServer((HOST, PORT), handler)
    url = f"http://{HOST}:{PORT}/"
    threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    print(f"Browser-Vorschau: {url}")
    print("Die Vorschau verwendet Demodaten. Mit Strg+C beenden.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
