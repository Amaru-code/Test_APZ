export type OutputType = 'HGB' | 'STB' | '7 Jahre'

export interface CompanySummary {
  name: string
  code: number | string
  rule_count: number
}

export interface Settings {
  output_dir: string
  auto_open_excel: boolean
  auto_open_folder: boolean
  remember_last_selection: boolean
  theme: 'light' | 'system'
}

export interface Inspection {
  path: string
  name: string
  sheet_name: string
  header_row: number
  record_count: number
}

export interface HistoryRun {
  id: string
  generated_at: string
  output_type: OutputType
  current_file: string
  previous_file?: string | null
  current_record_count: number
  companies: string[]
  workbook: string
  output_folder: string
  warnings: string[]
}

export interface BootstrapData {
  version: string
  companies: CompanySummary[]
  value_columns: Record<OutputType, string>
  history: HistoryRun[]
  settings: Settings
  rule_count: number
}

export interface RunPayload {
  current_file: string
  previous_file?: string | null
  output_type: OutputType
  companies: string[]
  output_dir?: string
}

export interface JobResult {
  workbook: string
  output_folder: string
  warnings: string[]
  history_item: HistoryRun
}

export interface JobStatus {
  id: string
  state: 'queued' | 'running' | 'done' | 'error'
  progress: number
  stage: string
  logs: string[]
  result?: JobResult
  error?: string
}

export interface WorkbookSheet {
  name: string
  max_row: number
  max_col: number
  rows: Array<Array<string | number | null>>
  merges: string[]
  widths: number[]
}

export interface WorkbookPreview {
  path: string
  file_name: string
  sheets: WorkbookSheet[]
}

export type RuleOperator = 'eq' | 'neq' | 'in' | 'not_in' | 'gt' | 'gte' | 'lt' | 'lte'

export interface RuleCondition {
  field: string
  op: RuleOperator
  value?: string | number | null
  values?: Array<string | number>
  set_ref?: string
}

export interface FieldRule {
  target_row: number
  section: string
  label: string
  all?: RuleCondition[]
  any?: RuleCondition[]
  warning?: string
  disable_company_scope?: boolean
}

export interface CompanyRules {
  code: number | string
  default_scope?: boolean
  rules: FieldRule[]
}

export interface RulesConfig {
  schema_version: number
  value_columns: Record<string, string>
  employee_id_priority: string[]
  header_aliases: Record<string, string[]>
  sets: Record<string, Array<string | number>>
  companies: Record<string, CompanyRules>
}
