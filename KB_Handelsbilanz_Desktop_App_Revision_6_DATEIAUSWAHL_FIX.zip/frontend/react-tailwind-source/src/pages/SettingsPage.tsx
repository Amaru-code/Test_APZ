import { useEffect, useState } from 'react'
import { Folder, Save, Settings2 } from 'lucide-react'
import { bridge } from '../lib/bridge'
import type { Settings } from '../types'

export function SettingsPage({ notify }: { notify: (kind: 'success' | 'error' | 'info', text: string) => void }) {
  const [settings, setSettings] = useState<Settings | null>(null)

  useEffect(() => { bridge.getSettings().then(setSettings).catch(() => undefined) }, [])

  if (!settings) return <div className="grid min-h-[650px] place-items-center text-sm text-slate-400">Einstellungen werden geladen …</div>

  async function chooseFolder() {
    const folder = await bridge.selectOutputFolder()
    if (folder) setSettings({ ...settings!, output_dir: folder })
  }

  async function save() {
    try {
      const saved = await bridge.saveSettings(settings!)
      setSettings(saved)
      notify('success', 'Einstellungen wurden gespeichert.')
    } catch (error) {
      notify('error', error instanceof Error ? error.message : 'Einstellungen konnten nicht gespeichert werden.')
    }
  }

  return (
    <div className="max-w-4xl">
      <div><h1 className="text-[28px] font-extrabold tracking-[-.035em] text-ink">Einstellungen</h1><p className="mt-1 text-sm text-slate-500">Standardverhalten und Ausgabe der Anwendung konfigurieren</p></div>
      <section className="mt-5 overflow-hidden rounded-[20px] border border-slate-200 bg-white shadow-soft">
        <div className="flex items-center gap-3 border-b border-slate-200 px-5 py-4"><span className="grid h-10 w-10 place-items-center rounded-xl bg-cyan-50 text-teal"><Settings2 className="h-5 w-5" /></span><div><strong className="block text-sm text-ink">Allgemein</strong><span className="text-xs text-slate-400">Einstellungen werden in config/app_settings.json gespeichert</span></div></div>
        <div className="space-y-6 p-6">
          <div><label className="field-label mb-2 block">Standard-Ausgabeordner</label><div className="flex gap-2"><input value={settings.output_dir} onChange={(event) => setSettings({ ...settings, output_dir: event.target.value })} className="input-control flex-1" /><button onClick={chooseFolder} className="flex items-center gap-2 rounded-xl border border-slate-200 px-4 text-sm font-bold text-slate-600 hover:bg-slate-50"><Folder className="h-4 w-4" /> Auswählen</button></div></div>
          <div className="grid grid-cols-2 gap-4">
            <SettingToggle label="Excel nach Abschluss automatisch öffnen" checked={settings.auto_open_excel} onChange={(value) => setSettings({ ...settings, auto_open_excel: value })} />
            <SettingToggle label="Ausgabeordner automatisch öffnen" checked={settings.auto_open_folder} onChange={(value) => setSettings({ ...settings, auto_open_folder: value })} />
            <SettingToggle label="Letzte Auswahl merken" checked={settings.remember_last_selection} onChange={(value) => setSettings({ ...settings, remember_last_selection: value })} />
          </div>
          <div className="flex justify-end"><button onClick={save} className="flex items-center gap-2 rounded-xl bg-teal px-5 py-3 text-sm font-bold text-white shadow-sm hover:bg-teal-700"><Save className="h-4 w-4" /> Einstellungen speichern</button></div>
        </div>
      </section>
    </div>
  )
}

function SettingToggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (value: boolean) => void }) {
  return <label className="flex cursor-pointer items-center justify-between rounded-2xl border border-slate-200 bg-slate-50/50 p-4 text-sm font-semibold text-slate-600"><span>{label}</span><button type="button" onClick={() => onChange(!checked)} className={`relative h-6 w-11 rounded-full transition ${checked ? 'bg-teal' : 'bg-slate-300'}`}><span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${checked ? 'left-[22px]' : 'left-0.5'}`} /></button></label>
}
