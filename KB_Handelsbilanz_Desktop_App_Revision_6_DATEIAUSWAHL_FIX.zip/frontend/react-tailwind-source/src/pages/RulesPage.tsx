import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  Braces,
  Check,
  ChevronRight,
  CircleAlert,
  Copy,
  Plus,
  Save,
  Search,
  Trash2,
} from 'lucide-react'
import clsx from 'clsx'
import { bridge } from '../lib/bridge'
import type { FieldRule, RuleCondition, RuleOperator, RulesConfig } from '../types'
import { Modal } from '../components/Modal'

const operators: Array<{ value: RuleOperator; label: string }> = [
  { value: 'eq', label: '=' },
  { value: 'neq', label: '!=' },
  { value: 'in', label: 'in Liste' },
  { value: 'not_in', label: 'nicht in Liste' },
  { value: 'gt', label: '>' },
  { value: 'gte', label: '>=' },
  { value: 'lt', label: '<' },
  { value: 'lte', label: '<=' },
]

function clone<T>(value: T): T {
  return structuredClone(value)
}

function normalizeValue(value: string): string | number {
  const trimmed = value.trim()
  if (trimmed !== '' && /^-?\d+(?:[.,]\d+)?$/.test(trimmed)) return Number(trimmed.replace(',', '.'))
  return trimmed
}

function describeCondition(condition: RuleCondition, sets: RulesConfig['sets']) {
  const operator = operators.find((item) => item.value === condition.op)?.label || condition.op
  if (condition.set_ref) return `${condition.field} ${operator} Set „${condition.set_ref}“ (${sets[condition.set_ref]?.length || 0} Werte)`
  if (condition.values) return `${condition.field} ${operator} {${condition.values.slice(0, 4).join(', ')}${condition.values.length > 4 ? ', …' : ''}}`
  return `${condition.field} ${operator} ${String(condition.value ?? '')}`
}

function ConditionEditor({
  title,
  conditions,
  fields,
  sets,
  onChange,
}: {
  title: string
  conditions: RuleCondition[]
  fields: string[]
  sets: RulesConfig['sets']
  onChange: (conditions: RuleCondition[]) => void
}) {
  function patch(index: number, patchValue: Partial<RuleCondition>) {
    const next = clone(conditions)
    next[index] = { ...next[index], ...patchValue }
    onChange(next)
  }

  function setOperator(index: number, op: RuleOperator) {
    const current = conditions[index]
    const next: RuleCondition = { field: current.field, op }
    if (op === 'in' || op === 'not_in') next.values = current.values || []
    else next.value = current.value ?? ''
    const all = clone(conditions)
    all[index] = next
    onChange(all)
  }

  return (
    <div className="rounded-2xl border border-slate-200 bg-slate-50/60 p-4">
      <div className="mb-3 flex items-center justify-between">
        <div><strong className="block text-sm text-ink">{title}</strong><span className="text-[11px] text-slate-400">{title.startsWith('UND') ? 'Alle Bedingungen müssen zutreffen' : 'Mindestens eine Bedingung muss zutreffen'}</span></div>
        <button
          onClick={() => onChange([...conditions, { field: fields[0] || 'GlobeCode', op: 'eq', value: '' }])}
          className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-2.5 py-2 text-xs font-bold text-teal shadow-sm hover:bg-cyan-50"
        ><Plus className="h-3.5 w-3.5" /> Bedingung</button>
      </div>
      <div className="space-y-3">
        {conditions.length === 0 && <div className="rounded-xl border border-dashed border-slate-300 bg-white px-4 py-5 text-center text-xs text-slate-400">Keine Bedingungen vorhanden.</div>}
        {conditions.map((condition, index) => {
          const listOperator = condition.op === 'in' || condition.op === 'not_in'
          const usesSet = Boolean(condition.set_ref)
          return (
            <motion.div layout key={index} className="rounded-xl border border-slate-200 bg-white p-3 shadow-sm">
              <div className="grid grid-cols-[1.15fr_.72fr_auto] gap-2">
                <select value={condition.field} onChange={(event) => patch(index, { field: event.target.value })} className="input-control">
                  {fields.map((field) => <option key={field}>{field}</option>)}
                </select>
                <select value={condition.op} onChange={(event) => setOperator(index, event.target.value as RuleOperator)} className="input-control">
                  {operators.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}
                </select>
                <button onClick={() => onChange(conditions.filter((_, conditionIndex) => conditionIndex !== index))} className="grid h-10 w-10 place-items-center rounded-xl text-slate-400 hover:bg-rose-50 hover:text-rose-600"><Trash2 className="h-4 w-4" /></button>
              </div>
              {listOperator ? (
                <div className="mt-2">
                  <div className="mb-2 flex rounded-xl bg-slate-100 p-1 text-[11px] font-bold">
                    <button onClick={() => patch(index, { set_ref: undefined, values: condition.values || [] })} className={clsx('flex-1 rounded-lg px-2 py-1.5', !usesSet ? 'bg-white text-teal shadow-sm' : 'text-slate-500')}>Eigene Liste</button>
                    <button onClick={() => patch(index, { set_ref: Object.keys(sets)[0] || '', values: undefined })} className={clsx('flex-1 rounded-lg px-2 py-1.5', usesSet ? 'bg-white text-teal shadow-sm' : 'text-slate-500')}>Zentrales Set</button>
                  </div>
                  {usesSet ? (
                    <select value={condition.set_ref} onChange={(event) => patch(index, { set_ref: event.target.value })} className="input-control w-full">
                      {Object.entries(sets).map(([name, values]) => <option key={name} value={name}>{name} ({values.length} Werte)</option>)}
                    </select>
                  ) : (
                    <textarea
                      value={(condition.values || []).join(', ')}
                      onChange={(event) => patch(index, { values: event.target.value.split(/[\n,;]+/).map(normalizeValue).filter((value) => value !== '') })}
                      rows={2}
                      className="input-control w-full resize-y"
                      placeholder="Werte mit Komma trennen"
                    />
                  )}
                </div>
              ) : (
                <input value={String(condition.value ?? '')} onChange={(event) => patch(index, { value: normalizeValue(event.target.value) })} className="input-control mt-2 w-full" placeholder="Vergleichswert" />
              )}
              <div className="mt-2 truncate text-[11px] text-slate-400">{describeCondition(condition, sets)}</div>
            </motion.div>
          )
        })}
      </div>
    </div>
  )
}

export function RulesPage({ notify }: { notify: (kind: 'success' | 'error' | 'info', text: string) => void }) {
  const [config, setConfig] = useState<RulesConfig | null>(null)
  const [company, setCompany] = useState('')
  const [selectedIndex, setSelectedIndex] = useState(0)
  const [query, setQuery] = useState('')
  const [dirty, setDirty] = useState(false)
  const [saving, setSaving] = useState(false)
  const [jsonOpen, setJsonOpen] = useState(false)
  const [jsonText, setJsonText] = useState('')

  async function load() {
    try {
      const data = await bridge.getRules()
      setConfig(data)
      setCompany(Object.keys(data.companies)[0] || '')
      setSelectedIndex(0)
      setDirty(false)
    } catch (error) {
      notify('error', error instanceof Error ? error.message : 'Regeln konnten nicht geladen werden.')
    }
  }

  useEffect(() => { void load() }, [])

  const companyRules = config?.companies[company]?.rules || []
  const filteredIndexes = useMemo(() => companyRules.map((rule, index) => ({ rule, index })).filter(({ rule }) => `${rule.target_row} ${rule.section} ${rule.label}`.toLowerCase().includes(query.toLowerCase())), [companyRules, query])
  const selectedRule = companyRules[selectedIndex]
  const fields = config ? Object.keys(config.header_aliases) : []

  function updateRule(updater: (rule: FieldRule) => FieldRule) {
    if (!config || !selectedRule) return
    const next = clone(config)
    next.companies[company].rules[selectedIndex] = updater(clone(selectedRule))
    setConfig(next)
    setDirty(true)
  }

  function selectCompany(name: string) {
    setCompany(name)
    setSelectedIndex(0)
    setQuery('')
  }

  async function save() {
    if (!config) return
    setSaving(true)
    try {
      const result = await bridge.saveRules(config)
      setDirty(false)
      notify('success', result.backup ? `${result.message} Sicherung: ${result.backup}` : result.message)
    } catch (error) {
      notify('error', error instanceof Error ? error.message : 'Regeln konnten nicht gespeichert werden.')
    } finally {
      setSaving(false)
    }
  }

  function addRule() {
    if (!config) return
    const next = clone(config)
    const rows = next.companies[company].rules.map((rule) => Number(rule.target_row))
    const target = Math.max(0, ...rows) + 1
    next.companies[company].rules.push({ target_row: target, section: 'Neue Kategorie', label: 'Neue Kennzahl', all: [], any: [] })
    next.companies[company].rules.sort((a, b) => a.target_row - b.target_row)
    setConfig(next)
    setSelectedIndex(next.companies[company].rules.findIndex((rule) => rule.target_row === target))
    setDirty(true)
  }

  function duplicateRule() {
    if (!config || !selectedRule) return
    const next = clone(config)
    const copy = clone(selectedRule)
    copy.target_row = Math.max(...next.companies[company].rules.map((rule) => Number(rule.target_row))) + 1
    copy.label = `${copy.label} – Kopie`
    next.companies[company].rules.push(copy)
    next.companies[company].rules.sort((a, b) => a.target_row - b.target_row)
    setConfig(next)
    setSelectedIndex(next.companies[company].rules.findIndex((rule) => rule.target_row === copy.target_row))
    setDirty(true)
  }

  function deleteRule() {
    if (!config || !selectedRule) return
    const next = clone(config)
    next.companies[company].rules.splice(selectedIndex, 1)
    setConfig(next)
    setSelectedIndex(Math.max(0, selectedIndex - 1))
    setDirty(true)
  }

  function openJson() {
    if (!config) return
    setJsonText(JSON.stringify(config, null, 2))
    setJsonOpen(true)
  }

  function applyJson() {
    try {
      const parsed = JSON.parse(jsonText) as RulesConfig
      setConfig(parsed)
      setCompany(Object.keys(parsed.companies)[0] || '')
      setSelectedIndex(0)
      setDirty(true)
      setJsonOpen(false)
      notify('info', 'JSON wurde übernommen. Zum dauerhaften Speichern oben „Regeln speichern“ klicken.')
    } catch (error) {
      notify('error', error instanceof Error ? error.message : 'Ungültiges JSON.')
    }
  }

  if (!config) return <div className="grid min-h-[650px] place-items-center text-sm text-slate-400">Regeln werden geladen …</div>

  return (
    <div className="flex h-full min-h-[730px] flex-col">
      <div className="mb-4 flex items-center justify-between">
        <div><div className="flex items-center gap-2"><h1 className="text-[28px] font-extrabold tracking-[-.035em] text-ink">Feldregeln</h1>{dirty && <span className="rounded-full bg-amber-50 px-2.5 py-1 text-[11px] font-bold text-amber-700">Ungespeicherte Änderungen</span>}</div><p className="mt-1 text-sm text-slate-500">Alle Kennzahlenregeln anzeigen, ändern und dauerhaft speichern</p></div>
        <div className="flex gap-2">
          <button onClick={openJson} className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm font-bold text-slate-600 shadow-sm hover:bg-slate-50"><Braces className="h-4 w-4" /> JSON-Modus</button>
          <button onClick={save} disabled={!dirty || saving} className="flex items-center gap-2 rounded-xl bg-teal px-4 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-teal-700 disabled:cursor-not-allowed disabled:opacity-45"><Save className="h-4 w-4" /> {saving ? 'Speichert …' : 'Regeln speichern'}</button>
        </div>
      </div>

      <section className="grid min-h-0 flex-1 grid-cols-[170px_320px_minmax(0,1fr)] overflow-hidden rounded-[20px] border border-slate-200 bg-white shadow-soft">
        <aside className="overflow-auto border-r border-slate-200 bg-slate-50/70 p-3">
          <div className="px-2 py-2 text-[11px] font-extrabold uppercase tracking-[.08em] text-slate-400">Gesellschaften</div>
          <div className="mt-1 space-y-1">
            {Object.entries(config.companies).map(([name, data]) => (
              <button key={name} onClick={() => selectCompany(name)} className={clsx('flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left text-sm transition', company === name ? 'bg-white font-extrabold text-teal shadow-sm' : 'font-medium text-slate-600 hover:bg-white/70 hover:text-ink')}>
                <span>{name}</span><span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-500">{data.rules.length}</span>
              </button>
            ))}
          </div>
        </aside>

        <aside className="flex min-h-0 flex-col border-r border-slate-200">
          <div className="border-b border-slate-200 p-3">
            <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2"><Search className="h-4 w-4 text-slate-400" /><input value={query} onChange={(event) => setQuery(event.target.value)} className="w-full bg-transparent text-xs outline-none" placeholder="Kennzahl suchen …" /></div>
            <button onClick={addRule} className="mt-2 flex w-full items-center justify-center gap-1.5 rounded-xl border border-dashed border-cyan-300 bg-cyan-50/50 px-3 py-2 text-xs font-bold text-teal hover:bg-cyan-50"><Plus className="h-3.5 w-3.5" /> Neue Regel</button>
          </div>
          <div className="min-h-0 flex-1 overflow-auto p-2">
            {filteredIndexes.map(({ rule, index }) => (
              <button key={`${rule.target_row}-${index}`} onClick={() => setSelectedIndex(index)} className={clsx('mb-1.5 flex w-full items-center gap-3 rounded-xl border px-3 py-3 text-left transition', selectedIndex === index ? 'border-cyan-200 bg-cyan-50/70 shadow-sm' : 'border-transparent hover:border-slate-200 hover:bg-slate-50')}>
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white text-xs font-extrabold text-teal shadow-sm">J{rule.target_row}</span>
                <span className="min-w-0 flex-1"><strong className="block truncate text-xs text-ink">{rule.label}</strong><small className="mt-0.5 block truncate text-[10px] text-slate-400">{rule.section}</small></span>
                <ChevronRight className="h-4 w-4 text-slate-300" />
              </button>
            ))}
          </div>
        </aside>

        <main className="min-h-0 overflow-auto p-5">
          <AnimatePresence mode="wait">
            {selectedRule ? (
              <motion.div key={`${company}-${selectedIndex}`} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -8 }}>
                <div className="flex items-start justify-between gap-4">
                  <div><div className="flex items-center gap-2"><span className="rounded-lg bg-cyan-50 px-2.5 py-1 text-xs font-extrabold text-teal">{company} · J{selectedRule.target_row}</span>{selectedRule.warning && <span title={selectedRule.warning} className="text-amber-500"><CircleAlert className="h-4 w-4" /></span>}</div><h2 className="mt-2 text-xl font-extrabold tracking-[-.025em] text-ink">{selectedRule.label}</h2></div>
                  <div className="flex gap-1"><button onClick={duplicateRule} title="Regel duplizieren" className="grid h-9 w-9 place-items-center rounded-xl text-slate-400 hover:bg-slate-100 hover:text-ink"><Copy className="h-4 w-4" /></button><button onClick={deleteRule} title="Regel löschen" className="grid h-9 w-9 place-items-center rounded-xl text-slate-400 hover:bg-rose-50 hover:text-rose-600"><Trash2 className="h-4 w-4" /></button></div>
                </div>

                <div className="mt-5 grid grid-cols-[120px_1fr] gap-3">
                  <label className="field-label">Zielzeile</label><input type="number" value={selectedRule.target_row} onChange={(event) => updateRule((rule) => ({ ...rule, target_row: Number(event.target.value) }))} className="input-control" />
                  <label className="field-label">Bereich</label><input value={selectedRule.section} onChange={(event) => updateRule((rule) => ({ ...rule, section: event.target.value }))} className="input-control" />
                  <label className="field-label">Kennzahl</label><input value={selectedRule.label} onChange={(event) => updateRule((rule) => ({ ...rule, label: event.target.value }))} className="input-control" />
                  <label className="field-label">Warnhinweis</label><textarea value={selectedRule.warning || ''} onChange={(event) => updateRule((rule) => ({ ...rule, warning: event.target.value || undefined }))} rows={2} className="input-control resize-y" placeholder="Optionaler fachlicher Hinweis" />
                  <label className="field-label">Scope</label><label className="flex items-center gap-2 text-xs text-slate-600"><input type="checkbox" checked={Boolean(selectedRule.disable_company_scope)} onChange={(event) => updateRule((rule) => ({ ...rule, disable_company_scope: event.target.checked || undefined }))} className="h-4 w-4 rounded border-slate-300 text-teal" /> GlobeCode-Scope dieser Gesellschaft deaktivieren</label>
                </div>

                <div className="mt-5 space-y-4">
                  <ConditionEditor title="UND-Bedingungen" conditions={selectedRule.all || []} fields={fields} sets={config.sets} onChange={(conditions) => updateRule((rule) => ({ ...rule, all: conditions }))} />
                  <ConditionEditor title="ODER-Gruppe" conditions={selectedRule.any || []} fields={fields} sets={config.sets} onChange={(conditions) => updateRule((rule) => ({ ...rule, any: conditions }))} />
                </div>

                <div className="mt-5 rounded-2xl border border-cyan-100 bg-cyan-50/55 p-4">
                  <strong className="text-xs text-ink">Lesbare Regel</strong>
                  <div className="mt-2 text-xs leading-6 text-slate-600">
                    {config.companies[company].default_scope !== false && !selectedRule.disable_company_scope && <span className="rule-chip">GlobeCode = {config.companies[company].code}</span>}
                    {(selectedRule.all || []).map((condition, index) => <span key={`all-${index}`} className="rule-chip">{describeCondition(condition, config.sets)}</span>)}
                    {(selectedRule.any || []).length > 0 && <span className="rule-chip rule-chip-or">ODER: {(selectedRule.any || []).map((condition) => describeCondition(condition, config.sets)).join(' · ')}</span>}
                  </div>
                </div>
              </motion.div>
            ) : <div className="grid h-full place-items-center text-sm text-slate-400">Keine Regel ausgewählt.</div>}
          </AnimatePresence>
        </main>
      </section>

      <Modal open={jsonOpen} title="Regelkonfiguration als JSON" onClose={() => setJsonOpen(false)} width="max-w-5xl">
        <textarea value={jsonText} onChange={(event) => setJsonText(event.target.value)} className="h-[62vh] w-full resize-none rounded-2xl border border-slate-200 bg-slate-950 p-4 font-mono text-xs leading-5 text-cyan-100 outline-none focus:border-teal" spellCheck={false} />
        <div className="mt-4 flex items-center justify-between"><p className="text-xs text-slate-400">Der JSON-Modus ist für große Listen und fortgeschrittene Änderungen gedacht.</p><button onClick={applyJson} className="flex items-center gap-2 rounded-xl bg-teal px-4 py-2.5 text-sm font-bold text-white"><Check className="h-4 w-4" /> JSON übernehmen</button></div>
      </Modal>
    </div>
  )
}
