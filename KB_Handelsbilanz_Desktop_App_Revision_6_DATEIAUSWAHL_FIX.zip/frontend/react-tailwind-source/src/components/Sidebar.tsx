import { motion } from 'framer-motion'
import { BarChart3, Clock3, FileSpreadsheet, Settings, SlidersHorizontal } from 'lucide-react'
import clsx from 'clsx'

export type AppPage = 'review' | 'results' | 'rules' | 'history' | 'settings'

const items: Array<{ id: AppPage; label: string; icon: typeof BarChart3 }> = [
  { id: 'review', label: 'Review', icon: BarChart3 },
  { id: 'results', label: 'Ergebnisse', icon: FileSpreadsheet },
  { id: 'rules', label: 'Regeln', icon: SlidersHorizontal },
  { id: 'history', label: 'Historie', icon: Clock3 },
  { id: 'settings', label: 'Einstellungen', icon: Settings },
]

interface Props {
  active: AppPage
  onChange: (page: AppPage) => void
}

export function Sidebar({ active, onChange }: Props) {
  return (
    <aside className="flex h-full w-[250px] shrink-0 flex-col border-r border-slate-200/80 bg-white/75 px-5 pb-5 pt-6 backdrop-blur-2xl">
      <div className="flex items-center gap-3 px-2">
        <div className="grid h-11 w-11 place-items-center rounded-[14px] bg-gradient-to-br from-teal-500 to-cyan-700 text-base font-extrabold text-white shadow-[0_10px_24px_rgba(13,139,149,.28)]">KB</div>
        <div>
          <div className="font-extrabold tracking-[-.02em] text-ink">KB Handelsbilanz</div>
          <div className="mt-0.5 text-xs text-slate-400">Review Automation</div>
        </div>
      </div>

      <nav className="mt-9 space-y-2">
        {items.map((item) => {
          const Icon = item.icon
          const selected = active === item.id
          return (
            <button
              key={item.id}
              onClick={() => onChange(item.id)}
              className={clsx(
                'group relative flex w-full items-center gap-3 rounded-2xl px-4 py-3.5 text-left text-[15px] font-medium transition-all duration-200',
                selected ? 'text-teal' : 'text-slate-600 hover:translate-x-0.5 hover:bg-slate-50 hover:text-ink',
              )}
            >
              {selected && (
                <motion.span
                  layoutId="sidebar-active"
                  className="absolute inset-0 rounded-2xl border border-cyan-100 bg-gradient-to-r from-cyan-50 to-sky-50 shadow-sm"
                  transition={{ type: 'spring', stiffness: 420, damping: 35 }}
                />
              )}
              <Icon className="relative z-10 h-[21px] w-[21px]" strokeWidth={1.8} />
              <span className={clsx('relative z-10', selected && 'font-bold')}>{item.label}</span>
            </button>
          )
        })}
      </nav>

      <div className="mt-auto border-t border-slate-200/80 px-2 pt-5">
        <div className="flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-teal-400 to-cyan-700 text-xs font-bold text-white">KB</div>
          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-bold text-ink">KB Unternehmensgruppe</div>
            <div className="truncate text-xs text-slate-400">Handelsbilanz Automation</div>
          </div>
        </div>
      </div>
    </aside>
  )
}
