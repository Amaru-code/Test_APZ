import { useMemo } from 'react'
import type { WorkbookSheet } from '../types'

function columnName(index: number) {
  let result = ''
  let value = index + 1
  while (value > 0) {
    value -= 1
    result = String.fromCharCode(65 + (value % 26)) + result
    value = Math.floor(value / 26)
  }
  return result
}

function displayValue(value: string | number | null) {
  if (value === null || value === undefined) return ''
  if (typeof value === 'number') return new Intl.NumberFormat('de-DE', { maximumFractionDigits: 2 }).format(value)
  return String(value)
}

export function SpreadsheetView({ sheet }: { sheet: WorkbookSheet }) {
  const maxCols = useMemo(() => Math.max(sheet.max_col, ...sheet.rows.map((row) => row.length)), [sheet])
  return (
    <div className="h-full overflow-auto rounded-b-[18px] bg-white">
      <table className="min-w-full border-separate border-spacing-0 text-[12px] text-slate-700">
        <thead className="sticky top-0 z-20">
          <tr>
            <th className="sticky left-0 z-30 h-8 w-12 min-w-12 border-b border-r border-slate-200 bg-slate-100" />
            {Array.from({ length: maxCols }).map((_, index) => (
              <th
                key={index}
                style={{ minWidth: `${Math.min(420, Math.max(90, (sheet.widths[index] || 14) * 7.2))}px` }}
                className="h-8 border-b border-r border-slate-200 bg-slate-100 px-2 text-center font-semibold text-slate-500"
              >
                {columnName(index)}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {sheet.rows.map((row, rowIndex) => (
            <tr key={rowIndex}>
              <th className="sticky left-0 z-10 h-8 border-b border-r border-slate-200 bg-slate-100 px-2 text-center font-semibold text-slate-400">{rowIndex + 1}</th>
              {Array.from({ length: maxCols }).map((_, colIndex) => {
                const value = row[colIndex] ?? null
                const isHeader = rowIndex === 0 || (rowIndex === 7 && sheet.name !== 'Start')
                const isFormula = typeof value === 'string' && value.startsWith('=')
                return (
                  <td
                    key={colIndex}
                    title={displayValue(value)}
                    className={`h-8 max-w-[420px] border-b border-r border-slate-100 px-2.5 align-middle ${isHeader ? 'bg-slate-50 font-bold text-ink' : 'bg-white'} ${isFormula ? 'font-mono text-blue-600' : ''}`}
                  >
                    <div className="max-h-14 overflow-hidden whitespace-pre-wrap break-words">{displayValue(value)}</div>
                  </td>
                )
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
