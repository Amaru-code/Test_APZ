import { ChartNoAxesCombined } from 'lucide-react'

export function Hero() {
  return (
    <section className="relative flex min-h-[160px] items-center overflow-hidden rounded-[22px] border border-slate-200/80 bg-gradient-to-r from-white via-white to-sky-50 px-8 shadow-soft">
      <div className="absolute -right-2 -top-16 h-64 w-64 rotate-12 rounded-[64px] bg-gradient-to-br from-cyan-300/30 to-blue-400/20 blur-[1px]" />
      <div className="absolute right-28 top-6 h-36 w-36 rotate-[24deg] rounded-[36px] border border-white/90 bg-white/50 shadow-xl backdrop-blur-xl" />
      <div className="absolute right-16 top-11 h-28 w-28 rotate-[24deg] rounded-[30px] bg-gradient-to-br from-teal-300/50 to-blue-400/35 shadow-xl backdrop-blur-xl" />
      <div className="relative z-10 mr-7 grid h-[88px] w-[88px] place-items-center rounded-3xl border border-slate-100 bg-white text-teal shadow-soft">
        <ChartNoAxesCombined className="h-11 w-11" strokeWidth={1.8} />
      </div>
      <div className="relative z-10">
        <h1 className="text-[32px] font-extrabold tracking-[-.04em] text-ink">Neue Handelsbilanz-Auswertung</h1>
        <p className="mt-2 text-[16px] text-muted">Erstelle eine neue Auswertung für HGB, STB oder 7 Jahre</p>
      </div>
    </section>
  )
}
