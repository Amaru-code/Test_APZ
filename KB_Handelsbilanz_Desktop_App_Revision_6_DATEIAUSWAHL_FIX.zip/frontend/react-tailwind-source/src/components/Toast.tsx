import { AnimatePresence, motion } from 'framer-motion'
import { CheckCircle2, CircleAlert, Info } from 'lucide-react'

export interface ToastMessage {
  id: number
  kind: 'success' | 'error' | 'info'
  text: string
}

export function Toasts({ messages }: { messages: ToastMessage[] }) {
  return (
    <div className="pointer-events-none fixed bottom-6 right-7 z-[100] flex w-[390px] flex-col gap-3">
      <AnimatePresence>
        {messages.map((message) => {
          const Icon = message.kind === 'success' ? CheckCircle2 : message.kind === 'error' ? CircleAlert : Info
          return (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 18, scale: .96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: .97 }}
              className="flex items-start gap-3 rounded-2xl border border-white/80 bg-ink px-4 py-3.5 text-sm text-white shadow-app"
            >
              <Icon className="mt-0.5 h-5 w-5 shrink-0 text-cyan-300" />
              <span className="leading-5">{message.text}</span>
            </motion.div>
          )
        })}
      </AnimatePresence>
    </div>
  )
}
