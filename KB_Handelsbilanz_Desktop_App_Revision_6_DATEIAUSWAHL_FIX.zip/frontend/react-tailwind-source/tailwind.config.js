/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#132238',
        muted: '#6c7a90',
        teal: '#0d8b95',
        teal2: '#20a7ad',
        panel: '#f7fafc',
      },
      boxShadow: {
        soft: '0 12px 34px rgba(31, 52, 78, .10)',
        app: '0 26px 80px rgba(31, 52, 78, .18)',
      },
      borderRadius: {
        app: '26px',
      },
    },
  },
  plugins: [],
}
