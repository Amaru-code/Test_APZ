fn main() {
    kb_handelsbilanz_lib::run();
}
