from __future__ import annotations

import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BATCH_FILES = [
    ROOT / "INSTALLIEREN_UND_STARTEN.bat",
    ROOT / "STARTEN.bat",
    ROOT / "APP_STARTEN.bat",
    ROOT / "BROWSER_VORSCHAU_STARTEN.bat",
    ROOT / "TAURI_ENTWICKLUNG_STARTEN.bat",
    ROOT / "TESTS_AUSFUEHREN.bat",
    ROOT / "DIAGNOSE.bat",
    ROOT / "scripts" / "BEISPIELDATEI_ERZEUGEN.bat",
]


class WindowsLauncherTests(unittest.TestCase):
    def test_batch_files_use_windows_crlf_only(self) -> None:
        for path in BATCH_FILES:
            with self.subTest(path=path.name):
                data = path.read_bytes()
                self.assertIn(b"\r\n", data)
                self.assertNotIn(b"\xef\xbb\xbf", data)
                self.assertNotIn(b"\n", data.replace(b"\r\n", b""))

    def test_batch_files_are_ascii(self) -> None:
        for path in BATCH_FILES:
            with self.subTest(path=path.name):
                path.read_bytes().decode("ascii")

    def test_install_launcher_contains_complete_echo_commands(self) -> None:
        text = (ROOT / "INSTALLIEREN_UND_STARTEN.bat").read_text(
            encoding="ascii"
        )
        self.assertIn("echo ============================================================", text)
        self.assertNotIn("\ncho ", text.replace("\r\n", "\n"))
        self.assertIn('"%VENV_PYTHON%" "%CD%\\src\\desktop_app.py"', text)


if __name__ == "__main__":
    unittest.main()
