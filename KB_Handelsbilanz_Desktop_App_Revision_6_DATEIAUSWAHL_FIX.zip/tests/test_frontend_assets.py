from __future__ import annotations

import json
import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "frontend" / "dist"


class FrontendAssetTests(unittest.TestCase):
    def test_required_pages_and_assets_exist(self) -> None:
        required = [
            DIST / "index.html",
            DIST / "app.css",
            DIST / "app.js",
            DIST / "assets" / "logo.svg",
            DIST / "assets" / "hero-visual.svg",
            ROOT / "frontend" / "src-tauri" / "tauri.conf.json",
            ROOT / "frontend" / "react-tailwind-source" / "package.json",
        ]
        for path in required:
            with self.subTest(path=path):
                self.assertTrue(path.exists(), path)
                self.assertGreater(path.stat().st_size, 20, path)

    def test_navigation_contains_requested_sections(self) -> None:
        html = (DIST / "index.html").read_text(encoding="utf-8")
        for page in ("Review", "Ergebnisse", "Regeln", "Historie", "Einstellungen"):
            self.assertIn(f">{page}<", html)
        self.assertIn('id="page-review"', html)
        self.assertIn('id="page-results"', html)
        self.assertIn('id="page-rules"', html)

    def test_all_static_icon_references_resolve(self) -> None:
        references: set[str] = set()
        for path in (DIST / "index.html", DIST / "app.css", DIST / "app.js"):
            references.update(
                re.findall(r"assets/icons/[^\"')${}]+\.svg", path.read_text(encoding="utf-8"))
            )
        for reference in references:
            with self.subTest(reference=reference):
                self.assertTrue((DIST / reference).exists(), reference)

        javascript = (DIST / "app.js").read_text(encoding="utf-8")
        dynamic_names = set(re.findall(r"icon\(['\"]([^'\"]+)['\"]\)", javascript))
        for name in dynamic_names:
            with self.subTest(dynamic_icon=name):
                self.assertTrue((DIST / "assets" / "icons" / f"{name}.svg").exists(), name)


    def test_desktop_bridge_waits_for_specific_methods_and_disables_demo_paths(self) -> None:
        javascript = (DIST / "app.js").read_text(encoding="utf-8")
        desktop_app = (ROOT / "src" / "desktop_app.py").read_text(encoding="utf-8")
        desktop_bridge = (ROOT / "src" / "desktop_bridge.py").read_text(encoding="utf-8")
        self.assertIn("waitForApiMethod(method", javascript)
        self.assertIn("!path && !desktopRequested", javascript)
        self.assertIn("FrontendServer", desktop_app)
        self.assertNotIn("frontend.as_uri()", desktop_app)
        self.assertIn("webview.FileDialog", desktop_bridge)
        self.assertNotIn("webview.OPEN_DIALOG", desktop_bridge)
        self.assertNotIn("self.window", desktop_bridge)

    def test_frontend_is_local_and_tauri_config_is_valid(self) -> None:
        html = (DIST / "index.html").read_text(encoding="utf-8")
        self.assertNotRegex(html, r"https?://")
        config = json.loads((ROOT / "frontend" / "src-tauri" / "tauri.conf.json").read_text(encoding="utf-8"))
        self.assertEqual(config["productName"], "KB Handelsbilanz")
        self.assertEqual(config["build"]["frontendDist"], "../dist")


if __name__ == "__main__":
    unittest.main()
