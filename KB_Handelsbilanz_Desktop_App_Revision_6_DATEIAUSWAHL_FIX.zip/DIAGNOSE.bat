@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title KB Handelsbilanz Desktop App - Revision 6 Diagnose

set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"

echo ============================================================
echo  KB Handelsbilanz Desktop App - Revision 6 Diagnose
echo ============================================================
echo Projektordner: %CD%
echo.

echo [1] Windows und CMD
ver
echo ComSpec: %ComSpec%
echo.

echo [2] Python Launcher
where py.exe 2>nul
py -3 --version 2>nul
echo.

echo [3] Python im PATH
where python.exe 2>nul
python --version 2>nul
echo.

echo [4] Virtuelle Umgebung und Python-Pakete
if exist ".venv\Scripts\python.exe" (
    echo Vorhanden: %CD%\.venv\Scripts\python.exe
    ".venv\Scripts\python.exe" --version
    ".venv\Scripts\python.exe" -c "import sys; print('Executable:', sys.executable); import openpyxl; print('openpyxl:', openpyxl.__version__); import webview; import importlib.metadata as md; print('pywebview:', md.version('pywebview')); print('FileDialog:', [x for x in dir(webview.FileDialog) if x.isupper()])"
) else (
    echo NICHT VORHANDEN
)
echo.

echo [5] Desktop-Frontend
for %%F in ("frontend\dist\index.html" "frontend\dist\app.css" "frontend\dist\app.js" "frontend\dist\assets\logo.svg") do (
    if exist %%F (echo OK: %%~F) else (echo FEHLT: %%~F)
)
echo.

echo [6] Zentrale Projektdateien
for %%F in ("requirements.txt" "config\rules.json" "config\app_settings.json" "src\desktop_app.py" "src\desktop_bridge.py" "src\main.py") do (
    if exist %%F (echo OK: %%~F) else (echo FEHLT: %%~F)
)
echo.

echo [7] Windows WebView2
reg query "HKLM\SOFTWARE\Microsoft\EdgeUpdate\Clients" /s /f "WebView2 Runtime" >nul 2>&1
if not errorlevel 1 (
    echo WebView2 Runtime wurde in der Registry gefunden.
) else (
    echo WebView2 konnte nicht eindeutig ueber die Registry erkannt werden.
    echo Auf aktuellen Windows-10- und Windows-11-Systemen ist es normalerweise bereits installiert.
)
echo.

echo Diagnose abgeschlossen.
pause
