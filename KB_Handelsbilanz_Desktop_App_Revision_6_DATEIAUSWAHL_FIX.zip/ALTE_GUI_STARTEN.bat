@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    call "%~dp0INSTALLIEREN_UND_STARTEN.bat"
    exit /b %ERRORLEVEL%
)
"%~dp0.venv\Scripts\python.exe" "%~dp0src\main.py"
if errorlevel 1 pause
