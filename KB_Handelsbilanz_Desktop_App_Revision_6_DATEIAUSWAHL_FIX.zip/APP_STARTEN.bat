@echo off
call "%~dp0STARTEN.bat"
