from __future__ import annotations

from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import logging
from pathlib import Path
import threading
from typing import Final


LOGGER = logging.getLogger(__name__)
_HOST: Final[str] = "127.0.0.1"


class _FrontendRequestHandler(SimpleHTTPRequestHandler):
    """Serve only local frontend files with conservative cache settings."""

    def end_headers(self) -> None:
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.send_header("X-Content-Type-Options", "nosniff")
        super().end_headers()

    def log_message(self, format: str, *args: object) -> None:
        LOGGER.debug("Frontend HTTP: " + format, *args)


class FrontendServer:
    """Small loopback-only HTTP server for the bundled desktop frontend.

    WebView2 can behave inconsistently when a query string is appended to a
    ``file:///`` URL. Serving the static bundle over localhost keeps relative
    CSS, JavaScript, SVG and JSON paths stable regardless of the project path.
    """

    def __init__(self, frontend_dir: Path, revision: int = 8) -> None:
        self._frontend_dir = frontend_dir.resolve()
        self._revision = int(revision)
        self._server: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None

    @property
    def frontend_dir(self) -> Path:
        return self._frontend_dir

    @property
    def is_running(self) -> bool:
        return self._server is not None and self._thread is not None and self._thread.is_alive()

    @property
    def url(self) -> str:
        if self._server is None:
            raise RuntimeError("Der Frontend-Server wurde noch nicht gestartet.")
        port = int(self._server.server_address[1])
        return f"http://{_HOST}:{port}/index.html?desktop=1&revision={self._revision}"

    def start(self) -> str:
        if self.is_running:
            return self.url

        index_file = self._frontend_dir / "index.html"
        if not index_file.is_file():
            raise FileNotFoundError(f"Frontend wurde nicht gefunden: {index_file}")

        handler = partial(_FrontendRequestHandler, directory=str(self._frontend_dir))
        self._server = ThreadingHTTPServer((_HOST, 0), handler)
        self._server.daemon_threads = True
        self._thread = threading.Thread(
            target=self._server.serve_forever,
            name="kb-frontend-http",
            daemon=True,
        )
        self._thread.start()
        LOGGER.info("Frontend wird lokal bereitgestellt: %s", self.url)
        return self.url

    def stop(self) -> None:
        server = self._server
        thread = self._thread
        self._server = None
        self._thread = None
        if server is not None:
            server.shutdown()
            server.server_close()
        if thread is not None and thread.is_alive():
            thread.join(timeout=2.0)
        LOGGER.info("Lokaler Frontend-Server wurde beendet.")

    def __enter__(self) -> "FrontendServer":
        self.start()
        return self

    def __exit__(self, exc_type, exc, traceback) -> None:  # type: ignore[no-untyped-def]
        self.stop()
