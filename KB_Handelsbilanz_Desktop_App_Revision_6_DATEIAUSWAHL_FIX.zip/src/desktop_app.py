from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
SRC_DIR = Path(__file__).resolve().parent
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from core.logging_setup import configure_logging  # noqa: E402
from desktop_bridge import DesktopBridge  # noqa: E402
from frontend_server import FrontendServer  # noqa: E402


def main() -> int:
    configure_logging(ROOT_DIR)
    try:
        import webview
    except ImportError:
        print("pywebview ist nicht installiert. Bitte INSTALLIEREN_UND_STARTEN.bat ausführen.")
        return 2

    frontend_dir = ROOT_DIR / "frontend" / "dist"
    index_file = frontend_dir / "index.html"
    if not index_file.is_file():
        print(f"Frontend wurde nicht gefunden: {index_file}")
        return 3

    bridge = DesktopBridge(ROOT_DIR)
    server = FrontendServer(frontend_dir, revision=7)

    try:
        frontend_url = server.start()
        webview.create_window(
            "KB Handelsbilanz",
            url=frontend_url,
            js_api=bridge,
            width=1500,
            height=960,
            min_size=(1120, 720),
            background_color="#eef3f8",
            confirm_close=False,
            text_select=True,
        )
        webview.start(debug=False)
        return 0
    except Exception as exc:
        print(f"Die Desktop-App konnte nicht gestartet werden: {exc}")
        return 4
    finally:
        server.stop()


if __name__ == "__main__":
    raise SystemExit(main())
