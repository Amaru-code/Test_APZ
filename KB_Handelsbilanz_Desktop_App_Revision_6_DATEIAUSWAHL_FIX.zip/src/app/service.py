from __future__ import annotations

from datetime import datetime
import logging
from pathlib import Path

from core.config_loader import load_rule_config
from core.models import AppOptions, LogCallback, RunResult
from core.rule_engine import calculate_all
from excel.output_writer import (
    write_company_markdown,
    write_manifest,
    write_workbook,
)
from excel.source_reader import read_source_file


def _log(callback: LogCallback | None, message: str) -> None:
    logging.getLogger("kb.service").info(message)
    if callback:
        callback(message)


def run_calculation(root_dir: Path, options: AppOptions, log: LogCallback | None = None) -> RunResult:
    config_path = root_dir / "config" / "rules.json"
    config = load_rule_config(config_path)

    unknown = sorted(set(options.companies) - set(config.company_names()))
    if unknown:
        raise ValueError("Unbekannte Gesellschaft(en): " + ", ".join(unknown))
    if not options.companies:
        raise ValueError("Es wurde keine Gesellschaft ausgewählt.")

    required_fields = config.required_fields(options.companies, options.output_type)
    _log(log, f"Lese aktuelles Jahr: {options.current_file}")
    current = read_source_file(options.current_file, config, required_fields)
    _log(
        log,
        f"Aktuell: Header in Zeile {current.header_row}, {len(current.records)} Datenzeilen erkannt.",
    )

    previous = None
    if options.previous_file:
        _log(log, f"Lese Vorjahr: {options.previous_file}")
        previous = read_source_file(options.previous_file, config, required_fields)
        _log(
            log,
            f"Vorjahr: Header in Zeile {previous.header_row}, {len(previous.records)} Datenzeilen erkannt.",
        )

    _log(log, "Berechne Kennzahlen …")
    company_results = calculate_all(
        current_dataset=current,
        previous_dataset=previous,
        companies=options.companies,
        output_type=options.output_type,
        config=config,
    )

    generated_at = datetime.now()
    timestamp = generated_at.strftime("%Y%m%d_%H%M%S")
    run_folder = options.output_dir / f"{options.output_type.replace(' ', '_')}_{timestamp}"
    run_folder.mkdir(parents=True, exist_ok=False)

    workbook_path = run_folder / f"KB_Handelsbilanz_{options.output_type.replace(' ', '_')}_{timestamp}.xlsx"
    _log(log, f"Erstelle Excel-Ausgabe: {workbook_path.name}")
    write_workbook(
        destination=workbook_path,
        output_type=options.output_type,
        current_dataset=current,
        previous_dataset=previous,
        company_results=company_results,
        config=config,
        generated_at=generated_at,
    )

    warnings: list[str] = []
    markdown_files: list[Path] = []
    for company_result in company_results:
        company_config = config.companies[company_result.company]
        for rule in company_config["rules"]:
            if rule.get("warning"):
                warnings.append(
                    f"{company_result.company} J{rule['target_row']}: {rule['warning']}"
                )
        md_path = run_folder / f"Regeln_{company_result.company}.md"
        write_company_markdown(
            destination=md_path,
            result=company_result,
            company_config=company_config,
            output_type=options.output_type,
            value_column=config.value_columns[options.output_type],
            config=config,
            current_dataset=current,
            previous_dataset=previous,
        )
        markdown_files.append(md_path)

    manifest_path = run_folder / "run_manifest.json"
    write_manifest(
        destination=manifest_path,
        output_type=options.output_type,
        current_dataset=current,
        previous_dataset=previous,
        company_results=company_results,
        workbook_path=workbook_path,
        warnings=warnings,
        generated_at=generated_at,
    )

    _log(log, f"Fertig. Ausgabeordner: {run_folder}")
    if warnings:
        _log(log, f"Hinweis: {len(warnings)} bekannte Regelwarnung(en) wurden dokumentiert.")

    return RunResult(
        output_workbook=workbook_path,
        output_folder=run_folder,
        markdown_files=markdown_files,
        manifest_file=manifest_path,
        warnings=warnings,
    )
