from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable

from openpyxl import load_workbook

from core.config_loader import RuleConfig
from core.exceptions import MissingColumnsError, SourceFileError
from core.models import SourceDataset
from core.normalization import normalize_header


EXPECTED_SHEET = "AllOnetabOrFile"


def _find_sheet_name(workbook) -> str:
    if EXPECTED_SHEET in workbook.sheetnames:
        return EXPECTED_SHEET
    lower_lookup = {name.casefold(): name for name in workbook.sheetnames}
    match = lower_lookup.get(EXPECTED_SHEET.casefold())
    if match:
        return match
    raise SourceFileError(
        f"Das Pflicht-Sheet '{EXPECTED_SHEET}' wurde nicht gefunden. "
        f"Vorhandene Sheets: {', '.join(workbook.sheetnames)}"
    )


def _alias_lookup(config: RuleConfig) -> dict[str, str]:
    lookup: dict[str, str] = {}
    for canonical, aliases in config.header_aliases.items():
        for alias in [canonical, *aliases]:
            normalized = normalize_header(alias)
            if normalized:
                lookup[normalized] = canonical
    return lookup


def _detect_header_row(
    rows: Iterable[tuple[Any, ...]],
    alias_lookup: dict[str, str],
    required_fields: set[str],
    max_scan_rows: int = 100,
) -> tuple[int, dict[str, int], list[str]]:
    best_row = 0
    best_map: dict[str, int] = {}
    best_raw: list[str] = []
    best_score = -1

    for row_number, row in enumerate(rows, start=1):
        if row_number > max_scan_rows:
            break
        canonical_map: dict[str, int] = {}
        raw_headers: list[str] = []
        for column_index, value in enumerate(row, start=1):
            if value is None:
                continue
            raw_headers.append(str(value).strip())
            canonical = alias_lookup.get(normalize_header(value))
            if canonical and canonical not in canonical_map:
                canonical_map[canonical] = column_index

        required_hits = len(required_fields.intersection(canonical_map))
        # Zusätzliche Treffer helfen bei Gleichstand. Der Required-Score dominiert klar.
        score = required_hits * 1000 + len(canonical_map)
        if score > best_score:
            best_score = score
            best_row = row_number
            best_map = canonical_map
            best_raw = raw_headers

    if best_row == 0 or not best_map:
        raise SourceFileError("Es konnte keine plausible Headerzeile gefunden werden.")
    return best_row, best_map, best_raw


def read_source_file(path: Path, config: RuleConfig, required_fields: set[str]) -> SourceDataset:
    if not path.exists():
        raise SourceFileError(f"Quelldatei existiert nicht: {path}")
    if path.suffix.lower() not in {".xlsx", ".xlsm"}:
        raise SourceFileError("Unterstützt werden derzeit nur .xlsx- und .xlsm-Dateien.")

    try:
        workbook = load_workbook(path, read_only=True, data_only=True)
    except Exception as exc:  # openpyxl liefert je nach Dateifehler verschiedene Typen
        raise SourceFileError(f"Excel-Datei konnte nicht geöffnet werden: {exc}") from exc

    try:
        sheet_name = _find_sheet_name(workbook)
        sheet = workbook[sheet_name]
        alias_lookup = _alias_lookup(config)
        header_row, header_map, raw_headers = _detect_header_row(
            sheet.iter_rows(values_only=True), alias_lookup, required_fields
        )

        missing = sorted(required_fields - set(header_map))
        if missing:
            raise MissingColumnsError(missing, raw_headers)

        records: list[dict[str, Any]] = []
        for excel_row, row in enumerate(
            sheet.iter_rows(min_row=header_row + 1, values_only=True), start=header_row + 1
        ):
            record = {
                canonical: row[column_index - 1] if column_index - 1 < len(row) else None
                for canonical, column_index in header_map.items()
            }
            # Komplett leere Zeilen werden übersprungen.
            if not any(value not in (None, "") for value in record.values()):
                continue
            record["__row_number__"] = excel_row
            records.append(record)

        return SourceDataset(
            path=path,
            sheet_name=sheet_name,
            header_row=header_row,
            headers=header_map,
            records=records,
        )
    finally:
        workbook.close()
