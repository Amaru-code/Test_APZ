from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

from openpyxl import Workbook
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from core.config_loader import RuleConfig
from core.models import CompanyResult, MetricResult, SourceDataset
from core.rule_engine import describe_rule


TITLE_FILL = PatternFill("solid", fgColor="1F4E78")
SECTION_FILL = PatternFill("solid", fgColor="D9EAF7")
HEADER_FILL = PatternFill("solid", fgColor="5B9BD5")
SUBTLE_FILL = PatternFill("solid", fgColor="E7E6E6")
WARNING_FILL = PatternFill("solid", fgColor="FFF2CC")
WHITE_FONT = Font(color="FFFFFF", bold=True)
THIN_GRAY = Side(style="thin", color="B7B7B7")
BORDER = Border(left=THIN_GRAY, right=THIN_GRAY, top=THIN_GRAY, bottom=THIN_GRAY)
MONEY_FORMAT = '#,##0.00;[Red]-#,##0.00'
COUNT_FORMAT = '0'


def _safe_sheet_name(name: str) -> str:
    for char in '[]:*?/\\':
        name = name.replace(char, "_")
    return name[:31]


def _metric_map(metrics: list[MetricResult] | None) -> dict[int, MetricResult]:
    return {metric.target_row: metric for metric in metrics or []}


def _write_start_sheet(
    workbook: Workbook,
    output_type: str,
    current_dataset: SourceDataset,
    previous_dataset: SourceDataset | None,
    companies: list[CompanyResult],
    generated_at: datetime,
) -> None:
    ws = workbook.active
    ws.title = "Start"
    ws.sheet_view.showGridLines = False
    ws.merge_cells("A1:H1")
    ws["A1"] = "KB Handelsbilanz – Berechnungsergebnis"
    ws["A1"].fill = TITLE_FILL
    ws["A1"].font = Font(color="FFFFFF", bold=True, size=16)
    ws["A1"].alignment = Alignment(horizontal="center")
    ws.row_dimensions[1].height = 28

    rows = [
        ("Erstellt am", generated_at.strftime("%d.%m.%Y %H:%M:%S")),
        ("Output-Typ", output_type),
        ("Aktuelles Jahr", str(current_dataset.path)),
        ("Headerzeile aktuell", current_dataset.header_row),
        ("Datensätze aktuell", len(current_dataset.records)),
        ("Vorjahr", str(previous_dataset.path) if previous_dataset else "Nicht ausgewählt"),
        ("Headerzeile Vorjahr", previous_dataset.header_row if previous_dataset else "-"),
        ("Datensätze Vorjahr", len(previous_dataset.records) if previous_dataset else "-"),
        ("Gesellschaften", ", ".join(result.company for result in companies)),
    ]
    for index, (label, value) in enumerate(rows, start=3):
        ws.cell(index, 1, label)
        ws.cell(index, 2, value)
        ws.cell(index, 1).font = Font(bold=True)
        ws.cell(index, 1).fill = SECTION_FILL
        ws.cell(index, 1).border = BORDER
        ws.cell(index, 2).border = BORDER

    ws["A14"] = "Hinweis"
    ws["A14"].font = Font(bold=True)
    ws["A14"].fill = WARNING_FILL
    ws["B14"] = (
        "Die Mitarbeiteranzahl zählt eindeutige IDs in der Reihenfolge ClientEEID, "
        "EmployeeIDNumber, AdditionalID. Fehlen alle IDs, wird die Excel-Zeilennummer verwendet."
    )
    ws["B14"].alignment = Alignment(wrap_text=True)
    ws.column_dimensions["A"].width = 24
    ws.column_dimensions["B"].width = 95


def _write_company_sheet(
    workbook: Workbook,
    company_result: CompanyResult,
    company_config: dict[str, Any],
    output_type: str,
    value_column: str,
    config: RuleConfig,
    has_previous: bool,
) -> None:
    ws = workbook.create_sheet(_safe_sheet_name(company_result.company))
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "A9"

    ws.merge_cells("A1:N1")
    ws["A1"] = f"{company_result.company} – {output_type}"
    ws["A1"].fill = TITLE_FILL
    ws["A1"].font = Font(color="FFFFFF", bold=True, size=16)
    ws["A1"].alignment = Alignment(horizontal="center")
    ws.row_dimensions[1].height = 28

    ws["A3"] = "Berechnungsspalte"
    ws["B3"] = value_column
    ws["A4"] = "GlobeCode / Gesellschaftscode"
    ws["B4"] = company_config["code"]
    ws["A5"] = "Vorjahr enthalten"
    ws["B5"] = "Ja" if has_previous else "Nein"
    for row in range(3, 6):
        ws.cell(row, 1).font = Font(bold=True)
        ws.cell(row, 1).fill = SECTION_FILL
        ws.cell(row, 1).border = BORDER
        ws.cell(row, 2).border = BORDER

    headings = {
        "A8": "Abschnitt",
        "B8": "Zielzelle",
        "C8": "Kennzahl",
        "D8": "Filter / Formel",
        "F8": "Rückstellung Vorjahr",
        "H8": "Anzahl Vorjahr",
        "J8": "Rückstellung aktuelles Jahr",
        "L8": "Differenz zum Vorjahr",
        "N8": "Anzahl aktuelles Jahr",
    }
    for cell, value in headings.items():
        ws[cell] = value
        ws[cell].fill = HEADER_FILL
        ws[cell].font = WHITE_FONT
        ws[cell].alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws[cell].border = BORDER
    ws.row_dimensions[8].height = 42

    current_map = _metric_map(company_result.current)
    previous_map = _metric_map(company_result.previous)
    rules_by_row = {int(rule["target_row"]): rule for rule in company_config["rules"]}
    section_by_row = {int(rule["target_row"]): rule["section"] for rule in company_config["rules"]}

    max_row = max(rules_by_row) if rules_by_row else 8
    previous_section = None
    for row in range(9, max_row + 1):
        if row not in rules_by_row:
            continue
        rule = rules_by_row[row]
        current = current_map[row]
        previous = previous_map.get(row)
        section = section_by_row[row]

        if section != previous_section:
            previous_section = section
        ws.cell(row, 1, section)
        ws.cell(row, 2, f"J{row}")
        ws.cell(row, 3, current.label)
        ws.cell(row, 4, describe_rule(company_result.company, rule, config))

        if previous is not None:
            ws.cell(row, 6, previous.value)
            ws.cell(row, 8, previous.employee_count)
            ws.cell(row, 12, f"=J{row}-F{row}")
        else:
            ws.cell(row, 6, None)
            ws.cell(row, 8, None)
            ws.cell(row, 12, None)

        ws.cell(row, 10, current.value)
        ws.cell(row, 14, current.employee_count)

        for col in [1, 2, 3, 4, 6, 8, 10, 12, 14]:
            cell = ws.cell(row, col)
            cell.border = BORDER
            cell.alignment = Alignment(vertical="top", wrap_text=(col in {1, 3, 4}))

        ws.cell(row, 6).number_format = MONEY_FORMAT
        ws.cell(row, 10).number_format = MONEY_FORMAT
        ws.cell(row, 12).number_format = MONEY_FORMAT
        ws.cell(row, 8).number_format = COUNT_FORMAT
        ws.cell(row, 14).number_format = COUNT_FORMAT

        if current.warning:
            ws.cell(row, 4).fill = WARNING_FILL
            ws.cell(row, 4).value = f"{ws.cell(row, 4).value}\nWARNUNG: {current.warning}"

    if not has_previous:
        for col in (6, 8, 12):
            for row in range(8, max_row + 1):
                ws.cell(row, col).fill = SUBTLE_FILL

    # Grüne positive und rote negative Differenzen.
    if has_previous and max_row >= 9:
        ws.conditional_formatting.add(
            f"L9:L{max_row}",
            CellIsRule(operator="greaterThan", formula=["0"], fill=PatternFill("solid", fgColor="E2F0D9")),
        )
        ws.conditional_formatting.add(
            f"L9:L{max_row}",
            CellIsRule(operator="lessThan", formula=["0"], fill=PatternFill("solid", fgColor="FCE4D6")),
        )

    widths = {
        "A": 30,
        "B": 12,
        "C": 34,
        "D": 85,
        "E": 3,
        "F": 20,
        "G": 3,
        "H": 16,
        "I": 3,
        "J": 23,
        "K": 3,
        "L": 22,
        "M": 3,
        "N": 18,
    }
    for column, width in widths.items():
        ws.column_dimensions[column].width = width

    for row in range(9, max_row + 1):
        if row in rules_by_row:
            ws.row_dimensions[row].height = 48
    ws.auto_filter.ref = f"A8:N{max_row}"
    ws.print_title_rows = "1:8"
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_area = f"A1:N{max_row}"


def write_workbook(
    destination: Path,
    output_type: str,
    current_dataset: SourceDataset,
    previous_dataset: SourceDataset | None,
    company_results: list[CompanyResult],
    config: RuleConfig,
    generated_at: datetime,
) -> None:
    workbook = Workbook()
    _write_start_sheet(
        workbook,
        output_type,
        current_dataset,
        previous_dataset,
        company_results,
        generated_at,
    )

    for result in company_results:
        _write_company_sheet(
            workbook=workbook,
            company_result=result,
            company_config=config.companies[result.company],
            output_type=output_type,
            value_column=config.value_columns[output_type],
            config=config,
            has_previous=previous_dataset is not None,
        )

    try:
        workbook.calculation.fullCalcOnLoad = True
        workbook.calculation.forceFullCalc = True
        workbook.calculation.calcMode = "auto"
    except AttributeError:
        pass

    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(".tmp.xlsx")
    workbook.save(temporary)
    temporary.replace(destination)


def write_company_markdown(
    destination: Path,
    result: CompanyResult,
    company_config: dict[str, Any],
    output_type: str,
    value_column: str,
    config: RuleConfig,
    current_dataset: SourceDataset,
    previous_dataset: SourceDataset | None,
) -> None:
    current_map = _metric_map(result.current)
    previous_map = _metric_map(result.previous)
    lines = [
        f"# {result.company} – Regeln und Berechnung",
        "",
        f"- Output-Typ: `{output_type}`",
        f"- Berechnungsspalte: `{value_column}`",
        f"- Aktuelle Quelldatei: `{current_dataset.path}`",
        f"- Erkannte Headerzeile aktuell: `{current_dataset.header_row}`",
        f"- Vorjahresdatei: `{previous_dataset.path if previous_dataset else 'nicht verwendet'}`",
        "",
    ]

    previous_section = None
    for rule in company_config["rules"]:
        row = int(rule["target_row"])
        section = rule["section"]
        if section != previous_section:
            lines.extend(["", f"## {section}", ""])
            previous_section = section
        current = current_map[row]
        previous = previous_map.get(row)
        lines.extend(
            [
                f"### J{row} – {rule['label']}",
                "",
                f"- Filter: `{describe_rule(result.company, rule, config)}`",
                f"- Aktuelles Jahr: Summe `{current.value:.2f}`, Mitarbeiter `{current.employee_count}`, passende Datenzeilen `{current.matched_rows}`",
            ]
        )
        if previous is not None:
            lines.append(
                f"- Vorjahr: Summe `{previous.value:.2f}`, Mitarbeiter `{previous.employee_count}`, passende Datenzeilen `{previous.matched_rows}`"
            )
            lines.append(f"- Differenz: `{current.value - previous.value:.2f}`")
        if rule.get("warning"):
            lines.append(f"- **Regelhinweis:** {rule['warning']}")
        lines.append("")

    destination.write_text("\n".join(lines), encoding="utf-8")


def write_manifest(
    destination: Path,
    output_type: str,
    current_dataset: SourceDataset,
    previous_dataset: SourceDataset | None,
    company_results: list[CompanyResult],
    workbook_path: Path,
    warnings: list[str],
    generated_at: datetime,
) -> None:
    payload = {
        "generated_at": generated_at.isoformat(),
        "output_type": output_type,
        "current_file": str(current_dataset.path),
        "current_header_row": current_dataset.header_row,
        "current_record_count": len(current_dataset.records),
        "previous_file": str(previous_dataset.path) if previous_dataset else None,
        "previous_header_row": previous_dataset.header_row if previous_dataset else None,
        "previous_record_count": len(previous_dataset.records) if previous_dataset else None,
        "companies": [result.company for result in company_results],
        "workbook": str(workbook_path),
        "warnings": warnings,
    }
    destination.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
