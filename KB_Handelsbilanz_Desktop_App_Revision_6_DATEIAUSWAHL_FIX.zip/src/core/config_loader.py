from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any

from core.exceptions import ConfigurationError


class RuleConfig:
    def __init__(self, raw: dict[str, Any], source_path: Path) -> None:
        self.raw = raw
        self.source_path = source_path
        self.value_columns: dict[str, str] = raw["value_columns"]
        self.header_aliases: dict[str, list[str]] = raw["header_aliases"]
        self.employee_id_priority: list[str] = raw["employee_id_priority"]
        self.sets: dict[str, list[Any]] = raw.get("sets", {})
        self.companies: dict[str, dict[str, Any]] = raw["companies"]

    def resolve_condition(self, condition: dict[str, Any]) -> dict[str, Any]:
        resolved = deepcopy(condition)
        set_ref = resolved.pop("set_ref", None)
        if set_ref:
            if set_ref not in self.sets:
                raise ConfigurationError(f"Unbekannte Set-Referenz: {set_ref}")
            resolved["values"] = self.sets[set_ref]
        return resolved

    def company_names(self) -> list[str]:
        return list(self.companies.keys())

    def required_fields(self, companies: list[str], output_type: str) -> set[str]:
        if output_type not in self.value_columns:
            raise ConfigurationError(f"Unbekannter Output-Typ: {output_type}")
        fields = {self.value_columns[output_type]}
        for company_name in companies:
            company = self.companies[company_name]
            if company.get("default_scope", True):
                fields.add("GlobeCode")
            for rule in company["rules"]:
                for condition in rule.get("all", []):
                    fields.add(condition["field"])
                for condition in rule.get("any", []):
                    fields.add(condition["field"])
        return fields


def load_rule_config(path: Path) -> RuleConfig:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ConfigurationError(f"Regeldatei wurde nicht gefunden: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ConfigurationError(f"Regeldatei ist kein gültiges JSON: {exc}") from exc

    required = {"value_columns", "header_aliases", "employee_id_priority", "companies"}
    missing = sorted(required - set(raw))
    if missing:
        raise ConfigurationError("Fehlende Hauptbereiche in rules.json: " + ", ".join(missing))
    return RuleConfig(raw, path)
