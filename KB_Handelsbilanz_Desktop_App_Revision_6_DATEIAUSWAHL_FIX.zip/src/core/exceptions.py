class KBToolError(Exception):
    """Basisfehler der Anwendung."""


class ConfigurationError(KBToolError):
    """Fehlerhafte oder unvollständige Regelkonfiguration."""


class SourceFileError(KBToolError):
    """Die Quelldatei kann nicht verarbeitet werden."""


class MissingColumnsError(SourceFileError):
    def __init__(self, missing: list[str], available: list[str]) -> None:
        self.missing = missing
        self.available = available
        super().__init__(
            "Benötigte Spalten fehlen: "
            + ", ".join(missing)
            + ". Erkannte Spalten: "
            + ", ".join(available)
        )
