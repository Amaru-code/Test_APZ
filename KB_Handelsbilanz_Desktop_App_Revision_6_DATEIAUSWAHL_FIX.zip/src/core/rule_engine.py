from __future__ import annotations

from typing import Any

from core.config_loader import RuleConfig
from core.models import CompanyResult, MetricResult, SourceDataset
from core.normalization import normalize_code, normalize_text, parse_number


CODE_FIELDS = {
    "GlobeCode",
    "USC",
    "SubsidiaryCode",
    "DivisionCode",
    "ClientEEID",
    "EmployeeIDNumber",
    "AdditionalID",
    "UnitCode",
}
TEXT_FIELDS = {"VOShortName", "Gender"}


def _normalize_for_field(field: str, value: Any) -> Any:
    if field in CODE_FIELDS:
        return normalize_code(value)
    if field in TEXT_FIELDS:
        return normalize_text(value)
    return value


def _condition_matches(record: dict[str, Any], condition: dict[str, Any]) -> bool:
    field = condition["field"]
    operator = condition["op"]
    actual = _normalize_for_field(field, record.get(field))

    if operator in {"in", "not_in"}:
        expected_values = [_normalize_for_field(field, value) for value in condition.get("values", [])]
        result = actual in expected_values
        return result if operator == "in" else not result

    expected = _normalize_for_field(field, condition.get("value"))
    if operator == "eq":
        return actual == expected
    if operator == "neq":
        return actual != expected

    # Bereichsvergleiche werden numerisch ausgeführt.
    try:
        actual_number = float(actual)
        expected_number = float(expected)
    except (TypeError, ValueError):
        return False

    if operator == "gt":
        return actual_number > expected_number
    if operator == "gte":
        return actual_number >= expected_number
    if operator == "lt":
        return actual_number < expected_number
    if operator == "lte":
        return actual_number <= expected_number
    raise ValueError(f"Unbekannter Operator: {operator}")


def _record_matches_rule(
    record: dict[str, Any],
    company: dict[str, Any],
    rule: dict[str, Any],
    config: RuleConfig,
) -> bool:
    if company.get("default_scope", True) and not rule.get("disable_company_scope", False):
        if normalize_code(record.get("GlobeCode")) != normalize_code(company["code"]):
            return False

    all_conditions = [config.resolve_condition(item) for item in rule.get("all", [])]
    if not all(_condition_matches(record, condition) for condition in all_conditions):
        return False

    any_conditions = [config.resolve_condition(item) for item in rule.get("any", [])]
    if any_conditions and not any(_condition_matches(record, condition) for condition in any_conditions):
        return False
    return True


def _employee_identity(record: dict[str, Any], priority: list[str], row_number: int) -> str:
    for field in priority:
        value = normalize_code(record.get(field))
        if value is not None:
            return f"{field}:{value}"
    return f"ROW:{row_number}"


def calculate_company(
    dataset: SourceDataset,
    company_name: str,
    output_type: str,
    config: RuleConfig,
) -> list[MetricResult]:
    company = config.companies[company_name]
    value_field = config.value_columns[output_type]
    results: list[MetricResult] = []

    for rule in company["rules"]:
        matched = [
            record
            for record in dataset.records
            if _record_matches_rule(record, company, rule, config)
        ]
        value = sum(parse_number(record.get(value_field)) for record in matched)
        identities = {
            _employee_identity(record, config.employee_id_priority, record["__row_number__"])
            for record in matched
        }
        display_ids = sorted(identity.split(":", 1)[1] for identity in identities)
        target_row = int(rule["target_row"])
        results.append(
            MetricResult(
                company=company_name,
                target_row=target_row,
                cell_reference=f"J{target_row}",
                section=rule["section"],
                label=rule["label"],
                value=value,
                employee_count=len(identities),
                matched_rows=len(matched),
                employee_ids=display_ids,
                warning=rule.get("warning"),
            )
        )
    return results


def calculate_all(
    current_dataset: SourceDataset,
    previous_dataset: SourceDataset | None,
    companies: list[str],
    output_type: str,
    config: RuleConfig,
) -> list[CompanyResult]:
    company_results: list[CompanyResult] = []
    for company in companies:
        current = calculate_company(current_dataset, company, output_type, config)
        previous = (
            calculate_company(previous_dataset, company, output_type, config)
            if previous_dataset is not None
            else None
        )
        company_results.append(CompanyResult(company=company, current=current, previous=previous))
    return company_results


def describe_condition(condition: dict[str, Any], config: RuleConfig) -> str:
    resolved = config.resolve_condition(condition)
    op_labels = {
        "eq": "=",
        "neq": "!=",
        "in": "in",
        "not_in": "nicht in",
        "gt": ">",
        "gte": ">=",
        "lt": "<",
        "lte": "<=",
    }
    op = op_labels[resolved["op"]]
    if resolved["op"] in {"in", "not_in"}:
        values = ", ".join(str(value) for value in resolved.get("values", []))
        return f"{resolved['field']} {op} {{{values}}}"
    return f"{resolved['field']} {op} {resolved.get('value')}"


def describe_rule(company_name: str, rule: dict[str, Any], config: RuleConfig) -> str:
    company = config.companies[company_name]
    parts: list[str] = []
    if company.get("default_scope", True) and not rule.get("disable_company_scope", False):
        parts.append(f"GlobeCode = {company['code']}")
    parts.extend(describe_condition(item, config) for item in rule.get("all", []))
    if rule.get("any"):
        any_text = " ODER ".join(describe_condition(item, config) for item in rule["any"])
        parts.append(f"({any_text})")
    return " UND ".join(parts) if parts else "Keine Filter"
