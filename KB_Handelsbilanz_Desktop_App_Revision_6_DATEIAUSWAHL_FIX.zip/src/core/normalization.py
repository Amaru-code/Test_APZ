from __future__ import annotations

import math
import re
from decimal import Decimal, InvalidOperation
from typing import Any


_HEADER_CLEAN_RE = re.compile(r"[^a-z0-9]+")


def normalize_header(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip().lower()
    text = (
        text.replace("ä", "ae")
        .replace("ö", "oe")
        .replace("ü", "ue")
        .replace("ß", "ss")
    )
    return _HEADER_CLEAN_RE.sub("", text)


def normalize_text(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, float) and math.isnan(value):
        return None
    text = str(value).strip()
    if not text:
        return None
    return text.upper()


def normalize_code(value: Any) -> int | str | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        if math.isnan(value):
            return None
        if value.is_integer():
            return int(value)
        return str(value).strip()

    text = str(value).strip()
    if not text:
        return None
    # Excel liefert Codes gelegentlich als "300.0" oder als Text.
    try:
        number = Decimal(text.replace(" ", "").replace(",", "."))
        if number == number.to_integral_value():
            return int(number)
    except InvalidOperation:
        pass
    return text.upper()


def parse_number(value: Any) -> float:
    if value is None:
        return 0.0
    if isinstance(value, bool):
        return float(value)
    if isinstance(value, (int, float, Decimal)):
        try:
            number = float(value)
            return 0.0 if math.isnan(number) else number
        except (TypeError, ValueError):
            return 0.0

    text = str(value).strip().replace("\u00a0", "").replace(" ", "")
    if not text or text in {"-", "–", "—"}:
        return 0.0

    negative = text.startswith("(") and text.endswith(")")
    if negative:
        text = text[1:-1]

    # Entfernt Währungssymbole und sonstige Zusätze, behält Vorzeichen/Trennzeichen.
    text = re.sub(r"[^0-9,\.\-+]", "", text)

    if "," in text and "." in text:
        # Das zuletzt vorkommende Zeichen ist mit hoher Wahrscheinlichkeit das Dezimalzeichen.
        if text.rfind(",") > text.rfind("."):
            text = text.replace(".", "").replace(",", ".")
        else:
            text = text.replace(",", "")
    elif "," in text:
        if text.count(",") == 1:
            text = text.replace(",", ".")
        else:
            parts = text.split(",")
            text = "".join(parts[:-1]) + "." + parts[-1]
    elif text.count(".") > 1:
        parts = text.split(".")
        text = "".join(parts[:-1]) + "." + parts[-1]

    try:
        result = float(text)
    except ValueError:
        return 0.0
    return -result if negative else result
