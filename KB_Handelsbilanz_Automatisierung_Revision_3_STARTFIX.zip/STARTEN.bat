@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title KB Handelsbilanz Automatisierung

set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"

if not exist ".venv\Scripts\python.exe" (
    echo Die virtuelle Umgebung fehlt.
    echo Die Installation wird jetzt gestartet.
    echo.
    call "%~dp0INSTALLIEREN_UND_STARTEN.bat"
    exit /b %ERRORLEVEL%
)

"%~dp0.venv\Scripts\python.exe" "%~dp0src\main.py"
set "EXITCODE=%ERRORLEVEL%"

if not "%EXITCODE%"=="0" (
    echo.
    echo FEHLER: Die Anwendung wurde mit Fehlercode %EXITCODE% beendet.
    echo Fuer weitere Details bitte DIAGNOSE.bat ausfuehren.
    pause
)

exit /b %EXITCODE%
