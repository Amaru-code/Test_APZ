from __future__ import annotations

import unittest
from pathlib import Path

from core.config_loader import load_rule_config


ROOT = Path(__file__).resolve().parents[1]


class ConfigTests(unittest.TestCase):
    def setUp(self) -> None:
        self.config = load_rule_config(ROOT / "config" / "rules.json")

    def _rule(self, company: str, target_row: int) -> dict:
        return next(
            rule
            for rule in self.config.companies[company]["rules"]
            if int(rule["target_row"]) == target_row
        )

    def test_target_rows_are_unique_per_company(self) -> None:
        for company, data in self.config.companies.items():
            rows = [int(rule["target_row"]) for rule in data["rules"]]
            self.assertEqual(len(rows), len(set(rows)), company)

    def test_all_referenced_sets_exist(self) -> None:
        for company in self.config.companies.values():
            for rule in company["rules"]:
                for condition in [*rule.get("all", []), *rule.get("any", [])]:
                    if "set_ref" in condition:
                        self.assertIn(condition["set_ref"], self.config.sets)

    def test_revised_rule_inventory(self) -> None:
        self.assertEqual(
            {name: len(company["rules"]) for name, company in self.config.companies.items()},
            {
                "AG": 49,
                "GRH": 21,
                "HW": 18,
                "IT": 19,
                "KBM": 19,
                "SFN": 31,
                "SFS": 22,
                "Steering": 3,
            },
        )
        self.assertEqual(sum(len(c["rules"]) for c in self.config.companies.values()), 182)
        for company in ("HW", "IT", "KBM"):
            self.assertNotIn(49, {int(r["target_row"]) for r in self.config.companies[company]["rules"]})

    def test_revised_manager_and_ag_rules(self) -> None:
        ag45 = self._rule("AG", 45)
        self.assertIn(
            {"field": "SubsidiaryCode", "op": "eq", "value": 301},
            ag45["all"],
        )
        self.assertFalse(any(c["field"] == "DivisionCode" for c in ag45["all"]))

        ag103 = self._rule("AG", 103)
        self.assertIn({"field": "USC", "op": "eq", "value": 50}, ag103["all"])

        sfs45 = self._rule("SFS", 45)
        self.assertIn(
            {"field": "SubsidiaryCode", "op": "eq", "value": 201},
            sfs45["all"],
        )

    def test_grh_foreign_and_mrp_rules(self) -> None:
        grh49 = self._rule("GRH", 49)
        self.assertEqual(grh49["all"], [{"field": "VOShortName", "op": "eq", "value": "VO"}])
        self.assertEqual(
            grh49["any"],
            [
                {"field": "DivisionCode", "op": "eq", "value": 270},
                {"field": "ClientEEID", "op": "in", "set_ref": "GRH_FOREIGN"},
            ],
        )
        grh56 = self._rule("GRH", 56)
        self.assertIn(
            {"field": "ClientEEID", "op": "in", "set_ref": "GRH_MRP_CLIENTS"},
            grh56["all"],
        )

    def test_sfn_alderbach_sets_are_complete(self) -> None:
        expected_lengths = {
            "SFN_VO_ANWAERTER_ALDERSBACH": 326,
            "SFN_VO_AUSGESCHIEDENE_ALDERSBACH": 169,
            "SFN_VO_RENTNER_ALDERSBACH": 92,
            "SFN_VO_WITWEN_ALDERSBACH": 6,
        }
        for name, expected_length in expected_lengths.items():
            values = self.config.sets[name]
            self.assertEqual(len(values), expected_length, name)
            self.assertEqual(len(values), len(set(values)), name)


if __name__ == "__main__":
    unittest.main()
