from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from openpyxl import Workbook

from app.service import run_calculation
from core.config_loader import load_rule_config
from core.models import AppOptions, SourceDataset
from core.rule_engine import calculate_company
from excel.source_reader import read_source_file


ROOT = Path(__file__).resolve().parents[1]


class RuleEngineTests(unittest.TestCase):
    def setUp(self) -> None:
        self.config = load_rule_config(ROOT / "config" / "rules.json")

    def _create_source(self, destination: Path) -> None:
        wb = Workbook()
        ws = wb.active
        ws.title = "AllOnetabOrFile"
        for row in range(1, 7):
            ws.cell(row, 1, f"Vorlauf {row}")
        headers = [
            "GlobalCode", "VOShortName", "USC", "Geschlecht", "SubsidaryCode",
            "Division Code", "ClientEEID", "Employee ID Number", "Additional ID",
            "Unit Code", "Trade.Trade AL", "TradeAltInt.Trade AL", "Tax.Tax AL",
        ]
        for col, header in enumerate(headers, start=1):
            ws.cell(7, col, header)
        rows = [
            [300, "VO", 10, "M", 300, 300, 10001, 50001, 0, 300, 1000, 900, 800],
            [300, "VO", 10, "M", 300, 300, 10001, 50001, 0, 300, 500, 450, 400],
            [300, "VO", 10, "F", 300, 300, 10002, 50002, 0, 300, 2000, 1800, 1600],
            [400, "VO", 50, "M", 400, 230, 10003, 50003, 1, 400, 4000, 3600, 3200],
        ]
        for row_index, values in enumerate(rows, start=8):
            for col_index, value in enumerate(values, start=1):
                ws.cell(row_index, col_index, value)
        wb.save(destination)

    def test_header_detection_and_unique_employee_count(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / "source.xlsx"
            self._create_source(source)
            required = self.config.required_fields(["AG"], "HGB")
            dataset = read_source_file(source, self.config, required)
            self.assertEqual(dataset.header_row, 7)
            results = calculate_company(dataset, "AG", "HGB", self.config)
            j12 = next(item for item in results if item.target_row == 12)
            self.assertEqual(j12.value, 1500.0)
            self.assertEqual(j12.employee_count, 1)
            self.assertEqual(j12.matched_rows, 2)

    def _dataset_from_records(self, records: list[dict]) -> SourceDataset:
        normalized = []
        for row_number, record in enumerate(records, start=8):
            item = {
                "Trade.Trade AL": 100.0,
                "TradeAltInt.Trade AL": 90.0,
                "Tax.Tax AL": 80.0,
                "__row_number__": row_number,
                **record,
            }
            normalized.append(item)
        return SourceDataset(
            path=Path("synthetic.xlsx"),
            sheet_name="AllOnetabOrFile",
            header_row=7,
            headers={},
            records=normalized,
        )

    def test_revised_ag_manager_uses_subsidiary_code(self) -> None:
        dataset = self._dataset_from_records([
            {
                "GlobeCode": 300, "VOShortName": "EZ", "Gender": "M",
                "SubsidiaryCode": 301, "DivisionCode": 999, "ClientEEID": 1,
            }
        ])
        results = calculate_company(dataset, "AG", "HGB", self.config)
        j45 = next(item for item in results if item.target_row == 45)
        self.assertEqual(j45.value, 100.0)
        self.assertEqual(j45.employee_count, 1)

    def test_grh_mrp_is_separated_by_client_list(self) -> None:
        dataset = self._dataset_from_records([
            {
                "GlobeCode": 400, "VOShortName": "VO", "USC": 20, "Gender": "M",
                "DivisionCode": 230, "ClientEEID": 6543,
            }
        ])
        results = calculate_company(dataset, "GRH", "HGB", self.config)
        j15 = next(item for item in results if item.target_row == 15)
        j56 = next(item for item in results if item.target_row == 56)
        self.assertEqual(j15.value, 0.0)
        self.assertEqual(j56.value, 100.0)

    def test_sfn_alderbach_or_rule_is_applied(self) -> None:
        dataset = self._dataset_from_records([
            {
                "GlobeCode": 100, "VOShortName": "VO", "USC": 10, "Gender": "M",
                "SubsidiaryCode": 100, "DivisionCode": 150, "ClientEEID": 8050,
            }
        ])
        results = calculate_company(dataset, "SFN", "HGB", self.config)
        j12 = next(item for item in results if item.target_row == 12)
        j29 = next(item for item in results if item.target_row == 29)
        self.assertEqual(j12.value, 0.0)
        self.assertEqual(j29.value, 100.0)

    def test_end_to_end_output(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            source = temp_path / "source.xlsx"
            self._create_source(source)
            result = run_calculation(
                ROOT,
                AppOptions(
                    current_file=source,
                    previous_file=source,
                    output_type="STB",
                    companies=["AG", "GRH"],
                    output_dir=temp_path / "out",
                ),
            )
            self.assertTrue(result.output_workbook.exists())
            self.assertEqual(len(result.markdown_files), 2)
            self.assertTrue(result.manifest_file.exists())


if __name__ == "__main__":
    unittest.main()
