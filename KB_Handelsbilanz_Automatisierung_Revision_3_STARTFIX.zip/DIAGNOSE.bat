@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title KB Handelsbilanz Automatisierung - Diagnose

set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"

echo ============================================================
echo  KB Handelsbilanz Automatisierung - Diagnose
echo ============================================================
echo Projektordner: %CD%
echo.

echo [1] Windows und CMD
ver
echo ComSpec: %ComSpec%
echo.

echo [2] Python Launcher
where py.exe 2>nul
py -3 --version 2>nul
echo.

echo [3] Python im PATH
where python.exe 2>nul
python --version 2>nul
echo.

echo [4] Virtuelle Umgebung
if exist ".venv\Scripts\python.exe" (
    echo Vorhanden: %CD%\.venv\Scripts\python.exe
    ".venv\Scripts\python.exe" --version
    ".venv\Scripts\python.exe" -c "import sys; print('Executable:', sys.executable); import tkinter; print('Tkinter: OK'); import openpyxl; print('openpyxl:', openpyxl.__version__)"
) else (
    echo NICHT VORHANDEN
)
echo.

echo [5] Zentrale Projektdateien
for %%F in ("requirements.txt" "config\rules.json" "src\main.py") do (
    if exist %%F (echo OK: %%~F) else (echo FEHLT: %%~F)
)
echo.

echo Diagnose abgeschlossen.
pause
