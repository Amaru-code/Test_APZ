@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title KB Handelsbilanz Automatisierung - Installation

set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"

echo ============================================================
echo  KB Handelsbilanz Automatisierung - Installation und Start
echo ============================================================
echo.

echo [0/3] Suche eine geeignete Python-Installation ...
set "PYTHON_CMD="

where py.exe >nul 2>&1
if not errorlevel 1 (
    py -3 -c "import sys; exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=py -3"
)

if not defined PYTHON_CMD (
    where python.exe >nul 2>&1
    if not errorlevel 1 (
        python -c "import sys; exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1
        if not errorlevel 1 set "PYTHON_CMD=python"
    )
)

if not defined PYTHON_CMD (
    echo.
    echo FEHLER: Python 3.10 oder neuer wurde nicht gefunden.
    echo Bitte Python von python.org installieren und dabei
    echo "Add python.exe to PATH" aktivieren.
    echo.
    pause
    exit /b 1
)

echo Gefunden: %PYTHON_CMD%

if not exist ".venv\Scripts\python.exe" (
    echo.
    echo [1/3] Erstelle die virtuelle Python-Umgebung .venv ...
    call %PYTHON_CMD% -m venv ".venv"
    if errorlevel 1 goto :error
) else (
    echo.
    echo [1/3] Die virtuelle Umgebung ist bereits vorhanden.
)

set "VENV_PYTHON=%CD%\.venv\Scripts\python.exe"

if not exist "%VENV_PYTHON%" (
    echo FEHLER: Die virtuelle Umgebung wurde nicht korrekt erstellt.
    goto :error
)

echo.
echo [2/3] Installiere bzw. aktualisiere die Abhaengigkeiten ...
"%VENV_PYTHON%" -m pip install --disable-pip-version-check --upgrade pip
if errorlevel 1 goto :error
"%VENV_PYTHON%" -m pip install --disable-pip-version-check -r "%CD%\requirements.txt"
if errorlevel 1 goto :error

echo.
echo [3/3] Starte die Anwendung ...
"%VENV_PYTHON%" "%CD%\src\main.py"
set "EXITCODE=%ERRORLEVEL%"

if not "%EXITCODE%"=="0" (
    echo.
    echo FEHLER: Die Anwendung wurde mit Fehlercode %EXITCODE% beendet.
    echo Fuer weitere Details bitte DIAGNOSE.bat ausfuehren.
    pause
)

exit /b %EXITCODE%

:error
echo.
echo FEHLER: Installation oder Start ist fehlgeschlagen.
echo Fuer weitere Details bitte DIAGNOSE.bat ausfuehren.
pause
exit /b 1
