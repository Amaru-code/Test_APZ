# Testbericht – Revision 3

Stand: 17.07.2026

## Ergebnis

- 14 von 14 automatisierten Tests erfolgreich.
- Fachliche Konfiguration aus Revision 2 unverändert.
- End-to-End-Erstellung der Excel-Ausgabe erfolgreich.
- Alle referenzierten Regelsets vorhanden.
- Zielzeilen je Gesellschaft eindeutig.
- Windows-BAT-Dateien geprüft:
  - ausschließlich CRLF-Zeilenumbrüche,
  - kein UTF-8-BOM,
  - ASCII-kompatible Befehle und Meldungen,
  - vollständige `echo`- und Python-Startbefehle.
- ZIP-Integritätsprüfung erfolgreich.

## Behobener Startfehler

Die BAT-Dateien der vorherigen Revision enthielten Unix-LF-Zeilenumbrüche. Auf dem betroffenen Windows-System wurde dadurch der erste Buchstabe nach einem Zeilenumbruch verschluckt, beispielsweise `echo` zu `cho`. Revision 3 verwendet echte Windows-CRLF-Zeilenumbrüche.
