# Revision 3 – Windows-Startkorrektur

- Alle BAT-Dateien von Unix-LF auf echtes Windows-CRLF umgestellt.
- BAT-Dateien ohne UTF-8-BOM und ausschließlich mit ASCII-Befehlsausgaben gespeichert.
- Fehler behoben, bei dem Windows CMD den ersten Buchstaben einer Zeile verschluckte (`echo` wurde zu `cho`).
- Python-Suche robuster gestaltet und Mindestversion 3.10 geprüft.
- `STARTEN.bat` startet bei fehlender virtueller Umgebung automatisch die Installation.
- Neue `DIAGNOSE.bat` prüft Python, virtuelle Umgebung, Tkinter, openpyxl und Projektdateien.
- Fachliche Feldregeln aus Revision 2 unverändert beibehalten.

---

# Änderungsstand 17.07.2026 – Feldregeln Revision 2

## Übernommen

- 182 Kennzahlenregeln für acht Gesellschaften.
- AG-Geschäftsführer werden über `SubsidiaryCode = 301` abgegrenzt.
- AG J103/J104 verwenden entsprechend der neuen Vorgabe `USC = 50`.
- GRH enthält neue Auslands- und MRP-ClientEEID-Listen.
- HW, IT und KBM grenzen Geschäftsführer über die jeweiligen SubsidiaryCodes 701, 901 und 601 ab; die bisherigen Auslandszeilen J49 entfallen.
- IT J51 verwendet nur noch `GlobeCode = 900` und `VOShortName = DC`.
- SFN enthält die vollständigen neuen Aldersbach-ID-Listen für Anwärter, Ausgeschiedene, Rentner und Witwen.
- SFS-Geschäftsführer werden über `SubsidiaryCode = 201` abgegrenzt.

## Technisch notwendige Festlegung

Die KBM-Zusammenfassung nennt J32 sowohl für Männer als auch für Frauen. Damit beide Kennzahlen separat ausgegeben werden können, bleibt die Frauenzeile in J33. Alle weiteren fachlich ungewöhnlichen Angaben wurden exakt übernommen und in `REGEL_WARNUNGEN.md` vermerkt.
