# Bekannte Regelhinweise und technisch notwendige Interpretationen

Die überarbeiteten Feldregeln wurden in `config/rules.json` übernommen. Fachlich ungewöhnliche Angaben werden nicht stillschweigend korrigiert, sondern exakt als Filter verwendet und hier dokumentiert.

## AG

- **J30 – Angestellte Frauen:** Die überarbeitete Feldregel nennt für „Angestellte Frauen“ ausdrücklich Gender=M. Der Filter wurde unverändert übernommen.
- **J45 – Männer:** „EZ & Klinker“ wurde als VOShortName in {EZ, Klinker} interpretiert.
- **J46 – Frauen:** Die Zielangabe lautet F46; die Kennzahl wird in Zeile 46 ausgegeben. „EZ & Klinker“ wurde als VOShortName in {EZ, Klinker} interpretiert.
- **J56 – Waisen:** Bezeichnung Waisen/Witwen widerspricht dem gelieferten USC=20. Der Filter wurde unverändert übernommen; J56 und J57 sind dadurch identisch.
- **J57 – Witwen:** Bezeichnung Waisen/Witwen widerspricht dem gelieferten USC=20. Der Filter wurde unverändert übernommen; J56 und J57 sind dadurch identisch.
- **J103 – Männer ausgesch. mit unvA:** Die Bezeichnung lautet „ausgesch. mit unvA“, die überarbeitete Feldregel verwendet jedoch ausdrücklich USC=50. Der Filter wurde unverändert übernommen.
- **J104 – Frauen ausgesch. mit unvA:** Die Bezeichnung lautet „ausgesch. mit unvA“, die überarbeitete Feldregel verwendet jedoch ausdrücklich USC=50. Der Filter wurde unverändert übernommen.

## GRH

- **J31 – Angestellte Frauen:** Die überarbeitete Feldregel nennt für „Angestellte Frauen“ ausdrücklich Gender=M. Der Filter wurde unverändert übernommen.
- **J46 – Frauen:** Die Zielangabe lautet F46; die Kennzahl wird in Zeile 46 ausgegeben.

## HW

- **J31 – Angestellte Frauen:** Die überarbeitete Feldregel nennt für „Angestellte Frauen“ ausdrücklich Gender=M. Der Filter wurde unverändert übernommen.
- **J46 – Frauen:** Die Zielangabe lautet F46; die Kennzahl wird in Zeile 46 ausgegeben.

## IT

- **J31 – Angestellte Frauen:** Die überarbeitete Feldregel nennt für „Angestellte Frauen“ ausdrücklich Gender=M. Der Filter wurde unverändert übernommen.
- **J46 – Frauen:** Die Zielangabe lautet F46; die Kennzahl wird in Zeile 46 ausgegeben.

## KBM

- **J31 – Angestellte Frauen:** Die überarbeitete Feldregel nennt für „Angestellte Frauen“ ausdrücklich Gender=M. Der Filter wurde unverändert übernommen.
- **J33 – Frauen ausgesch. mit unvA:** Die überarbeitete Zusammenfassung nennt J32 für Männer und Frauen. Da zwei Kennzahlen nicht dieselbe Zielzeile belegen können, wird die Frauenzeile weiterhin als J33 geführt.
- **J46 – Frauen:** Die Zielangabe lautet F46; die Kennzahl wird in Zeile 46 ausgegeben.

## SFN

- **J39 – Rentner Waisen:** Die überarbeitete Feldregel enthält für J39 keinen DivisionCode- oder ClientEEID-Filter. J39 ist dadurch fachlich identisch mit J24 und wurde unverändert übernommen.
- **J51 – Männer:** „EZ & RATE“ wurde als VOShortName in {EZ, RATE} interpretiert.
- **J52 – Frauen:** „EZ & RATE“ wurde als VOShortName in {EZ, RATE} interpretiert.
- **J64 – Mitarbeiter Auslandsges.:** Diese Regel enthält laut Vorgabe keinen GlobeCode und wird deshalb gesellschaftsübergreifend nur über ClientEEID ausgewertet.
- **J70 – ehem. Bosch:** Diese Regel enthält laut Vorgabe keinen GlobeCode und wird gesellschaftsübergreifend ausgewertet.

## SFS

- **J31 – Angestellte Frauen:** Die überarbeitete Feldregel nennt für „Angestellte Frauen“ ausdrücklich Gender=M. Der Filter wurde unverändert übernommen.
- **J46 – Frauen:** Die Zielangabe lautet F46; die Kennzahl wird in Zeile 46 ausgegeben.
