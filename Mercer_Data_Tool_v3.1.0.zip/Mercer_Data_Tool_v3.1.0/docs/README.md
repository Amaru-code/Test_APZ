# Mercer Data Converter & Merger 3.1.0

Ein kombiniertes Windows-Tool für die vorhandene DU/DP-Konvertierungslogik und das Zusammenführen vieler Tabellen in eine einzige Excel-Masterdatei.

## Hauptfunktionen

- Mehrfachauswahl und Drag & Drop von Quelldateien
- freie Auswahl des Ausgabeordners
- Konvertierung einzelner Dateien
- Konvertierung mit zusätzlicher Masterdatei
- reiner Merge ohne Einzeldateien
- fester Mercer-Zielheader und FirmenID-Filter
- Entfernung von Metadaten-, Marker- und wiederholten Headerzeilen
- sichtbarer Fortschritt in einem nicht blockierenden Hintergrundprozess
- native Windows-Titelleiste und skalierbare SVG-Icons statt Emoji-Symbole

## Wichtige Merge-Korrekturen

Die folgenden Inhalte werden nicht mehr als Daten übernommen:

```text
>>>> DU_MERCER_20250320_20250320
<<<<<
```

Auch automatische Quelldatei-TXT-Listen und zusätzliche Herkunftsspalten werden nicht erzeugt.

## Oberfläche

Die Oberfläche basiert auf PySide6/Qt. Sie nutzt eine klare Drei-Schritte-Struktur:

1. Quelldateien auswählen
2. Zielformat und Ausgabeordner festlegen
3. Konvertieren, Konvertieren + Master oder Nur zusammenführen

## Konfiguration

Die fachlichen Header und zugelassenen FirmenIDs stehen in:

```text
app/config/settings.json
```

## SVG-Icons

Die mitgelieferten SVG-Icons stammen aus Font Awesome Free und liegen einzeln unter `assets/icons/`. Die zugehörige Lizenz befindet sich unter `assets/licenses/FONT_AWESOME_FREE_LICENSE.txt`.

## Ausgabe

Das Tool schreibt nur die fachlich angeforderten Ausgabedateien. Fehlerdetails werden im Fenster angezeigt und nicht als zusätzliche Textdatei im Ausgabeordner abgelegt.


## FirmenID-Filter

Bei der Konvertierung und beim Zusammenführen werden in der Spalte `FirmenID` ausschließlich folgende Werte übernommen:

```text
MERCER_0003
MERCER_0351
MERCER_0342
MERCER_0352
MERCER_0343
INTELJP_0003
INTELSK_0001
INTELSK_0002
INTELSK_0003
MERCER_XXX
```

Der Vergleich ist robust gegenüber führenden und nachgestellten Leerzeichen sowie unterschiedlicher Groß-/Kleinschreibung. Andere FirmenIDs werden verworfen.

## Installationskorrektur 3.0.1

PySide6 enthaelt intern sehr tief verschachtelte Dateien. Bei langen Projektpfaden konnte Windows deshalb die klassische 260-Zeichen-Grenze ueberschreiten. Die virtuelle Python-Umgebung wird nun bewusst unter `%LOCALAPPDATA%\MercerDataTool\venv` installiert. Der sichtbare Programmordner bleibt dadurch sauber und das Tool kann auch aus tiefen Projektordnern gestartet werden.

## Verarbeitung mehrerer hundert Dateien

Version 3.1.0 wurde speziell für große Stapel optimiert. Die Dateiliste wird im Hintergrund aufgebaut und die Masterdatei wird direkt auf die Festplatte gestreamt. Dadurch bleibt die Oberfläche während der Auswahl und Verarbeitung sichtbar aktiv und der Arbeitsspeicher wächst nicht mehr proportional zur vollständigen Mastertabelle doppelt an.

Für maximale Stabilität werden die Dateien bewusst nacheinander verarbeitet. Das ist bei 200 bis mehreren hundert Dateien zuverlässiger als eine parallele Verarbeitung, die viele Excel-Arbeitsmappen gleichzeitig öffnen würde.
