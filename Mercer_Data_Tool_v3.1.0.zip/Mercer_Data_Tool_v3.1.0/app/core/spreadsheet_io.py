from __future__ import annotations

import csv
import os
import time
import uuid
from pathlib import Path
from typing import Iterable, Sequence

from openpyxl import Workbook, load_workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.utils import get_column_letter

from .data_parser import ParsedTable, extract_table
from .settings import SETTINGS


HEADER_FILL = "002C77"
HEADER_FONT = "FFFFFF"
ACCENT_FILL = "EAF7FA"
BORDER_COLOR = "D9E2EC"


def _read_xlsx_rows(file_path: Path) -> tuple[list[list[object]], str]:
    workbook = None
    for attempt in range(3):
        try:
            workbook = load_workbook(file_path, read_only=True, data_only=True)
            break
        except (PermissionError, OSError):
            if attempt >= 2:
                raise
            time.sleep(0.20 * (attempt + 1))

    assert workbook is not None
    try:
        for worksheet in workbook.worksheets:
            rows = [list(row) for row in worksheet.iter_rows(values_only=True)]
            if any(any(value is not None and str(value).strip() for value in row) for row in rows):
                return rows, worksheet.title
        return [], workbook.active.title if workbook.worksheets else ""
    finally:
        workbook.close()


def _read_xls_rows(file_path: Path) -> tuple[list[list[object]], str]:
    try:
        import xlrd
    except ImportError as exc:
        raise RuntimeError(
            "Für alte .xls-Dateien fehlt das Paket 'xlrd'. Bitte INSTALL.bat erneut ausführen."
        ) from exc

    book = None
    for attempt in range(3):
        try:
            book = xlrd.open_workbook(file_path)
            break
        except (PermissionError, OSError):
            if attempt >= 2:
                raise
            time.sleep(0.20 * (attempt + 1))

    assert book is not None
    for sheet in book.sheets():
        rows = [sheet.row_values(index) for index in range(sheet.nrows)]
        if any(any(str(value).strip() for value in row) for row in rows):
            return rows, sheet.name
    return [], ""


def read_spreadsheet_table(
    file_path: Path,
    *,
    fixed_target_header: bool,
    apply_company_filter: bool = SETTINGS.apply_company_filter,
) -> ParsedTable:
    suffix = file_path.suffix.lower()
    if suffix == ".xls":
        rows, sheet_name = _read_xls_rows(file_path)
    else:
        rows, sheet_name = _read_xlsx_rows(file_path)

    parsed = extract_table(
        rows,
        fixed_target_header=fixed_target_header,
        apply_company_filter=apply_company_filter,
    )
    parsed.source_sheet = sheet_name
    return parsed


def write_xlsx_table(
    table: ParsedTable,
    output_file: Path,
    *,
    sheet_name: str,
    table_name: str = "MercerDaten",
) -> Path:
    output_file.parent.mkdir(parents=True, exist_ok=True)

    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = sheet_name[:31]
    worksheet.sheet_view.showGridLines = False
    worksheet.freeze_panes = "A2"

    header = table.header or list(SETTINGS.target_headers)
    worksheet.append(header)

    for row in table.rows:
        worksheet.append(list(row))

    thin_border = Border(
        bottom=Side(style="thin", color=BORDER_COLOR),
    )

    for cell in worksheet[1]:
        cell.fill = PatternFill("solid", fgColor=HEADER_FILL)
        cell.font = Font(name="Segoe UI", size=10, bold=True, color=HEADER_FONT)
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = thin_border
    worksheet.row_dimensions[1].height = 25

    for row in worksheet.iter_rows(min_row=2):
        for cell in row:
            cell.number_format = "@"
            cell.font = Font(name="Segoe UI", size=10)
            cell.alignment = Alignment(vertical="center")

    last_row = worksheet.max_row
    last_col = worksheet.max_column
    if last_col:
        worksheet.auto_filter.ref = f"A1:{get_column_letter(last_col)}{max(1, last_row)}"

    # Excel tables are attractive and convenient, but huge tables become slow.
    if 2 <= last_row <= 200_000 and last_col >= 1:
        reference = f"A1:{get_column_letter(last_col)}{last_row}"
        table_object = Table(displayName=table_name, ref=reference)
        table_object.tableStyleInfo = TableStyleInfo(
            name="TableStyleMedium2",
            showFirstColumn=False,
            showLastColumn=False,
            showRowStripes=True,
            showColumnStripes=False,
        )
        worksheet.add_table(table_object)

    sample_end = min(last_row, 2000)
    for col_index in range(1, last_col + 1):
        max_length = len(str(worksheet.cell(1, col_index).value or ""))
        for row_index in range(2, sample_end + 1):
            value = worksheet.cell(row_index, col_index).value
            if value is not None:
                max_length = max(max_length, len(str(value)))
        worksheet.column_dimensions[get_column_letter(col_index)].width = min(max(max_length + 2, 11), 34)

    worksheet.page_setup.orientation = "landscape"
    worksheet.page_setup.fitToWidth = 1
    worksheet.page_setup.fitToHeight = 0
    worksheet.sheet_properties.pageSetUpPr.fitToPage = True
    worksheet.print_title_rows = "1:1"

    workbook.save(output_file)
    return output_file


def write_csv_table(table: ParsedTable, output_file: Path) -> Path:
    output_file.parent.mkdir(parents=True, exist_ok=True)
    with output_file.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle, delimiter=";", quotechar='"', quoting=csv.QUOTE_MINIMAL)
        writer.writerow(table.header)
        writer.writerows(table.rows)
    return output_file


def write_txt_table(table: ParsedTable, output_file: Path) -> Path:
    # TXT means a clean semicolon-delimited data export, not a source-file report.
    return write_csv_table(table, output_file)


EXCEL_MAX_DATA_ROWS = 1_048_575


class StreamingXlsxWriter:
    """Speicherschonender Writer fuer sehr grosse Masterdateien.

    Die Zeilen werden sofort in temporaere XML-Dateien von openpyxl
    geschrieben. Dadurch werden nicht gleichzeitig eine Python-Liste aller
    Daten und ein vollstaendiger Zellbaum im RAM gehalten.
    """

    def __init__(self, output_file: Path, header: Sequence[object], *, sheet_name: str) -> None:
        self.output_file = output_file
        self.output_file.parent.mkdir(parents=True, exist_ok=True)
        self.partial_file = output_file.with_name(
            f".{output_file.stem}.{uuid.uuid4().hex[:10]}.partial.xlsx"
        )
        self.header = ["" if value is None else str(value) for value in header]
        self.row_count = 0
        self._closed = False

        self.workbook = Workbook(write_only=True)
        self.worksheet = self.workbook.create_sheet(title=sheet_name[:31])
        self.worksheet.sheet_view.showGridLines = False
        self.worksheet.freeze_panes = "A2"

        thin_border = Border(bottom=Side(style="thin", color=BORDER_COLOR))
        header_cells: list[WriteOnlyCell] = []
        for value in self.header:
            cell = WriteOnlyCell(self.worksheet, value=value)
            cell.fill = PatternFill("solid", fgColor=HEADER_FILL)
            cell.font = Font(name="Segoe UI", size=10, bold=True, color=HEADER_FONT)
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.border = thin_border
            header_cells.append(cell)
        self.worksheet.append(header_cells)

        for col_index, value in enumerate(self.header, start=1):
            width = min(max(len(value) + 2, 11), 28)
            self.worksheet.column_dimensions[get_column_letter(col_index)].width = width

        self.worksheet.page_setup.orientation = "landscape"
        self.worksheet.page_setup.fitToWidth = 1
        self.worksheet.page_setup.fitToHeight = 0
        self.worksheet.sheet_properties.pageSetUpPr.fitToPage = True
        self.worksheet.print_title_rows = "1:1"

    def append_rows(self, rows: Iterable[Sequence[object]]) -> int:
        appended = 0
        width = len(self.header)
        for row in rows:
            if self.row_count >= EXCEL_MAX_DATA_ROWS:
                raise RuntimeError(
                    "Die zusammengeführte Datei überschreitet die Excel-Grenze "
                    f"von {EXCEL_MAX_DATA_ROWS:,} Datenzeilen.".replace(",", ".")
                )
            values = list(row[:width]) if isinstance(row, list) else list(row)[:width]
            if len(values) < width:
                values.extend([""] * (width - len(values)))
            self.worksheet.append(["" if value is None else str(value) for value in values])
            self.row_count += 1
            appended += 1
        return appended

    def save(self) -> Path:
        if self._closed:
            raise RuntimeError("Der Streaming-Writer wurde bereits geschlossen.")
        last_row = self.row_count + 1
        if self.header:
            self.worksheet.auto_filter.ref = (
                f"A1:{get_column_letter(len(self.header))}{max(1, last_row)}"
            )
        self.workbook.save(self.partial_file)
        os.replace(self.partial_file, self.output_file)
        self._closed = True
        return self.output_file

    def abort(self) -> None:
        if self._closed:
            return
        try:
            self.worksheet.close()
        except Exception:
            pass
        try:
            self.workbook.close()
        except Exception:
            pass
        try:
            self.partial_file.unlink(missing_ok=True)
        except OSError:
            pass
        self._closed = True
