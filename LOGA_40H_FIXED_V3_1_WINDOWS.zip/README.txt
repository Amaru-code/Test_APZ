LOGA 40H Fixed V3.1
====================

Behobener Fehler:
  Assignment to constant variable.

Ursache:
  In openPopupForDate wurden handle und startPoint als const angelegt,
  später nach der Scroll-Suche aber erneut zugewiesen.

Fix:
  const handle     -> let handle
  const startPoint -> let startPoint

Dadurch wird nach dem Finden des Drop-Ziels die Prüfung auf bereits
vorhandene Buchungen wieder ausgeführt. Montag wurde im fehlerhaften Lauf
nicht falsch bewertet; das Skript brach vorher ab.
