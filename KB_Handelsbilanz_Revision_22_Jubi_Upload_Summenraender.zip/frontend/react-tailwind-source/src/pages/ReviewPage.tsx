import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Building2,
  Check,
  CloudUpload,
  Database,
  FileCheck2,
  FileSpreadsheet,
  FolderOpen,
  LoaderCircle,
  Play,
  TrendingUp,
  Users,
} from 'lucide-react'
import clsx from 'clsx'
import { bridge } from '../lib/bridge'
import type { BootstrapData, Inspection, JubileeInspection, JobResult, JobStatus, OutputType } from '../types'
import { Hero } from '../components/Hero'
import { Modal } from '../components/Modal'

interface Props {
  bootstrap: BootstrapData
  onCompleted: (result: JobResult) => void
  notify: (kind: 'success' | 'error' | 'info', text: string) => void
}

const types: OutputType[] = ['HGB', 'STB', '7 Jahre']

function FileCard({
  title,
  inspection,
  optional,
  disabled,
  onSelect,
}: {
  title: string
  inspection: Inspection | null
  optional?: boolean
  disabled?: boolean
  onSelect: () => void
}) {
  return (
    <div className={clsx('rounded-[18px] border border-slate-200 bg-white/85 p-5 shadow-soft transition-all', disabled && 'opacity-45')}>
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2.5 text-[15px] font-extrabold text-ink">
          <span className="grid h-8 w-8 place-items-center rounded-xl bg-cyan-50 text-teal"><FileSpreadsheet className="h-4.5 w-4.5" /></span>
          {title}
        </div>
        {optional && <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-500">Optional</span>}
      </div>
      <button
        disabled={disabled}
        onClick={onSelect}
        className={clsx(
          'group flex min-h-[132px] w-full flex-col items-center justify-center rounded-2xl border border-dashed px-5 text-center transition-all duration-200',
          inspection ? 'border-teal/40 bg-cyan-50/55' : 'border-slate-300 bg-slate-50/50 hover:-translate-y-0.5 hover:border-teal hover:bg-cyan-50/60',
        )}
      >
        {inspection ? (
          <>
            <span className="grid h-12 w-12 place-items-center rounded-2xl bg-white text-teal shadow-sm"><FileCheck2 className="h-6 w-6" /></span>
            <span className="mt-3 max-w-full truncate text-[15px] font-extrabold text-ink">{inspection.name}</span>
            <span className="mt-1 text-xs text-slate-500">{inspection.record_count.toLocaleString('de-DE')} Datensätze · Header in Zeile {inspection.header_row}</span>
            <span className="mt-2 text-xs font-bold text-teal">Datei ändern</span>
          </>
        ) : (
          <>
            <CloudUpload className="h-8 w-8 text-teal transition-transform group-hover:-translate-y-1" strokeWidth={1.8} />
            <span className="mt-3 text-[15px] font-semibold text-ink">XLSX-Datei auswählen</span>
            <span className="mt-1 text-sm text-slate-400">Sheet „AllOnetabOrFile“</span>
          </>
        )}
      </button>
    </div>
  )
}

function JubileeCard({ inspection, source, disabled, onSelect }: { inspection: JubileeInspection | null; source: string; disabled?: boolean; onSelect: () => void }) {
  return (
    <button disabled={disabled} onClick={onSelect} className={clsx('mt-2.5 flex w-full items-center gap-3 rounded-[14px] border border-slate-200 bg-slate-50/80 px-3 py-2.5 text-left transition-all hover:border-teal hover:bg-cyan-50/60', disabled && 'opacity-45')}>
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-cyan-50 text-teal"><FileSpreadsheet className="h-4.5 w-4.5" /></span>
      <span className="min-w-0 flex-1">
        <strong className="block truncate text-[13px] text-ink">{inspection?.name || 'Jubiläums-XLSX (optional)'}</strong>
        <small className="block truncate text-[11px] text-slate-500">{inspection ? `${inspection.total.toLocaleString('de-DE')} · ${source}` : `Summe aus ${source}`}</small>
      </span>
      <span className="text-[11px] font-extrabold text-teal">Auswählen</span>
    </button>
  )
}

export function ReviewPage({ bootstrap, onCompleted, notify }: Props) {
  const [outputType, setOutputType] = useState<OutputType>('HGB')
  const [selectedCompanies, setSelectedCompanies] = useState<string[]>(bootstrap.companies.map((company) => company.name))
  const [current, setCurrent] = useState<Inspection | null>(null)
  const [previous, setPrevious] = useState<Inspection | null>(null)
  const [currentJubilee, setCurrentJubilee] = useState<JubileeInspection | null>(null)
  const [previousJubilee, setPreviousJubilee] = useState<JubileeInspection | null>(null)
  const [previousEnabled, setPreviousEnabled] = useState(false)
  const [progressOpen, setProgressOpen] = useState(false)
  const [job, setJob] = useState<JobStatus | null>(null)

  const selectedRuleCount = useMemo(
    () => bootstrap.companies.filter((company) => selectedCompanies.includes(company.name)).reduce((sum, item) => sum + item.rule_count, 0),
    [bootstrap.companies, selectedCompanies],
  )

  async function chooseFile(kind: 'current' | 'previous') {
    try {
      const path = await bridge.selectExcelFile()
      if (!path) {
        const desktopRequested = new URLSearchParams(window.location.search).get('desktop') === '1'
        if (!desktopRequested) {
          notify('info', 'Im Browser-Demomodus steht der native Dateidialog nur in der Desktop-App zur Verfügung.')
          if (kind === 'current') {
            setCurrent({ path: 'data/samples/sample_AllOnetabOrFile.xlsx', name: 'sample_AllOnetabOrFile.xlsx', sheet_name: 'AllOnetabOrFile', header_row: 7, record_count: 6 })
          }
        }
        return
      }
      const inspected = await bridge.inspectSource(path, outputType, selectedCompanies)
      if (kind === 'current') setCurrent(inspected)
      else setPrevious(inspected)
      notify('success', `${inspected.name} wurde erfolgreich geprüft.`)
    } catch (error) {
      notify('error', error instanceof Error ? error.message : 'Datei konnte nicht geprüft werden.')
    }
  }

  async function chooseJubilee(kind: 'current' | 'previous') {
    try {
      const path = await bridge.selectExcelFile()
      if (!path) return
      const inspected = await bridge.inspectJubilee(path, outputType)
      if (kind === 'current') setCurrentJubilee(inspected)
      else setPreviousJubilee(inspected)
      notify('success', `${inspected.name} wurde als Jubiläumsdatei geprüft.`)
    } catch (error) {
      notify('error', error instanceof Error ? error.message : 'Jubiläumsdatei konnte nicht geprüft werden.')
    }
  }

  function toggleCompany(name: string) {
    setSelectedCompanies((currentSelection) =>
      currentSelection.includes(name)
        ? currentSelection.filter((item) => item !== name)
        : [...currentSelection, name],
    )
  }

  async function run() {
    if (!current) {
      notify('error', 'Bitte zuerst die Datei des aktuellen Jahres auswählen.')
      return
    }
    if (!selectedCompanies.length) {
      notify('error', 'Bitte mindestens eine Gesellschaft auswählen.')
      return
    }
    let interestRatePercent: number | null = null
    if (outputType === 'HGB' || outputType === '7 Jahre') {
      const rawInterestRate = window.prompt(
        'Bitte den BilMoG-Zinssatz in Prozent eingeben (z. B. 2,05):',
        '2,05',
      )
      if (rawInterestRate === null) return
      interestRatePercent = Number(rawInterestRate.trim().replace('%', '').replace(',', '.'))
      if (!Number.isFinite(interestRatePercent) || interestRatePercent < 0 || interestRatePercent > 100) {
        notify('error', 'Der Zinssatz muss zwischen 0 und 100 Prozent liegen.')
        return
      }
    }
    try {
      setProgressOpen(true)
      setJob({ id: '', state: 'queued', progress: 2, stage: 'Auswertung wird vorbereitet', logs: [] })
      const id = await bridge.startRun({
        current_file: current.path,
        previous_file: previousEnabled ? previous?.path : null,
        current_jubilee_file: currentJubilee?.path || null,
        previous_jubilee_file: previousEnabled ? previousJubilee?.path || null : null,
        output_type: outputType,
        companies: selectedCompanies,
        output_dir: bootstrap.settings.output_dir,
        interest_rate_percent: interestRatePercent,
      })
      const timer = window.setInterval(async () => {
        const status = await bridge.getJob(id)
        setJob(status)
        if (status.state === 'done') {
          window.clearInterval(timer)
          if (status.result) {
            onCompleted(status.result)
            notify('success', 'Die Handelsbilanz-Auswertung wurde erfolgreich erstellt.')
          }
        }
        if (status.state === 'error') {
          window.clearInterval(timer)
          notify('error', status.error || 'Die Berechnung ist fehlgeschlagen.')
        }
      }, 450)
    } catch (error) {
      setProgressOpen(false)
      notify('error', error instanceof Error ? error.message : 'Berechnung konnte nicht gestartet werden.')
    }
  }

  return (
    <div className="space-y-4 pb-8">
      <Hero />

      <div className="grid grid-cols-[1.2fr_.95fr] gap-4">
        <div><FileCard title="Aktuelles Jahr" inspection={current} onSelect={() => chooseFile('current')} /><JubileeCard inspection={currentJubilee} source={bootstrap.value_columns[outputType]} onSelect={() => chooseJubilee('current')} /></div>
        <div className="relative">
          <div className="absolute right-5 top-5 z-10 flex items-center gap-2 text-xs font-semibold text-slate-500">
            Optionaler Vergleich
            <button
              onClick={() => setPreviousEnabled((value) => { if (value) { setPrevious(null); setPreviousJubilee(null) }; return !value })}
              className={clsx('relative h-6 w-11 rounded-full transition-colors', previousEnabled ? 'bg-teal' : 'bg-slate-300')}
            >
              <span className={clsx('absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all', previousEnabled ? 'left-[22px]' : 'left-0.5')} />
            </button>
          </div>
          <FileCard title="Vorjahr" inspection={previous} optional disabled={!previousEnabled} onSelect={() => chooseFile('previous')} />
          <JubileeCard inspection={previousJubilee} source={bootstrap.value_columns[outputType]} disabled={!previousEnabled} onSelect={() => chooseJubilee('previous')} />
        </div>
      </div>

      <div className="grid grid-cols-[minmax(0,1fr)_282px] gap-4">
        <div className="space-y-4">
          <section className="rounded-[18px] border border-slate-200 bg-white/85 p-5 shadow-soft">
            <h2 className="mb-3 text-[15px] font-extrabold text-ink">Auswertungstyp wählen</h2>
            <div className="grid grid-cols-3 gap-3">
              {types.map((type) => {
                const selected = type === outputType
                return (
                  <motion.button
                    key={type}
                    whileHover={{ y: -2 }}
                    onClick={() => setOutputType(type)}
                    className={clsx(
                      'relative min-h-[102px] rounded-2xl border p-4 text-left transition-colors',
                      selected ? 'border-teal bg-gradient-to-br from-cyan-50 to-white shadow-[0_0_0_2px_rgba(13,139,149,.07)]' : 'border-slate-200 bg-white hover:shadow-soft',
                    )}
                  >
                    <span className={clsx('grid h-10 w-10 place-items-center rounded-xl', type === 'STB' ? 'bg-blue-50 text-blue-600' : type === '7 Jahre' ? 'bg-emerald-50 text-emerald-600' : 'bg-cyan-50 text-teal')}>
                      <FileSpreadsheet className="h-5 w-5" />
                    </span>
                    <span className="mt-2 block text-lg font-extrabold text-ink">{type}</span>
                    <span className="mt-0.5 block text-xs text-slate-500">{bootstrap.value_columns[type]}</span>
                    <span className={clsx('absolute right-3 top-3 grid h-5 w-5 place-items-center rounded-full border text-[11px]', selected ? 'border-teal bg-teal text-white' : 'border-slate-300')}>{selected && <Check className="h-3 w-3" />}</span>
                  </motion.button>
                )
              })}
            </div>
          </section>

          <section className="rounded-[18px] border border-slate-200 bg-white/85 p-5 shadow-soft">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-[15px] font-extrabold text-ink">Gesellschaften auswählen</h2>
              <button
                onClick={() => setSelectedCompanies(selectedCompanies.length === bootstrap.companies.length ? [] : bootstrap.companies.map((item) => item.name))}
                className="text-xs font-bold text-teal hover:underline"
              >
                {selectedCompanies.length === bootstrap.companies.length ? 'Auswahl aufheben' : 'Alle auswählen'}
              </button>
            </div>
            <div className="grid grid-cols-4 gap-2.5">
              {bootstrap.companies.map((company) => {
                const selected = selectedCompanies.includes(company.name)
                return (
                  <motion.button
                    key={company.name}
                    whileHover={{ y: -1 }}
                    onClick={() => toggleCompany(company.name)}
                    className={clsx('flex items-center gap-2.5 rounded-2xl border p-3 text-left transition-colors', selected ? 'border-cyan-200 bg-cyan-50/70' : 'border-slate-200 bg-white')}
                  >
                    <span className="grid h-9 w-9 place-items-center rounded-xl bg-cyan-50 text-teal"><Building2 className="h-4.5 w-4.5" /></span>
                    <span className="min-w-0 flex-1">
                      <strong className="block text-sm text-ink">{company.name}</strong>
                      <small className="block text-[11px] text-emerald-600">{company.rule_count} Regeln ✓</small>
                    </span>
                    <span className={clsx('grid h-[19px] w-[19px] shrink-0 place-items-center rounded-md border', selected ? 'border-teal bg-teal text-white' : 'border-slate-300')}>{selected && <Check className="h-3 w-3" />}</span>
                  </motion.button>
                )
              })}
            </div>
          </section>
        </div>

        <aside className="h-max rounded-[18px] border border-slate-200 bg-white/90 p-5 shadow-soft">
          <h2 className="text-[15px] font-extrabold text-ink">Ergebnisübersicht</h2>
          <div className="mt-3 divide-y divide-slate-200">
            <div className="flex items-center gap-3 py-3">
              <span className="grid h-11 w-11 place-items-center rounded-2xl bg-cyan-50 text-teal"><TrendingUp className="h-5 w-5" /></span>
              <div><strong className="block text-[24px] leading-none text-ink">{selectedRuleCount}</strong><span className="mt-1 block text-xs text-slate-500">Kennzahlen</span></div>
            </div>
            <div className="flex items-center gap-3 py-3">
              <span className="grid h-11 w-11 place-items-center rounded-2xl bg-blue-50 text-blue-600"><Users className="h-5 w-5" /></span>
              <div><strong className="block text-[24px] leading-none text-ink">{selectedCompanies.length}</strong><span className="mt-1 block text-xs text-slate-500">Gesellschaften</span></div>
            </div>
            <div className="flex items-center gap-3 py-3">
              <span className="grid h-11 w-11 place-items-center rounded-2xl bg-slate-50 text-teal"><Database className="h-5 w-5" /></span>
              <div><strong className="block text-[24px] leading-none text-ink">{current ? current.record_count.toLocaleString('de-DE') : '—'}</strong><span className="mt-1 block text-xs text-slate-500">Datensätze</span></div>
            </div>
          </div>
          <button onClick={run} className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-teal to-teal2 px-4 py-3.5 text-sm font-extrabold text-white shadow-[0_12px_25px_rgba(13,139,149,.22)] transition hover:-translate-y-0.5 hover:shadow-[0_16px_30px_rgba(13,139,149,.28)]">
            <Play className="h-4 w-4" fill="currentColor" /> Auswertung erstellen
          </button>
          <button onClick={() => bridge.openPath(bootstrap.settings.output_dir)} className="mt-2.5 flex w-full items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-bold text-slate-600 transition hover:bg-slate-50">
            <FolderOpen className="h-4 w-4" /> Ausgabeordner öffnen
          </button>
        </aside>
      </div>

      <Modal open={progressOpen} title={job?.state === 'done' ? 'Auswertung abgeschlossen' : 'Auswertung wird erstellt'} onClose={() => job?.state !== 'running' && setProgressOpen(false)} width="max-w-xl">
        <div className="text-center">
          <div className="relative mx-auto grid h-28 w-28 place-items-center rounded-full bg-cyan-50 text-teal">
            {job?.state === 'done' ? <Check className="h-11 w-11" /> : <LoaderCircle className="h-11 w-11 animate-spin" />}
            <span className="absolute text-sm font-extrabold text-ink">{job?.progress ?? 0}%</span>
          </div>
          <h3 className="mt-5 text-lg font-extrabold text-ink">{job?.stage}</h3>
          <div className="mt-5 h-2.5 overflow-hidden rounded-full bg-slate-100">
            <motion.div className="h-full rounded-full bg-gradient-to-r from-teal to-blue-500" animate={{ width: `${job?.progress ?? 0}%` }} />
          </div>
          <div className="mt-5 max-h-32 space-y-2 overflow-auto rounded-2xl bg-slate-50 p-4 text-left text-xs text-slate-500">
            {(job?.logs || []).map((line, index) => <div key={`${line}-${index}`}>✓ {line}</div>)}
          </div>
          {job?.state === 'done' && (
            <button onClick={() => setProgressOpen(false)} className="mt-5 rounded-2xl bg-teal px-5 py-3 text-sm font-bold text-white">Ergebnisse anzeigen</button>
          )}
        </div>
      </Modal>
    </div>
  )
}
