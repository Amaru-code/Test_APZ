from __future__ import annotations

"""Template-preserving Excel output.

The customer's local workbooks are the source of truth for layout. The template
is copied first and only report text, dates and result values are changed.
Column widths, row heights, merges, logos, page breaks, print areas, headers,
footers and all other workbook formatting remain untouched.

On Windows, Excel COM is mandatory for this path because it is the only writer
that reliably preserves Excel header pictures and other native drawing objects.
A failed COM run must therefore fail visibly instead of silently creating a
layout-reduced OpenPyXL output.
"""

from collections import OrderedDict
from copy import copy
from datetime import date, datetime
import logging
from pathlib import Path
import re
import shutil
import sys
from typing import Any, Iterable

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils.datetime import from_excel

from core.config_loader import RuleConfig
from core.models import CompanyResult, MetricResult, SourceDataset
from core.normalization import output_type_requires_interest_rate
from excel.template_writer import (
    BASE_SHEETS,
    COMPANY_HEADER_CODES,
    COMPANY_NAMES,
    OUTPUT_LABELS,
    SECTION_CAPTIONS,
    SECTION_CODE_FALLBACKS,
    SHEET_ALIASES,
    _date_from_path,
    _normalise_text,
)

LOGGER = logging.getLogger("kb.template.preserve")

VALUE_COLUMNS = (6, 8, 10, 12, 14)
SUMMARY_SHEET_NAME = "Summe"
BILMOG_SHEET_NAME = "BilMoG"
INTEGER_NUMBER_FORMAT = "#,##0;-#,##0;0"
INTEGER_NUMBER_FORMAT_LOCAL = "#.##0;-#.##0;0"

# Excel formulas can refer to local sheets or to an external workbook.  The
# local customer templates already contain the desired aggregation structure
# on the sheet ``Summe``.  We keep that structure, but rewrite every sheet
# reference so it points to the sheets generated in the current workbook.
FORMULA_SHEET_REFERENCE_RE = re.compile(
    r"(?P<sheet>'(?:[^']|'')+'|\[[^\]]+\][^!+\-*/(),;]+|[A-Za-z_][A-Za-z0-9_.]*)!"
    r"(?P<reference>\$?[A-Z]{1,3}\$?\d+(?::\$?[A-Z]{1,3}\$?\d+)?)"
)
FORMULA_CELL_RE = re.compile(r"(?P<column>\$?[A-Z]{1,3})(?P<absolute>\$?)(?P<row>\d+)")
PRINT_AREA_RE = re.compile(
    r"(?P<start>\$?[A-Z]{1,3}\$?\d+)\s*:\s*(?P<end_column>\$?[A-Z]{1,3}\$?)(?P<end_row>\d+)"
)

# Business-rule target rows stay unchanged in rules.json. Only the physical
# placement in the local GRH ICT template is shifted to prevent the lower
# sections from overlapping the Geschäftsführer subtotal.
OUTPUT_ROW_OVERRIDES: dict[str, dict[int, int]] = {
    # The lower blocks of GRH and SFS use the same physical layout.  The
    # business target rows in rules.json stay unchanged; only the output rows
    # are shifted so section headings, metrics and subtotals never share a row.
    "GRH": {
        49: 51,  # Mitarbeiter Auslandsges.
        51: 55,  # Einbehalte von Mitarbeitern
        56: 59,  # MRP / unverfallb. Ausgesch.; Zeile 56 bleibt leer
    },
    "SFS": {
        49: 51,  # Mitarbeiter Auslandsges.
        51: 55,  # Barlohnumwandlung two rows below the preceding metric
        56: 59,  # MRP; Zeile 56 bleibt leer
    },
}

# The customer template sheet ``Summe`` intentionally contains the labels and
# formatting but may contain no formulas.  These are the proven formulas from
# the reference workbook supplied by the user.  External/company references
# are subsequently rewritten to local sheet names and to the physical output
# rows defined above.
SUMMARY_FORMULA_BLUEPRINT: dict[tuple[int, int], str] = {
    (12, 6): "=SFS!F12+GRH!F12+SFS!F13+GRH!F13",
    (12, 8): "=SFS!H12+GRH!H12+SFS!H13+GRH!H13",
    (13, 6): "=SFS!F14+GRH!F14",
    (13, 8): "=SFS!H14+GRH!H14",
    (14, 6): "=SFS!F15+GRH!F15",
    (14, 8): "=SFS!H15+GRH!H15",
    (15, 6): "=SFS!F16+GRH!F16",
    (15, 8): "=SFS!H16+GRH!H16",
    (16, 6): "=SUM(F12:F15)",
    (16, 8): "=SUM(H12:H15)",
    (20, 6): "=SFS!F21+GRH!F21",
    (20, 8): "=SFS!H21+GRH!H21",
    (21, 6): "=SFS!F22+GRH!F22",
    (21, 8): "=SFS!H22+GRH!H22",
    (22, 6): "=SFS!F23+GRH!F23",
    (22, 8): "=SFS!H23+GRH!H23",
    (23, 6): "=SFS!F24+GRH!F24",
    (23, 8): "=SFS!H24+GRH!H24",
    (24, 6): "=SUM(F20:F23)",
    (24, 8): "=SUM(H20:H23)",
    (29, 6): "=SFS!F30+GRH!F30+SFS!F45+GRH!F45+SFS!F49+GRH!F49",
    (29, 8): "=SFS!H30+SFS!H45+SFS!H49+GRH!H30+GRH!H45+GRH!H49",
    (30, 6): "=SFS!F31+GRH!F31",
    (30, 8): "=SFS!H31+GRH!H31",
    (31, 6): "=0",
    (31, 8): "=0",
    (32, 6): "=SFS!F56+GRH!F56",
    (32, 8): "=SFS!H56+GRH!H56",
    (33, 6): "=SFS!F32+GRH!F32",
    (33, 8): "=SFS!H32+GRH!H32",
    (34, 6): "=0",
    (34, 8): "=0",
    (35, 6): "=SUM(F28:F34)",
    (35, 8): "=SUM(H28:H34)",
    (39, 6): "=SFS!F37+GRH!F37",
    (39, 8): "=SFS!H37+GRH!H37",
    (40, 6): "=SFS!F38+GRH!F38",
    (40, 8): "=SFS!H38+GRH!H38",
    (41, 6): "=SFS!F40+GRH!F40",
    (41, 8): "=SFS!H40+GRH!H40",
    (42, 6): "=SFS!F39+GRH!F39",
    (42, 8): "=SFS!H39+GRH!H39",
    (43, 6): "=SUM(F39:F42)",
    (43, 8): "=SUM(H39:H42)",
    (45, 6): "=SFS!F51+GRH!F51",
    (45, 8): "=SFS!H51+GRH!H51",
    (49, 6): "=F16+F24+F35+F43+F45",
    (49, 8): "=H16+H24+H35+H43+H45",
}


# Static captions and account numbers of the customer BilMoG worksheet.  The
# values in columns D/E are always formulas and are generated semantically from
# the SFS and GRH report sections below.
BILMOG_TEXT_CELLS: dict[str, Any] = {
    "B3": "Gutachten",
    "C3": "Nr.",
    "E3": "davon \nZinsanteil",
    "B5": "Knorr-Bremse Systeme für Schienenfahrzeuge GmbH",
    "B6": "Einzelzusagen - Anwärter -", "C6": "001/210",
    "B7": "Einzelzusagen - Rentner -", "C7": "001/220",
    "B8": "Allgemeine VO - Anwärter -", "C8": "001/230",
    "B9": "Allgemeine VO - Rentner -", "C9": "001/240",
    "B10": "Werk Berlin", "C10": "001/250",
    "B11": "MRP", "C11": "001/260",
    "B12": "Zwischensumme",
    "B13": "neue Kapitalzusagen", "C13": 200,
    "B14": "Einzelzusagen - Geschäftsführer -", "C14": "300/200",
    "B15": "Ausland - E", "C15": "400/270",
    "B16": "Kapitalzusagen aus Deferred Compensation", "C16": "500/280",
    "B17": "Gesamt",
    "B19": "Global Rail Holding",
    "B20": "Einzelzusagen - Anwärter -", "C20": "001/210",
    "B21": "Einzelzusagen - Rentner -", "C21": "001/220",
    "B22": "Allgemeine VO - Anwärter -", "C22": "001/230",
    "B23": "Allgemeine VO - Rentner -", "C23": "001/240",
    "B24": "Werk Berlin", "C24": "001/250",
    "B25": "MRP", "C25": "001/260",
    "B26": "Zwischensumme",
    "B27": "neue Kapitalzusagen", "C27": 200,
    "B28": "Einzelzusagen - Geschäftsführer -", "C28": "300/200",
    "B29": "Ausland - E", "C29": "400/270",
    "B30": "Kapitalzusagen aus Deferred Compensation", "C30": "500/280",
    "B31": "Gesamt",
    "B33": "Insgesamt",
}

BILMOG_FORMULA_ROWS = (
    6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17,
    20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 33,
)


def _output_row(company: str, target_row: int) -> int:
    return OUTPUT_ROW_OVERRIDES.get(company, {}).get(target_row, target_row)


def _known_company_from_reference(token: str) -> str | None:
    """Resolve a sheet/external-workbook token to a configured company."""
    raw = token.strip()
    if raw.startswith("'") and raw.endswith("'"):
        raw = raw[1:-1].replace("''", "'")

    sheet_part = raw.rsplit("]", 1)[-1] if "]" in raw else raw
    workbook_part = ""
    if "[" in raw and "]" in raw:
        workbook_part = raw.rsplit("[", 1)[-1].split("]", 1)[0]

    exact_candidates: dict[str, str] = {}
    for company, display_name in COMPANY_NAMES.items():
        exact_candidates[_normalise_text(company)] = company
        exact_candidates[_normalise_text(display_name)] = company
    for company, alias in SHEET_ALIASES.items():
        exact_candidates[_normalise_text(alias)] = company

    for candidate in (sheet_part, raw):
        resolved = exact_candidates.get(_normalise_text(candidate))
        if resolved:
            return resolved

    # External formulas often use a generic sheet name such as
    # "Handelsbilanz" and identify the company only in the workbook name.
    searchable = _normalise_text(" ".join(part for part in (workbook_part, raw) if part))
    for company in sorted(COMPANY_NAMES, key=len, reverse=True):
        aliases = {
            _normalise_text(company),
            _normalise_text(COMPANY_NAMES[company]),
        }
        alias = SHEET_ALIASES.get(company)
        if alias:
            aliases.add(_normalise_text(alias))
        for candidate in sorted(aliases, key=len, reverse=True):
            if len(candidate) >= 4 and candidate in searchable:
                return company
            if len(candidate) < 4 and re.search(
                rf"(?:^|\s){re.escape(candidate)}(?:$|\s)", searchable
            ):
                return company
    return None


def _rewrite_formula_cell_reference(
    reference: str,
    company: str,
    row_mappings: dict[str, dict[int, int]] | None = None,
) -> str:
    def rewrite_single(cell_reference: str) -> str:
        match = FORMULA_CELL_RE.fullmatch(cell_reference)
        if not match:
            return cell_reference
        source_row = int(match.group("row"))
        company_mapping = (row_mappings or {}).get(company, {})
        row = company_mapping.get(source_row, _output_row(company, source_row))
        return f"{match.group('column')}{match.group('absolute')}{row}"

    return ":".join(rewrite_single(part) for part in reference.split(":"))


def _rewrite_summary_formula(
    formula: str,
    selected_companies: Iterable[str],
    row_mappings: dict[str, dict[int, int]] | None = None,
) -> str:
    """Turn template external links into local workbook formulas.

    References to companies that were not selected are replaced by zero.  This
    prevents #REF! errors while keeping all subtotal and grand-total formulas on
    the Summe sheet intact.
    """
    selected = set(selected_companies)

    def replace(match: re.Match[str]) -> str:
        company = _known_company_from_reference(match.group("sheet"))
        if company is None or company not in selected:
            return "0"
        sheet_name = company.replace("'", "''")
        reference = _rewrite_formula_cell_reference(
            match.group("reference"),
            company,
            row_mappings,
        )
        return f"'{sheet_name}'!{reference}"

    rewritten = FORMULA_SHEET_REFERENCE_RE.sub(replace, formula)
    # No external workbook token may remain in the final report.  An unmatched
    # external reference is safer as zero than as a broken link prompt.
    if re.search(r"\[[^\]]+\][^!]*!", rewritten):
        LOGGER.warning("Nicht erkannte externe Summenformel wurde auf 0 gesetzt: %s", formula)
        return "=0"
    return rewritten


def _resize_print_area_text(print_area: object, end_row: int) -> str | None:
    text = str(print_area or "").strip()
    match = PRINT_AREA_RE.search(text)
    if not match:
        return None
    return f"{match.group('start')}:{match.group('end_column')}{end_row}"


def _format_date_value(value: Any) -> str | None:
    """Return a German report date from the source workbook's B5 value."""
    if isinstance(value, datetime):
        return value.strftime("%d.%m.%Y")
    if isinstance(value, date):
        return value.strftime("%d.%m.%Y")
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        try:
            converted = from_excel(value)
            if isinstance(converted, (datetime, date)):
                return converted.strftime("%d.%m.%Y")
        except (TypeError, ValueError, OverflowError):
            pass

    text = str(value or "").strip()
    if not text:
        return None
    patterns = (
        (r"(?<!\d)(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{4})(?!\d)", "dmy"),
        (r"(?<!\d)(\d{4})[.\-/](\d{1,2})[.\-/](\d{1,2})(?!\d)", "ymd"),
    )
    for pattern, order in patterns:
        match = re.search(pattern, text)
        if not match:
            continue
        first, second, third = (int(part) for part in match.groups())
        try:
            parsed = (
                datetime(third, second, first)
                if order == "dmy"
                else datetime(first, second, third)
            )
        except ValueError:
            continue
        return parsed.strftime("%d.%m.%Y")
    return None


def _date_from_source_b5(dataset: SourceDataset, fallback: datetime) -> str:
    """Read the report date from B5 of the uploaded source workbook."""
    workbook = None
    try:
        workbook = load_workbook(dataset.path, read_only=True, data_only=True)
        if dataset.sheet_name in workbook.sheetnames:
            worksheet = workbook[dataset.sheet_name]
        else:
            worksheet = workbook[workbook.sheetnames[0]]
        source_value = worksheet["B5"].value
        formatted = _format_date_value(source_value)
        if formatted:
            year = formatted.rsplit(".", 1)[-1]
            normalized = f"31.12.{year}"
            LOGGER.info("Stichtag aus Quelldatei %s!B5: %s -> %s", worksheet.title, formatted, normalized)
            return normalized
        LOGGER.warning(
            "Kein gueltiger Stichtag in %s!B5; verwende Dateinamen-Fallback.",
            worksheet.title,
        )
    except Exception as exc:
        LOGGER.warning(
            "Stichtag aus B5 konnte nicht gelesen werden (%s); verwende Dateinamen-Fallback.",
            exc,
        )
    finally:
        if workbook is not None:
            workbook.close()
    fallback_date = _date_from_path(dataset.path, fallback)
    year = fallback_date.rsplit(".", 1)[-1]
    return f"31.12.{year}"


def _metric_output_rows(metrics: Iterable[MetricResult]) -> list[int]:
    return sorted({_output_row(metric.company, metric.target_row) for metric in metrics})


def _is_metric_visible(metric: MetricResult, previous: MetricResult | None, with_previous: bool) -> bool:
    if with_previous:
        previous_value = previous.value if previous else 0
        previous_count = previous.employee_count if previous else 0
        return any((metric.value, metric.employee_count, previous_value, previous_count, metric.value - previous_value))
    return any((metric.value, metric.employee_count))


def _section_has_visible_content(
    metrics: Iterable[MetricResult],
    previous_map: dict[int, MetricResult],
    with_previous: bool,
) -> bool:
    return any(_is_metric_visible(metric, previous_map.get(metric.target_row), with_previous) for metric in metrics)


def _clear_row_contents(ws, row: int, columns: Iterable[int]) -> None:
    for column in columns:
        ws.cell(row, column).value = None


def _sum_formula(column: str, rows: Iterable[int], hide_zero: bool = True) -> str:
    """Build a SUM formula and optionally display zero results as blank.

    SUM is deliberately used for non-contiguous cells as well.  It safely
    ignores cells whose formulas return an empty string, whereas a chain using
    ``+`` could produce ``#VALUE!``.
    """
    ordered = sorted(set(rows))
    if not ordered:
        return '=IF(0=0,"",0)' if hide_zero else "=0"
    if len(ordered) == 1:
        expression = f"SUM({column}{ordered[0]})"
    elif ordered == list(range(ordered[0], ordered[-1] + 1)):
        expression = f"SUM({column}{ordered[0]}:{column}{ordered[-1]})"
    else:
        references = ",".join(f"{column}{row}" for row in ordered)
        expression = f"SUM({references})"
    if hide_zero:
        return f'=IF({expression}=0,"",{expression})'
    return f"={expression}"


def _visible_value(value: int | float) -> int | float | None:
    """Hide numeric zero values in company detail rows."""
    return None if value == 0 else value


def _summary_rows(
    groups: OrderedDict[str, list[MetricResult]],
    total_rows: dict[str, int | None],
) -> list[int]:
    rows: list[int] = []
    for section, metrics in groups.items():
        total_row = total_rows[section]
        if total_row is not None:
            rows.append(total_row)
        else:
            rows.extend(_metric_output_rows(metrics))
    return rows


def _metric_map(metrics: Iterable[MetricResult] | None) -> dict[int, MetricResult]:
    return {metric.target_row: metric for metric in metrics or []}


def _group_metrics(metrics: list[MetricResult]) -> OrderedDict[str, list[MetricResult]]:
    groups: OrderedDict[str, list[MetricResult]] = OrderedDict()
    for metric in metrics:
        groups.setdefault(metric.section, []).append(metric)
    return groups


def _section_caption(company: str, section: str) -> str:
    if company == "AG" and section == "EZ – Geschäftsführer":
        return "Einzelzusagen Vorstand"
    if company == "GRH" and section == "VO Anwärter (Ausland)":
        # The ICT template uses this as the section heading. The actual metric
        # "Mitarbeiter Auslandsges." is written two rows below it.
        return "Einzelzusagen Anwärter"
    return SECTION_CAPTIONS.get(section, section)


def _capture_template_section_codes_openpyxl(ws) -> dict[str, str]:
    result: dict[str, str] = {}
    for row in range(8, ws.max_row + 1):
        code = ws.cell(row, 2).value
        caption = ws.cell(row, 3).value
        if code not in (None, "") and caption not in (None, ""):
            result[_normalise_text(caption)] = str(code)
    return result


def _find_captured_code(captured: dict[str, str], caption: str) -> str | None:
    wanted = _normalise_text(caption)
    if wanted in captured:
        return captured[wanted]
    for key, code in captured.items():
        if len(wanted) >= 8 and len(key) >= 8 and (wanted in key or key in wanted):
            return code
    return None


def _section_code(company: str, section: str, caption: str, captured: dict[str, str]) -> str:
    captured_code = _find_captured_code(captured, caption)
    if captured_code is not None and company != "GRH":
        return captured_code
    return SECTION_CODE_FALLBACKS.get(company, {}).get(section, captured_code or "")


def _report_rows(result: CompanyResult) -> tuple[OrderedDict[str, list[MetricResult]], dict[str, int], dict[str, int | None], int]:
    groups = _group_metrics(result.current)
    section_rows: dict[str, int] = {}
    total_rows: dict[str, int | None] = {}
    max_metric = 8
    for section, metrics in groups.items():
        rows = sorted(_output_row(result.company, metric.target_row) for metric in metrics)
        section_rows[section] = max(8, rows[0] - 2)
        total_rows[section] = rows[-1] + 1 if len(rows) > 1 else None
        max_metric = max(max_metric, rows[-1])
    # Prefer the conventional two-row gap after the final metric/total. If the
    # actual template already has a usable Gesamtsumme row, it is retained.
    grand_total = max_metric + 3
    return groups, section_rows, total_rows, grand_total


def _bil_mog_row_map(company_results: Iterable[CompanyResult]) -> dict[str, dict[str, int]]:
    """Resolve BilMoG references from business sections, not fixed template rows."""
    mappings: dict[str, dict[str, int]] = {}
    for result in company_results:
        if result.company not in {"SFS", "GRH"}:
            continue
        groups, _, total_rows, _ = _report_rows(result)
        by_target = {
            metric.target_row: _output_row(result.company, metric.target_row)
            for metric in result.current
        }

        def section_total(section: str) -> int:
            metrics = groups.get(section, [])
            if not metrics:
                raise ValueError(
                    f"{result.company}: BilMoG-Bereich {section!r} wurde nicht gefunden."
                )
            total = total_rows.get(section)
            return total if total is not None else _output_row(
                result.company, metrics[0].target_row
            )

        mappings[result.company] = {
            "ez_anwaerter": section_total("EZ Anwärter"),
            "ez_rentner": section_total("EZ Rentner"),
            "vo_anwaerter": section_total("VO Anwärter"),
            "vo_rentner": section_total("VO Rentner"),
            "new_capital": by_target[13],
            "geschaeftsfuehrer": section_total("EZ – Geschäftsführer"),
            "ausland": by_target[49],
            "barlohnumwandlung": by_target[51],
            "mrp": by_target[56],
        }
    return mappings


def _bil_mog_company_value(
    row_map: dict[str, dict[str, int]],
    company: str,
    key: str,
    column: str = "F",
) -> str:
    rows = row_map.get(company)
    if rows is None:
        return "0"
    sheet_name = company.replace("'", "''")
    return f"N('{sheet_name}'!{column}{rows[key]})"


def _build_bil_mog_formulas(
    company_results: Iterable[CompanyResult],
    with_previous: bool = False,
) -> dict[tuple[int, int], str]:
    """Build BilMoG formulas for the appropriate local template layout.

    Without a prior-year file the compact template uses D for the current
    result and E for the interest component. With a prior-year file the
    customer template uses D=current, E=previous, F=change and H=interest.
    """
    rows = _bil_mog_row_map(company_results)

    def company_value(company: str, key: str, column: str) -> str:
        return _bil_mog_company_value(rows, company, key, column)

    if not with_previous:
        sfs = lambda key: company_value("SFS", key, "F")
        grh = lambda key: company_value("GRH", key, "F")
        d_formulas: dict[int, str] = {
            6: f"={sfs('ez_anwaerter')}",
            7: f"={sfs('ez_rentner')}",
            8: f"={sfs('vo_anwaerter')}-N(D13)",
            9: f"={sfs('vo_rentner')}",
            10: "=0",
            11: f"={sfs('mrp')}",
            12: "=SUM(D6:D11)",
            13: f"={sfs('new_capital')}",
            14: f"={sfs('geschaeftsfuehrer')}",
            15: f"={sfs('ausland')}",
            16: f"={sfs('barlohnumwandlung')}",
            17: "=SUM(D12:D16)",
            20: f"={grh('ez_anwaerter')}",
            21: f"={grh('ez_rentner')}",
            22: f"={grh('vo_anwaerter')}-N(D27)",
            23: f"={grh('vo_rentner')}",
            24: "=0",
            25: f"={grh('mrp')}",
            26: "=SUM(D20:D25)",
            27: f"={grh('new_capital')}",
            28: f"={grh('geschaeftsfuehrer')}",
            29: f"={grh('ausland')}",
            30: f"={grh('barlohnumwandlung')}",
            31: "=SUM(D26:D30)",
            33: "=D17+D31",
        }
        formulas: dict[tuple[int, int], str] = {
            (row, 4): formula for row, formula in d_formulas.items()
        }
        detail_rows = (6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 20, 21, 22, 23, 24, 25, 27, 28, 29, 30)
        for row in detail_rows:
            formulas[(row, 5)] = f"=ROUND(D{row}*$H$3,0)"
        formulas.update({
            (12, 5): "=SUM(E6:E11)",
            (17, 5): "=SUM(E12:E16)",
            (26, 5): "=SUM(E20:E25)",
            (31, 5): "=SUM(E26:E30)",
            (33, 5): "=E17+E31",
        })
        return formulas

    def build_result_column(column: str, source_column: str) -> dict[int, str]:
        sfs = lambda key: company_value("SFS", key, source_column)
        grh = lambda key: company_value("GRH", key, source_column)
        return {
            6: f"={sfs('ez_anwaerter')}",
            7: f"={sfs('ez_rentner')}",
            8: f"={sfs('vo_anwaerter')}-N({column}13)",
            9: f"={sfs('vo_rentner')}",
            10: "=0",
            11: f"={sfs('mrp')}",
            12: f"=SUM({column}6:{column}11)",
            13: f"={sfs('new_capital')}",
            14: f"={sfs('geschaeftsfuehrer')}",
            15: f"={sfs('ausland')}",
            16: f"={sfs('barlohnumwandlung')}",
            17: f"=SUM({column}12:{column}16)",
            20: f"={grh('ez_anwaerter')}",
            21: f"={grh('ez_rentner')}",
            22: f"={grh('vo_anwaerter')}-N({column}27)",
            23: f"={grh('vo_rentner')}",
            24: "=0",
            25: f"={grh('mrp')}",
            26: f"=SUM({column}20:{column}25)",
            27: f"={grh('new_capital')}",
            28: f"={grh('geschaeftsfuehrer')}",
            29: f"={grh('ausland')}",
            30: f"={grh('barlohnumwandlung')}",
            31: f"=SUM({column}26:{column}30)",
            33: f"={column}17+{column}31",
        }

    current_formulas = build_result_column("D", "J")
    previous_formulas = build_result_column("E", "F")
    formulas = {(row, 4): formula for row, formula in current_formulas.items()}
    formulas.update({(row, 5): formula for row, formula in previous_formulas.items()})
    detail_rows = (6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 20, 21, 22, 23, 24, 25, 27, 28, 29, 30)
    for row in detail_rows:
        formulas[(row, 6)] = f"=D{row}-E{row}"
        formulas[(row, 8)] = f"=ROUND(E{row}*$K$3,0)"
    for row in (12, 17, 26, 31, 33):
        formulas[(row, 6)] = f"=D{row}-E{row}"
    formulas.update({
        (12, 8): "=SUM(H6:H11)",
        (17, 8): "=SUM(H12:H16)",
        (26, 8): "=SUM(H20:H25)",
        (31, 8): "=SUM(H26:H30)",
        (33, 8): "=H17+H31",
    })
    return formulas


def _max_output_metric_row(result: CompanyResult) -> int:
    return max(
        (_output_row(result.company, metric.target_row) for metric in result.current),
        default=8,
    )


def _select_grand_total_row(
    company: str,
    existing_row: int | None,
    calculated_row: int,
    max_metric_row: int,
) -> int:
    """Keep the template's total row when it cannot overlap detail rows."""
    if company == "Steering":
        # The Kiepe/Steering report is intentionally compact: detail rows
        # 12-14, subtotal 15, one blank row, final total 17.
        return calculated_row
    if company in OUTPUT_ROW_OVERRIDES:
        # The shifted lower block places MRP in row 59.  Keep one blank row
        # before the green final total, for both GRH and SFS.
        return max(existing_row or 0, max_metric_row + 2)
    if existing_row is not None and existing_row > max_metric_row:
        return existing_row
    return calculated_row


def _find_grand_total_row_openpyxl(ws) -> int | None:
    for row in range(8, ws.max_row + 1):
        for column in (2, 3, 4):
            if "gesamtsumme" in _normalise_text(ws.cell(row, column).value):
                return row
    return None


def _first_style_rows_openpyxl(ws) -> tuple[int, int, int, int]:
    section = 10
    metric = 12
    total = 16
    grand = _find_grand_total_row_openpyxl(ws) or max(1, ws.max_row)
    for row in range(8, ws.max_row + 1):
        if ws.cell(row, 2).value not in (None, "") and ws.cell(row, 3).value not in (None, ""):
            section = row
            break
    for row in range(8, ws.max_row + 1):
        if ws.cell(row, 4).value not in (None, ""):
            metric = row
            break
    for row in range(metric + 1, ws.max_row + 1):
        if any(ws.cell(row, col).border.bottom.style for col in (6, 8, 10, 12, 14)):
            total = row
            break
    return section, metric, total, grand


def _row_has_format_openpyxl(ws, row: int, max_column: int = 14) -> bool:
    return any(ws.cell(row, col).has_style for col in range(1, max_column + 1))


def _copy_row_format_openpyxl(ws, source_row: int, target_row: int, max_column: int = 14) -> None:
    if source_row == target_row:
        return
    for col in range(1, max_column + 1):
        source = ws.cell(source_row, col)
        target = ws.cell(target_row, col)
        if source.has_style:
            target._style = copy(source._style)
        target.number_format = source.number_format
        target.alignment = copy(source.alignment)
        target.protection = copy(source.protection)
    ws.row_dimensions[target_row].height = ws.row_dimensions[source_row].height
    ws.row_dimensions[target_row].hidden = False


def _ensure_row_format_openpyxl(ws, target_row: int, source_row: int) -> None:
    if not _row_has_format_openpyxl(ws, target_row):
        _copy_row_format_openpyxl(ws, source_row, target_row)


def _copy_row_cell_formats_openpyxl(
    ws,
    source_row: int,
    target_row: int,
    columns: Iterable[int],
) -> None:
    """Copy only cell formats, never values or formulas."""
    for column in columns:
        source = ws.cell(source_row, column)
        target = ws.cell(target_row, column)
        target._style = copy(source._style)
        target.number_format = source.number_format
        target.alignment = copy(source.alignment)
        target.protection = copy(source.protection)


def _set_bold_openpyxl(ws, row: int, columns: Iterable[int], bold: bool) -> None:
    for column in columns:
        cell = ws.cell(row, column)
        font = copy(cell.font)
        font.bold = bold
        cell.font = font


def _move_top_border_to_bottom_openpyxl(
    ws,
    row: int,
    columns: Iterable[int],
) -> None:
    """Move an accidental top edge to the bottom edge of the same cells."""
    for column in columns:
        cell = ws.cell(row, column)
        border = copy(cell.border)
        if not border.top.style:
            continue
        former_top = copy(border.top)
        border.top = type(border.top)()
        border.bottom = former_top
        cell.border = border


def _apply_shifted_lower_block_formats_openpyxl(
    ws,
    style_metric: int,
) -> None:
    """Format the common shifted SFS/GRH lower report block."""
    # Section headings must be bold.
    _set_bold_openpyxl(ws, 49, (3,), True)
    _set_bold_openpyxl(ws, 53, (3,), True)

    # Key one-line result blocks are bold.
    _set_bold_openpyxl(ws, 51, VALUE_COLUMNS, True)
    _set_bold_openpyxl(ws, 55, VALUE_COLUMNS, True)

    # Row 59 is a normal MRP metric, not a subtotal/grand-total row.  Always
    # replace the old template format so no green fill or thick outline remains.
    _copy_row_cell_formats_openpyxl(ws, style_metric, 59, range(3, 15))
    _set_bold_openpyxl(ws, 59, VALUE_COLUMNS, True)


def _apply_sfs_format_corrections_openpyxl(
    ws,
    total_rows: Iterable[int],
    grand_row: int,
    style_metric: int,
    style_total: int,
    style_grand: int,
) -> None:
    total_format_columns = (3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14)
    for row in total_rows:
        _copy_row_cell_formats_openpyxl(ws, style_total, row, total_format_columns)
        _set_bold_openpyxl(ws, row, (3, *VALUE_COLUMNS), True)
    _copy_row_cell_formats_openpyxl(ws, style_grand, grand_row, total_format_columns)
    _set_bold_openpyxl(ws, grand_row, (3, *VALUE_COLUMNS), True)
    _apply_shifted_lower_block_formats_openpyxl(ws, style_metric)


def _apply_grh_format_corrections_openpyxl(
    ws,
    total_rows: Iterable[int],
    grand_row: int,
    style_metric: int,
    style_total: int,
    style_grand: int,
) -> None:
    # Reapply the template's subtotal and final-total borders.  Some customer
    # templates contain formatted but borderless target rows, so the previous
    # "only if unformatted" rule was insufficient.
    total_format_columns = (3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14)
    for row in total_rows:
        _copy_row_cell_formats_openpyxl(ws, style_total, row, total_format_columns)
        _set_bold_openpyxl(ws, row, VALUE_COLUMNS, True)
    _copy_row_cell_formats_openpyxl(ws, style_grand, grand_row, total_format_columns)
    _set_bold_openpyxl(ws, grand_row, (3, *VALUE_COLUMNS), True)

    _apply_shifted_lower_block_formats_openpyxl(ws, style_metric)

    # Requested GRH emphasis corrections.
    _set_bold_openpyxl(ws, 45, VALUE_COLUMNS, False)
    _set_bold_openpyxl(ws, 46, VALUE_COLUMNS, False)
    _set_bold_openpyxl(ws, 47, VALUE_COLUMNS, True)




def _template_text_matches(actual: Any, wanted: str) -> bool:
    actual_text = _normalise_text(actual)
    wanted_text = _normalise_text(wanted)
    if not actual_text or not wanted_text:
        return False
    if actual_text == wanted_text:
        return True
    # Customer templates occasionally contain an account code or a short
    # qualifier in the same cell.  A contained match is therefore accepted for
    # meaningful labels, but not for very short labels such as "Männer".
    return min(len(actual_text), len(wanted_text)) >= 7 and (
        wanted_text in actual_text or actual_text in wanted_text
    )


def _row_label_text_openpyxl(ws, row: int) -> str:
    return " ".join(
        str(ws.cell(row, column).value or "") for column in (2, 3, 4)
    ).strip()


def _find_text_row_openpyxl(
    ws,
    wanted: str,
    start_row: int,
    end_row: int,
) -> int | None:
    for row in range(max(1, start_row), max(start_row, end_row) + 1):
        if _template_text_matches(_row_label_text_openpyxl(ws, row), wanted):
            return row
    return None


TEMPLATE_METRIC_ROW_OVERRIDES: dict[str, dict[int, int]] = {
    "SFN": {66: 69},
    "AG": {86: 87, 87: 88, 88: 89, 89: 90},
}


def _template_metric_row_override(company: str, target_row: int) -> int | None:
    return TEMPLATE_METRIC_ROW_OVERRIDES.get(company, {}).get(target_row)


def _template_row_map_openpyxl(
    ws,
    result: CompanyResult,
) -> tuple[OrderedDict[str, list[MetricResult]], dict[str, int], dict[int, int], dict[str, int | None], int]:
    """Resolve business metrics against the customer's existing template.

    No rows, captions or formats are generated here.  The template remains the
    source of truth; this mapping only finds the cells into which values and
    subtotal formulas must be written.
    """
    groups = _group_metrics(result.current)
    max_row = max(ws.max_row, 8)
    section_rows: dict[str, int] = {}
    cursor = 8
    for section in groups:
        caption = _section_caption(result.company, section)
        found = _find_text_row_openpyxl(ws, caption, cursor, max_row)
        if found is None:
            # A dedicated template should normally contain every caption.  The
            # business row is only a conservative fallback and does not trigger
            # any label/format changes.
            found = max(8, min(metric.target_row for metric in groups[section]) - 2)
        section_rows[section] = found
        cursor = found + 1

    ordered_sections = list(groups)
    metric_rows: dict[int, int] = {}
    total_rows: dict[str, int | None] = {}
    for index, section in enumerate(ordered_sections):
        section_row = section_rows[section]
        next_section = (
            section_rows[ordered_sections[index + 1]]
            if index + 1 < len(ordered_sections)
            else (_find_grand_total_row_openpyxl(ws) or max_row + 1)
        )
        search_start = section_row
        search_end = max(search_start, next_section - 1)
        used_rows: set[int] = set()
        for metric in groups[section]:
            found = _template_metric_row_override(result.company, metric.target_row)
            if found is not None and not (search_start <= found <= search_end):
                found = None
            for row in range(search_start, search_end + 1):
                if found is not None:
                    break
                if row in used_rows:
                    continue
                if _template_text_matches(_row_label_text_openpyxl(ws, row), metric.label):
                    found = row
                    break
            if found is None and len(groups[section]) == 1:
                # One-line chapters (e.g. Barlohnumwandlung or Steering alte
                # Leipziger) often carry their value directly in the heading row.
                found = section_row
            if found is None:
                found = metric.target_row
            metric_rows[metric.target_row] = found
            used_rows.add(found)

        rows = sorted(metric_rows[metric.target_row] for metric in groups[section])
        if len(rows) > 1:
            candidate = rows[-1] + 1
            total_rows[section] = candidate if candidate < next_section else None
        else:
            total_rows[section] = None

    grand_row = _find_grand_total_row_openpyxl(ws) or max(
        [*metric_rows.values(), 8]
    ) + 2
    return groups, section_rows, metric_rows, total_rows, grand_row


def _apply_common_sheet_rules_openpyxl(
    ws,
    total_rows: Iterable[int],
    grand_row: int,
    with_previous: bool,
    metric_rows: Iterable[int] = (),
) -> None:
    """Apply the final, workbook-wide presentation rules after all template copies.

    This is intentionally the last formatting pass. Template row copies may
    otherwise restore decimal formats, bold detail values or misplaced borders.
    """
    max_row = max(ws.max_row, grand_row)
    max_col = max(ws.max_column, 14)
    thin = Side(style="thin", color="000000")
    medium = Side(style="medium", color="000000")
    value_columns = (6, 8, 10, 12, 14) if with_previous else (6, 8)
    metric_set = {int(row) for row in metric_rows if row is not None}
    total_set = {int(row) for row in total_rows if row is not None}

    # Column B is obsolete. Clear it only in the final pass so section codes
    # written earlier cannot reappear.
    for row in range(1, max_row + 1):
        ws.cell(row, 2).value = None

    # Global cleanup: no colours, no italics, integer values with thousands
    # separators. The format is also assigned to currently empty cells so
    # recalculated formulas inherit it.
    for row in range(1, max_row + 1):
        for column in range(1, max_col + 1):
            cell = ws.cell(row, column)
            cell.fill = PatternFill(fill_type=None)
            font = copy(cell.font)
            font.italic = False
            cell.font = font
        for column in value_columns:
            ws.cell(row, column).number_format = INTEGER_NUMBER_FORMAT

    # Detail values must never be bold and must not carry subtotal borders.
    for row in metric_set - total_set - {grand_row}:
        for column in value_columns:
            cell = ws.cell(row, column)
            font = copy(cell.font)
            font.bold = False
            font.italic = False
            cell.font = font
            border = copy(cell.border)
            border.top = Side()
            border.bottom = Side()
            cell.border = border

    # Subtotals: bold values with one separator directly above the sum.
    for row in total_set - {grand_row}:
        for column in value_columns:
            cell = ws.cell(row, column)
            font = copy(cell.font)
            font.bold = True
            font.italic = False
            cell.font = font
            border = copy(cell.border)
            border.top = thin
            border.bottom = Side()
            cell.border = border
            cell.number_format = INTEGER_NUMBER_FORMAT

    # Grand total: strong complete frame from label through final count.
    end_column = 14 if with_previous else 8
    for column in range(4, end_column + 1):
        cell = ws.cell(grand_row, column)
        cell.border = Border(
            top=medium,
            bottom=medium,
            left=medium if column == 4 else thin,
            right=medium if column == end_column else thin,
        )
        font = copy(cell.font)
        font.bold = True
        font.italic = False
        cell.font = font
        if column in value_columns:
            cell.number_format = INTEGER_NUMBER_FORMAT

    # Never leave helper/calculation values below the visible grand total.
    for row in range(grand_row + 1, max_row + 1):
        for column in range(10, max_col + 1):
            ws.cell(row, column).value = None


def _hide_empty_sections_openpyxl(
    ws,
    groups: OrderedDict[str, list[MetricResult]],
    section_rows: dict[str, int],
    total_rows: dict[str, int | None],
    previous_map: dict[int, MetricResult],
    with_previous: bool,
    grand_row: int,
) -> None:
    ordered = list(groups)
    clear_columns = (2, 3, 4, 6, 8, 10, 12, 14)
    for index, section in enumerate(ordered):
        start = section_rows[section]
        end = (section_rows[ordered[index + 1]] - 1) if index + 1 < len(ordered) else grand_row - 1
        end = max(start, end)
        visible = _section_has_visible_content(groups[section], previous_map, with_previous)
        for row in range(start, end + 1):
            ws.row_dimensions[row].hidden = not visible
            if not visible:
                for column in clear_columns:
                    ws.cell(row, column).value = None


def _fix_summary_barlohnumwandlung_openpyxl(ws) -> None:
    heading_row = _find_text_row_openpyxl(ws, "Barlohnumwandlung", 1, ws.max_row)
    if heading_row is None:
        return
    detail_row = _find_text_row_openpyxl(
        ws, "Einbehalte von Mitarbeiter", heading_row + 1, min(ws.max_row, heading_row + 5)
    )
    if detail_row is None:
        detail_row = heading_row + 2
    for column in VALUE_COLUMNS:
        source = ws.cell(heading_row, column)
        target = ws.cell(detail_row, column)
        if source.value not in (None, "") and target.value in (None, ""):
            target.value = source.value
        source.value = None
        target.number_format = INTEGER_NUMBER_FORMAT
    # Rewrite formulas below the block to reference the actual detail row.
    for row in range(detail_row + 1, ws.max_row + 1):
        for column in VALUE_COLUMNS:
            value = ws.cell(row, column).value
            if isinstance(value, str) and value.startswith("="):
                value = re.sub(
                    rf"(?<!\d){heading_row}(?!\d)", str(detail_row), value
                )
                ws.cell(row, column).value = value

def _fix_bilmog_previous_formulas_openpyxl(ws) -> None:
    for row in range(6, ws.max_row + 1):
        cell = ws.cell(row, 5)
        value = cell.value
        if isinstance(value, str) and value.startswith("="):
            cell.value = re.sub(r"!H(\d+)", r"!F\1", value)
        for column in (4, 5, 6, 8):
            target = ws.cell(row, column)
            if target.value not in (None, ""):
                target.number_format = INTEGER_NUMBER_FORMAT
                target.fill = PatternFill(fill_type=None)
                font = copy(target.font)
                font.italic = False
                target.font = font


def _fill_existing_template_sheet_openpyxl(
    ws,
    result: CompanyResult,
    output_type: str,
    current_date: str,
    previous_date: str | None,
) -> tuple[int | None, int]:
    """Insert values into a dedicated customer template without rebuilding it."""
    groups, section_rows, metric_rows, total_rows, grand_row = _template_row_map_openpyxl(ws, result)
    previous_map = _metric_map(result.previous)
    with_previous = previous_date is not None
    _set_header_openpyxl(ws, output_type, current_date, previous_date)

    for metrics in groups.values():
        for metric in metrics:
            row = metric_rows[metric.target_row]
            # Never write labels/codes in template-only mode.
            if with_previous:
                previous = previous_map.get(metric.target_row)
                previous_value = previous.value if previous else 0
                previous_count = previous.employee_count if previous else 0
                values = {
                    6: _visible_value(previous_value),
                    8: _visible_value(previous_count),
                    10: _visible_value(metric.value),
                    12: _visible_value(metric.value - previous_value),
                    14: _visible_value(metric.employee_count),
                }
            else:
                values = {
                    6: _visible_value(metric.value),
                    8: _visible_value(metric.employee_count),
                }
            for column, value in values.items():
                ws.cell(row, column).value = value

    visible_sections = {
        section: _section_has_visible_content(metrics, previous_map, with_previous)
        for section, metrics in groups.items()
    }
    for section, metrics in groups.items():
        total_row = total_rows[section]
        section_row = section_rows[section]
        mapped_rows = {metric_rows[metric.target_row] for metric in metrics}
        if section_row not in mapped_rows:
            for column in VALUE_COLUMNS:
                ws.cell(section_row, column).value = None
        if total_row is not None:
            if visible_sections[section]:
                _write_total_formulas_openpyxl(
                    ws,
                    total_row,
                    (metric_rows[metric.target_row] for metric in metrics),
                    with_previous,
                )
            else:
                for column in VALUE_COLUMNS:
                    ws.cell(total_row, column).value = None

    summary_rows: list[int] = []
    for section, metrics in groups.items():
        if not visible_sections[section]:
            continue
        total_row = total_rows[section]
        if total_row is not None:
            summary_rows.append(total_row)
        else:
            summary_rows.extend(metric_rows[metric.target_row] for metric in metrics)
    _write_total_formulas_openpyxl(ws, grand_row, summary_rows, with_previous)
    ws.cell(grand_row, 3).value = "Gesamtsumme:"
    ws.row_dimensions[grand_row].hidden = False
    _hide_empty_sections_openpyxl(ws, groups, section_rows, total_rows, previous_map, with_previous, grand_row)
    _apply_common_sheet_rules_openpyxl(ws, total_rows.values(), grand_row, with_previous, metric_rows.values())
    resized = _resize_print_area_text(ws.print_area, grand_row)
    if resized:
        ws.print_area = resized
    return grand_row, grand_row


def _capture_summary_formulas_openpyxl(ws) -> dict[tuple[int, int], str]:
    formulas: dict[tuple[int, int], str] = {}
    for row in range(1, ws.max_row + 1):
        for column in VALUE_COLUMNS:
            value = ws.cell(row, column).value
            if isinstance(value, str) and value.startswith("="):
                formulas[(row, column)] = value
    return formulas


def _prepare_summary_sheet_openpyxl(
    ws,
    output_type: str,
    current_date: str,
    previous_date: str | None,
    selected_companies: list[str],
    template_formulas: dict[tuple[int, int], str],
    row_mappings: dict[str, dict[int, int]] | None = None,
) -> None:
    _set_header_openpyxl(ws, output_type, current_date, previous_date)
    formulas_to_write = dict(template_formulas) if template_formulas else dict(SUMMARY_FORMULA_BLUEPRINT)
    max_formula_row = max((row for row, _ in formulas_to_write), default=8)
    max_row = max(ws.max_row, max_formula_row)
    _clear_value_columns_openpyxl(ws, 8, max_row)
    for (row, column), formula in formulas_to_write.items():
        ws.cell(row, column).value = _rewrite_summary_formula(
            formula,
            selected_companies,
            row_mappings,
        )

    if not template_formulas:
        LOGGER.info(
            "Das Template-Blatt 'Summe' war leer; die freigegebenen "
            "Aggregationsformeln wurden eingefügt."
        )
    _fix_summary_barlohnumwandlung_openpyxl(ws)
    for row in range(1, ws.max_row + 1):
        for column in range(1, ws.max_column + 1):
            cell = ws.cell(row, column)
            cell.fill = PatternFill(fill_type=None)
            font = copy(cell.font)
            font.italic = False
            cell.font = font
            if column in (6, 8, 10, 12, 14) and cell.value not in (None, ""):
                cell.number_format = INTEGER_NUMBER_FORMAT


def _style_empty_bil_mog_openpyxl(ws) -> None:
    """Provide a conservative fallback layout when the local template is empty."""
    if ws.max_row > 1 or ws["A1"].value not in (None, ""):
        return
    thin = Side(style="thin", color="808080")
    medium = Side(style="medium", color="404040")
    ws.merge_cells("A1:E1")
    ws["A1"].font = Font(name="Arial", size=12, bold=True)
    ws["A1"].alignment = Alignment(horizontal="left")
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 46
    ws.column_dimensions["C"].width = 14
    ws.column_dimensions["D"].width = 23
    ws.column_dimensions["E"].width = 17
    for row in range(3, 34):
        for column in range(2, 6):
            ws.cell(row, column).border = Border(bottom=thin)
            ws.cell(row, column).font = Font(name="Arial", size=10)
    for cell in ws[3][1:5]:
        cell.font = Font(name="Arial", size=10, bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.fill = PatternFill("solid", fgColor="E7E6E6")
        cell.border = Border(top=medium, bottom=medium)
    for row in (5, 19):
        for column in range(2, 6):
            ws.cell(row, column).font = Font(name="Arial", size=10, bold=True)
            ws.cell(row, column).border = Border(top=medium, bottom=thin)
    for row in (12, 17, 26, 31, 33):
        for column in range(2, 6):
            ws.cell(row, column).font = Font(name="Arial", size=10, bold=True)
            ws.cell(row, column).border = Border(top=medium, bottom=medium)
    ws.print_area = "$A$1:$E$33"


def _write_jubilee_values_openpyxl(
    ws,
    previous_date: str | None,
    current_total: int | None,
    previous_total: int | None,
) -> None:
    row = _find_text_row_openpyxl(ws, "Jubiläumsrückstellungen", 1, ws.max_row)
    if row is None:
        return
    for column in (4, 5, 6, 8):
        ws.cell(row, column).value = None
        ws.cell(row, column).number_format = INTEGER_NUMBER_FORMAT
    if previous_date is not None:
        if current_total is not None:
            ws.cell(row, 4).value = current_total
        if previous_total is not None:
            ws.cell(row, 5).value = previous_total
        if current_total is not None or previous_total is not None:
            ws.cell(row, 6).value = f'=IF(AND(D{row}="",E{row}=""),"",N(D{row})-N(E{row}))'
        if previous_total is not None:
            ws.cell(row, 8).value = f'=IF(E{row}="","",ROUND(E{row}*$K$3,0))'
    elif current_total is not None:
        ws.cell(row, 4).value = current_total
        ws.cell(row, 5).value = f'=ROUND(D{row}*$H$3,0)'


def _prepare_bil_mog_sheet_openpyxl(
    ws,
    current_date: str,
    previous_date: str | None,
    interest_rate: float | None,
    company_results: list[CompanyResult],
    current_jubilee_total: int | None = None,
    previous_jubilee_total: int | None = None,
) -> None:
    _style_empty_bil_mog_openpyxl(ws)
    ws["A1"] = f"Ergebnisse zum Stichtag {current_date} gemäß BilMoG"

    if previous_date is not None:
        # The customer template with prior year has a wider, fixed layout:
        # D=current result, E=previous result, F=change, H=interest share.
        # Keep all template captions/formulas and update only the dynamic header
        # fields and the rate used by the existing H-column formulas.
        ws["D3"] = f"Ergebnisse zum {current_date} gem. BilMoG"
        ws["E3"] = f"Ergebnisse zum {previous_date} gem. BilMoG"
        ws["F3"] = "Zuführung"
        ws["H2"] = None
        ws["H3"] = "davon \nZinsanteil"
        ws["K3"] = interest_rate
        ws["K3"].number_format = "0.00%"

        # A real with-VJ template already contains all company blocks and their
        # formulas. Do not overwrite them. Only use generated formulas as a
        # fallback for an otherwise empty template.
        has_template_formulas = any(
            isinstance(ws.cell(row, column).value, str)
            and ws.cell(row, column).value.startswith("=")
            for row in range(6, min(ws.max_row, 98) + 1)
            for column in (4, 5, 6, 8)
        )
        if not has_template_formulas:
            for row in BILMOG_FORMULA_ROWS:
                for column in (4, 5, 6, 8):
                    ws.cell(row, column).value = None
            for (row, column), formula in _build_bil_mog_formulas(
                company_results, with_previous=True
            ).items():
                ws.cell(row, column).value = formula
        _fix_bilmog_previous_formulas_openpyxl(ws)
        for row in range(6, ws.max_row + 1):
            for column in (4, 5, 6, 8):
                if ws.cell(row, column).value not in (None, ""):
                    ws.cell(row, column).number_format = INTEGER_NUMBER_FORMAT
        _write_jubilee_values_openpyxl(
            ws, previous_date, current_jubilee_total, previous_jubilee_total
        )
        return

    # Compact template without a prior-year comparison.
    ws["D3"] = f"Ergebnisse zum {current_date} gem. BilMoG"
    for address, value in BILMOG_TEXT_CELLS.items():
        ws[address] = value
    ws["H2"] = "Zinssatz"
    ws["H3"] = interest_rate
    ws["H3"].number_format = "0.00%"
    for row in BILMOG_FORMULA_ROWS:
        ws.cell(row, 4).value = None
        ws.cell(row, 5).value = None
    for (row, column), formula in _build_bil_mog_formulas(company_results).items():
        ws.cell(row, column).value = formula
    for row in BILMOG_FORMULA_ROWS:
        ws.cell(row, 4).number_format = INTEGER_NUMBER_FORMAT
        ws.cell(row, 5).number_format = INTEGER_NUMBER_FORMAT
    for row in range(1, ws.max_row + 1):
        for column in range(1, ws.max_column + 1):
            cell = ws.cell(row, column)
            cell.fill = PatternFill(fill_type=None)
            font = copy(cell.font)
            font.italic = False
            cell.font = font
            if column in (4, 5, 6, 8) and cell.value not in (None, ""):
                cell.number_format = INTEGER_NUMBER_FORMAT
    if not str(ws.print_area or "").strip():
        ws.print_area = "$A$1:$E$33"
    _write_jubilee_values_openpyxl(
        ws, previous_date, current_jubilee_total, previous_jubilee_total
    )


def _clear_value_columns_openpyxl(ws, start_row: int, end_row: int) -> None:
    for row in range(start_row, end_row + 1):
        for column in (6, 8, 10, 12, 14):
            ws.cell(row, column).value = None


def _write_metric_openpyxl(
    ws,
    metric: MetricResult,
    previous: MetricResult | None,
    with_previous: bool,
    output_row: int,
) -> None:
    """Write result values without changing number formats, fills or fonts."""
    row = output_row
    ws.cell(row, 4).value = metric.label
    if with_previous:
        previous_value = previous.value if previous else 0
        previous_count = previous.employee_count if previous else 0
        difference = metric.value - previous_value
        values = {
            6: _visible_value(previous_value),
            8: _visible_value(previous_count),
            10: _visible_value(metric.value),
            12: _visible_value(difference),
            14: _visible_value(metric.employee_count),
        }
        for col, value in values.items():
            ws.cell(row, col).value = value
    else:
        ws.cell(row, 6).value = _visible_value(metric.value)
        ws.cell(row, 8).value = _visible_value(metric.employee_count)


def _write_total_formulas_openpyxl(
    ws,
    total_row: int,
    source_rows: Iterable[int],
    with_previous: bool,
) -> None:
    """Write subtotal/grand-total cells as formulas while preserving their style."""
    rows = list(source_rows)
    if with_previous:
        ws.cell(total_row, 6).value = _sum_formula("F", rows)
        ws.cell(total_row, 8).value = _sum_formula("H", rows)
        ws.cell(total_row, 10).value = _sum_formula("J", rows)
        ws.cell(total_row, 12).value = (
            f'=IF(AND(J{total_row}="",F{total_row}=""),"",'
            f'N(J{total_row})-N(F{total_row}))'
        )
        ws.cell(total_row, 14).value = _sum_formula("N", rows)
    else:
        ws.cell(total_row, 6).value = _sum_formula("F", rows)
        ws.cell(total_row, 8).value = _sum_formula("H", rows)


def _set_header_openpyxl(ws, output_type: str, current_date: str, previous_date: str | None) -> None:
    title = f"Entwicklung der Pensionsrückstellungen {current_date} - {OUTPUT_LABELS[output_type]}"
    ws["C2"] = title
    if previous_date:
        ws["F4"] = "Rückstellung per"
        ws["F5"] = previous_date
        ws["F6"] = "€"
        ws["H4"] = "Anzahl"
        ws["H5"] = "Berechtigte"
        ws["J4"] = "Rückstellung per"
        ws["J5"] = current_date
        ws["J6"] = "€"
        ws["L4"] = "Zuführung"
        ws["L6"] = "€"
        ws["N4"] = "Anzahl"
        ws["N5"] = "Berechtigte"
    else:
        ws["F4"] = "Rückstellung per"
        ws["F5"] = current_date
        ws["F6"] = "€"
        ws["H4"] = "Anzahl"
        ws["H5"] = "Berechtigte"


def _remove_external_links_openpyxl(workbook) -> None:
    try:
        workbook._external_links = []
    except Exception:
        pass
    try:
        for key in list(workbook.defined_names):
            formula = str(workbook.defined_names[key].attr_text or "")
            if "[" in formula or "Rechenlauf" in formula:
                del workbook.defined_names[key]
    except Exception:
        pass


def _prepare_sheet_openpyxl(
    ws,
    result: CompanyResult,
    company_config: dict[str, Any],
    output_type: str,
    current_date: str,
    previous_date: str | None,
    generic_clone: bool,
) -> tuple[int | None, int]:
    groups, section_rows, total_rows, calculated_grand = _report_rows(result)
    max_metric_row = _max_output_metric_row(result)
    existing_grand = _find_grand_total_row_openpyxl(ws)
    grand_row = _select_grand_total_row(
        result.company,
        existing_grand,
        calculated_grand,
        max_metric_row,
    )
    max_needed = max(ws.max_row, grand_row + 1, max_metric_row + 2)
    captured = _capture_template_section_codes_openpyxl(ws)
    style_section, style_metric, style_total, style_grand = _first_style_rows_openpyxl(ws)

    _set_header_openpyxl(ws, output_type, current_date, previous_date)
    _clear_value_columns_openpyxl(ws, 8, max_needed)
    if generic_clone or result.company == "Steering":
        for row in range(8, max_needed + 1):
            for col in (2, 3, 4):
                ws.cell(row, col).value = None

    company = result.company
    if company in OUTPUT_ROW_OVERRIDES:
        # Clear old labels from both the original and shifted lower block. Only
        # cell contents are removed; all formatting and page layout remain.
        for row in range(43, min(max_needed, 60) + 1):
            for col in (2, 3, 4):
                ws.cell(row, col).value = None
    ws["B8"] = COMPANY_HEADER_CODES.get(company, str(company_config.get("code", "")))
    ws["C8"] = COMPANY_NAMES.get(company, company)

    previous_map = _metric_map(result.previous)
    with_previous = previous_date is not None
    for section, metrics in groups.items():
        section_row = section_rows[section]
        visible_section = _section_has_visible_content(metrics, previous_map, with_previous)
        _ensure_row_format_openpyxl(ws, section_row, style_section)
        caption = _section_caption(company, section)
        if visible_section:
            ws.cell(section_row, 2).value = _section_code(company, section, caption, captured)
            ws.cell(section_row, 3).value = caption
            _set_bold_openpyxl(ws, section_row, (3,), True)
        else:
            _clear_row_contents(ws, section_row, (2, 3, 4, 6, 8, 10, 12, 14))
        for metric in metrics:
            output_row = _output_row(company, metric.target_row)
            previous_metric = previous_map.get(metric.target_row)
            _ensure_row_format_openpyxl(ws, output_row, style_metric)
            if visible_section:
                _write_metric_openpyxl(
                    ws,
                    metric,
                    previous_metric,
                    with_previous,
                    output_row,
                )
            else:
                _clear_row_contents(ws, output_row, (2, 3, 4, 6, 8, 10, 12, 14))
        total_row = total_rows[section]
        if total_row:
            if visible_section:
                if company == "Steering":
                    _copy_row_cell_formats_openpyxl(
                        ws,
                        style_total,
                        total_row,
                        range(3, 15),
                    )
                    ws.cell(total_row, 3).value = "Gesamtsumme:"
                    ws.cell(total_row, 4).value = None
                else:
                    _ensure_row_format_openpyxl(ws, total_row, style_total)
                _write_total_formulas_openpyxl(
                    ws,
                    total_row,
                    _metric_output_rows(metrics),
                    with_previous,
                )
            else:
                _clear_row_contents(ws, total_row, (2, 3, 4, 6, 8, 10, 12, 14))

    _ensure_row_format_openpyxl(ws, grand_row, style_grand)
    ws.cell(grand_row, 3).value = "Gesamtsumme:"
    _write_total_formulas_openpyxl(
        ws,
        grand_row,
        _summary_rows(groups, total_rows),
        previous_date is not None,
    )

    if company == "GRH":
        _apply_grh_format_corrections_openpyxl(
            ws,
            (row for row in total_rows.values() if row is not None),
            grand_row,
            style_metric,
            style_total,
            style_grand,
        )
        resized = _resize_print_area_text(ws.print_area, grand_row)
        if resized:
            ws.print_area = resized
    elif company == "SFS":
        _apply_sfs_format_corrections_openpyxl(
            ws,
            (row for row in total_rows.values() if row is not None),
            grand_row,
            style_metric,
            style_total,
            style_grand,
        )
        resized = _resize_print_area_text(ws.print_area, grand_row)
        if resized:
            ws.print_area = resized
    elif company == "Steering":
        _copy_row_cell_formats_openpyxl(ws, style_grand, grand_row, range(3, 15))
        _set_bold_openpyxl(ws, grand_row, (3, *VALUE_COLUMNS), True)
        resized = _resize_print_area_text(ws.print_area, grand_row)
        if resized:
            ws.print_area = resized

    all_metric_rows = [
        _output_row(company, metric.target_row)
        for metrics in groups.values()
        for metric in metrics
    ]
    _apply_common_sheet_rules_openpyxl(
        ws,
        total_rows.values(),
        grand_row,
        with_previous,
        all_metric_rows,
    )

    # Print area, visible columns, gridline setting, tab color and page layout
    # remain as defined in the selected template, except for the deliberately
    # compact Steering page and the one-row GRH extension required by MRP.
    return existing_grand, grand_row


def _clone_sheet_openpyxl(workbook, source_name: str, target_name: str):
    source = workbook[source_name]
    clone = workbook.copy_worksheet(source)
    # openpyxl does not clone images when copying a sheet.
    for image in getattr(source, "_images", []):
        try:
            image_copy = copy(image)
            image_copy.anchor = copy(image.anchor)
            clone.add_image(image_copy)
        except Exception:
            continue
    clone.title = target_name
    # copy_worksheet does not retain the sheet-scoped print area. Reapply only
    # the coordinate from the source so the target sheet keeps the same page
    # width/margins without rebuilding any page setup.
    source_print_area = str(source.print_area or "").strip()
    if source_print_area:
        clone.print_area = source_print_area.split("!", 1)[-1]
    return clone


def _write_openpyxl(
    destination: Path,
    template_path: Path,
    output_type: str,
    current_dataset: SourceDataset,
    previous_dataset: SourceDataset | None,
    company_results: list[CompanyResult],
    config: RuleConfig,
    generated_at: datetime,
    interest_rate: float | None,
    current_jubilee_total: int | None = None,
    previous_jubilee_total: int | None = None,
) -> None:
    keep_vba = template_path.suffix.casefold() == ".xlsm"
    workbook = load_workbook(template_path, keep_vba=keep_vba, keep_links=False, data_only=False)
    try:
        selected = [result.company for result in company_results]
        summary_formulas: dict[tuple[int, int], str] = {}
        if SUMMARY_SHEET_NAME in workbook.sheetnames:
            summary_formulas = _capture_summary_formulas_openpyxl(
                workbook[SUMMARY_SHEET_NAME]
            )
        if BILMOG_SHEET_NAME not in workbook.sheetnames:
            workbook.create_sheet(BILMOG_SHEET_NAME)
        generic_created: set[str] = set()
        for company in selected:
            if company in workbook.sheetnames:
                continue
            alias = SHEET_ALIASES.get(company)
            if alias and alias in workbook.sheetnames:
                workbook[alias].title = company
                continue
            if "Gesellschaft" in workbook.sheetnames:
                _clone_sheet_openpyxl(workbook, "Gesellschaft", company)
                generic_created.add(company)
                continue
            base = BASE_SHEETS.get(company, company)
            if base not in workbook.sheetnames:
                raise ValueError(
                    f"Das lokale Template enthält weder das Blatt {company!r}, "
                    f"noch 'Gesellschaft' oder die Basis {base!r}."
                )
            _clone_sheet_openpyxl(workbook, base, company)
            generic_created.add(company)

        include_bil_mog = True
        sheets_to_keep = set(selected)
        if SUMMARY_SHEET_NAME in workbook.sheetnames:
            sheets_to_keep.add(SUMMARY_SHEET_NAME)
        if include_bil_mog:
            sheets_to_keep.add(BILMOG_SHEET_NAME)
        for ws in list(workbook.worksheets):
            if ws.title not in sheets_to_keep:
                workbook.remove(ws)

        current_date = _date_from_source_b5(current_dataset, generated_at)
        previous_date = _date_from_source_b5(previous_dataset, generated_at) if previous_dataset else None
        result_map = {result.company: result for result in company_results}
        summary_row_mappings: dict[str, dict[int, int]] = {}
        for company in selected:
            if company not in generic_created and company not in {"GRH", "SFS"}:
                existing_grand, output_grand = _fill_existing_template_sheet_openpyxl(
                    workbook[company],
                    result_map[company],
                    output_type,
                    current_date,
                    previous_date,
                )
            else:
                existing_grand, output_grand = _prepare_sheet_openpyxl(
                    workbook[company],
                    result_map[company],
                    config.companies[company],
                    output_type,
                    current_date,
                    previous_date,
                    company in generic_created,
                )
            if existing_grand is not None and existing_grand != output_grand:
                summary_row_mappings.setdefault(company, {})[existing_grand] = output_grand

        if SUMMARY_SHEET_NAME in workbook.sheetnames:
            _prepare_summary_sheet_openpyxl(
                workbook[SUMMARY_SHEET_NAME],
                output_type,
                current_date,
                previous_date,
                selected,
                summary_formulas,
                summary_row_mappings,
            )

        if include_bil_mog:
            if output_type_requires_interest_rate(output_type) and interest_rate is None:
                raise ValueError("Das Blatt 'BilMoG' benötigt einen Zinssatz.")
            _prepare_bil_mog_sheet_openpyxl(
                workbook[BILMOG_SHEET_NAME],
                current_date,
                previous_date,
                interest_rate,
                company_results,
                current_jubilee_total,
                previous_jubilee_total,
            )

        _remove_external_links_openpyxl(workbook)
        ordered_sheets = selected + (
            [SUMMARY_SHEET_NAME]
            if SUMMARY_SHEET_NAME in workbook.sheetnames
            else []
        ) + ([BILMOG_SHEET_NAME] if include_bil_mog else [])
        workbook._sheets = [workbook[name] for name in ordered_sheets]
        workbook.active = 0
        try:
            workbook.calculation.calcMode = "auto"
            workbook.calculation.fullCalcOnLoad = True
            workbook.calculation.forceFullCalc = True
        except Exception:
            pass
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_name(destination.stem + ".tmp" + destination.suffix)
        workbook.save(temporary)
        temporary.replace(destination)
    finally:
        workbook.close()



def _com_sheet(workbook, name: str):
    try:
        return workbook.Worksheets(name)
    except Exception:
        return None


def _com_normal_value(ws, row: int, col: int) -> str:
    try:
        return _normalise_text(ws.Cells(row, col).Value)
    except Exception:
        return ""


def _find_grand_total_row_com(ws, max_row: int) -> int | None:
    for row in range(8, max_row + 1):
        if any("gesamtsumme" in _com_normal_value(ws, row, col) for col in (2, 3, 4)):
            return row
    return None


def _capture_codes_com(ws, max_row: int) -> dict[str, str]:
    result: dict[str, str] = {}
    for row in range(8, max_row + 1):
        code = ws.Cells(row, 2).Value
        caption = ws.Cells(row, 3).Value
        if code not in (None, "") and caption not in (None, ""):
            result[_normalise_text(caption)] = str(code)
    return result


def _style_rows_com(ws, max_row: int) -> tuple[int, int, int, int]:
    section, metric, total = 10, 12, 16
    grand = _find_grand_total_row_com(ws, max_row) or max_row
    for row in range(8, max_row + 1):
        if ws.Cells(row, 2).Value not in (None, "") and ws.Cells(row, 3).Value not in (None, ""):
            section = row
            break
    for row in range(8, max_row + 1):
        if ws.Cells(row, 4).Value not in (None, ""):
            metric = row
            break
    # A conventional total row is usually directly after the first metric block.
    for row in range(metric + 1, max_row + 1):
        try:
            if ws.Cells(row, 6).Borders(9).LineStyle not in (0, None):
                total = row
                break
        except Exception:
            continue
    return section, metric, total, grand


def _row_is_unformatted_com(ws, row: int) -> bool:
    try:
        return all(ws.Cells(row, col).Style == "Normal" for col in range(2, 15))
    except Exception:
        return False


def _copy_format_com(excel, ws, source_row: int, target_row: int) -> None:
    if source_row == target_row:
        return
    ws.Rows(source_row).Copy()
    ws.Rows(target_row).PasteSpecial(Paste=-4122)  # xlPasteFormats
    ws.Rows(target_row).RowHeight = ws.Rows(source_row).RowHeight
    excel.CutCopyMode = False


def _ensure_format_com(excel, ws, row: int, source_row: int) -> None:
    if _row_is_unformatted_com(ws, row):
        _copy_format_com(excel, ws, source_row, row)


def _copy_cell_formats_com(excel, ws, source_row: int, target_row: int) -> None:
    source = ws.Range(ws.Cells(source_row, 3), ws.Cells(source_row, 14))
    target = ws.Range(ws.Cells(target_row, 3), ws.Cells(target_row, 14))
    source.Copy()
    target.PasteSpecial(Paste=-4122)  # xlPasteFormats
    excel.CutCopyMode = False


def _set_bold_com(ws, row: int, columns: Iterable[int], bold: bool) -> None:
    for column in columns:
        ws.Cells(row, column).Font.Bold = bool(bold)


def _clear_row_contents_com(ws, row: int, columns: Iterable[int]) -> None:
    for column in columns:
        ws.Cells(row, column).ClearContents()


def _move_top_border_to_bottom_com(ws, row: int, columns: Iterable[int]) -> None:
    # Excel border indices: 8 = xlEdgeTop, 9 = xlEdgeBottom.
    for column in columns:
        cell = ws.Cells(row, column)
        top = cell.Borders(8)
        try:
            line_style = top.LineStyle
        except Exception:
            continue
        if line_style in (None, 0, -4142):
            continue
        weight = top.Weight
        color = top.Color
        bottom = cell.Borders(9)
        bottom.LineStyle = line_style
        bottom.Weight = weight
        bottom.Color = color
        top.LineStyle = -4142  # xlLineStyleNone


def _apply_shifted_lower_block_formats_com(excel, ws, style_metric: int) -> None:
    _set_bold_com(ws, 49, (3,), True)
    _set_bold_com(ws, 53, (3,), True)
    _set_bold_com(ws, 51, VALUE_COLUMNS, True)
    _set_bold_com(ws, 55, VALUE_COLUMNS, True)

    # Remove the subtotal/grand-total outline inherited by row 59 and restore a
    # normal metric row before applying bold to the MRP results.
    source = ws.Range(ws.Cells(style_metric, 3), ws.Cells(style_metric, 14))
    target = ws.Range(ws.Cells(59, 3), ws.Cells(59, 14))
    source.Copy()
    target.PasteSpecial(Paste=-4122)  # xlPasteFormats
    excel.CutCopyMode = False
    _set_bold_com(ws, 59, VALUE_COLUMNS, True)


def _apply_sfs_format_corrections_com(
    excel,
    ws,
    total_rows: Iterable[int],
    grand_row: int,
    style_metric: int,
    style_total: int,
    style_grand: int,
) -> None:
    for row in total_rows:
        _copy_cell_formats_com(excel, ws, style_total, row)
        _set_bold_com(ws, row, (3, *VALUE_COLUMNS), True)
    _copy_cell_formats_com(excel, ws, style_grand, grand_row)
    _set_bold_com(ws, grand_row, (3, *VALUE_COLUMNS), True)
    _apply_shifted_lower_block_formats_com(excel, ws, style_metric)


def _apply_grh_format_corrections_com(
    excel,
    ws,
    total_rows: Iterable[int],
    grand_row: int,
    style_metric: int,
    style_total: int,
    style_grand: int,
) -> None:
    for row in total_rows:
        _copy_cell_formats_com(excel, ws, style_total, row)
        _set_bold_com(ws, row, VALUE_COLUMNS, True)
    _copy_cell_formats_com(excel, ws, style_grand, grand_row)
    _set_bold_com(ws, grand_row, (3, *VALUE_COLUMNS), True)

    _apply_shifted_lower_block_formats_com(excel, ws, style_metric)
    _set_bold_com(ws, 45, VALUE_COLUMNS, False)
    _set_bold_com(ws, 46, VALUE_COLUMNS, False)
    _set_bold_com(ws, 47, VALUE_COLUMNS, True)



def _row_label_text_com(ws, row: int) -> str:
    return " ".join(
        str(ws.Cells(row, column).Value2 or "") for column in (2, 3, 4)
    ).strip()


def _find_text_row_com(ws, wanted: str, start_row: int, end_row: int) -> int | None:
    for row in range(max(1, start_row), max(start_row, end_row) + 1):
        if _template_text_matches(_row_label_text_com(ws, row), wanted):
            return row
    return None


def _template_row_map_com(
    ws,
    result: CompanyResult,
    used_max: int,
) -> tuple[OrderedDict[str, list[MetricResult]], dict[str, int], dict[int, int], dict[str, int | None], int]:
    groups = _group_metrics(result.current)
    section_rows: dict[str, int] = {}
    cursor = 8
    for section in groups:
        caption = _section_caption(result.company, section)
        found = _find_text_row_com(ws, caption, cursor, used_max)
        if found is None:
            found = max(8, min(metric.target_row for metric in groups[section]) - 2)
        section_rows[section] = found
        cursor = found + 1

    ordered_sections = list(groups)
    metric_rows: dict[int, int] = {}
    total_rows: dict[str, int | None] = {}
    existing_grand = _find_grand_total_row_com(ws, used_max)
    for index, section in enumerate(ordered_sections):
        section_row = section_rows[section]
        next_section = (
            section_rows[ordered_sections[index + 1]]
            if index + 1 < len(ordered_sections)
            else (existing_grand or used_max + 1)
        )
        search_start = section_row
        search_end = max(search_start, next_section - 1)
        used_rows: set[int] = set()
        for metric in groups[section]:
            found = _template_metric_row_override(result.company, metric.target_row)
            if found is not None and not (search_start <= found <= search_end):
                found = None
            for row in range(search_start, search_end + 1):
                if found is not None:
                    break
                if row in used_rows:
                    continue
                if _template_text_matches(_row_label_text_com(ws, row), metric.label):
                    found = row
                    break
            if found is None and len(groups[section]) == 1:
                found = section_row
            if found is None:
                found = metric.target_row
            metric_rows[metric.target_row] = found
            used_rows.add(found)
        rows = sorted(metric_rows[metric.target_row] for metric in groups[section])
        if len(rows) > 1:
            candidate = rows[-1] + 1
            total_rows[section] = candidate if candidate < next_section else None
        else:
            total_rows[section] = None

    grand_row = existing_grand or max([*metric_rows.values(), 8]) + 2
    return groups, section_rows, metric_rows, total_rows, grand_row


def _apply_common_sheet_rules_com(
    ws,
    total_rows: Iterable[int],
    grand_row: int,
    with_previous: bool,
    used_max: int,
    metric_rows: Iterable[int] = (),
) -> None:
    """Final Excel-COM presentation pass after every template/style copy."""
    max_col = max(int(ws.UsedRange.Columns.Count), 14)
    value_columns = (6, 8, 10, 12, 14) if with_previous else (6, 8)
    metric_set = {int(row) for row in metric_rows if row is not None}
    total_set = {int(row) for row in total_rows if row is not None}

    try:
        ws.Range(ws.Cells(1, 2), ws.Cells(used_max, 2)).ClearContents()
    except Exception:
        pass
    try:
        used = ws.Range(ws.Cells(1, 1), ws.Cells(used_max, max_col))
        used.Interior.Pattern = -4142  # xlPatternNone
        used.Font.Italic = False
    except Exception:
        pass

    # NumberFormatLocal is required for German Excel. NumberFormat alone was
    # later restored by copied template styles and produced values such as
    # 73977609,0.
    for column in value_columns:
        try:
            ws.Range(ws.Cells(1, column), ws.Cells(used_max, column)).NumberFormatLocal = INTEGER_NUMBER_FORMAT_LOCAL
        except Exception:
            try:
                ws.Range(ws.Cells(1, column), ws.Cells(used_max, column)).NumberFormat = INTEGER_NUMBER_FORMAT
            except Exception:
                pass

    # Detail metrics: normal font, no top/bottom subtotal line.
    for row in metric_set - total_set - {grand_row}:
        try:
            rng = ws.Range(ws.Cells(row, min(value_columns)), ws.Cells(row, max(value_columns)))
            rng.Font.Bold = False
            rng.Font.Italic = False
            for border_index in (8, 9):  # xlEdgeTop / xlEdgeBottom
                rng.Borders(border_index).LineStyle = 0
        except Exception:
            pass

    # Subtotals: bold values and a separator directly above the sum.
    for row in total_set - {grand_row}:
        try:
            rng = ws.Range(ws.Cells(row, min(value_columns)), ws.Cells(row, max(value_columns)))
            rng.Font.Bold = True
            rng.Font.Italic = False
            rng.Borders(9).LineStyle = 0
            top = rng.Borders(8)
            top.LineStyle = 1
            top.Weight = 2
            top.Color = 0
            rng.NumberFormatLocal = INTEGER_NUMBER_FORMAT_LOCAL
        except Exception:
            pass

    # Grand total: complete heavy outline from label to final count.
    end_column = 14 if with_previous else 8
    try:
        rng = ws.Range(ws.Cells(grand_row, 4), ws.Cells(grand_row, end_column))
        rng.Font.Bold = True
        rng.Font.Italic = False
        for border_index in (7, 8, 9, 10):
            border = rng.Borders(border_index)
            border.LineStyle = 1
            border.Weight = 3
            border.Color = 0
        for column in value_columns:
            ws.Cells(grand_row, column).NumberFormatLocal = INTEGER_NUMBER_FORMAT_LOCAL
    except Exception:
        pass

    try:
        if used_max > grand_row:
            ws.Range(ws.Cells(grand_row + 1, 10), ws.Cells(used_max, max_col)).ClearContents()
    except Exception:
        pass


def _hide_empty_sections_com(
    ws,
    groups: OrderedDict[str, list[MetricResult]],
    section_rows: dict[str, int],
    previous_map: dict[int, MetricResult],
    with_previous: bool,
    grand_row: int,
) -> None:
    ordered = list(groups)
    clear_columns = (2, 3, 4, 6, 8, 10, 12, 14)
    for index, section in enumerate(ordered):
        start = section_rows[section]
        end = (section_rows[ordered[index + 1]] - 1) if index + 1 < len(ordered) else grand_row - 1
        end = max(start, end)
        visible = _section_has_visible_content(groups[section], previous_map, with_previous)
        try:
            ws.Rows(f"{start}:{end}").Hidden = not visible
            if not visible:
                for column in clear_columns:
                    ws.Range(ws.Cells(start, column), ws.Cells(end, column)).ClearContents()
        except Exception:
            pass


def _fix_summary_barlohnumwandlung_com(ws) -> None:
    try:
        used_max = max(int(ws.UsedRange.Rows.Count), 1)
        heading_row = _find_text_row_com(ws, "Barlohnumwandlung", 1, used_max)
        if heading_row is None:
            return
        detail_row = _find_text_row_com(
            ws, "Einbehalte von Mitarbeiter", heading_row + 1, min(used_max, heading_row + 5)
        )
        if detail_row is None:
            detail_row = heading_row + 2
        for column in VALUE_COLUMNS:
            source = ws.Cells(heading_row, column)
            target = ws.Cells(detail_row, column)
            if (source.Formula not in (None, "") or source.Value2 not in (None, "")) and target.Formula in (None, "") and target.Value2 in (None, ""):
                target.Formula = source.Formula
            source.ClearContents()
            target.NumberFormatLocal = INTEGER_NUMBER_FORMAT_LOCAL
        for row in range(detail_row + 1, used_max + 1):
            for column in VALUE_COLUMNS:
                formula = ws.Cells(row, column).Formula
                if isinstance(formula, str) and formula.startswith("="):
                    ws.Cells(row, column).Formula = re.sub(
                        rf"(?<!\d){heading_row}(?!\d)", str(detail_row), formula
                    )
    except Exception:
        LOGGER.warning("Barlohnumwandlung im Blatt Summe konnte nicht verschoben werden.")

def _fix_bilmog_previous_formulas_com(ws) -> None:
    try:
        used_max = max(int(ws.UsedRange.Rows.Count), 6)
        for row in range(6, used_max + 1):
            formula = ws.Cells(row, 5).Formula
            if isinstance(formula, str) and formula.startswith("="):
                ws.Cells(row, 5).Formula = re.sub(r"!H(\d+)", r"!F\1", formula)
        rng = ws.Range(ws.Cells(1, 1), ws.Cells(used_max, max(int(ws.UsedRange.Columns.Count), 8)))
        rng.Interior.Pattern = -4142
        rng.Font.Italic = False
        ws.Range(f"D6:H{used_max}").NumberFormatLocal = INTEGER_NUMBER_FORMAT_LOCAL
    except Exception:
        LOGGER.warning("BilMoG-Vorjahresformeln konnten nicht vollständig korrigiert werden.")


def _fill_existing_template_sheet_com(
    ws,
    result: CompanyResult,
    output_type: str,
    current_date: str,
    previous_date: str | None,
    used_max: int,
) -> tuple[int | None, int]:
    groups, section_rows, metric_rows, total_rows, grand_row = _template_row_map_com(
        ws, result, used_max
    )
    previous_map = _metric_map(result.previous)
    with_previous = previous_date is not None
    _set_header_com(ws, output_type, current_date, previous_date)

    for metrics in groups.values():
        for metric in metrics:
            row = metric_rows[metric.target_row]
            previous = previous_map.get(metric.target_row)
            if with_previous:
                previous_value = previous.value if previous else 0
                previous_count = previous.employee_count if previous else 0
                values = {
                    6: _visible_value(previous_value),
                    8: _visible_value(previous_count),
                    10: _visible_value(metric.value),
                    12: _visible_value(metric.value - previous_value),
                    14: _visible_value(metric.employee_count),
                }
            else:
                values = {
                    6: _visible_value(metric.value),
                    8: _visible_value(metric.employee_count),
                }
            for column, value in values.items():
                if value is None:
                    ws.Cells(row, column).ClearContents()
                else:
                    ws.Cells(row, column).Value2 = value

    visible_sections = {
        section: _section_has_visible_content(metrics, previous_map, with_previous)
        for section, metrics in groups.items()
    }
    for section, metrics in groups.items():
        total_row = total_rows[section]
        section_row = section_rows[section]
        mapped_rows = {metric_rows[metric.target_row] for metric in metrics}
        if section_row not in mapped_rows:
            for column in VALUE_COLUMNS:
                ws.Cells(section_row, column).ClearContents()
        if total_row is not None:
            if visible_sections[section]:
                _write_total_formulas_com(
                    ws,
                    total_row,
                    (metric_rows[metric.target_row] for metric in metrics),
                    with_previous,
                )
            else:
                for column in VALUE_COLUMNS:
                    ws.Cells(total_row, column).ClearContents()

    summary_rows: list[int] = []
    for section, metrics in groups.items():
        if not visible_sections[section]:
            continue
        total_row = total_rows[section]
        if total_row is not None:
            summary_rows.append(total_row)
        else:
            summary_rows.extend(metric_rows[metric.target_row] for metric in metrics)
    _write_total_formulas_com(ws, grand_row, summary_rows, with_previous)
    ws.Cells(grand_row, 3).Value2 = "Gesamtsumme:"
    ws.Rows(grand_row).Hidden = False
    _hide_empty_sections_com(ws, groups, section_rows, previous_map, with_previous, grand_row)
    _apply_common_sheet_rules_com(ws, total_rows.values(), grand_row, with_previous, used_max, metric_rows.values())
    _set_compact_print_area_com(ws, grand_row)
    return grand_row, grand_row


def _capture_summary_formulas_com(ws) -> dict[tuple[int, int], str]:
    formulas: dict[tuple[int, int], str] = {}
    used_max = max(int(ws.UsedRange.Rows.Count), 8)
    for row in range(1, used_max + 1):
        for column in VALUE_COLUMNS:
            formula = ws.Cells(row, column).Formula
            if isinstance(formula, str) and formula.startswith("="):
                formulas[(row, column)] = formula
    return formulas


def _prepare_summary_sheet_com(
    ws,
    output_type: str,
    current_date: str,
    previous_date: str | None,
    selected_companies: list[str],
    template_formulas: dict[tuple[int, int], str],
    row_mappings: dict[str, dict[int, int]] | None = None,
) -> None:
    _set_header_com(ws, output_type, current_date, previous_date)
    formulas_to_write = dict(template_formulas) if template_formulas else dict(SUMMARY_FORMULA_BLUEPRINT)
    used_max = max(
        int(ws.UsedRange.Rows.Count),
        max((row for row, _ in formulas_to_write), default=8),
    )
    for column in VALUE_COLUMNS:
        ws.Range(ws.Cells(8, column), ws.Cells(used_max, column)).ClearContents()
    for (row, column), formula in formulas_to_write.items():
        ws.Cells(row, column).Formula = _rewrite_summary_formula(
            formula,
            selected_companies,
            row_mappings,
        )
    if not template_formulas:
        LOGGER.info(
            "Das Template-Blatt 'Summe' war leer; die freigegebenen "
            "Aggregationsformeln wurden eingefügt."
        )
    _fix_summary_barlohnumwandlung_com(ws)
    try:
        used_max = max(int(ws.UsedRange.Rows.Count), 1)
        used_col = max(int(ws.UsedRange.Columns.Count), 14)
        rng = ws.Range(ws.Cells(1, 1), ws.Cells(used_max, used_col))
        rng.Interior.Pattern = -4142
        rng.Font.Italic = False
        for column in (6, 8, 10, 12, 14):
            ws.Range(ws.Cells(1, column), ws.Cells(used_max, column)).NumberFormatLocal = INTEGER_NUMBER_FORMAT_LOCAL
    except Exception:
        pass


def _style_empty_bil_mog_com(ws) -> None:
    try:
        is_empty = int(ws.UsedRange.Cells.Count) <= 1 and ws.Range("A1").Value in (None, "")
    except Exception:
        is_empty = False
    if not is_empty:
        return
    try:
        ws.Range("A1:E1").Merge()
        ws.Range("A1").Font.Bold = True
        ws.Range("A1").Font.Size = 12
        ws.Columns("A").ColumnWidth = 3
        ws.Columns("B").ColumnWidth = 46
        ws.Columns("C").ColumnWidth = 14
        ws.Columns("D").ColumnWidth = 23
        ws.Columns("E").ColumnWidth = 17
        ws.Range("B3:E33").Font.Name = "Arial"
        ws.Range("B3:E33").Font.Size = 10
        ws.Range("B3:E3").Font.Bold = True
        ws.Range("B3:E3").HorizontalAlignment = -4108  # xlCenter
        ws.Range("B3:E3").WrapText = True
        for row in (5, 12, 17, 19, 26, 31, 33):
            ws.Range(ws.Cells(row, 2), ws.Cells(row, 5)).Font.Bold = True
        ws.PageSetup.PrintArea = "$A$1:$E$33"
    except Exception:
        LOGGER.warning("Fallback-Formatierung für BilMoG konnte nicht vollständig gesetzt werden.")


def _write_jubilee_values_com(
    ws,
    previous_date: str | None,
    current_total: int | None,
    previous_total: int | None,
) -> None:
    try:
        used_max = max(int(ws.UsedRange.Rows.Count), 1)
        row = _find_text_row_com(ws, "Jubiläumsrückstellungen", 1, used_max)
        if row is None:
            return
        for column in (4, 5, 6, 8):
            ws.Cells(row, column).ClearContents()
            ws.Cells(row, column).NumberFormatLocal = INTEGER_NUMBER_FORMAT_LOCAL
        if previous_date is not None:
            if current_total is not None:
                ws.Cells(row, 4).Value2 = current_total
            if previous_total is not None:
                ws.Cells(row, 5).Value2 = previous_total
            if current_total is not None or previous_total is not None:
                ws.Cells(row, 6).Formula = f'=IF(AND(D{row}="",E{row}=""),"",N(D{row})-N(E{row}))'
            if previous_total is not None:
                ws.Cells(row, 8).Formula = f'=IF(E{row}="","",ROUND(E{row}*$K$3,0))'
        elif current_total is not None:
            ws.Cells(row, 4).Value2 = current_total
            ws.Cells(row, 5).Formula = f'=ROUND(D{row}*$H$3,0)'
    except Exception:
        LOGGER.warning("Jubiläumsrückstellungen konnten nicht in BilMoG geschrieben werden.")


def _prepare_bil_mog_sheet_com(
    ws,
    current_date: str,
    previous_date: str | None,
    interest_rate: float | None,
    company_results: list[CompanyResult],
    current_jubilee_total: int | None = None,
    previous_jubilee_total: int | None = None,
) -> None:
    _style_empty_bil_mog_com(ws)
    ws.Range("A1").Value2 = f"Ergebnisse zum Stichtag {current_date} gemäß BilMoG"

    if previous_date is not None:
        ws.Range("D3").Value2 = f"Ergebnisse zum {current_date} gem. BilMoG"
        ws.Range("E3").Value2 = f"Ergebnisse zum {previous_date} gem. BilMoG"
        ws.Range("F3").Value2 = "Zuführung"
        ws.Range("H2").ClearContents()
        ws.Range("H3").Value2 = "davon \nZinsanteil"
        ws.Range("K3").Value2 = interest_rate
        ws.Range("K3").NumberFormatLocal = "0,00%"

        has_template_formulas = False
        try:
            used_max = min(max(int(ws.UsedRange.Rows.Count), 6), 98)
            for row in range(6, used_max + 1):
                for column in (4, 5, 6, 8):
                    formula = ws.Cells(row, column).Formula
                    if isinstance(formula, str) and formula.startswith("="):
                        has_template_formulas = True
                        break
                if has_template_formulas:
                    break
        except Exception:
            has_template_formulas = True

        if not has_template_formulas:
            for row in BILMOG_FORMULA_ROWS:
                for column in (4, 5, 6, 8):
                    ws.Cells(row, column).ClearContents()
            for (row, column), formula in _build_bil_mog_formulas(
                company_results, with_previous=True
            ).items():
                ws.Cells(row, column).Formula = formula
        _fix_bilmog_previous_formulas_com(ws)
        try:
            ws.Range("D6:H98").NumberFormatLocal = INTEGER_NUMBER_FORMAT_LOCAL
        except Exception:
            pass
        _write_jubilee_values_com(
            ws, previous_date, current_jubilee_total, previous_jubilee_total
        )
        return

    ws.Range("D3").Value2 = f"Ergebnisse zum {current_date} gem. BilMoG"
    for address, value in BILMOG_TEXT_CELLS.items():
        ws.Range(address).Value2 = value
    ws.Range("H2").Value2 = "Zinssatz"
    ws.Range("H3").Value2 = interest_rate
    ws.Range("H3").NumberFormatLocal = "0,00%"
    for row in BILMOG_FORMULA_ROWS:
        ws.Cells(row, 4).ClearContents()
        ws.Cells(row, 5).ClearContents()
    for (row, column), formula in _build_bil_mog_formulas(company_results).items():
        ws.Cells(row, column).Formula = formula
    try:
        used_max = max(int(ws.UsedRange.Rows.Count), 33)
        used_col = max(int(ws.UsedRange.Columns.Count), 5)
        rng = ws.Range(ws.Cells(1, 1), ws.Cells(used_max, used_col))
        rng.Interior.Pattern = -4142
        rng.Font.Italic = False
        ws.Range("D6:E33").NumberFormatLocal = INTEGER_NUMBER_FORMAT_LOCAL
        if not str(ws.PageSetup.PrintArea or "").strip():
            ws.PageSetup.PrintArea = "$A$1:$E$33"
    except Exception:
        pass
    _write_jubilee_values_com(
        ws, previous_date, current_jubilee_total, previous_jubilee_total
    )


def _set_compact_print_area_com(ws, end_row: int) -> None:
    try:
        resized = _resize_print_area_text(ws.PageSetup.PrintArea, end_row)
        if resized:
            ws.PageSetup.PrintArea = resized
    except Exception:
        LOGGER.warning("Druckbereich konnte für Blatt %s nicht angepasst werden.", ws.Name)



def _break_external_links_com(workbook) -> None:
    try:
        sources = workbook.LinkSources(1)  # xlLinkTypeExcelLinks
    except Exception:
        sources = None
    if not sources:
        return
    try:
        for source in list(sources):
            workbook.BreakLink(Name=source, Type=1)
    except Exception:
        pass


def _set_header_com(ws, output_type: str, current_date: str, previous_date: str | None) -> None:
    """Update header text only; never alter visibility or page layout."""
    ws.Range("C2").Value2 = (
        f"Entwicklung der Pensionsrückstellungen {current_date} - "
        f"{OUTPUT_LABELS[output_type]}"
    )
    if previous_date:
        values = {
            "F4": "Rückstellung per",
            "F5": previous_date,
            "F6": "€",
            "H4": "Anzahl",
            "H5": "Berechtigte",
            "J4": "Rückstellung per",
            "J5": current_date,
            "J6": "€",
            "L4": "Zuführung",
            "L6": "€",
            "N4": "Anzahl",
            "N5": "Berechtigte",
        }
    else:
        values = {
            "F4": "Rückstellung per",
            "F5": current_date,
            "F6": "€",
            "H4": "Anzahl",
            "H5": "Berechtigte",
        }

    for address, value in values.items():
        ws.Range(address).Value2 = value


def _write_metric_com(
    ws,
    metric: MetricResult,
    previous: MetricResult | None,
    with_previous: bool,
    output_row: int,
) -> None:
    """Write values only; all number formats and colours come from the template."""
    row = output_row
    ws.Cells(row, 4).Value2 = metric.label
    if with_previous:
        previous_value = previous.value if previous else 0
        previous_count = previous.employee_count if previous else 0
        difference = metric.value - previous_value
        values = {
            6: _visible_value(previous_value),
            8: _visible_value(previous_count),
            10: _visible_value(metric.value),
            12: _visible_value(difference),
            14: _visible_value(metric.employee_count),
        }
        for col, value in values.items():
            if value is None:
                ws.Cells(row, col).ClearContents()
            else:
                ws.Cells(row, col).Value2 = value
    else:
        for col, value in (
            (6, _visible_value(metric.value)),
            (8, _visible_value(metric.employee_count)),
        ):
            if value is None:
                ws.Cells(row, col).ClearContents()
            else:
                ws.Cells(row, col).Value2 = value


def _write_total_formulas_com(
    ws,
    row: int,
    source_rows: Iterable[int],
    with_previous: bool,
) -> None:
    """Write subtotal/grand-total cells as native Excel formulas."""
    rows = list(source_rows)
    if with_previous:
        formulas = {
            6: _sum_formula("F", rows),
            8: _sum_formula("H", rows),
            10: _sum_formula("J", rows),
            12: f'=IF(AND(J{row}="",F{row}=""),"",N(J{row})-N(F{row}))',
            14: _sum_formula("N", rows),
        }
    else:
        formulas = {6: _sum_formula("F", rows), 8: _sum_formula("H", rows)}

    for col, formula in formulas.items():
        ws.Cells(row, col).Formula = formula


def _write_com(
    destination: Path,
    template_path: Path,
    output_type: str,
    current_dataset: SourceDataset,
    previous_dataset: SourceDataset | None,
    company_results: list[CompanyResult],
    config: RuleConfig,
    generated_at: datetime,
    interest_rate: float | None,
    current_jubilee_total: int | None = None,
    previous_jubilee_total: int | None = None,
) -> None:
    import pythoncom  # type: ignore[import-not-found]
    import win32com.client  # type: ignore[import-not-found]

    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(template_path, destination)
    pythoncom.CoInitialize()
    excel = None
    workbook = None
    save_completed = False
    try:
        excel = win32com.client.DispatchEx("Excel.Application")
        excel.Visible = False
        excel.DisplayAlerts = False
        excel.ScreenUpdating = False
        workbook = excel.Workbooks.Open(
            str(destination.resolve()),
            UpdateLinks=0,
            ReadOnly=False,
            IgnoreReadOnlyRecommended=True,
        )
        summary_formulas: dict[tuple[int, int], str] = {}
        summary_ws = _com_sheet(workbook, SUMMARY_SHEET_NAME)
        if summary_ws is not None:
            summary_formulas = _capture_summary_formulas_com(summary_ws)
        include_bil_mog = True
        bil_mog_ws = _com_sheet(workbook, BILMOG_SHEET_NAME)
        if bil_mog_ws is None:
            bil_mog_ws = workbook.Worksheets.Add(
                After=workbook.Worksheets(workbook.Worksheets.Count)
            )
            bil_mog_ws.Name = BILMOG_SHEET_NAME
        _break_external_links_com(workbook)
        selected = [result.company for result in company_results]
        generic_created: set[str] = set()
        for company in selected:
            if _com_sheet(workbook, company) is not None:
                continue
            alias = SHEET_ALIASES.get(company)
            if alias and _com_sheet(workbook, alias) is not None:
                workbook.Worksheets(alias).Name = company
                continue
            generic = _com_sheet(workbook, "Gesellschaft")
            if generic is not None:
                generic.Copy(After=workbook.Worksheets(workbook.Worksheets.Count))
                workbook.Worksheets(workbook.Worksheets.Count).Name = company
                generic_created.add(company)
                continue
            base = BASE_SHEETS.get(company, company)
            source = _com_sheet(workbook, base)
            if source is None:
                raise ValueError(
                    f"Das lokale Template enthält weder das Blatt {company!r}, "
                    f"noch 'Gesellschaft' oder die Basis {base!r}."
                )
            source.Copy(After=workbook.Worksheets(workbook.Worksheets.Count))
            workbook.Worksheets(workbook.Worksheets.Count).Name = company
            generic_created.add(company)

        sheets_to_keep = set(selected)
        if _com_sheet(workbook, SUMMARY_SHEET_NAME) is not None:
            sheets_to_keep.add(SUMMARY_SHEET_NAME)
        if include_bil_mog:
            sheets_to_keep.add(BILMOG_SHEET_NAME)
        for index in range(workbook.Worksheets.Count, 0, -1):
            if workbook.Worksheets(index).Name not in sheets_to_keep:
                workbook.Worksheets(index).Delete()

        current_date = _date_from_source_b5(current_dataset, generated_at)
        previous_date = _date_from_source_b5(previous_dataset, generated_at) if previous_dataset else None
        result_map = {result.company: result for result in company_results}
        summary_row_mappings: dict[str, dict[int, int]] = {}

        for company in selected:
            ws = workbook.Worksheets(company)
            result = result_map[company]
            preliminary_groups, _, _, preliminary_grand = _report_rows(result)
            preliminary_max = _max_output_metric_row(result)
            used_max = max(int(ws.UsedRange.Rows.Count), preliminary_grand + 1, preliminary_max + 2)

            if company not in generic_created and company not in {"GRH", "SFS"}:
                existing_grand, output_grand = _fill_existing_template_sheet_com(
                    ws,
                    result,
                    output_type,
                    current_date,
                    previous_date,
                    used_max,
                )
                if existing_grand is not None and existing_grand != output_grand:
                    summary_row_mappings.setdefault(company, {})[existing_grand] = output_grand
                try:
                    print_area = ws.PageSetup.PrintArea
                except Exception:
                    print_area = ""
                try:
                    shape_count = int(ws.Shapes.Count)
                except Exception:
                    shape_count = 0
                LOGGER.info(
                    "Template unverändert befüllt: Blatt=%s, Druckbereich=%s, Shapes=%s",
                    company,
                    print_area,
                    shape_count,
                )
                continue

            groups, section_rows, total_rows, calculated_grand = _report_rows(result)
            max_metric = _max_output_metric_row(result)
            existing_grand = _find_grand_total_row_com(ws, used_max)
            grand_row = _select_grand_total_row(
                company,
                existing_grand,
                calculated_grand,
                max_metric,
            )
            if existing_grand is not None and existing_grand != grand_row:
                summary_row_mappings.setdefault(company, {})[existing_grand] = grand_row
            captured = _capture_codes_com(ws, used_max)
            style_section, style_metric, style_total, style_grand = _style_rows_com(ws, used_max)

            _set_header_com(ws, output_type, current_date, previous_date)
            for col in (6, 8, 10, 12, 14):
                ws.Range(ws.Cells(8, col), ws.Cells(used_max, col)).ClearContents()
            if company in generic_created or company == "Steering":
                ws.Range(ws.Cells(8, 2), ws.Cells(used_max, 4)).ClearContents()
            if company in OUTPUT_ROW_OVERRIDES:
                # Remove labels from the former J49/J51/J56 placement without
                # changing formats, borders, print areas or the Mercer logo.
                ws.Range(ws.Cells(43, 2), ws.Cells(min(used_max, 62), 4)).ClearContents()

            ws.Range("B8").Value2 = COMPANY_HEADER_CODES.get(company, str(config.companies[company].get("code", "")))
            ws.Range("C8").Value2 = COMPANY_NAMES.get(company, company)

            previous_map = _metric_map(result.previous)
            with_previous = previous_date is not None
            for section, metrics in groups.items():
                section_row = section_rows[section]
                visible_section = _section_has_visible_content(metrics, previous_map, with_previous)
                _ensure_format_com(excel, ws, section_row, style_section)
                caption = _section_caption(company, section)
                if visible_section:
                    ws.Cells(section_row, 2).Value2 = _section_code(company, section, caption, captured)
                    ws.Cells(section_row, 3).Value2 = caption
                    _set_bold_com(ws, section_row, (3,), True)
                else:
                    _clear_row_contents_com(ws, section_row, (2, 3, 4, 6, 8, 10, 12, 14))
                for metric in metrics:
                    output_row = _output_row(company, metric.target_row)
                    previous_metric = previous_map.get(metric.target_row)
                    _ensure_format_com(excel, ws, output_row, style_metric)
                    if visible_section:
                        _write_metric_com(
                            ws,
                            metric,
                            previous_metric,
                            with_previous,
                            output_row,
                        )
                    else:
                        _clear_row_contents_com(ws, output_row, (2, 3, 4, 6, 8, 10, 12, 14))
                total_row = total_rows[section]
                if total_row:
                    if visible_section:
                        if company == "Steering":
                            _copy_cell_formats_com(excel, ws, style_total, total_row)
                            ws.Cells(total_row, 3).Value2 = "Gesamtsumme:"
                            ws.Cells(total_row, 4).ClearContents()
                        else:
                            _ensure_format_com(excel, ws, total_row, style_total)
                        _write_total_formulas_com(
                            ws,
                            total_row,
                            _metric_output_rows(metrics),
                            with_previous,
                        )
                    else:
                        _clear_row_contents_com(ws, total_row, (2, 3, 4, 6, 8, 10, 12, 14))

            _ensure_format_com(excel, ws, grand_row, style_grand)
            ws.Cells(grand_row, 3).Value2 = "Gesamtsumme:"
            _write_total_formulas_com(
                ws,
                grand_row,
                _summary_rows(groups, total_rows),
                previous_date is not None,
            )

            if company == "GRH":
                _apply_grh_format_corrections_com(
                    excel,
                    ws,
                    (row for row in total_rows.values() if row is not None),
                    grand_row,
                    style_metric,
                    style_total,
                    style_grand,
                )
                _set_compact_print_area_com(ws, grand_row)
            elif company == "SFS":
                _apply_sfs_format_corrections_com(
                    excel,
                    ws,
                    (row for row in total_rows.values() if row is not None),
                    grand_row,
                    style_metric,
                    style_total,
                    style_grand,
                )
                _set_compact_print_area_com(ws, grand_row)
            elif company == "Steering":
                _copy_cell_formats_com(excel, ws, style_grand, grand_row)
                _set_bold_com(ws, grand_row, (3, *VALUE_COLUMNS), True)
                _set_compact_print_area_com(ws, grand_row)

            all_metric_rows = [
                _output_row(company, metric.target_row)
                for metrics in groups.values()
                for metric in metrics
            ]
            _apply_common_sheet_rules_com(
                ws,
                total_rows.values(),
                grand_row,
                with_previous,
                used_max,
                all_metric_rows,
            )

            try:
                print_area = ws.PageSetup.PrintArea
            except Exception:
                print_area = ""
            try:
                shape_count = int(ws.Shapes.Count)
            except Exception:
                shape_count = 0
            LOGGER.info(
                "Template-Layout beibehalten: Blatt=%s, Druckbereich=%s, Shapes=%s",
                company,
                print_area,
                shape_count,
            )

        summary_ws = _com_sheet(workbook, SUMMARY_SHEET_NAME)
        if summary_ws is not None:
            _prepare_summary_sheet_com(
                summary_ws,
                output_type,
                current_date,
                previous_date,
                selected,
                summary_formulas,
                summary_row_mappings,
            )

        bil_mog_ws = _com_sheet(workbook, BILMOG_SHEET_NAME)
        if output_type_requires_interest_rate(output_type) and interest_rate is None:
            raise ValueError("Das Blatt 'BilMoG' benötigt einen Zinssatz.")
        if bil_mog_ws is None:
            raise ValueError("Das Blatt 'BilMoG' konnte nicht erstellt werden.")
        _prepare_bil_mog_sheet_com(
            bil_mog_ws,
            current_date,
            previous_date,
            interest_rate,
            company_results,
            current_jubilee_total,
            previous_jubilee_total,
        )
        if summary_ws is not None:
            summary_ws.Move(After=workbook.Worksheets(selected[-1]))
        if bil_mog_ws is not None:
            bil_mog_ws.Move(After=workbook.Worksheets(workbook.Worksheets.Count))

        try:
            workbook.ForceFullCalculation = True
            excel.CalculateFullRebuild()
        except Exception:
            pass

        workbook.Worksheets(selected[0]).Activate()
        workbook.Save()
        save_completed = True
        LOGGER.info("Excel-COM-Ausgabe erfolgreich: %s", destination)
    finally:
        if workbook is not None:
            try:
                workbook.Close(SaveChanges=save_completed)
            except Exception:
                pass
        if excel is not None:
            try:
                excel.Quit()
            except Exception:
                pass
        pythoncom.CoUninitialize()


def write_template_workbook_preserving_layout(
    destination: Path,
    template_path: Path,
    output_type: str,
    current_dataset: SourceDataset,
    previous_dataset: SourceDataset | None,
    company_results: list[CompanyResult],
    config: RuleConfig,
    generated_at: datetime,
    interest_rate: float | None,
    current_jubilee_total: int | None = None,
    previous_jubilee_total: int | None = None,
) -> None:
    """Copy the selected local template and fill it without rebuilding layout."""
    if sys.platform == "win32":
        try:
            _write_com(
                destination,
                template_path,
                output_type,
                current_dataset,
                previous_dataset,
                company_results,
                config,
                generated_at,
                interest_rate,
                current_jubilee_total,
                previous_jubilee_total,
            )
            return
        except Exception:
            LOGGER.exception(
                "Excel-COM-Ausgabe fehlgeschlagen. Es wird bewusst kein "
                "OpenPyXL-Fallback erzeugt, damit Logo und Template-Layout "
                "nicht verloren gehen."
            )
            if destination.exists():
                try:
                    destination.unlink()
                except OSError:
                    pass
            raise

    _write_openpyxl(
        destination,
        template_path,
        output_type,
        current_dataset,
        previous_dataset,
        company_results,
        config,
        generated_at,
        interest_rate,
        current_jubilee_total,
        previous_jubilee_total,
    )
