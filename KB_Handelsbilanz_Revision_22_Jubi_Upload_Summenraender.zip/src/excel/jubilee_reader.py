from __future__ import annotations

"""Read the optional jubilee-liability workbook used by the BilMoG sheet."""

from pathlib import Path
from typing import Any

from openpyxl import load_workbook

from core.normalization import normalize_header, parse_number


PREFERRED_SHEET = "AllOnetabOrFile"


def _sheet_for_workbook(workbook):
    if PREFERRED_SHEET in workbook.sheetnames:
        return workbook[PREFERRED_SHEET]
    lookup = {name.casefold(): name for name in workbook.sheetnames}
    match = lookup.get(PREFERRED_SHEET.casefold())
    if match:
        return workbook[match]
    for worksheet in workbook.worksheets:
        if worksheet.sheet_state == "visible":
            return worksheet
    return workbook.worksheets[0]


def _find_value_column(sheet, value_column: str, max_scan_rows: int = 100) -> tuple[int, int]:
    wanted = normalize_header(value_column)
    for row_number, row in enumerate(
        sheet.iter_rows(min_row=1, max_row=min(sheet.max_row, max_scan_rows), values_only=True),
        start=1,
    ):
        for column_number, value in enumerate(row, start=1):
            if normalize_header(value) == wanted:
                return row_number, column_number
    raise ValueError(
        f"Die Jubiläumsdatei enthält die benötigte Spalte {value_column!r} nicht."
    )


def read_jubilee_total(path: Path, value_column: str) -> int:
    """Return the rounded sum of the selected accounting value column."""
    if not path.exists():
        raise FileNotFoundError(f"Jubiläumsdatei wurde nicht gefunden: {path}")
    if path.suffix.casefold() not in {".xlsx", ".xlsm"}:
        raise ValueError("Für Jubiläumsrückstellungen werden .xlsx oder .xlsm unterstützt.")

    try:
        workbook = load_workbook(path, read_only=True, data_only=True)
    except Exception as exc:
        raise ValueError(f"Jubiläumsdatei konnte nicht geöffnet werden: {exc}") from exc

    try:
        sheet = _sheet_for_workbook(workbook)
        header_row, value_column_index = _find_value_column(sheet, value_column)
        total = 0.0
        for row in sheet.iter_rows(min_row=header_row + 1, values_only=True):
            value: Any = row[value_column_index - 1] if value_column_index - 1 < len(row) else None
            total += parse_number(value)
        return int(round(total))
    finally:
        workbook.close()
