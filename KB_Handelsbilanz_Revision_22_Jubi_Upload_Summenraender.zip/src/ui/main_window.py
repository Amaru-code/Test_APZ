from __future__ import annotations

import os
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

from app.service import run_calculation
from core.config_loader import load_rule_config
from core.models import AppOptions
from core.normalization import parse_interest_rate_percent, output_type_requires_interest_rate


class MainWindow(tk.Tk):
    def __init__(self, root_dir: Path) -> None:
        super().__init__()
        self.root_dir = root_dir
        self.config_data = load_rule_config(root_dir / "config" / "rules.json")
        self.title("KB Handelsbilanz Automatisierung")
        self.geometry("980x760")
        self.minsize(880, 680)

        self.current_file_var = tk.StringVar()
        self.previous_enabled_var = tk.BooleanVar(value=False)
        self.previous_file_var = tk.StringVar()
        self.current_jubilee_file_var = tk.StringVar()
        self.previous_jubilee_file_var = tk.StringVar()
        self.output_type_var = tk.StringVar(value="HGB")
        self.output_dir_var = tk.StringVar(value=str(root_dir / "outputs"))
        self.company_vars = {
            name: tk.BooleanVar(value=True) for name in self.config_data.company_names()
        }
        self.status_var = tk.StringVar(value="Bereit")
        self._build_ui()

    def _build_ui(self) -> None:
        style = ttk.Style(self)
        if "vista" in style.theme_names():
            style.theme_use("vista")

        outer = ttk.Frame(self, padding=18)
        outer.pack(fill="both", expand=True)

        title = ttk.Label(
            outer,
            text="KB Handelsbilanz – Excel-Automatisierung",
            font=("Segoe UI", 18, "bold"),
        )
        title.pack(anchor="w", pady=(0, 14))

        files = ttk.LabelFrame(outer, text="1. Quelldateien", padding=12)
        files.pack(fill="x", pady=(0, 10))
        files.columnconfigure(1, weight=1)

        ttk.Label(files, text="Aktuelles Jahr:").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=4)
        ttk.Entry(files, textvariable=self.current_file_var).grid(row=0, column=1, sticky="ew", pady=4)
        ttk.Button(files, text="Auswählen …", command=self._choose_current).grid(row=0, column=2, padx=(8, 0), pady=4)

        ttk.Checkbutton(
            files,
            text="Vorjahr einbeziehen",
            variable=self.previous_enabled_var,
            command=self._toggle_previous,
        ).grid(row=1, column=0, sticky="w", padx=(0, 8), pady=4)
        self.previous_entry = ttk.Entry(files, textvariable=self.previous_file_var, state="disabled")
        self.previous_entry.grid(row=1, column=1, sticky="ew", pady=4)
        self.previous_button = ttk.Button(files, text="Auswählen …", command=self._choose_previous, state="disabled")
        self.previous_button.grid(row=1, column=2, padx=(8, 0), pady=4)

        ttk.Label(files, text="Jubi aktuell (optional):").grid(row=2, column=0, sticky="w", padx=(0, 8), pady=4)
        ttk.Entry(files, textvariable=self.current_jubilee_file_var).grid(row=2, column=1, sticky="ew", pady=4)
        ttk.Button(files, text="Auswählen …", command=self._choose_current_jubilee).grid(row=2, column=2, padx=(8, 0), pady=4)

        ttk.Label(files, text="Jubi Vorjahr (optional):").grid(row=3, column=0, sticky="w", padx=(0, 8), pady=4)
        self.previous_jubilee_entry = ttk.Entry(files, textvariable=self.previous_jubilee_file_var, state="disabled")
        self.previous_jubilee_entry.grid(row=3, column=1, sticky="ew", pady=4)
        self.previous_jubilee_button = ttk.Button(files, text="Auswählen …", command=self._choose_previous_jubilee, state="disabled")
        self.previous_jubilee_button.grid(row=3, column=2, padx=(8, 0), pady=4)

        settings = ttk.Frame(outer)
        settings.pack(fill="x", pady=(0, 10))
        settings.columnconfigure(0, weight=1)
        settings.columnconfigure(1, weight=1)

        output_frame = ttk.LabelFrame(settings, text="2. Output-Typ", padding=12)
        output_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 5))
        for index, output_type in enumerate(self.config_data.value_columns):
            ttk.Radiobutton(
                output_frame,
                text=f"{output_type}  ({self.config_data.value_columns[output_type]})",
                variable=self.output_type_var,
                value=output_type,
            ).grid(row=index, column=0, sticky="w", pady=3)

        company_frame = ttk.LabelFrame(settings, text="3. Gesellschaften", padding=12)
        company_frame.grid(row=0, column=1, sticky="nsew", padx=(5, 0))
        button_row = ttk.Frame(company_frame)
        button_row.grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 5))
        ttk.Button(button_row, text="Alle", command=lambda: self._set_all_companies(True)).pack(side="left")
        ttk.Button(button_row, text="Keine", command=lambda: self._set_all_companies(False)).pack(side="left", padx=5)
        for index, (name, variable) in enumerate(self.company_vars.items(), start=1):
            ttk.Checkbutton(company_frame, text=name, variable=variable).grid(
                row=(index - 1) // 2 + 1,
                column=(index - 1) % 2,
                sticky="w",
                padx=(0, 20),
                pady=2,
            )

        destination = ttk.LabelFrame(outer, text="4. Ausgabeordner", padding=12)
        destination.pack(fill="x", pady=(0, 10))
        destination.columnconfigure(0, weight=1)
        ttk.Entry(destination, textvariable=self.output_dir_var).grid(row=0, column=0, sticky="ew")
        ttk.Button(destination, text="Auswählen …", command=self._choose_output_dir).grid(row=0, column=1, padx=(8, 0))

        actions = ttk.Frame(outer)
        actions.pack(fill="x", pady=(0, 10))
        self.run_button = ttk.Button(actions, text="Berechnung starten", command=self._start)
        self.run_button.pack(side="left")
        self.open_output_button = ttk.Button(
            actions, text="Letzten Ausgabeordner öffnen", command=self._open_last_output, state="disabled"
        )
        self.open_output_button.pack(side="left", padx=8)
        self.progress = ttk.Progressbar(actions, mode="indeterminate")
        self.progress.pack(side="right", fill="x", expand=True, padx=(20, 0))

        log_frame = ttk.LabelFrame(outer, text="Protokoll", padding=8)
        log_frame.pack(fill="both", expand=True)
        self.log_text = tk.Text(log_frame, height=16, wrap="word", state="disabled", font=("Consolas", 10))
        scrollbar = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=scrollbar.set)
        self.log_text.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        ttk.Label(outer, textvariable=self.status_var).pack(anchor="w", pady=(8, 0))
        self.last_output_folder: Path | None = None

    def _choose_current(self) -> None:
        path = filedialog.askopenfilename(
            title="Datei für aktuelles Jahr auswählen",
            filetypes=[("Excel Dateien", "*.xlsx *.xlsm"), ("Alle Dateien", "*.*")],
        )
        if path:
            self.current_file_var.set(path)

    def _choose_previous(self) -> None:
        path = filedialog.askopenfilename(
            title="Vorjahresdatei auswählen",
            filetypes=[("Excel Dateien", "*.xlsx *.xlsm"), ("Alle Dateien", "*.*")],
        )
        if path:
            self.previous_file_var.set(path)

    def _choose_current_jubilee(self) -> None:
        path = filedialog.askopenfilename(
            title="Jubiläumsdatei aktuelles Jahr auswählen",
            filetypes=[("Excel Dateien", "*.xlsx *.xlsm"), ("Alle Dateien", "*.*")],
        )
        if path:
            self.current_jubilee_file_var.set(path)

    def _choose_previous_jubilee(self) -> None:
        path = filedialog.askopenfilename(
            title="Jubiläumsdatei Vorjahr auswählen",
            filetypes=[("Excel Dateien", "*.xlsx *.xlsm"), ("Alle Dateien", "*.*")],
        )
        if path:
            self.previous_jubilee_file_var.set(path)

    def _choose_output_dir(self) -> None:
        path = filedialog.askdirectory(title="Ausgabeordner auswählen")
        if path:
            self.output_dir_var.set(path)

    def _toggle_previous(self) -> None:
        state = "normal" if self.previous_enabled_var.get() else "disabled"
        self.previous_entry.configure(state=state)
        self.previous_button.configure(state=state)
        self.previous_jubilee_entry.configure(state=state)
        self.previous_jubilee_button.configure(state=state)
        if state == "disabled":
            self.previous_file_var.set("")
            self.previous_jubilee_file_var.set("")

    def _set_all_companies(self, selected: bool) -> None:
        for variable in self.company_vars.values():
            variable.set(selected)

    def _append_log(self, message: str) -> None:
        def write() -> None:
            self.log_text.configure(state="normal")
            self.log_text.insert("end", message + "\n")
            self.log_text.see("end")
            self.log_text.configure(state="disabled")
            self.status_var.set(message)

        self.after(0, write)

    def _validate_options(self) -> AppOptions | None:
        current = Path(self.current_file_var.get().strip())
        if not current.is_file():
            messagebox.showerror("Fehlende Datei", "Bitte eine gültige Datei für das aktuelle Jahr auswählen.")
            return None

        previous = None
        if self.previous_enabled_var.get():
            previous = Path(self.previous_file_var.get().strip())
            if not previous.is_file():
                messagebox.showerror("Fehlende Vorjahresdatei", "Bitte eine gültige Vorjahresdatei auswählen.")
                return None

        companies = [name for name, variable in self.company_vars.items() if variable.get()]
        if not companies:
            messagebox.showerror("Keine Gesellschaft", "Bitte mindestens eine Gesellschaft auswählen.")
            return None

        interest_rate = None
        if output_type_requires_interest_rate(self.output_type_var.get()):
            raw_interest_rate = simpledialog.askstring(
                "BilMoG-Zinssatz",
                "Bitte den Zinssatz in Prozent eingeben (z. B. 2,05):",
                parent=self,
                initialvalue="2,05",
            )
            if raw_interest_rate is None:
                return None
            try:
                interest_rate = parse_interest_rate_percent(raw_interest_rate)
            except ValueError as exc:
                messagebox.showerror("Ungültiger Zinssatz", str(exc))
                return None

        current_jubilee = Path(self.current_jubilee_file_var.get().strip()) if self.current_jubilee_file_var.get().strip() else None
        previous_jubilee = Path(self.previous_jubilee_file_var.get().strip()) if self.previous_jubilee_file_var.get().strip() else None
        for label, file_path in (("Jubi aktuell", current_jubilee), ("Jubi Vorjahr", previous_jubilee)):
            if file_path is not None and not file_path.is_file():
                messagebox.showerror("Fehlende Datei", f"Bitte eine gültige Datei für {label} auswählen.")
                return None

        output_dir = Path(self.output_dir_var.get().strip())
        return AppOptions(
            current_file=current,
            previous_file=previous,
            output_type=self.output_type_var.get(),
            companies=companies,
            output_dir=output_dir,
            interest_rate=interest_rate,
            current_jubilee_file=current_jubilee,
            previous_jubilee_file=previous_jubilee,
        )

    def _start(self) -> None:
        options = self._validate_options()
        if options is None:
            return
        self.run_button.configure(state="disabled")
        self.open_output_button.configure(state="disabled")
        self.progress.start(12)
        self._append_log("Berechnung gestartet …")

        thread = threading.Thread(target=self._worker, args=(options,), daemon=True)
        thread.start()

    def _worker(self, options: AppOptions) -> None:
        try:
            result = run_calculation(self.root_dir, options, self._append_log)
        except Exception as exc:
            self.after(0, lambda: self._finish_error(exc))
            return
        self.after(0, lambda: self._finish_success(result))

    def _finish_success(self, result) -> None:
        self.progress.stop()
        self.run_button.configure(state="normal")
        self.last_output_folder = result.output_folder
        self.open_output_button.configure(state="normal")
        self.status_var.set("Berechnung erfolgreich abgeschlossen.")
        message = f"Excel-Datei wurde erstellt:\n{result.output_workbook}"
        if result.warnings:
            message += f"\n\n{len(result.warnings)} Regelhinweis(e) stehen in den Markdown-Dateien."
        messagebox.showinfo("Fertig", message)

    def _finish_error(self, exc: Exception) -> None:
        self.progress.stop()
        self.run_button.configure(state="normal")
        self.status_var.set("Fehler")
        self._append_log(f"FEHLER: {exc}")
        messagebox.showerror("Berechnung fehlgeschlagen", str(exc))

    def _open_last_output(self) -> None:
        if self.last_output_folder and self.last_output_folder.exists():
            os.startfile(self.last_output_folder)  # type: ignore[attr-defined]
