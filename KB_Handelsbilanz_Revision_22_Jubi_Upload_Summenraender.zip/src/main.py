from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
SRC_DIR = Path(__file__).resolve().parent
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from app.service import run_calculation  # noqa: E402
from core.config_loader import load_rule_config  # noqa: E402
from core.models import AppOptions  # noqa: E402
from core.logging_setup import configure_logging  # noqa: E402
from core.normalization import parse_interest_rate_percent, output_type_requires_interest_rate  # noqa: E402
from ui.main_window import MainWindow  # noqa: E402


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="KB Handelsbilanz Automatisierung")
    parser.add_argument("--current", type=Path, help="XLSX-Datei des aktuellen Jahres")
    parser.add_argument("--previous", type=Path, help="Optionale XLSX-Datei des Vorjahres")
    parser.add_argument("--type", choices=["HGB", "STB", "7 Jahre"], default="HGB")
    parser.add_argument("--companies", help="Kommagetrennte Gesellschaften, z. B. AG,GRH,SFS")
    parser.add_argument("--output-dir", type=Path, default=ROOT_DIR / "outputs")
    parser.add_argument("--interest-rate", help="BilMoG-Zinssatz in Prozent, z. B. 2,05")
    parser.add_argument("--current-jubilee", type=Path, help="Optionale Jubiläums-XLSX des aktuellen Jahres")
    parser.add_argument("--previous-jubilee", type=Path, help="Optionale Jubiläums-XLSX des Vorjahres")
    parser.add_argument("--no-gui", action="store_true", help="Kommandozeilenmodus verwenden")
    return parser


def main() -> int:
    configure_logging(ROOT_DIR)
    args = _parser().parse_args()
    if not args.no_gui:
        app = MainWindow(ROOT_DIR)
        app.mainloop()
        return 0

    if not args.current:
        print("Fehler: --current ist im Kommandozeilenmodus erforderlich.", file=sys.stderr)
        return 2
    interest_rate = None
    if output_type_requires_interest_rate(args.type):
        if args.interest_rate is None:
            print("Fehler: --interest-rate ist für HGB und 7 Jahre erforderlich.", file=sys.stderr)
            return 2
        try:
            interest_rate = parse_interest_rate_percent(args.interest_rate)
        except ValueError as exc:
            print(f"Fehler: {exc}", file=sys.stderr)
            return 2
    elif args.interest_rate is not None:
        try:
            interest_rate = parse_interest_rate_percent(args.interest_rate)
        except ValueError as exc:
            print(f"Fehler: {exc}", file=sys.stderr)
            return 2

    config = load_rule_config(ROOT_DIR / "config" / "rules.json")
    companies = (
        [item.strip() for item in args.companies.split(",") if item.strip()]
        if args.companies
        else config.company_names()
    )
    options = AppOptions(
        current_file=args.current,
        previous_file=args.previous,
        output_type=args.type,
        companies=companies,
        output_dir=args.output_dir,
        interest_rate=interest_rate,
        current_jubilee_file=args.current_jubilee,
        previous_jubilee_file=args.previous_jubilee,
    )
    try:
        result = run_calculation(ROOT_DIR, options, print)
    except Exception as exc:
        print(f"Fehler: {exc}", file=sys.stderr)
        return 1
    print(result.output_workbook)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
