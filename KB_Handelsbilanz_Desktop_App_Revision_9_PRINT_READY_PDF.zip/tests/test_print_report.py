from __future__ import annotations

import shutil
import tempfile
import unittest
from pathlib import Path

from openpyxl import load_workbook

from app.service import run_calculation
from core.models import AppOptions


ROOT = Path(__file__).resolve().parents[1]
SAMPLE = ROOT / "data" / "samples" / "sample_AllOnetabOrFile.xlsx"


class PrintReportTests(unittest.TestCase):
    def test_print_ready_report_without_previous_year(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            current = temp_path / "Sommerbewertung_30.06.2026.xlsx"
            shutil.copy2(SAMPLE, current)
            result = run_calculation(
                ROOT,
                AppOptions(
                    current_file=current,
                    previous_file=None,
                    output_type="HGB",
                    companies=["SFS", "GRH"],
                    output_dir=temp_path / "out",
                ),
            )
            workbook = load_workbook(result.output_workbook, data_only=False)
            self.assertEqual(workbook.sheetnames, ["Rechenlauf", "SFS", "GRH", "Summe"])
            sfs = workbook["SFS"]
            self.assertEqual(
                sfs["D3"].value,
                "Entwicklung der Pensionsrückstellungen 30.06.2026 - Handelsbilanz",
            )
            self.assertEqual(sfs["B8"].value, "186")
            self.assertEqual(sfs["C8"].value, "Knorr-Bremse Systeme für Schienenfahrzeuge GmbH")
            self.assertEqual(sfs["C10"].value, "Versorgungswerk Anwärter")
            self.assertIn("$J$", str(sfs.print_area))
            self.assertEqual(sfs.page_setup.orientation, "portrait")
            self.assertEqual(sfs.page_setup.fitToWidth, 1)
            self.assertEqual(sfs.oddFooter.center.text, "Seite &P von &N")
            self.assertIsNone(sfs["L4"].value)

    def test_print_ready_report_with_previous_year(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            current = temp_path / "Bewertung_30.06.2026.xlsx"
            previous = temp_path / "Bewertung_31.12.2025.xlsx"
            shutil.copy2(SAMPLE, current)
            shutil.copy2(SAMPLE, previous)
            result = run_calculation(
                ROOT,
                AppOptions(
                    current_file=current,
                    previous_file=previous,
                    output_type="HGB",
                    companies=["SFS"],
                    output_dir=temp_path / "out",
                ),
            )
            workbook = load_workbook(result.output_workbook, data_only=False)
            sfs = workbook["SFS"]
            self.assertEqual(sfs["F4"].value, "Rückstellung per\n31.12.2025\n€")
            self.assertEqual(sfs["J4"].value, "Rückstellung per\n30.06.2026\n€")
            self.assertEqual(sfs["L4"].value, "Zuführung\n€")
            self.assertIn("$N$", str(sfs.print_area))
            self.assertEqual(sfs["L12"].value, 0)
            ranges = {str(item.sqref) for item in sfs.conditional_formatting}
            self.assertTrue(any("J10:N" in value for value in ranges))
            self.assertIn("Summe", workbook.sheetnames)
            self.assertIsNone(result.output_pdf)  # Linux-Testumgebung ohne Excel-COM


if __name__ == "__main__":
    unittest.main()
