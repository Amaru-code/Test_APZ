# Testbericht – Revision 9

Stand: 19.07.2026

## Ergebnis

- 33 von 33 automatisierten Tests erfolgreich.
- Feldregeln: 183, unverändert gegenüber Revision 8.
- Dateiauswahl für `.xlsx` und `.xlsm` unverändert funktionsfähig.
- Desktop-App lädt weiterhin über den lokalen Loopback-Server.
- Druckfertige Arbeitsmappe ohne Vorjahr erfolgreich erzeugt.
- Druckfertige Arbeitsmappe mit Vorjahr erfolgreich erzeugt.
- Reportblätter: Rechenlauf, Gesellschaften und Summe.
- Stichtagserkennung aus Dateinamen geprüft.
- A4-Hochformat, Fit-to-Width, Druckbereich, Drucktitel und Seitenzahlen geprüft.
- Vorjahres-, aktuelle und Zuführungsspalten geprüft.
- Bedingte grün/rote Hervorhebung geprüft.
- Windows-PDF-Export ist fehlertolerant und wird nur über Microsoft Excel/COM ausgeführt.
- JavaScript-Syntax der produktiven Oberfläche geprüft.
- ZIP-Integrität wird vor der Auslieferung geprüft.
