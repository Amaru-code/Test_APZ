from __future__ import annotations

import json
import re
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any

from openpyxl import Workbook
from openpyxl.formatting.rule import CellIsRule, FormulaRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from core.config_loader import RuleConfig
from core.models import CompanyResult, MetricResult, SourceDataset
from core.rule_engine import describe_rule


# Technische Farben
TITLE_FILL = PatternFill("solid", fgColor="1F4E78")
SECTION_FILL = PatternFill("solid", fgColor="D9EAF7")
HEADER_FILL = PatternFill("solid", fgColor="5B9BD5")
SUBTLE_FILL = PatternFill("solid", fgColor="E7E6E6")
WARNING_FILL = PatternFill("solid", fgColor="FFF2CC")
WHITE_FONT = Font(color="FFFFFF", bold=True)
THIN_GRAY = Side(style="thin", color="B7B7B7")
BORDER = Border(left=THIN_GRAY, right=THIN_GRAY, top=THIN_GRAY, bottom=THIN_GRAY)
MONEY_FORMAT = '#,##0.00;[Red]-#,##0.00'
COUNT_FORMAT = '0'

# Print-Report
WHOLE_MONEY_FORMAT = '#,##0;[Red]-#,##0'
MERCER_BLUE = "1F3A7A"
MERCER_LIGHT = "DCE6F1"
POSITIVE_FILL = PatternFill("solid", fgColor="D9EAD3")
NEGATIVE_FILL = PatternFill("solid", fgColor="E6B8AF")
ZERO_FILL = PatternFill("solid", fgColor="E2F0D9")
REPORT_LINE = Side(style="thin", color="808080")
REPORT_BOTTOM = Side(style="medium", color="404040")

OUTPUT_LABELS = {
    "HGB": "Handelsbilanz",
    "STB": "Steuerbilanz",
    "7 Jahre": "7-Jahres-Betrachtung",
}

# SFS=186 ist aus der übermittelten Referenz bekannt. Für die übrigen
# Gesellschaften wird der in der Regelkonfiguration hinterlegte Code verwendet.
COMPANY_DISPLAY = {
    "SFS": ("186", "Knorr-Bremse Systeme für Schienenfahrzeuge GmbH"),
    "SFN": ("185", "Knorr-Bremse Systeme für Nutzfahrzeuge GmbH"),
}

SECTION_CODES = {
    "VO Anwärter": "230",
    "VO Rentner": "240",
    "EZ Anwärter": "210",
    "EZ Rentner": "220",
}


# ---------------------------------------------------------------------------
# Allgemeine Helfer
# ---------------------------------------------------------------------------

def _safe_sheet_name(name: str) -> str:
    for char in '[]:*?/\\':
        name = name.replace(char, "_")
    return name[:31]


def _metric_map(metrics: list[MetricResult] | None) -> dict[int, MetricResult]:
    return {metric.target_row: metric for metric in metrics or []}


def _detect_reporting_date(path: Path, fallback: datetime) -> str:
    """Liest einen Stichtag aus dem Dateinamen, sonst Änderungs-/Erstellungsdatum."""
    name = path.stem
    patterns = (
        r"(?<!\d)(\d{2})[.\-_](\d{2})[.\-_](\d{4})(?!\d)",
        r"(?<!\d)(\d{4})[.\-_](\d{2})[.\-_](\d{2})(?!\d)",
    )
    match = re.search(patterns[0], name)
    if match:
        day, month, year = match.groups()
        return f"{day}.{month}.{year}"
    match = re.search(patterns[1], name)
    if match:
        year, month, day = match.groups()
        return f"{day}.{month}.{year}"
    try:
        modified = datetime.fromtimestamp(path.stat().st_mtime)
        return modified.strftime("%d.%m.%Y")
    except OSError:
        return fallback.strftime("%d.%m.%Y")


def _company_title(company: str, company_config: dict[str, Any]) -> tuple[str, str]:
    if company in COMPANY_DISPLAY:
        return COMPANY_DISPLAY[company]
    return str(company_config.get("code", "")), company


def _section_caption(section: str) -> str:
    replacements = {
        "VO Anwärter": "Versorgungswerk Anwärter",
        "VO Rentner": "Versorgungswerk Rentner",
        "EZ Anwärter": "Einzelzusagen Anwärter",
        "EZ Rentner": "Einzelzusagen Rentner",
        "EZ – Geschäftsführer": "Einzelzusagen Geschäftsführer",
        "VO Anwärter (Ausland)": "Versorgungswerk Ausland",
    }
    return replacements.get(section, section)


def _configure_print_page(ws, max_row: int, max_col_letter: str) -> None:
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "D10"
    ws.print_title_rows = "1:7"
    ws.print_area = f"A1:{max_col_letter}{max_row}"
    ws.page_setup.orientation = "portrait"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_margins.left = 0.35
    ws.page_margins.right = 0.35
    ws.page_margins.top = 0.55
    ws.page_margins.bottom = 0.55
    ws.page_margins.header = 0.2
    ws.page_margins.footer = 0.25
    ws.print_options.horizontalCentered = True
    ws.oddFooter.left.text = "Mercer"
    ws.oddFooter.center.text = "Seite &P von &N"
    ws.oddFooter.right.text = "&D"
    ws.oddFooter.left.size = 8
    ws.oddFooter.center.size = 8
    ws.oddFooter.right.size = 8


def _write_branding(ws) -> None:
    # Abstraktes Mercer-Zeichen aus Zellen; kein externes Bild erforderlich.
    ws.merge_cells("B1:C2")
    ws["B1"] = "◆"
    ws["B1"].font = Font(name="Arial", size=27, bold=True, color=MERCER_BLUE)
    ws["B1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.merge_cells("D1:F2")
    ws["D1"] = "Mercer"
    ws["D1"].font = Font(name="Arial", size=25, color=MERCER_BLUE)
    ws["D1"].alignment = Alignment(vertical="center")
    ws.row_dimensions[1].height = 24
    ws.row_dimensions[2].height = 20


# ---------------------------------------------------------------------------
# Technischer Rechenlauf
# ---------------------------------------------------------------------------

def _write_rechenlauf_sheet(
    workbook: Workbook,
    output_type: str,
    value_column: str,
    current_dataset: SourceDataset,
    previous_dataset: SourceDataset | None,
    companies: list[CompanyResult],
    config: RuleConfig,
    generated_at: datetime,
) -> None:
    ws = workbook.active
    ws.title = "Rechenlauf"
    ws.sheet_properties.tabColor = "A5A5A5"
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "A9"
    ws.merge_cells("A1:N1")
    ws["A1"] = "KB Handelsbilanz – technischer Rechenlauf"
    ws["A1"].fill = TITLE_FILL
    ws["A1"].font = Font(color="FFFFFF", bold=True, size=16)
    ws["A1"].alignment = Alignment(horizontal="center")
    ws.row_dimensions[1].height = 28

    metadata = [
        ("Erstellt am", generated_at.strftime("%d.%m.%Y %H:%M:%S")),
        ("Output-Typ", output_type),
        ("Berechnungsspalte", value_column),
        ("Aktuelles Jahr", str(current_dataset.path)),
        ("Headerzeile aktuell", current_dataset.header_row),
        ("Datensätze aktuell", len(current_dataset.records)),
        ("Vorjahr", str(previous_dataset.path) if previous_dataset else "Nicht ausgewählt"),
        ("Gesellschaften", ", ".join(result.company for result in companies)),
    ]
    for index, (label, value) in enumerate(metadata, start=3):
        ws.cell(index, 1, label)
        ws.cell(index, 2, value)
        ws.cell(index, 1).font = Font(bold=True)
        ws.cell(index, 1).fill = SECTION_FILL
        ws.cell(index, 1).border = BORDER
        ws.cell(index, 2).border = BORDER

    row = 13
    headers = [
        "Gesellschaft", "Abschnitt", "Zielzelle", "Kennzahl", "Filter / Formel",
        "Vorjahr", "Anzahl VJ", "Aktuell", "Differenz", "Anzahl aktuell",
    ]
    for col, label in enumerate(headers, start=1):
        cell = ws.cell(row, col, label)
        cell.fill = HEADER_FILL
        cell.font = WHITE_FONT
        cell.border = BORDER
        cell.alignment = Alignment(horizontal="center", wrap_text=True)
    row += 1

    for result in companies:
        rules_by_row = {int(rule["target_row"]): rule for rule in config.companies[result.company]["rules"]}
        previous_map = _metric_map(result.previous)
        for metric in result.current:
            rule = rules_by_row[metric.target_row]
            previous = previous_map.get(metric.target_row)
            values = [
                result.company,
                metric.section,
                f"J{metric.target_row}",
                metric.label,
                describe_rule(result.company, rule, config),
                previous.value if previous else None,
                previous.employee_count if previous else None,
                metric.value,
                metric.value - previous.value if previous else None,
                metric.employee_count,
            ]
            for col, value in enumerate(values, start=1):
                cell = ws.cell(row, col, value)
                cell.border = BORDER
                cell.alignment = Alignment(vertical="top", wrap_text=col in {2, 4, 5})
            for col in (6, 8, 9):
                ws.cell(row, col).number_format = MONEY_FORMAT
            row += 1

    widths = [15, 34, 12, 34, 80, 18, 13, 18, 18, 15]
    for index, width in enumerate(widths, start=1):
        ws.column_dimensions[chr(64 + index)].width = width
    ws.auto_filter.ref = f"A13:J{max(13, row - 1)}"
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True


# ---------------------------------------------------------------------------
# Druckfertige Gesellschaftsblätter
# ---------------------------------------------------------------------------

def _write_report_header(
    ws,
    output_type: str,
    current_date: str,
    previous_date: str | None,
) -> None:
    _write_branding(ws)
    title_end = "N" if previous_date else "J"
    ws.merge_cells(f"D3:{title_end}3")
    ws["D3"] = f"Entwicklung der Pensionsrückstellungen {current_date} - {OUTPUT_LABELS[output_type]}"
    ws["D3"].font = Font(name="Arial", size=16, bold=True, underline="single")
    ws["D3"].alignment = Alignment(horizontal="center")
    ws.row_dimensions[3].height = 28

    if previous_date:
        ws.merge_cells("F4:G4")
        ws["F4"] = f"Rückstellung per\n{previous_date}\n€"
        ws.merge_cells("H4:I4")
        ws["H4"] = "Anzahl\nBerechtigte"
        ws.merge_cells("J4:K4")
        ws["J4"] = f"Rückstellung per\n{current_date}\n€"
        ws.merge_cells("L4:M4")
        ws["L4"] = "Zuführung\n€"
        ws["N4"] = "Anzahl\nBerechtigte"
        header_cells = ("F4", "H4", "J4", "L4", "N4")
        for col in ("F", "H", "J", "L", "N"):
            ws[f"{col}6"].border = Border(bottom=REPORT_LINE)
        ws.row_dimensions[4].height = 47
    else:
        ws.merge_cells("F4:H4")
        ws["F4"] = f"Rückstellung per\n{current_date}\n€"
        ws.merge_cells("I4:J4")
        ws["I4"] = "Anzahl\nBerechtigte"
        header_cells = ("F4", "I4")
        ws["F6"].border = Border(bottom=REPORT_LINE)
        ws["I6"].border = Border(bottom=REPORT_LINE)
        ws.row_dimensions[4].height = 47

    for address in header_cells:
        ws[address].font = Font(name="Arial", size=11)
        ws[address].alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def _section_positions(rules: list[dict[str, Any]]) -> dict[str, tuple[int, int]]:
    grouped: dict[str, list[int]] = defaultdict(list)
    for rule in rules:
        grouped[rule["section"]].append(int(rule["target_row"]))
    return {section: (min(rows), max(rows)) for section, rows in grouped.items()}


def _write_report_company_row(ws, company: str, company_config: dict[str, Any]) -> None:
    company_code, company_name = _company_title(company, company_config)
    ws["B8"] = company_code
    ws["B8"].font = Font(name="Arial", size=11)
    ws.merge_cells("C8:J8")
    ws["C8"] = company_name
    ws["C8"].font = Font(name="Arial", size=12, bold=True, underline="single")
    ws["C8"].alignment = Alignment(vertical="center")
    ws.row_dimensions[8].height = 24


def _write_report_metric_row(
    ws,
    row: int,
    label: str,
    current_value: float,
    current_count: int,
    previous_value: float | None,
    previous_count: int | None,
) -> None:
    ws.merge_cells(start_row=row, start_column=3, end_row=row, end_column=5)
    ws.cell(row, 3, label)
    ws.cell(row, 3).font = Font(name="Arial", size=10)
    ws.cell(row, 3).alignment = Alignment(vertical="center")

    if previous_value is not None:
        ws.merge_cells(start_row=row, start_column=6, end_row=row, end_column=7)
        ws.cell(row, 6, previous_value)
        ws.cell(row, 8, previous_count or 0)
        ws.merge_cells(start_row=row, start_column=10, end_row=row, end_column=11)
        ws.cell(row, 10, current_value)
        ws.merge_cells(start_row=row, start_column=12, end_row=row, end_column=13)
        ws.cell(row, 12, current_value - previous_value)
        ws.cell(row, 14, current_count)
        value_cells = (6, 10, 12)
        count_cells = (8, 14)
    else:
        ws.merge_cells(start_row=row, start_column=6, end_row=row, end_column=8)
        ws.cell(row, 6, current_value)
        ws.merge_cells(start_row=row, start_column=9, end_row=row, end_column=10)
        ws.cell(row, 9, current_count)
        value_cells = (6,)
        count_cells = (9,)

    for col in value_cells:
        ws.cell(row, col).number_format = WHOLE_MONEY_FORMAT
        ws.cell(row, col).alignment = Alignment(horizontal="right", vertical="center")
        ws.cell(row, col).font = Font(name="Arial", size=10)
    for col in count_cells:
        ws.cell(row, col).number_format = COUNT_FORMAT
        ws.cell(row, col).alignment = Alignment(horizontal="right", vertical="center")
        ws.cell(row, col).font = Font(name="Arial", size=10)
    ws.row_dimensions[row].height = 18


def _write_report_total_row(
    ws,
    row: int,
    metrics: list[MetricResult],
    previous_map: dict[int, MetricResult],
) -> None:
    current_value = sum(metric.value for metric in metrics)
    current_count = sum(metric.employee_count for metric in metrics)
    has_previous = bool(previous_map)
    if has_previous:
        previous_value = sum(previous_map[metric.target_row].value for metric in metrics if metric.target_row in previous_map)
        previous_count = sum(previous_map[metric.target_row].employee_count for metric in metrics if metric.target_row in previous_map)
        ws.merge_cells(start_row=row, start_column=6, end_row=row, end_column=7)
        ws.cell(row, 6, previous_value)
        ws.cell(row, 8, previous_count)
        ws.merge_cells(start_row=row, start_column=10, end_row=row, end_column=11)
        ws.cell(row, 10, current_value)
        ws.merge_cells(start_row=row, start_column=12, end_row=row, end_column=13)
        ws.cell(row, 12, current_value - previous_value)
        ws.cell(row, 14, current_count)
        value_cells = (6, 10, 12)
        count_cells = (8, 14)
    else:
        ws.merge_cells(start_row=row, start_column=6, end_row=row, end_column=8)
        ws.cell(row, 6, current_value)
        ws.merge_cells(start_row=row, start_column=9, end_row=row, end_column=10)
        ws.cell(row, 9, current_count)
        value_cells = (6,)
        count_cells = (9,)

    for col in value_cells:
        ws.cell(row, col).font = Font(name="Arial", size=10, bold=True)
        ws.cell(row, col).number_format = WHOLE_MONEY_FORMAT
        ws.cell(row, col).alignment = Alignment(horizontal="right")
        ws.cell(row, col).border = Border(top=REPORT_LINE, bottom=REPORT_BOTTOM)
    for col in count_cells:
        ws.cell(row, col).font = Font(name="Arial", size=10, bold=True)
        ws.cell(row, col).number_format = COUNT_FORMAT
        ws.cell(row, col).alignment = Alignment(horizontal="right")
        ws.cell(row, col).border = Border(top=REPORT_LINE, bottom=REPORT_BOTTOM)
    ws.row_dimensions[row].height = 19


def _write_company_report_sheet(
    workbook: Workbook,
    result: CompanyResult,
    company_config: dict[str, Any],
    output_type: str,
    current_date: str,
    previous_date: str | None,
) -> None:
    ws = workbook.create_sheet(_safe_sheet_name(result.company))
    ws.sheet_properties.tabColor = "70AD47"
    _write_report_header(ws, output_type, current_date, previous_date)
    _write_report_company_row(ws, result.company, company_config)

    current_map = _metric_map(result.current)
    previous_map = _metric_map(result.previous)
    section_positions = _section_positions(company_config["rules"])
    rules_by_row = {int(rule["target_row"]): rule for rule in company_config["rules"]}

    for section, (first_row, last_row) in section_positions.items():
        section_row = max(9, first_row - 2)
        section_code = SECTION_CODES.get(section, "")
        if section_code:
            ws["B" + str(section_row)] = section_code
        ws.merge_cells(start_row=section_row, start_column=3, end_row=section_row, end_column=8)
        ws.cell(section_row, 3, _section_caption(section))
        ws.cell(section_row, 3).font = Font(name="Arial", size=11, bold=True, underline="single")
        ws.cell(section_row, 3).alignment = Alignment(vertical="center")
        ws.row_dimensions[section_row].height = 22

        section_metrics: list[MetricResult] = []
        for row in range(first_row, last_row + 1):
            if row not in current_map or row not in rules_by_row:
                continue
            metric = current_map[row]
            previous = previous_map.get(row)
            section_metrics.append(metric)
            _write_report_metric_row(
                ws=ws,
                row=row,
                label=metric.label,
                current_value=metric.value,
                current_count=metric.employee_count,
                previous_value=previous.value if previous else None,
                previous_count=previous.employee_count if previous else None,
            )
        if section_metrics:
            _write_report_total_row(ws, last_row + 1, section_metrics, previous_map)

    max_rule_row = max((int(rule["target_row"]) for rule in company_config["rules"]), default=10)
    max_row = max_rule_row + 2

    # Conditional Formatting wie in der Referenz: aktueller Wert, Zuführung
    # und aktuelle Anzahl folgen gemeinsam dem Vorzeichen der Zuführung.
    if previous_date:
        ws.conditional_formatting.add(
            f"J10:N{max_row}",
            FormulaRule(formula=["AND($L10<>\"\",$L10>=0)"], fill=POSITIVE_FILL),
        )
        ws.conditional_formatting.add(
            f"J10:N{max_row}",
            FormulaRule(formula=["AND($L10<>\"\",$L10<0)"], fill=NEGATIVE_FILL),
        )

    widths = {
        "A": 2.5,
        "B": 6,
        "C": 3,
        "D": 24,
        "E": 4,
        "F": 13,
        "G": 3,
        "H": 10,
        "I": 3,
        "J": 13,
        "K": 3,
        "L": 12,
        "M": 3,
        "N": 10,
    }
    for column, width in widths.items():
        ws.column_dimensions[column].width = width
    _configure_print_page(ws, max_row, "N" if previous_date else "J")


# ---------------------------------------------------------------------------
# Summenblatt
# ---------------------------------------------------------------------------

def _write_sum_sheet(
    workbook: Workbook,
    company_results: list[CompanyResult],
    output_type: str,
    current_date: str,
    previous_date: str | None,
) -> None:
    ws = workbook.create_sheet("Summe")
    ws.sheet_properties.tabColor = "548235"
    _write_report_header(ws, output_type, current_date, previous_date)
    ws["B8"] = "Σ"
    ws.merge_cells("C8:J8")
    ws["C8"] = "Summe ausgewählte Gesellschaften"
    ws["C8"].font = Font(name="Arial", size=12, bold=True, underline="single")

    order: list[tuple[str, str]] = []
    current_values: dict[tuple[str, str], list[MetricResult]] = defaultdict(list)
    previous_values: dict[tuple[str, str], list[MetricResult]] = defaultdict(list)
    for company in company_results:
        previous_map = _metric_map(company.previous)
        for metric in company.current:
            key = (metric.section, metric.label)
            if key not in current_values:
                order.append(key)
            current_values[key].append(metric)
            if metric.target_row in previous_map:
                previous_values[key].append(previous_map[metric.target_row])

    row = 12
    current_section = None
    section_metrics: list[MetricResult] = []
    section_start_row = row
    section_number = 0

    def finish_section(total_row: int) -> None:
        nonlocal section_metrics
        if not section_metrics:
            return
        synthetic_previous = {
            metric.target_row: MetricResult(
                company="Summe",
                target_row=metric.target_row,
                cell_reference=metric.cell_reference,
                section=metric.section,
                label=metric.label,
                value=sum(item.value for item in previous_values.get((metric.section, metric.label), [])),
                employee_count=sum(item.employee_count for item in previous_values.get((metric.section, metric.label), [])),
                matched_rows=0,
            )
            for metric in section_metrics
        } if previous_date else {}
        _write_report_total_row(ws, total_row, section_metrics, synthetic_previous)
        section_metrics = []

    for section, label in order:
        if section != current_section:
            if current_section is not None:
                finish_section(row)
                row += 3
            current_section = section
            section_number += 1
            ws["B" + str(row)] = SECTION_CODES.get(section, "")
            ws.merge_cells(start_row=row, start_column=3, end_row=row, end_column=8)
            ws.cell(row, 3, _section_caption(section))
            ws.cell(row, 3).font = Font(name="Arial", size=11, bold=True, underline="single")
            row += 2
            section_start_row = row

        entries = current_values[(section, label)]
        current_value = sum(item.value for item in entries)
        current_count = sum(item.employee_count for item in entries)
        previous_entries = previous_values.get((section, label), [])
        previous_value = sum(item.value for item in previous_entries) if previous_date else None
        previous_count = sum(item.employee_count for item in previous_entries) if previous_date else None
        synthetic = MetricResult(
            company="Summe",
            target_row=row,
            cell_reference=f"J{row}",
            section=section,
            label=label,
            value=current_value,
            employee_count=current_count,
            matched_rows=0,
        )
        section_metrics.append(synthetic)
        _write_report_metric_row(
            ws, row, label, current_value, current_count, previous_value, previous_count
        )
        row += 1

    if current_section is not None:
        finish_section(row)
        row += 1

    widths = {
        "A": 2.5, "B": 6, "C": 3, "D": 24, "E": 4, "F": 13, "G": 3,
        "H": 10, "I": 3, "J": 13, "K": 3, "L": 12, "M": 3, "N": 10,
    }
    for column, width in widths.items():
        ws.column_dimensions[column].width = width
    _configure_print_page(ws, max(12, row), "N" if previous_date else "J")


# ---------------------------------------------------------------------------
# Öffentliche Writer-Funktionen
# ---------------------------------------------------------------------------

def write_workbook(
    destination: Path,
    output_type: str,
    current_dataset: SourceDataset,
    previous_dataset: SourceDataset | None,
    company_results: list[CompanyResult],
    config: RuleConfig,
    generated_at: datetime,
) -> None:
    workbook = Workbook()
    value_column = config.value_columns[output_type]
    current_date = _detect_reporting_date(current_dataset.path, generated_at)
    previous_date = (
        _detect_reporting_date(previous_dataset.path, generated_at)
        if previous_dataset is not None
        else None
    )

    _write_rechenlauf_sheet(
        workbook=workbook,
        output_type=output_type,
        value_column=value_column,
        current_dataset=current_dataset,
        previous_dataset=previous_dataset,
        companies=company_results,
        config=config,
        generated_at=generated_at,
    )

    for result in company_results:
        _write_company_report_sheet(
            workbook=workbook,
            result=result,
            company_config=config.companies[result.company],
            output_type=output_type,
            current_date=current_date,
            previous_date=previous_date,
        )

    _write_sum_sheet(
        workbook=workbook,
        company_results=company_results,
        output_type=output_type,
        current_date=current_date,
        previous_date=previous_date,
    )

    # Beim Öffnen direkt den ersten druckfertigen Bericht statt des Rechenlaufs zeigen.
    if company_results:
        workbook.active = 1

    try:
        workbook.calculation.fullCalcOnLoad = True
        workbook.calculation.forceFullCalc = True
        workbook.calculation.calcMode = "auto"
    except AttributeError:
        pass

    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(".tmp.xlsx")
    workbook.save(temporary)
    temporary.replace(destination)


def write_company_markdown(
    destination: Path,
    result: CompanyResult,
    company_config: dict[str, Any],
    output_type: str,
    value_column: str,
    config: RuleConfig,
    current_dataset: SourceDataset,
    previous_dataset: SourceDataset | None,
) -> None:
    current_map = _metric_map(result.current)
    previous_map = _metric_map(result.previous)
    lines = [
        f"# {result.company} – Regeln und Berechnung",
        "",
        f"- Output-Typ: `{output_type}`",
        f"- Berechnungsspalte: `{value_column}`",
        f"- Aktuelle Quelldatei: `{current_dataset.path}`",
        f"- Erkannte Headerzeile aktuell: `{current_dataset.header_row}`",
        f"- Vorjahresdatei: `{previous_dataset.path if previous_dataset else 'nicht verwendet'}`",
        "",
    ]

    previous_section = None
    for rule in company_config["rules"]:
        row = int(rule["target_row"])
        section = rule["section"]
        if section != previous_section:
            lines.extend(["", f"## {section}", ""])
            previous_section = section
        current = current_map[row]
        previous = previous_map.get(row)
        lines.extend(
            [
                f"### J{row} – {rule['label']}",
                "",
                f"- Filter: `{describe_rule(result.company, rule, config)}`",
                f"- Aktuelles Jahr: Summe `{current.value:.2f}`, Mitarbeiter `{current.employee_count}`, passende Datenzeilen `{current.matched_rows}`",
            ]
        )
        if previous is not None:
            lines.append(
                f"- Vorjahr: Summe `{previous.value:.2f}`, Mitarbeiter `{previous.employee_count}`, passende Datenzeilen `{previous.matched_rows}`"
            )
            lines.append(f"- Differenz: `{current.value - previous.value:.2f}`")
        if rule.get("warning"):
            lines.append(f"- **Regelhinweis:** {rule['warning']}")
        lines.append("")

    destination.write_text("\n".join(lines), encoding="utf-8")


def write_manifest(
    destination: Path,
    output_type: str,
    current_dataset: SourceDataset,
    previous_dataset: SourceDataset | None,
    company_results: list[CompanyResult],
    workbook_path: Path,
    pdf_path: Path | None,
    warnings: list[str],
    generated_at: datetime,
) -> None:
    payload = {
        "generated_at": generated_at.isoformat(),
        "output_type": output_type,
        "current_file": str(current_dataset.path),
        "current_header_row": current_dataset.header_row,
        "current_record_count": len(current_dataset.records),
        "previous_file": str(previous_dataset.path) if previous_dataset else None,
        "previous_header_row": previous_dataset.header_row if previous_dataset else None,
        "previous_record_count": len(previous_dataset.records) if previous_dataset else None,
        "companies": [result.company for result in company_results],
        "workbook": str(workbook_path),
        "pdf": str(pdf_path) if pdf_path else None,
        "warnings": warnings,
        "report_layout": "print_ready_v1",
    }
    destination.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
